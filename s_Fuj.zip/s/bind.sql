col name for a20
col position for 999
col datatype for 999
col datatype_string for a20
col value_string for a70
set lines 130
set pages 5000
SELECT
   b.name,
   b.position,
   b.datatype,
   b.datatype_string,
   b.value_string
FROM
  v$sql_bind_capture b,
  v$sqlarea          a
WHERE
   b.sql_id = '&sqlid'
AND
   b.sql_id = a.sql_id;

SELECT
   b.name,
   b.position,
   b.datatype,
   b.datatype_string,
   b.value_string
FROM
  DBA_HIST_SQLBIND B
WHERE
   b.sql_id = '&sqlid'
AND
   ROWNUM <30
ORDER BY SNAP_ID,POSITION,NAME;