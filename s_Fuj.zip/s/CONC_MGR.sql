select USER_CONCURRENT_QUEUE_NAME,MAX_PROCESSES,running_processes,TARGET_PROCESSES from 
apps.fnd_concurrent_queues_vl where USER_CONCURRENT_QUEUE_NAME like '%FTP%'
/
