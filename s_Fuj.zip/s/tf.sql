rem ********************************************************************
rem * Filename          : tf.sql - Version 1.1
rem * Description       : Report tablespace space
rem * Usage             : start tf.sql
rem ********************************************************************

def aps_prog    = 'tf.sql'
def aps_title   = 'Database Freespace Summary'

set line 132
set pagesize 999
comp sum of nfrags totsiz avasiz on report
break on report

col tsname  format         a25 justify c heading 'Tablespace'
col nfrags  format     999,990 justify c heading 'Free|Frags'
col mxfrag  format 999,999,999,990 justify c heading 'Largest|Frag (KB)'
col totsiz  format 999,999,999,990 justify c heading 'Total|(KB)'
col avasiz  format 999,999,999,990 justify c heading 'Available|(KB)'
col pctusd  format         990 justify c heading 'Pct|Used'
--spool tf.lst

select
  total.tablespace_name                       tsname,
  count(free.bytes)                           nfrags,
  nvl(max(free.bytes)/1024,0)            	mxfrag,
  total.bytes/1024                            totsiz,
  nvl(sum(free.bytes)/1024,0)            	avasiz,
  (1-nvl(sum(free.bytes),0)/total.bytes)*100  pctusd
from
    (select tablespace_name, sum(bytes)       bytes
  from dba_data_files
  group by tablespace_name)  total,
 dba_free_space  free
where
  total.tablespace_name = free.tablespace_name(+)
group by
  total.bytes,
  total.tablespace_name
order by tsname asc
/
--spool off

