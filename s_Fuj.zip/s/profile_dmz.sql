set linesize 132
set pagesize 132
col NAME format A40
col LEVEL_SET format a15
col CONTEXT format a20
col VALUE format A20 wrap
col Server format a10
col resp format a8 wrap
col application format a10  

break on NAME  

select  
  '('||language||')-'||n.user_profile_option_name NAME,  
  decode(v.level_id,  
         10001, 'Site',   
         10002, 'Application',  
         10003, 'Responsibility',  
         10004, 'User',  
         10005, 'Server',   
         10006, 'Organization',  
         10007, 'ServResp',  
                'Undefined') LEVEL_SET,  
  decode(to_char(v.level_id),  
         '10001', '',
         '10002', app.application_short_name,  
         '10003', rsp.responsibility_key,  
         '10004', usr.user_name,   
         '10005', svr.node_name,   
         '10006', org.name,  
         '10007', (select n.node_name  
                   from fnd_nodes n  
                   where n.node_id=level_value2)  
                   ||'/'||  
                   (decode(v.level_value,  
                    -1,'Default',  
                    (select responsibility_key  
                    from fnd_responsibility  
                    where responsibility_id=level_value))),  
                  v.level_id) "CONTEXT",   
  v.profile_option_value VALUE  
from  
  fnd_profile_options p,  
  fnd_profile_option_values v,  
  fnd_profile_options_tl n,  
  fnd_user usr,  
  fnd_application app,  
  fnd_responsibility rsp,  
  fnd_nodes svr,  
  hr_operating_units org  
where  
  p.profile_option_id = v.profile_option_id (+)  
  and p.profile_option_name = n.profile_option_name  
  and ((upper(v.profile_option_value) like '%HTTP%')  
      or  
        p.profile_option_name in     
        ('APPS_WEB_AGENT','APPS_SERVLET_AGENT','APPS_JSP_AGENT','APPS_FRAMEWORK_AGENT',  
         'ICX_FORMS_LAUNCHER','ICX_DISCOVERER_LAUNCHER','ICX_DISCOVERER_VIEWER_LAUNCHER',  
         'HELP_WEB_AGENT','APPS_PORTAL','CZ_UIMGR_URL','ASO_CONFIGURATOR_URL',  
         'QP_PRICING_ENGINE_URL','TCF:HOST','NODE_TRUST_LEVEL','APPL_SERVER_TRUST_LEVEL')  
      or hierarchy_type='SERVER'  
      or hierarchy_type='SERVRESP')  
  and usr.user_id (+) = v.level_value  
  and rsp.application_id (+) = v.level_value_application_id  
  and rsp.responsibility_id (+) = v.level_value  
  and app.application_id (+) = v.level_value  
  and svr.node_id (+) = v.level_value  
  and org.organization_id (+) = v.level_value   
order by name, v.level_id;