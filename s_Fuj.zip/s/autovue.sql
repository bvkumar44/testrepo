col REMOTE_HOST for a20
col REMOTE_PORT for a10
col INSTANCE_NAME for a10
col MASKIP for a30
select * from apps.xcbpc_avhost_data
/