set lines 170
select distinct to_char(begin_interval_time,'mm/dd/yyyy hh24:mi') dt,
dhss.instance_number ins,
plan_hash_value,executions_delta,rows_processed_delta,sql_profile,(elapsed_time_delta/1000000) ela,session_id sesid,
dhss.module,js.event
from dba_hist_sqlstat dhss,
dba_hist_snapshot dhs,
dba_hist_active_sess_history js
where js.sql_id = dhss.sql_id
and dhss.sql_id = '19vsjub2t1k4p'
and dhss.snap_id=dhs.snap_id
and dhss.instance_Number=dhs.instance_number
order by 1 desc