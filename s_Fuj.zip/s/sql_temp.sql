select  a.sql_id,sql_text ss,last_call_et,event
from    gv$sqltext a,gv$session b
where   b.sid = 188 and a.inst_id=b.inst_id
and b.sql_hash_value = a.hash_value
and b.sql_address = a.address
order by a.piece
/
