select tablespace_name, file_name, bytes/1024/1024
from dba_temp_files
order by tablespace_name, file_name
/