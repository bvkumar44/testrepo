set pages 500

col nam for a15 head "TS"
col gb for 9999.99

select tablespace_name nam,
       sum(bytes)/1024/1024/1024 gb
  from dba_free_space
where  tablespace_name like '%UNDO%'
group by tablespace_name
/

