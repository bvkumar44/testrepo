select  tablespace_name,freespace
from
(
select 	tablespace_name,SUM(maxbytes-bytes)/1024/1024 freespace
  from 	dba_data_files
where 	autoextensible='YES'
  AND 	bytes < maxbytes 
group 	by tablespace_name
union
Select tablespace_name,SUM(BYTES)/1024/1024 freespace
  From DBA_FREE_SPACE
 group  by tablespace_name

)
where freespace <400