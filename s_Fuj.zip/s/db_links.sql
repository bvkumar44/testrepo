set pages 250
set lines 250
col db_link for a40
col host for a40
col owner for a14
col username for a13

select name from v$database;

select * from dba_db_links order by created;
