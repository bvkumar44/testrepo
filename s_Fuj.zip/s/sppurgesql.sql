set pages 0 verify off
select distinct 'exec dbms_shared_pool.purge('''||address||','||hash_value||''',''c'');' from v$sql where sql_id='&sql_id';
set pages 1000 verify on 