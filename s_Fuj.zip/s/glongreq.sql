SELECT a.session_id sid,
  b.owner,
  b.object_name,
  b.object_type,
  DECODE(a.locked_mode,0,'none',1,'null (NULL)',2,'row-S (SS)',3,'row-X (SX)',4,'share (S)',5,'S/Row-X (SSX)',6,'exclusive (X)') locked_mode
FROM v$locked_object a,
  dba_objects b
WHERE a.object_id = b.object_id 
/
