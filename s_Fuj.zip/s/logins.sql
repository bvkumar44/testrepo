select 	d.user_name "User Name", b.sid SID,b.serial# "Serial#", c.spid "srvPID", 
	a.SPID "ClPID",to_char(START_TIME,'DD-MON-YY HH:MM:SS') "STime"
from 	fnd_logins a, v$session b, v$process c, fnd_user d 
where 	b.paddr = c.addr and a.pid=c.pid and a.spid = b.process 
and 	d.user_id = a.user_id and (d.user_name = 'USER_NAME' OR 1=1)
/
