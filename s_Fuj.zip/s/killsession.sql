select 'alter system kill session'||''''||sid||','||serial#||''''||';' cmd,
module
--a.sid,serial#,action,module,program,last_call_et,status,event
 from v$session a
where module like '%bom10u03.sql%'
/
