set pages 500
set lines 120
col pnam for a40
col pval for a70
select user_PROFILE_OPTION_NAME pnam,PROFILE_OPTION_value pval
from fnd_profile_options_vl a,fnd_profile_option_values b
where a.application_id = b.application_id
and  a.profile_option_id = b.profile_option_id
and profile_option_value like '%usahsvuam107%';