select  sid,sql_text                      ss,event,last_call_et,b.sql_id
from    gv$sqltext a,gv$session b
where   b.sid = '&sid'
and b.inst_id='&inst'
and b.inst_id = a.inst_id
and b.sql_hash_value = a.hash_value
and b.sql_address = a.address
order by a.piece
/
