set pages 500
set lines 120
col tablespace_name for a15
col file_name for a60
col mbfree for 9999999
break on tablespace_name
select tablespace_name,file_name,bytes,maxbytes,autoextensible, (maxbytes-bytes)/1024/1024 mbfree from dba_data_files
where tablespace_name in 
(
'JAROSDIMDAT',
'JAROSDIMIDX',
'JAROSEULDAT',
'JAROSFACTDAT',
'JAROSFACTIDX',
'JAROSMETADAT',
'JAROSMETAIDX',
'JAROSODSDAT',
'JAROSODSIDX',
'JAROSREP86DAT',
'JAROSREPDAT'
)
and autoextensible = 'YES'
and maxbytes!=bytes
and maxbytes-bytes >50000000
order by tablespace_name,2;


select tablespace_name,max(bytes)/1024/1024 mbfree
from dba_free_space
where tablespace_name in 
(
'JAROSDIMDAT',
'JAROSDIMIDX',
'JAROSEULDAT',
'JAROSFACTDAT',
'JAROSFACTIDX',
'JAROSMETADAT',
'JAROSMETAIDX',
'JAROSODSDAT',
'JAROSODSIDX',
'JAROSREP86DAT'
)
group by tablespace_name
order by tablespace_name;
