select  B.TOTALMB , C_ACTIVE.ACTIVEMB, C_EXPIRED.EXPIREDMB, C_UNEXPIRED.UNEXPIREDMB,
     (B.TOTALMB - C_ACTIVE.ACTIVEMB - C_UNEXPIRED.UNEXPIREDMB) AvailableBeforeGetting1055
from (select tablespace_name, trunc(sum(bytes)/1024/1024) TOTALMB from dba_data_files group by tablespace_name) B,
     (select tablespace_name, trunc(sum(bytes)/1024/1024) ACTIVEMB from dba_undo_extents where STATUS='ACTIVE' group by tablespace_name) C_ACTIVE,
     (select tablespace_name, trunc(sum(bytes)/1024/1024) EXPIREDMB from dba_undo_extents where STATUS='EXPIRED' group by tablespace_name) C_EXPIRED,
     (select tablespace_name, trunc(sum(bytes)/1024/1024) UNEXPIREDMB from dba_undo_extents where STATUS='UNEXPIRED' group by tablespace_name) C_UNEXPIRED
where B.tablespace_name = 'UNDOTBS1'
  and C_ACTIVE.tablespace_name = 'UNDOTBS1'
  and C_EXPIRED.tablespace_name = 'UNDOTBS1'
  and C_UNEXPIRED.tablespace_name = 'UNDOTBS1'
/
