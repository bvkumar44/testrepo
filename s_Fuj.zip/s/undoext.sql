select status,sum(bytes/1024/1024) from dba_undo_extents group by status
/
