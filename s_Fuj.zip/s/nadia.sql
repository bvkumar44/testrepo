explain plan for
SELECT   MAX(poh.segment1) segment1
        ,MAX(poh.revision_num) revision_num
        ,MAX(poh.type_lookup_code) type_lookup_code
        ,MAX(poh.currency_code) currency_code
        ,MAX(poh.vendor_id) vendor_id
        ,MAX(poh.vendor_site_id) vendor_site_id
        ,MAX(poh.agent_id) agent_id_poh
        ,MAX(poh.po_header_id) po_header_id_poh
        ,MAX(pol.line_num) line_num
        ,MAX(pol.item_id) item_id
        ,MAX(pol.unit_price) unit_price
        ,MAX(pol.unit_meas_lookup_code) unit_meas_lookup_code_pol
        ,MAX(pol.po_line_id) po_line_id_pol
        ,MAX(pol.line_type_id) line_type_id
        ,MAX(por.release_num) release_num
        ,MAX(por.revision_num) release_rev_num
        ,MAX(por.closed_code) closed_code
        ,MAX(por.po_release_id) po_release_id_por
        ,MAX(por.release_date) order_date
        ,MAX(por.revised_date) revised_date
        ,MAX(por.edi_processed_flag) edi_processed_flag
        ,MAX(pll.shipment_num) shipment_num
        ,MAX(pll.promised_date) promised_date
        ,MAX(pll.need_by_date) need_by_date
        ,MAX(pll.closed_code) closed_code_pll
        ,MAX(pll.unit_meas_lookup_code) unit_meas_lookup_code_pll
        ,MAX(pll.line_location_id) line_location_id_pll
        ,MAX(pll.price_override) price_override
        ,pod.po_distribution_id po_distribution_id
        ,MAX(pod.quantity_ordered) quantity_ordered
        ,MAX(pod.quantity_cancelled) quantity_cancelled
        ,MAX(pod.quantity_delivered) quantity_delivered
        ,MAX(pod.code_combination_id) code_combination_id
        ,MAX(pod.destination_organization_id) destination_organization_id
        ,MAX(pod.set_of_books_id) set_of_books_id
        ,MAX(pod.amount_billed) amount_billed
        ,MAX(pod.rate) rate
        ,'BLANKET RELEASE' rec_type
FROM     po_headers_all poh, po_lines_all pol, po_releases_all por, po_line_locations_all pll, po_distributions_all pod, rcv_transactions rts, ap_invoice_distributions_all aid
WHERE    pll.po_release_id = por.po_release_id
AND      pod.po_release_id = por.po_release_id
AND      pod.line_location_id = pll.line_location_id
AND      rts.po_release_id(+) = pod.po_release_id
AND      rts.po_line_location_id(+) = pod.line_location_id
AND      rts.po_distribution_id(+) = pod.po_distribution_id
AND      aid.po_distribution_id(+) = pod.po_distribution_id
AND      poh.po_header_id = por.po_header_id
AND      pol.po_header_id = poh.po_header_id
AND      pol.po_line_id = pll.po_line_id
AND      rts.parent_transaction_id(+) = -1
AND      pol.line_type_id IN(1, 3)
AND      pod.destination_organization_id = :b3
AND      (   (    TRUNC(rts.creation_date) >= :b2
              AND TRUNC(rts.creation_date) <= :b1)
          OR (    TRUNC(aid.creation_date) >= :b2
              AND TRUNC(aid.creation_date) <= :b1)
          OR (    TRUNC(pod.last_update_date) >= :b2
              AND TRUNC(pod.last_update_date) <= :b1
              AND TRUNC(pod.creation_date) >= :b2
              AND TRUNC(pod.creation_date) <= :b1))
GROUP BY por.po_release_id, pll.line_location_id, pod.po_distribution_id
UNION
SELECT   MAX(poh.segment1) segment1
        ,MAX(poh.revision_num) revision_num
        ,MAX(poh.type_lookup_code) type_lookup_code
        ,MAX(poh.currency_code) currency_code
        ,MAX(poh.vendor_id) vendor_id
        ,MAX(poh.vendor_site_id) vendor_site_id
        ,MAX(poh.agent_id) agent_id_poh
        ,MAX(poh.po_header_id) po_header_id_poh
        ,MAX(pol.line_num) line_num
        ,MAX(pol.item_id) item_id
        ,MAX(pol.unit_price) unit_price
        ,MAX(pol.unit_meas_lookup_code) unit_meas_lookup_code_pol
        ,MAX(pol.po_line_id) po_line_id_pol
        ,MAX(pol.line_type_id) line_type_id
        ,0 release_num
        ,0 release_rev_num
        ,MAX(poh.closed_code) closed_code
        ,0 po_release_id_por
        ,MAX(poh.creation_date) order_date
        ,MAX(poh.revised_date) revised_date
        ,MAX(poh.edi_processed_flag) edi_processed_flag
        ,0 shipment_num
        ,MAX(pll.promised_date) promised_date
        ,MAX(pll.need_by_date) need_by_date
        ,MAX(pll.closed_code) closed_code_pll
        ,MAX(pll.unit_meas_lookup_code) unit_meas_lookup_code_pll
        ,MAX(pll.line_location_id) line_location_id_pll
        ,MAX(pll.price_override) price_override
        ,pod.po_distribution_id po_distribution_id
        ,MAX(pod.quantity_ordered) quantity_ordered
        ,MAX(pod.quantity_cancelled) quantity_cancelled
        ,MAX(pod.quantity_delivered) quantity_delivered
        ,MAX(pod.code_combination_id) code_combination_id
        ,MAX(pod.destination_organization_id) destination_organization_id
        ,MAX(pod.set_of_books_id) set_of_books_id
        ,MAX(pod.amount_billed) amount_billed
        ,MAX(pod.rate) rate
        ,'STANDARD' rec_type
FROM     po_headers_all poh, po_lines_all pol, po_line_locations_all pll, po_distributions_all pod, rcv_transactions rts, ap_invoice_distributions_all aid
WHERE    pol.po_header_id = poh.po_header_id
AND      pll.po_header_id = poh.po_header_id
AND      pll.po_line_id = pol.po_line_id
AND      pod.po_header_id = poh.po_header_id
AND      pod.po_line_id = pol.po_line_id
AND      pod.line_location_id = pll.line_location_id
AND      rts.po_header_id(+) = pod.po_header_id
AND      rts.po_line_id(+) = pod.po_line_id
AND      rts.po_line_location_id(+) = pod.line_location_id
AND      rts.po_distribution_id(+) = pod.po_distribution_id
AND      aid.po_distribution_id(+) = pod.po_distribution_id
AND      rts.parent_transaction_id(+) = -1
AND      poh.type_lookup_code = 'STANDARD'
AND      pol.line_type_id IN(1, 3)
AND      pod.destination_organization_id = :b3
AND      (   (    TRUNC(rts.creation_date) >= :b2
              AND TRUNC(rts.creation_date) <= :b1)
          OR (    TRUNC(aid.creation_date) >= :b2
              AND TRUNC(aid.creation_date) <= :b1)
          OR (    TRUNC(pod.last_update_date) >= :b2
              AND TRUNC(pod.last_update_date) <= :b1
              AND TRUNC(pod.creation_date) >= :b2
              AND TRUNC(pod.creation_date) <= :b1))
GROUP BY poh.po_header_id, pol.po_line_id, pll.line_location_id, pod.po_distribution_id;

set lines 1000
set pages 0
select * from table(dbms_xplan.display());