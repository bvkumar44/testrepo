select table_name,avg_row_len,num_rows, (avg_row_len*num_rows)/1024/1024 mb
 from dba_tables
where table_name in
(
'PO_DISTRIBUTIONS_ALL',
'PO_HEADERS_ALL',
'PO_LINES_ALL',
'PO_LINE_LOCATIONS_ALL',
'PO_RELEASES_ALL',
'RCV_TRANSACTIONS',
'AP_INVOICE_DISTRIBUTIONS_ALL'
)
order by 1
/

select segment_name,bytes/1024/1024 mb from dba_segments where segment_name in
(
'PO_DISTRIBUTIONS_ALL',
'PO_HEADERS_ALL',
'PO_LINES_ALL',
'PO_LINE_LOCATIONS_ALL',
'PO_RELEASES_ALL',
'RCV_TRANSACTIONS',
'AP_INVOICE_DISTRIBUTIONS_ALL'
)
order by 1
/