select to_char(sysdate,'dd/mm hh24:mi') dt from dual;
select count(1) from v$session where type!='BACKGROUND';
select sid,serial#,action,module,last_call_et,status,event
 from v$session
where type!='BACKGROUND'
and status='ACTIVE'
and event not like 'pipe%'
and event not like 'Streams%';
@longreq
col rundatetime for a20
col formsusers for 9999
col selfservusers for 9999
col jdbcthinkclient for 9999
SELECT TO_CHAR (SYSDATE, 'DD-MON-YY HH24:MI') rundatetime,
       (SELECT COUNT (*)
          FROM v$session
         WHERE program LIKE 'frmweb%')
          formsusers,
       (SELECT COUNT (*)
          FROM v$session
         WHERE     program LIKE 'JDBC Thin Client%'
               AND module != 'JDBC Thin Client'
               AND client_identifier NOT IN
                      ('GUEST', 'ANONYMOUS', 'SYSADMIN'))
          selfservusers,
       (SELECT COUNT (*)
          FROM v$session
         WHERE program = 'JDBC Thin Client')
          jdbcthinclient
  FROM DUAL;

