set pages 5000
set lines 170
SELECT * FROM TABLE(dbms_xplan.display_awr('&sqlid'));