select *
--application_id,profile_option_id,level_id,level_value 
from fnd_profile_option_values 
where application_id=200
and profile_option_id=1001096
and level_id=10003
and level_value=50394
--group by application_id,profile_option_id,level_id,level_value having count(*) >1
/
