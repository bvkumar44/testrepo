set lines 150
col begin_interval_time for a25
SELECT snap.snap_id,
  begin_interval_time,
  snap.instance_number inst,
  plan_hash_value,
  ROUND(elapsed_time_delta/1000000,2) "Elapsed Time",
  executions_delta,
  rows_processed_delta,
  ROUND(elapsed_time_delta/1000000/DECODE(executions_delta,0,1,executions_delta),3)"Ela/Exec",
  ROUND(disk_reads_delta/DECODE(executions_delta,0,1,executions_delta),3)"Reads/Exec",
  ROUND(buffer_gets_delta/DECODE(executions_delta,0,1,executions_delta),3)"Gets/Exec"
FROM dba_hist_snapshot snap,
  dba_hist_sqlstat stat
WHERE snap.snap_id       = stat.snap_id
AND snap.instance_number = stat.instance_number
AND sql_id               = '&sql_id'
ORDER BY 2 DESC
/