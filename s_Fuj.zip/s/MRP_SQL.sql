explain plan for 
select 	mr.reservation_id ,demands.line_id ,
	demands.inventory_item_id ,demands.ship_from_org_id ,
	TO_CHAR(demands.schedule_ship_date,'J') ,to_char(null ) ,
	nvl(DECODE(sub.netting_type,2,0,(mr.primary_reservation_quantity-NVL(INV_DECIMALS_PUB.get_primary_quantity(demands.ship_from_org_id,demands.inventory_item_id,demands.order_quantity_uom,demands.shipped_quantity),0))),0) ,
	nvl(DECODE(sub.netting_type,2,(mr.primary_reservation_quantity-NVL(INV_DECIMALS_PUB.get_primary_quantity(demands.ship_from_org_id,demands.inventory_item_id,demands.order_quantity_uom,demands.shipped_quantity),0)),0),0) ,2 ,
	INV_SALESORDER.get_salesorder_for_oeheader(demands.header_id) ,to_char(null ) ,NVL(demands.project_id,(-23453)) ,
	NVL(demands.task_id,(-23453)) ,NVL(pa.planning_group,'-23453')  
from 	pjm_project_parameters pa ,
	mrp_sub_inventories sub ,
	oe_order_lines_all demands ,
	mtl_reservations mr ,
	mrp_system_items sys ,
	mrp_plan_organizations_v mpo 
where 	((((((((((((((((pa.project_id(+)=demands.project_id and 
	pa.organization_id(+)=demands.ship_from_org_id) and 
	(exists 
	(select null   
	   from mrp_schedule_dates dates ,
		mrp_plan_schedules_v mps 
	  where (((((((((dates.schedule_level=2 and 
		dates.schedule_origination_type=3) and 
		dates.reservation_id=demands.line_id) and 
		dates.organization_id=demands.ship_from_org_id) and 
		dates.schedule_designator=mps.input_designator_name) and 
		dates.organization_id=mps.input_organization_id) and	
		mps.organization_id=:b0) and mps.compile_designator=:b1) and 
		mps.input_designator_type in (1,2)) and 
		dates.inventory_item_id=demands.inventory_item_id)) or 
		(((NVL(demands.demand_class_code,:b2)<>:b3 and mr.reservation_id is null ) and :b3 is  not null ) and 
		MRP_OE.AVAILABLE_TO_MRP(demands.line_id)=1))) and sub.sub_inventory_code(+)=to_char(null )) and 
		sub.organization_id(+)=demands.ship_from_org_id) and 
		sub.compile_designator(+)=:b1) and 
		demands.line_id=mr.demand_source_line_id) and 
		mr.supply_source_type_id=13) and demands.visible_demand_flag='Y') and 
		INV_DECIMALS_PUB.get_primary_quantity(demands.ship_from_org_id,demands.inventory_item_id,demands.order_quantity_uom,demands.ordered_quantity)>NVL(INV_DECIMALS_PUB.get_primary_quantity(demands.ship_from_org_id,demands.inventory_item_id,demands.order_quantity_uom,demands.shipped_quantity),0)) and 
		demands.ship_from_org_id=sys.organization_id) and 
		demands.inventory_item_id=sys.inventory_item_id) and 
		sys.compile_designator=mpo.compile_designator) and 
		sys.organization_id=mpo.planned_organization) and 
		mpo.net_reservations=1) and mpo.organization_id=:b0) and 
		mpo.compile_designator=:b1) 
order by demands.ship_from_org_id,demands.inventory_item_id;

set linesize 1000
set pages 1000
select * from table(dbms_xplan.display());