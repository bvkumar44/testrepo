select tablespace_name,sum(bytes)/1024/1024/1024 gb from dba_free_space group by tablespace_name having sum(bytes)/1024/1024/1024<2
/
