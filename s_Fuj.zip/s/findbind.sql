col name FOR a20 
col position FOR 999 
col datatype FOR 999 
col datatype_string FOR a20 
col value_string FOR a70
SET lines 200
SET pages 5000
SELECT b.name,
  b.position,
  b.datatype,
  b.datatype_string,
  b.value_string
FROM v$sql_bind_capture b,
  v$sqlarea a
WHERE b.sql_id = '&sqlid'
AND b.sql_id   = a.sql_id;
SELECT b.name,
  b.position,
  b.datatype,
  b.datatype_string,
  b.value_string
FROM DBA_HIST_SQLBIND B
WHERE b.sql_id = '&sqlid'
AND ROWNUM     <30
ORDER BY SNAP_ID,
  POSITION,
  NAME;