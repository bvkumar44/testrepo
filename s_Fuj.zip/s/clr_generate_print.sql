DECLARE 
V_LABEL_ID       NUMBER;
V_LABEL_NAME     VARCHAR2(255);
V_PRINTER        VARCHAR2(255);

BEGIN
V_LABEL_NAME := 'ARM_EU_FLW_CUSTOMER';
V_PRINTER    := 'ams_intpm4_001'; 
          v_label_id := Bpl.define_label(v_label_name);
          Bpl.bar_code_print(v_printer,v_label_id,1,1);
COMMIT;
END;
/
