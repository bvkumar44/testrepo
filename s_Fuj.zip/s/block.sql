set head on
col host_name for a15
col SESS for a12
col id1 for 999999999
col id2 for 999999999
set lines 132
prompt Instance Details
prompt ================
select INSTANCE_NUMBER, INSTANCE_NAME, HOST_NAME, VERSION, INSTANCE_ROLE from gv$instance order by INSTANCE_NUMBER
/
prompt Blocking Session
prompt ================
select * from gv$lock where (ID1,ID2,TYPE) in (select ID1,ID2,TYPE from gv$lock where request>0)
/
prompt Holding Session
prompt ===============
column sess format a13
column inst_id format 99
SELECT substr(DECODE(request,0,'Holder: ','Waiter: ')||sid,1,12) sess, inst_id,
id1, id2, lmode, request, type, block
FROM GV$LOCK
WHERE (id1, id2, type) IN
(SELECT id1, id2, type FROM GV$LOCK WHERE request>0)
ORDER BY id1, request
/
prompt Holding Session(EM Query)
prompt ========================
SELECT blocking_sid, SUM(num_blocked) num_blocked
FROM (SELECT id1, id2,
MAX(DECODE(block, 1, sid, 0)) blocking_sid,
SUM(DECODE(request, 0, 0, 1)) num_blocked
FROM v$lock
WHERE block = 1
OR request > 0
GROUP BY id1, id2)
GROUP BY blocking_sid
/
