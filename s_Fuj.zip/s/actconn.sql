select machine,count(*) from gv$session where type!='BACKGROUND' and status='ACTIVE' group by machine order by 2 desc
/
