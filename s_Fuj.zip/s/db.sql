select name,open_mode,log_mode,created from v$database
/