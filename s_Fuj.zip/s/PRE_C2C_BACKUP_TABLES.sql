SET ECHO ON
SPOOL d:\pre_c2c_table_bkp.log
---------------------- For PCM -------------------------------

SELECT COUNT (*) FROM apps.pa_transaction_interface_all
/

CREATE TABLE sape_it.pre_pa_transact_interface_all
AS
   SELECT * FROM apps.pa_transaction_interface_all
/

SELECT COUNT (*) FROM sape_it.pre_pa_transact_interface_all
/

SELECT COUNT (*) FROM apps.pa_expenditure_groups_all
/

CREATE TABLE sape_it.pre_pa_expenditure_groups_all
AS
   SELECT * FROM apps.pa_expenditure_groups_all
/

SELECT COUNT (*) FROM sape_it.pre_pa_expenditure_groups_all
/

SELECT COUNT (*) FROM apps.pa_expenditure_batches_all
/

CREATE TABLE sape_it.pre_pa_expenditur_batches_all
AS
   SELECT * FROM apps.pa_expenditure_batches_all
/

SELECT COUNT (*) FROM sape_it.pre_pa_expenditur_batches_all
/

SELECT COUNT (*) FROM apps.pa_expenditure_items_all
/

CREATE TABLE sape_it.pre_pa_expenditure_items_all
AS
   SELECT * FROM apps.pa_expenditure_items_all
/

SELECT COUNT (*) FROM sape_it.pre_pa_expenditure_items_all
/

SELECT COUNT (*) FROM apps.pa_draft_invoices_all
/

CREATE TABLE sape_it.pre_pa_draft_invoices_all
AS
   SELECT * FROM apps.pa_draft_invoices_all
/

SELECT COUNT (*) FROM sape_it.pre_pa_draft_invoices_all
/

SELECT COUNT (*) FROM apps.pa_events
/

CREATE TABLE sape_it.pre_pa_events
AS
   SELECT * FROM apps.pa_events
/

SELECT COUNT (*) FROM sape_it.pre_pa_events
/

SELECT COUNT (*) FROM apps.pa_draft_invoice_items
/

CREATE TABLE sape_it.pre_pa_draft_invoice_items
AS
   SELECT * FROM apps.pa_draft_invoice_items
/

SELECT COUNT (*) FROM sape_it.pre_pa_draft_invoice_items
/

SELECT COUNT (*) FROM apps.PA_CUST_REV_DIST_LINES_ALL
/

CREATE TABLE sape_it.prePA_CUST_REV_DIST_LINES_ALL
AS
   SELECT * FROM apps.PA_CUST_REV_DIST_LINES_ALL
/

SELECT COUNT (*) FROM sape_it.prePA_CUST_REV_DIST_LINES_ALL
/

SELECT COUNT (*) FROM apps.PA_COST_DISTRIBUTION_LINES_ALL
/

CREATE TABLE sape_it.pre_PA_COST_DISTRIB_LINES_ALL
AS
   SELECT * FROM apps.PA_COST_DISTRIBUTION_LINES_ALL
/

SELECT COUNT (*) FROM sape_it.pre_PA_COST_DISTRIB_LINES_ALL
/

SELECT COUNT (*) FROM apps.pa_draft_revenues_all
/

CREATE TABLE sape_it.pre_pa_draft_revenues_all
AS
   SELECT * FROM apps.pa_draft_revenues_all
/

SELECT COUNT (*) FROM sape_it.pre_pa_draft_revenues_all
/

SELECT COUNT (*) FROM apps.pa_agreements_all
/

CREATE TABLE sape_it.pre_pa_agreements_all
AS
   SELECT * FROM apps.pa_agreements_all
/

SELECT COUNT (*) FROM sape_it.pre_pa_agreements_all
/

SELECT COUNT (*) FROM apps.pa_project_fundings
/

CREATE TABLE sape_it.pre_pa_project_fundings
AS
   SELECT * FROM apps.pa_project_fundings
/

SELECT COUNT (*) FROM sape_it.pre_pa_project_fundings
/

SELECT COUNT (*) FROM apps.pa_tasks
/

CREATE TABLE sape_it.pre_pa_tasks
AS
   SELECT * FROM apps.pa_tasks
/

SELECT COUNT (*) FROM sape_it.pre_pa_tasks
/

SELECT COUNT (*) FROM apps.pa_cust_event_rdl_all 
/

CREATE TABLE sape_it.pre_pa_cust_event_rdl_all 
AS
   SELECT * FROM apps.pa_cust_event_rdl_all 
/

SELECT COUNT (*) FROM sape_it.pre_pa_cust_event_rdl_all 
/

select * from eai_dbo.EAI_PROJECT_R
where end_date>='16-DEC-2012'
/

CREATE TABLE sape_it.post_EAI_PROJECT_R
AS
   SELECT * FROM  eai_dbo.EAI_PROJECT_R
   where end_date>='16-DEC-2012'
/

SELECT COUNT (*) FROM sape_it.post_EAI_PROJECT_R
where end_date>='16-DEC-2012'
/
---------------------------------------- For Receivables--------------------------

SELECT COUNT (*) FROM apps.ra_interface_lines_all
/

CREATE TABLE sape_it.pre_ra_interface_lines_all
AS
   SELECT * FROM apps.ra_interface_lines_all
/

SELECT COUNT (*) FROM sape_it.pre_ra_interface_lines_all
/

SELECT COUNT (*) FROM apps.ra_customer_trx_all
/

CREATE TABLE sape_it.pre_ra_customer_trx_all
AS
   SELECT * FROM apps.ra_customer_trx_all
/

SELECT COUNT (*) FROM sape_it.pre_ra_customer_trx_all
/

SELECT COUNT (*) FROM apps.ra_customer_trx_lines_all
/

CREATE TABLE sape_it.pre_ra_customer_trx_lines_all
AS
   SELECT * FROM apps.ra_customer_trx_lines_all
/

SELECT COUNT (*) FROM sape_it.pre_ra_customer_trx_lines_all
/

SELECT COUNT (*) FROM apps.AR_CASH_RECEIPTS_ALL
/

CREATE TABLE sape_it.pre_AR_CASH_RECEIPTS_ALL
AS
   SELECT * FROM apps.AR_CASH_RECEIPTS_ALL
/

SELECT COUNT (*) FROM sape_it.pre_AR_CASH_RECEIPTS_ALL
/

SELECT COUNT (*) FROM apps.RA_CUST_TRX_LINE_GL_DIST_ALL
/

CREATE TABLE sape_it.preRA_CUST_TRX_LINEGLDIST_ALL
AS
   SELECT * FROM apps.RA_CUST_TRX_LINE_GL_DIST_ALL
/

SELECT COUNT (*) FROM sape_it.preRA_CUST_TRX_LINEGLDIST_ALL
/

SELECT COUNT (*) FROM apps.AR_PAYMENT_SCHEDULES_ALL
/

CREATE TABLE sape_it.pre_AR_PAYMENT_SCHEDULES_ALL
AS
   SELECT * FROM apps.AR_PAYMENT_SCHEDULES_ALL
/

SELECT COUNT (*) FROM sape_it.pre_AR_PAYMENT_SCHEDULES_ALL
/

---------------------- For PRM --------------------------------

SELECT COUNT (*) FROM apps.pa_schedules
/

CREATE TABLE sape_it.pre_pa_schedules
AS
   SELECT * FROM apps.pa_schedules
/

SELECT COUNT (*) FROM sape_it.pre_pa_schedules
/

SELECT COUNT (*) FROM apps.pa_resources_denorm
/

CREATE TABLE sape_it.pre_pa_resources_denorm
AS
   SELECT * FROM apps.pa_resources_denorm
/

SELECT COUNT (*) FROM apps.pa_candidate_reviews
/

CREATE TABLE sape_it.pre_pa_candidate_reviews
AS
   SELECT * FROM apps.pa_candidate_reviews
/

SELECT COUNT (*) FROM sape_it.pre_pa_candidate_reviews
/

SELECT COUNT (*) FROM apps.pa_candidates
/

CREATE TABLE sape_it.pre_pa_candidates
AS
   SELECT * FROM apps.pa_candidates
/

SELECT COUNT (*) FROM sape_it.pre_pa_candidates
/

SELECT COUNT (*) FROM apps.pa_resources
/

CREATE TABLE sape_it.pre_pa_resources
AS
   SELECT * FROM apps.pa_resources
/

SELECT COUNT (*) FROM sape_it.pre_pa_resources
/

SELECT COUNT (*)
  FROM apps.pa_forecast_items
 WHERE last_update_date >= '13-DEC-2012'
/

CREATE TABLE sape_it.pre_pa_forecast_items
AS
   SELECT *
     FROM apps.pa_forecast_items
    WHERE last_update_date >= '13-DEC-2012'
/

SELECT COUNT (*) FROM sape_it.pre_pa_forecast_items
/

----------------------- For Workflow -----------------------------

SELECT COUNT (*) FROM apps.wf_notifications
/

CREATE TABLE sape_it.pre_wf_notifications
AS
   SELECT * FROM apps.wf_notifications
/

SELECT COUNT (*) FROM sape_it.pre_wf_notifications
/

SELECT COUNT (*)
  FROM apps.wf_items
 WHERE end_date >= '13-DEC-2012'
/

CREATE TABLE sape_it.pre_wf_items
AS
   SELECT *
     FROM apps.wf_items
    WHERE end_date >= '13-DEC-2012'
/

SELECT COUNT (*) FROM sape_it.pre_wf_items
/

--------------------------- GL PRE --------------------------------

SELECT COUNT (*) FROM apps.gl_sets_of_books
/

CREATE TABLE sape_it.pre_gl_sets_of_books
AS
   SELECT * FROM apps.gl_sets_of_books
/

SELECT COUNT (*) FROM sape_it.pre_gl_sets_of_books
/

-------------------------- TCA PRE --------------------------------

SELECT COUNT (*) FROM ar.ra_customers
/

CREATE TABLE sape_it.pre_ra_customers
AS
   SELECT * FROM ar.ra_customers
/

SELECT COUNT (*) FROM sape_it.pre_ra_customers
/

--------------------------FND, DBA Tables ----------------------

SELECT COUNT (*) FROM apps.PA_LOOKUPS
/

CREATE TABLE sape_it.pre_PA_LOOKUPS
AS
   SELECT * FROM apps.PA_LOOKUPS
/

SELECT COUNT (*) FROM sape_it.pre_PA_LOOKUPS
/

SELECT COUNT (*) FROM apps.AR_LOOKUPS
/

CREATE TABLE sape_it.pre_AR_LOOKUPS
AS
   SELECT * FROM apps.AR_LOOKUPS
/

SELECT COUNT (*) FROM sape_it.pre_AR_LOOKUPS
/

SELECT COUNT (*) FROM apps.FND_LOOKUPS
/

CREATE TABLE sape_it.pre_FND_LOOKUPS
AS
   SELECT * FROM apps.FND_LOOKUPS
/

SELECT COUNT (*) FROM sape_it.pre_FND_LOOKUPS
/

SELECT COUNT (*) FROM apps.FND_USER
/

CREATE TABLE sape_it.pre_FND_USER
AS
   SELECT * FROM apps.FND_USER
/

SELECT COUNT (*) FROM sape_it.pre_FND_USER
/

SELECT COUNT (*) FROM apps.FND_RESPONSIBILITY
/

CREATE TABLE sape_it.pre_FND_RESPONSIBILITY
AS
   SELECT * FROM apps.FND_RESPONSIBILITY
/

SELECT COUNT (*) FROM sape_it.pre_FND_RESPONSIBILITY
/

SELECT COUNT (*) FROM apps.FND_PROFILE_OPTION_VALUES
/

CREATE TABLE sape_it.pre_FND_PROFILE_OPTION_VALUES
AS
   SELECT * FROM apps.FND_PROFILE_OPTION_VALUES
/

SELECT COUNT (*) FROM sape_it.pre_FND_PROFILE_OPTION_VALUES
/

SELECT COUNT (*) FROM apps.FND_PROFILE_OPTIONS
/

CREATE TABLE sape_it.pre_FND_PROFILE_OPTIONS
AS
   SELECT * FROM apps.FND_PROFILE_OPTIONS
/

SELECT COUNT (*) FROM sape_it.pre_FND_PROFILE_OPTIONS
/

SELECT COUNT (*) FROM apps.FND_MENUS
/

CREATE TABLE sape_it.pre_FND_MENUS
AS
   SELECT * FROM apps.FND_MENUS
/

SELECT COUNT (*) FROM sape_it.pre_FND_MENUS
/

SELECT COUNT (*) FROM apps.FND_FORM_FUNCTIONS
/

CREATE TABLE sape_it.pre_FND_FORM_FUNCTIONS
AS
   SELECT * FROM apps.FND_FORM_FUNCTIONS
/

SELECT COUNT (*) FROM sape_it.pre_FND_FORM_FUNCTIONS
/

SELECT COUNT (*) FROM sys.DBA_TABLES
/

CREATE TABLE sape_it.pre_DBA_TABLES
AS
   SELECT * FROM sys.DBA_TABLES
/

SELECT COUNT (*) FROM sape_it.pre_DBA_TABLES
/

SELECT COUNT (*) FROM sys.DBA_SEGMENTS
/

CREATE TABLE sape_it.pre_DBA_SEGMENTS
AS
   SELECT * FROM sys.DBA_SEGMENTS
/

SELECT COUNT (*) FROM sape_it.pre_DBA_SEGMENTS
/

SELECT COUNT (*) FROM sys.DBA_OBJECTS
/

CREATE TABLE sape_it.pre_DBA_OBJECTS
AS
   SELECT * FROM sys.DBA_OBJECTS
/

SELECT COUNT (*) FROM sape_it.pre_DBA_OBJECTS
/

SELECT COUNT (*) FROM sys.dba_sequences
/

CREATE TABLE sape_it.pre_dba_sequences
AS
   SELECT * FROM sys.dba_sequences
/

SELECT COUNT (*) FROM sape_it.pre_dba_sequences
/

--------------------------Project Audit --------------------------

SELECT COUNT (*) FROM apps.pa_projects_all_ac1
/

CREATE TABLE sape_it.pre_pa_projects_all_ac1
AS
   SELECT * FROM apps.pa_projects_all_ac1
/

SELECT COUNT (*) FROM sape_it.pre_pa_projects_all_ac1
/

SELECT COUNT (*) FROM apps.PA_AGREEMENTS_ALL_AC1
/

CREATE TABLE sape_it.pre_PA_AGREEMENTS_ALL_AC1
AS
   SELECT * FROM apps.PA_AGREEMENTS_ALL_AC1
/

SELECT COUNT (*) FROM sape_it.pre_PA_AGREEMENTS_ALL_AC1
/

SELECT COUNT (*) FROM apps.PA_CONTROL_ITEMS_AC1
/

CREATE TABLE sape_it.pre_PA_CONTROL_ITEMS_AC1
AS
   SELECT * FROM apps.PA_CONTROL_ITEMS_AC1
/

SELECT COUNT (*) FROM sape_it.pre_PA_CONTROL_ITEMS_AC1
/

SELECT COUNT (*) FROM apps.PA_PROJECTS_ERP_EXT_B_AC1
/

CREATE TABLE sape_it.pre_PA_PROJECTS_ERP_EXT_B_AC1
AS
   SELECT * FROM apps.PA_PROJECTS_ERP_EXT_B_AC1
/

SELECT COUNT (*) FROM sape_it.pre_PA_PROJECTS_ERP_EXT_B_AC1
/

SELECT COUNT (*) FROM apps.PA_PROJECT_ASSIGNMENTS_AC1
/

CREATE TABLE sape_it.prePA_PROJECT_ASSIGNMENTS_AC1
AS
   SELECT * FROM apps.PA_PROJECT_ASSIGNMENTS_AC1
/

SELECT COUNT (*) FROM sape_it.prePA_PROJECT_ASSIGNMENTS_AC1
/

SELECT COUNT (*) FROM apps.PA_PROJECT_FUNDINGS_AC1
/

CREATE TABLE sape_it.pre_PA_PROJECT_FUNDINGS_AC1
AS
   SELECT * FROM apps.PA_PROJECT_FUNDINGS_AC1
/

SELECT COUNT (*) FROM sape_it.pre_PA_PROJECT_FUNDINGS_AC1
/

SELECT COUNT (*) FROM apps.PA_TASKS_AC1
/

CREATE TABLE sape_it.pre_PA_TASKS_AC1
AS
   SELECT * FROM apps.PA_TASKS_AC1
/

SELECT COUNT (*) FROM sape_it.pre_PA_TASKS_AC1
/

SELECT COUNT (*) FROM apps.SAPE_MILESTONE_SCH_LINES_AC1
/

CREATE TABLE sape_it.preSAPE_MILESTO_SCH_LINES_AC1
AS
   SELECT * FROM apps.SAPE_MILESTONE_SCH_LINES_AC1
/

SELECT COUNT (*) FROM sape_it.preSAPE_MILESTO_SCH_LINES_AC1
/

SELECT COUNT (*) FROM apps.SAPE_PA_LABOR_RATE_OVERR_AC1
/

CREATE TABLE sape_it.pre_SAPE_PA_LAB_RATE_OVER_AC1
AS
   SELECT * FROM apps.SAPE_PA_LABOR_RATE_OVERR_AC1
/

SELECT COUNT (*) FROM sape_it.pre_SAPE_PA_LAB_RATE_OVER_AC1
/

SELECT COUNT (*) FROM apps.SAPE_PA_LABOR_RATES_AC1
/

CREATE TABLE sape_it.pre_SAPE_PA_LABOR_RATES_AC1
AS
   SELECT * FROM apps.SAPE_PA_LABOR_RATES_AC1
/

SELECT COUNT (*) FROM sape_it.pre_SAPE_PA_LABOR_RATES_AC1
/

SPOOL OFF
SET ECHO OFF