SELECT TOPSQL.SQL_ID,
               TOPSQL.MODULE,
               TOPSQL.CPU_TIME,
               TOPSQL.IO_TIME,
               TOPSQL.ELAPSED_TIME,
               TOPSQL.EXEC_COUNT,
               TOPSQL.ELAPSED_TIME_PER_EXEC
          FROM (  SELECT STAT.SQL_ID,
                         STAT.MODULE,
                         ROUND (SUM (STAT.CPU_TIME_DELTA / 1000000), 0) CPU_TIME,
                         ROUND (SUM (STAT.IOWAIT_DELTA / 1000000), 0) IO_TIME,
                         ROUND (SUM (STAT.ELAPSED_TIME_DELTA / 1000000), 0)
                            ELAPSED_TIME,
                         ROUND (SUM (STAT.EXECUTIONS_DELTA), 0) EXEC_COUNT,
                         ROUND (
                            (SUM (STAT.ELAPSED_TIME_DELTA)
                             / DECODE(SUM(STAT.EXECUTIONS_DELTA),0,1,SUM(STAT.EXECUTIONS_DELTA)))
                            / 1000000,
                            0)
                            ELAPSED_TIME_PER_EXEC,
                         RANK ()
                         OVER (
                            ORDER BY
                               ROUND (SUM (STAT.ELAPSED_TIME_DELTA / 1000000), 0) DESC)
                            AS TOPORDER
                    FROM DBA_HIST_SQLSTAT STAT,
                         DBA_HIST_SNAPSHOT SNAP,
                         DBA_HIST_SQLTEXT TEXT
                   WHERE     STAT.SNAP_ID = SNAP.SNAP_ID
                         AND STAT.SQL_ID = TEXT.SQL_ID
						 AND STAT.MODULE != 'DBMS_SCHEDULER'
                          AND TEXT.COMMAND_TYPE IN (2, 3, 6, 7)
                         AND STAT.SQL_ID NOT IN
                                ('c92uxxwhs2sbz','5xcqgzcxb958t',
						'29jpyrwdu3ztp','gmhkpn4q0tfsb',
	'gasf6wsrkfgdn','587a3abysrfbj',
	'3kwcksp8zf2j9','93p43ka2mqa46',
	'4dbfz7njtmmt0','0kx956yqhq1pm',
	'6npsfdvj35bsd','544jdt08bhpx7',
	'6npsfdvj35bsd','bz9tptwwqy5sm',
	'8rz1u9cpgy5c2','bjw4bd5pm2vs8',
	'12az2y858ujt5','4vv8avga9nd5a',
	'4wzwx9y2vj681','25mk2k3s7wrx8',
	'1umxtr5dyh9x3','48nqtd9ndbrh6',
	'0hqgg16qaf7jr','618jt13vgvb8y',
	'1nc3tt9415mk9','gppghmz476gcr',
	'51vcx5ywxvwhm','c2un8zc10766b',
	'b3rurj1m7y77y','6npsfdvj35bsd',
	'3ktgw7pm4np0z','dv9a4kc89a31',
	'71ctdqgu6d8h6','33ahdffcuc1mz',
	'cxp029jd5jcv1','2qc9v57avaffj',
	'dqddu2qq2hkmb','1zb7t1xff3kk6',
	'gkbgpdr5c503m','5j2n2dgtjzxg6',
	'2ggvqqqh3a9ty','3ktgw7pm4np0z',
	'6nxhqjztwwuc5')
                         AND SNAP.SNAP_ID BETWEEN 120643 AND 121290
                GROUP BY STAT.SQL_ID, STAT.MODULE) TOPSQL
         WHERE TOPORDER < 21
      ORDER BY TOPSQL.ELAPSED_TIME DESC;

