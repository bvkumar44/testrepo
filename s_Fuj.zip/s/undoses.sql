select sysdate from dual
/
select se.module, sum(tr.used_ublk*8192/1024/1024)"Used(MB)"
from v$session  se, V$transaction   tr
where tr.ses_addr = se.saddr
group by se.module
/
