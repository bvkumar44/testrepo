set pages 300
set lines 300
col Manager for a35
col request_id Heading 'Request ID'FORM 99999999 TRUNC
col PHASE for a12
col STATUS for a10
col PROGRAM for a35
col REQUESTOR for a12
set  verfiy off

accept concname varchar prompt 'Concurrent Manager Name :'


select d.USER_CONCURRENT_QUEUE_NAME "Manager",a.request_id 'Request ID',decode(a.PHASE_CODE,'R','Running','P','Pending','I','Inactive') PHASE,decode(a.STATUS_CODE,'A','Waiting','I','Scheduled','Q','Standby','M','No Manager','R','Normal','H','On hold')Status,b.USER_CONCURRENT_PROGRAM_NAME PROGRAM,c.user_name Requestor
from apps.fnd_concurrent_requests a,
apps.fnd_concurrent_programs_tl b,
apps.fnd_user c,
apps.fnd_concurrent_queues_tl d,
apps.fnd_concurrent_processes e
where e.concurrent_process_id = a.controlling_manager
and c.user_id = a.requested_by
and a.concurrent_program_id =b.concurrent_program_id
and e.CONCURRENT_QUEUE_ID=d.CONCURRENT_QUEUE_ID
and a.PHASE_CODE!='C'
and a.STATUS_CODE not in ('I','X')
and d.USER_CONCURRENT_QUEUE_NAME like '%concname%';
