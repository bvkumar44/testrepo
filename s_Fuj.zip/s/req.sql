set pages 500
set lines 140
col module for a40 trunc
col action for a20 trunc noprint
col uname for a10 trunc
col event for a20 trunc
select 	s.sid sid,s.serial# serial,to_char(logon_time,'dd/mm hh:mi') dt,
	s.module module,s.action action,sw.event
from	v$session_wait sw,v$session s
where 	sw.sid = s.sid
and s.process = '&ps';
