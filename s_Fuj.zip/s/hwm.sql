select a.owner,table_name,round((avg_row_len*num_rows)/1024/1024) mbtobe,round(bytes/1024/1024) mbact,
round((bytes/1024/1024) - (round((avg_row_len*num_rows)/1024/1024))) diff
from dba_tables a, dba_segments b
where a.owner = b.owner
and a.table_name = b.segment_name
and A.owner='DBO'
and bytes/1024/1024 >30
and round((bytes/1024/1024) - (round((avg_row_len*num_rows)/1024/1024))) >100
order by 3;