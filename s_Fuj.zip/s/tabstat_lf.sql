set lines 140
undefine tname
col column_name for a30 head "col_nam"
col data_type for a15
col owner for a13
col table_name for a30 head "tab_name"
col num_distinct for 99999999999 head "num_dist"
col index_name for a30 head "index_name"
col column_position for 99
col gb for 999
col mb for 99999
select owner,table_name,num_rows,last_analyzed,avg_row_len,(avg_row_len*num_rows)/1024/1024 emb,temporary temp from dba_tables where table_name=upper('&&tname') and owner = 'LFATG_CORE';
select owner,table_name,column_name,num_distinct,histogram,data_type,NUM_NULLS from dba_tab_columns where table_name=upper('&&tname') and owner not in ('AMARCHIVE','AMQUERY')  and owner = 'LFATG_CORE' order by 1,2,3;
select index_name,column_name,column_position from dba_ind_columns where table_name=upper('&&tname') order by 1,3,2;
select index_name,status,degree from dba_indexes where table_name=upper('&&tname')  and owner = 'LFATG_CORE' order by 1,2;
select owner,bytes/1024/1024 mb,bytes/1024/1024/1024 gb from dba_segments where segment_name=upper('&&tname')  and owner = 'LFATG_CORE';