set lines 130
set pages 500
col cmd for a130

select 	'ls -l $'||fa.APPLICATION_SHORT_NAME||'/'||
	DECODE (fcp.execution_method_code,
		'Q','sql/US/',
		'H','bin/US/',
		'L','bin/US/',
		'P','reports/US/'
		)||
	fcp.CONCURRENT_PROGRAM_NAME||
	DECODE (fcp.execution_method_code,
		'Q','.sql',
		'H','.sh',
		'L','*',
		'P','.rdf'
		) cmd
from 	fnd_user fnda,
	fnd_user fndb,
	fnd_concurrent_programs_vl  fcp,
	fnd_application_vl fa
where 	fndb.user_id = fcp.created_by
and	fnda.user_id = fcp.last_updated_by
and	fa.application_id = fcp.application_id
and     fcp.execution_method_code in ('Q','H','L','P')
and     fcp.last_update_date >= sysdate - 60
/
