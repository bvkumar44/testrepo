SET LINES 140
SET PAGES 500
spool SR_OUTPUT

select CRP_RESOURCE_HOURS_S.nextval from dual;

select * from all_sequences where SEQUENCE_NAME like 'CRP_RESOURCE_HOURS_S';

SPOOL OFF