set pages 500
col cnt for 99999
col event for a40 trunc
select count(*) cnt,event from v$session_wait where event not like 'SQL*Net%' group by event order by 1
/
--select name from v$database;