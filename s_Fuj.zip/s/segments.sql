      SELECT OWNER,
             SEGMENT_NAME,
             SEGMENT_TYPE,
             SIZE_GB
        FROM (SELECT SEG.OWNER,
                     SEG.SEGMENT_TYPE,
                     ROUND (SEG.SIZE_IN_GB, 2) SIZE_GB,
                     CASE SEG.SEGMENT_TYPE
                        WHEN 'LOBSEGMENT'
                        THEN
                           (SELECT L.TABLE_NAME || '.' || L.COLUMN_NAME
                              FROM DBA_LOBS L
                             WHERE L.SEGMENT_NAME = SEG.SEGMENT_NAME)
                        WHEN 'LOB PARTITION'
                        THEN
                           (SELECT L.TABLE_NAME || '.' || L.COLUMN_NAME
                              FROM DBA_LOBS L
                             WHERE L.SEGMENT_NAME = SEG.SEGMENT_NAME)
                        ELSE
                           SEG.SEGMENT_NAME
                     END
                        SEGMENT_NAME
                FROM (  SELECT OWNER,
                               SEGMENT_NAME,
                               SEGMENT_TYPE,
                               SUM (BYTES / 1024 / 1024 / 1024) SIZE_IN_GB
                          FROM DBA_SEGMENTS
                         WHERE SEGMENT_TYPE NOT IN ('TYPE2 UNDO')
                      GROUP BY OWNER, SEGMENT_NAME, SEGMENT_TYPE
                      ORDER BY SUM (BYTES / 1024 / 1024 / 1024) DESC) SEG
               WHERE ROWNUM < 21);