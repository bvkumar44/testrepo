col OWNER for a10
col SYNONYM_NAME for a25
col TABLE_NAME for a25
col TABLE_OWNER for a10
col DB_LINK for a30
select * from dba_synonyms where SYNONYM_NAME='&synonym_name';