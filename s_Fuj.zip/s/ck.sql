SELECT COUNT(*)
          FROM   fnd_concurrent_requests
         WHERE  concurrent_program_id = 32766
         AND    request_id = (SELECT MAX(request_id)
                              FROM   fnd_concurrent_requests
                              WHERE  concurrent_program_id = 32766
                              AND    requested_by = fnd_profile.VALUE('2585'))
         AND    request_id > fnd_global.conc_request_id
/
