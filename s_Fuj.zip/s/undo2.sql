set lines 110
col sid for 9999
col action for a20 trunc
col module for a20 trunc
col segname for a10 trunc
col tspace for a20 trunc
col program for a10 trunc
col ublk for 9999
col urec for 99999
col logdt for a11
col status for a6
col status for a6 trunc

select sid,
       a.status status,
       to_char(logon_time,'dd/mm hh:mi') logdt,
       module,
       action,
       program,
       b.segment_name segname,  
       used_ublk ublk,
       used_urec urec
  from v$session a, 
       dba_rollback_segs b, 
       v$transaction c
  where a.taddr = c.addr 
    and b.segment_id = c.xidusn
  order by logon_time
/