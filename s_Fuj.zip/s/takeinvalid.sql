set lines 120
set pages 5000
col obj for a30
col objt for a30
break on owner on report
compute sum of cnt on owner report
col cnt for 9999

select owner,object_name obj,object_type objt,1 cnt from dba_objects where status!='VALID' order by 1,2;
