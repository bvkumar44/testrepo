select host_name from gv$instance@&Link
/