select  sql_text                      ss
from    v$sqltext a,v$session b
where   b.sid = &sid
and b.sql_hash_value = a.hash_value
and b.sql_address = a.address
order by a.piece
/