select 	request_id,
	to_char(requested_start_date,'dd/mm/hh:mi'),
	-- user_name,
	to_char(actual_start_date,'dd/mm/ hh24:mi') stdt ,
	to_char(actual_completion_date,'dd/mm hh24:mi') enddt ,
	ARGUMENT_TEXT argt
from 	fnd_concurrent_requests a,
	fnd_user b
where 	a.requested_by= b.user_id and
	concurrent_program_id =38655 and
	b.user_id = 4764 AND
        actual_start_date >= sysdate -2 and
        argument_text like '%37792044%'
order by 5
/
