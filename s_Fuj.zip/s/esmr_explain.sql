set pages 5000 lines 140
undefine tname
undefine SQL_ID
col column_name for a30 head "col_nam" 
col owner for a13 
col table_name for a30 head "tab_name" 
col num_distinct for 99999999999 head "num_dist" 
col index_name for a30 head "index_name" 
col column_position for 99 
col gb for 999 
col mb for 99999
break on owner on table_name on report
--SELECT * FROM TABLE(dbms_xplan.display_awr('&SQL_ID'));
SELECT * FROM TABLE(dbms_xplan.display_cursor('&&SQL_ID'));
select owner,table_name,num_rows,last_analyzed,avg_row_len from dba_tables where (owner,table_name) in (select distinct object_owner,object_name from dba_hist_sql_plan where sql_id='&&sql_id' and object_type='TABLE') order by 1,2;
select owner,table_name,column_name,num_distinct,histogram from dba_tab_columns where (owner,table_name) in (select distinct object_owner,object_name from dba_hist_sql_plan where sql_id='&&sql_id' and object_type='TABLE') order by 1,2,3 asc;
select table_owner,table_name,index_name,column_name,column_position from dba_ind_columns where (table_owner,table_name) in (select distinct object_owner,object_name from dba_hist_sql_plan where sql_id='&&sql_id' and object_type='TABLE') order by 1,2,3,5; 
select owner,bytes/1024/1024 mb,bytes/1024/1024/1024 gb from dba_segments where  (owner,segment_name) in (select distinct object_owner,object_name from dba_hist_sql_plan where sql_id='&&sql_id' and object_type='TABLE');