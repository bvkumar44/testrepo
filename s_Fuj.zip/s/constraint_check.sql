REM
REM FILENAME
REM datatype_check.sql
REM DESCRIPTION
REM find the difference in constraints before/after the upgrade
REM NOTES
REM Usage: sqlplus <ofsa_user/ofsa_passwd> @constraint_check
REM
REM
REM $Id: constraint_check.sql,v 1.0 
REM
REM
REM +==============================+
select 'in t1, not t2',constraint_name,decode (constraint_type, 'P', 'primary key', 'C', 'check',
'U', 'unique key', 'R', 'referential', 'undefined') type from user_constraints@DEV
where table_name = '&old'
minus
select 'in t1, not t2',constraint_name,decode (constraint_type, 'P', 'primary key', 'C', 'check',
'U', 'unique key', 'R', 'referential', 'undefined') type from user_constraints 
where table_name = '&new' 
union all  
select 'in t1, not t2',constraint_name,decode (constraint_type, 'P', 'primary key', 'C', 'check',
'U', 'unique key', 'R', 'referential', 'undefined') type from user_constraints 
where table_name = '&new'
minus
select 'in t1, not t2',constraint_name,decode (constraint_type, 'P', 'primary key', 'C', 'check',
'U', 'unique key', 'R', 'referential', 'undefined') type from user_constraints@DEV
where table_name = '&old'
/