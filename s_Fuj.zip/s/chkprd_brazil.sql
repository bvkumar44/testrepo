select to_char(sysdate,'dd/mm/rr hh:mi') dt from dual;
@undo
@locks
@longreq
@undo_status
