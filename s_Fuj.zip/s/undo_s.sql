SELECT s.username, s.SID, s.serial#, s.logon_time, t.xidusn, t.ubafil,
t.ubablk, t.used_ublk, t.start_date, t.status
FROM v$session s, v$transaction t
WHERE s.saddr = t.ses_addr;