--spool e:\Patch_logs\post_&patch_number
select name,open_mode from v$database;
exec SYS.utl_recomp.recomp_parallel(64);
--select bug_number from ad_bugs where bug_number in ('&patch_number');
--select patch_name from ad_applied_patches where patch_name in ('&&patch_number');
col owner for a20
col obj for a30
col typ for a20
set lines 120
set pages 500
compute sum of cnt on report
compute sum of cnt on owner
break on owner on report
select owner,object_name obj,object_type typ,1 cnt from dba_objects where status!='VALID' order by 1,2;
--spool off