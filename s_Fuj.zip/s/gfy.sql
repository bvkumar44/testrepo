update mtl_material_transactions_temp
set      process_flag='Y',
         lock_flag='N',
         transaction_mode='3',
        transaction_type_id=52
where  transaction_header_id=471791971
and      organization_id=8;