REM
REM FILENAME
REM datatype_check.sql
REM DESCRIPTION
REM find the difference in datatype, datalength and length before/after the upgrade
REM NOTES
REM Usage: sqlplus <ofsa_user/ofsa_passwd> @datatype_check
REM
REM
REM $Id: datatype_check.sql,v 1.0 
REM
REM
REM +==============================+
select 'IN T1, NOT T2', column_name,data_type,data_length
from user_tab_columns@DEV
where table_name = '&OLD'
MINUS
select 'IN T1, NOT T2', column_name,data_type,data_length
from user_tab_columns
where table_name = '&NEW' 
UNION ALL  
select 'IN T2, NOT T1', column_name,data_type,data_length
from user_tab_columns
where table_name = '&NEW'
MINUS
select 'IN T2, NOT T1', column_name,data_type,data_length
from user_tab_columns@DEV
where table_name = '&OLD'
/
