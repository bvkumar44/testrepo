select session_id,object_name nam
from v$locked_object a,dba_objects b
where a.object_id = b.object_id
/
