set lines 150
col message for a100
select sid,message,time_remaining from gv$session_longops where sofar!=totalwork
/
