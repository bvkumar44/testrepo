select 'Current Application Release: '||ver||' ('||bug||')' "Description" from (
select x.* from
(select 1 seq, '1939818' bug,'11.5.0' pv,'11.5.6' ver from dual
union select 2,'2123967','11.5.0','11.5.7' from dual
union select 3,'2293243','11.5.0','11.5.8' from dual
union select 4,'2669606','11.5.0','11.5.9 MP' from dual
union select 5,'3126422','11.5.0','11.5.9 Update1' from dual
union select 6,'3171663','11.5.0','11.5.9 Update2' from dual
union select 7,'3714435','11.5.0','11.5.9 June Update' from dual
union select 8,'3140000','11.5.0','11.5.10' from dual
union select 9,'3240000','11.5.0','11.5.10.1' from dual
union select 10,'3460000','11.5.0','11.5.10.2' from dual
union select 11,'3480000','11.5.0','11.5.10.2' from dual
union select 12,'4440000','12.0.0','12.0' from dual
union select 12,'94440000','12.0.0','12.0*' from dual
union select 13,'5082400','12.0.0','12.0.1' from dual
union select 14,'5484000','12.0.0','12.0.2' from dual
union select 14,'95484000','12.0.0','12.0.2*' from dual
union select 15,'6141000','12.0.0','12.0.3' from dual
union select 15,'96141000','12.0.0','12.0.3*' from dual
union select 16,'6435000','12.0.0','12.0.4' from dual
union select 17,'7282993','12.0.0','12.0.5' from dual
union select 18,'6728000','12.0.0','12.0.6' from dual
union select 19,'6646600','12.0.0','12.1.0' from dual
union select 20,'7303030','12.0.0','12.1.1' from dual
union select 20,'97303030','12.0.0','12.1.1*' from dual
union select 21,'7303033','12.0.0','12.1.2' from dual
union select 22,'9239090','12.0.0','12.1.3' from dual
) x,
(select product_version pv from fnd_product_installations
where application_id=401) i,
ad_bugs bugs
where x.bug = bugs.bug_number and x.pv = i.pv order by 1 desc) where rownum = 1
union
select 'Current INV Rollup: '||ver||' ('||bug||')' "Description" from (
select x.* from
(select 1 seq, '1426212' bug,'11.5.0' pv,'INV.C' ver from dual
union select 2,'1551167','11.5.0','MFG.D' from dual
union select 3, '1550583','11.5.0','OM.D' from dual
union select 4,'1538130','11.5.0','INV.D' from dual
union select 5, '1745355','11.5.0','MFG.E' from dual
union select 6,'1696652','11.5.0','INV.E' from dual
union select 7, '1891480','11.5.0','MFG.F' from dual
union select 8, '1942144','11.5.0','OM.F' from dual
union select 9,'1886015','11.5.0','INV.F' from dual
union select 10, '2133107','11.5.0','MFG.G' from dual
union select 11, '2118482','11.5.0','OM.G' from dual
union select 12,'2004922','11.5.0','INV.G' from dual
union select 13, '2248408','11.5.0','MFG.H' from dual
union select 14,'2250333','11.5.0','OM.H' from dual
union select 15,'2248490','11.5.0','INV.H' from dual
union select 16, '2697753','11.5.0','MFG.I' from dual
union select 17,'2698175','11.5.0','OM.I' from dual
union select 18,'2371213','11.5.0','INV.I' from dual
union select 19,'3384350','11.5.0','INV.J' from dual
union select 20,'4042499','11.5.0','INV.J RUP1' from dual
union select 21,'4231215','11.5.0','INV.J RUP2' from dual
union select 22,'4734840','11.5.0','INV.J RUP3' from dual
union select 23,'5739724','11.5.0','INV.J RUP4' from dual
union select 24,'6449139','11.5.0','INV.J RUP5' from dual
union select 25,'6461517','11.5.0','INV.J RUP6' from dual
union select 26,'6461519','11.5.0','INV.J RUP7' from dual
union select 27,'6461522','11.5.0','INV.J RUP8' from dual
union select 28,'6870030','11.5.0','INV.J RUP9' from dual
union select 29,'7258620','11.5.0','INV.J RUP10' from dual
union select 30,'7258624','11.5.0','INV.J RUP11' from dual
union select 31,'7258629','11.5.0','INV.J RUP12' from dual
union select 32,'7581431','11.5.0','INV.J RUP13' from dual
union select 33,'7666112','11.5.0','INV.J RUP14' from dual
union select 34,'8403245','11.5.0','INV.J RUP15' from dual
union select 35,'8403254','11.5.0','INV.J RUP16' from dual
union select 36,'8403258','11.5.0','INV.J RUP17' from dual
union select 37,'9063156','11.5.0','INV.J RUP18' from dual
union select 38,'9265857','11.5.0','INV.J RUP19' from dual
union select 39,'9466436','11.5.0','INV.J RUP20' from dual
union select 40,'9649124','11.5.0','INV.J RUP21' from dual
union select 41,'9878808','11.5.0','INV.J RUP22' from dual
union select 42,'10111967','11.5.0','INV.J RUP23' from dual
union select 43,'8478486','12.0.0','R12 INV/RCV RUP7' from dual
union select 44,'7587155','12.1.1','R12.1.1 OPM-INV Consolidated' from dual
) x,
(select product_version pv from fnd_product_installations
where application_id = 401) i,
ad_bugs bugs
where x.bug = bugs.bug_number and x.pv = i.pv order by 1 desc) where rownum = 1
UNION
select 'Current WMS Rollup: '||ver||' ('||bug||')' "Description" from ( 
select x.* from 
(select 1 seq, '4734840' bug, '11.5.0' pv,'RUP3' ver from dual 
union select 2 seq, '5855276' bug,'11.5.0' pv,'WMS RUP4' ver from dual 
union select 3 seq, '6957082' bug,'11.5.0' pv,'WMS RUP5' ver from dual 
union select 4 seq, '7041845' bug,'11.5.0' pv,'WMS RUP6' ver from dual 
union select 5 seq, '7219660' bug,'11.5.0' pv,'WMS RUP7' ver from dual 
union select 6 seq, '7317230' bug,'11.5.0' pv,'WMS RUP8' ver from dual 
union select 7 seq, '7453739' bug,'11.5.0' pv,'WMS RUP9' ver from dual 
union select 8 seq, '7591071' bug,'11.5.0' pv,'WMS RUP10' ver from dual 
union select 9 seq, '7644924' bug,'11.5.0' pv,'WMS RUP11' ver from dual 
union select 10 seq,'7688739' bug,'11.5.0' pv,'WMS RUP12' ver from dual
union select 11 seq,'8337529' bug,'11.5.0' pv,'WMS RUP13' ver from dual
union select 12 seq,'8524873' bug,'11.5.0' pv,'WMS RUP14' ver from dual
union select 13 seq,'8785944' bug,'11.5.0' pv,'WMS RUP15' ver from dual
union select 13 seq,'8941985' bug,'11.5.0' pv,'WMS RUP16' ver from dual
union select 14 seq,'9127290' bug,'11.5.0' pv,'WMS RUP17' ver from dual
union select 15 seq,'9857061' bug,'11.5.0' pv,'WMS RUP18' ver from dual
union select 16 seq,'9951502' bug,'11.5.0' pv,'WMS RUP19' ver from dual
) x, 
(select product_version pv from fnd_product_installations 
where application_id=385) i, 
ad_bugs bugs 
where x.bug = bugs.bug_number and x.pv = i.pv order by 1 desc) where rownum = 1 
union
select 'Product Installation List : ' from dual
union
select 'Product Installation: '||patch_level||': '||decode(status,
'I','Installed','S','Shared','Not Installed')
from fnd_product_installations
where application_id IN (401, 385, 201, 431, 702, 703)
order by 1;