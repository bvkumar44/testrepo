begin
dbms_application_info.set_client_info(522);
end;
/
