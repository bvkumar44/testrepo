set lines 500
set pages 100
col OWNER for a10
col DIRECTORY_NAME for a30
col DIRECTORY_PATH for a100
select * from dba_directories order by DIRECTORY_NAME
/