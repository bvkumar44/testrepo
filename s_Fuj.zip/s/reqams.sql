SELECT A.REQUEST_ID,
       B.USER_CONCURRENT_PROGRAM_NAME, D.USER_NAME,
       A.ORACLE_PROCESS_ID,
       A.actual_start_date,
       DECODE(A.PHASE_CODE,'C','Completed','I','Inactive','P','Pending','R','Running') PHASE, 
       DECODE(A.STATUS_CODE,'A','Waiting','B','Resuming','C','Normal','D','Cancelled','E','Error','F','Scheduled','G','Warning','H','On Hold','I','Normal','M','No Manager','Q','Standby','R','Normal','S','Suspended','T','Terminating','U','Disabled','W','Paused','X','Terminated','Z','Waiting') STATUS,
       A.ARGUMENT_TEXT
FROM 	perfstat.arm_fnd_concurrent_requests A, 
	applsys.fnd_concurrent_programs_tl B, 
	applsys.fnd_concurrent_programs C, 
	applsys.fnd_user D
WHERE
   A.PROGRAM_APPLICATION_ID = b.APPLICATION_ID 
   AND A.CONCURRENT_PROGRAM_ID  = b.CONCURRENT_PR