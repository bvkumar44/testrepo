set lines 250
set pages 200
col process for a8
col action for a15
col osuser for a7
col machine for a13
col module for a30
col osuser for a8 trunc
col event for a40 
select a.sid,serial#,a.process,action,module,osuser,last_call_et,status,a.event,a.sql_id
from v$session a,v$session_wait b 
where a.sid = b.sid and
      a.sid in (&sid)
/
