SELECT FCRSV.USER_CONCURRENT_PROGRAM_NAME "Program",
FCRSV.REQUESTOR "User",
FLP.MEANING "Phase",
FLS.MEANING  "Status",
FCRSV.ACTUAL_START_DATE "Start Time",
FCRSV.ACTUAL_COMPLETION_DATE "End Time",
ROUND((FCRSV.ACTUAL_COMPLETION_DATE - FCRSV.ACTUAL_START_DATE)*24*60,0) "Run Time"
FROM
FND_CONC_REQ_SUMMARY_V FCRSV,
FND_LOOKUPS FLP,
FND_LOOKUPS FLS
WHERE  FCRSV.PHASE_CODE = FLP.LOOKUP_CODE
AND FCRSV.STATUS_CODE = FLS.LOOKUP_CODE
AND FLP.LOOKUP_TYPE = 'CP_PHASE_CODE'
AND FLS.LOOKUP_TYPE = 'CP_STATUS_CODE'
AND ACTUAL_START_DATE > SYSDATE - 2 
AND USER_CONCURRENT_PROGRAM_NAME IN ('Planning Data Pull',
'Memory Based Planner 64-bit Sun',
'Copy Plan',
'Planning ODS Load',
'Push Plan Information',
'Planning Data Pull Worker',
'Analyze Plan Partition',
'Planning ODS Load Worker',
'Memory Based Snapshot 64 bit Sun',
'Planning Data Collection - Purge Staging Tables',
'Snapshot Monitor',
'Loader Worker With Direct Load Option',
'Memory Based Snapshot Worker 64 bit Sun',
'Purge Designator',
'Auto-Release Planned Orders',
'Snapshot Delete Worker',
'ASCP Post Plan Program for UI',
'Launch Supply Chain Planning Process')
ORDER BY ACTUAL_START_DATE DESC
/