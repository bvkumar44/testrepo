prompt Datafiles added recently
prompt ========================
set pagesize 1000
set lines 300
col FILE_NAME for a55
col TABLESPACE_NAME for a20
select * from (select a.FILE_NAME,a.TABLESPACE_NAME,a.bytes/1024/1024,a.maxbytes/1024/1024,a.autoextensible,b.CREATION_TIME from dba_data_files a, v$datafile b
where a.FILE_NAME=b.name and a.TABLESPACE_NAME='&tbs' order by b.CREATION_TIME desc ) where rownum <10
/
