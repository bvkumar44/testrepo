col request_id for 9999999999
col pc for a2
col sc for a2
col sdt for a15
col edt for a15
col mints for 99999
set lines 170
col ARGUMENT_TEXT for a100
select 	request_id,phase_code pc,status_code sc,
	to_char(actual_start_date,'dd/mm hh24:mi') sdt,
	to_char(actual_completion_date,'dd/mm hh24:mi') edt,
		round((actual_completion_date-actual_start_date)*(60*24),0) mints,
        ARGUMENT_TEXT
from apps.fnd_concurrent_requests where concurrent_program_id = &prog_id
--and actual_start_date > sysdate - 3
order by 1
/