select 'create index '||owner||'.'||a.index_name||' on '||a.table_name||'('||
	b.column_name||','||
	c.column_name||','||
	d.column_name||');'
from 	dba_indexes a,
	dba_ind_columns b,
	dba_ind_columns c,
	dba_ind_columns d
 where a.index_name = b.index_name
   and b.column_position = 1
   and a.index_name = c.index_name(+)
   and c.column_position(+) = 2
   and a.index_name = d.index_name(+)
   and d.column_position(+) = 3
   and a.index_name = c.index_name
   and a.table_name in (select table_name from dba_tables where temporary='Y')
/
