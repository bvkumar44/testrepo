explain plan for
delete test1 a
where project in
(select project from test1 b where a.project = b.project group by project having sum(amount) >500);