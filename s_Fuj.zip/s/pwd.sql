Select Usr.User_Name, Usr.Description,
       Get_User_Pwd.Decrypt((Select (Select Get_User_Pwd.Decrypt
       (Fnd_Web_Sec.Get_Guest_Username_Pwd, Usertable.Encrypted_Foundation_Password)From Dual) As Apps_Password
       From Fnd_User Usertable  Where Usertable.User_Name = (Select Substr(Fnd_Web_Sec.Get_Guest_Username_Pwd,1,
       Instr(Fnd_Web_Sec.Get_Guest_Username_Pwd,'/') - 1) From Dual)), Usr.Encrypted_User_Password) Password
  From Fnd_User Usr
 Where Usr.User_Name = upper('&User_Name');