set lines 160 pages 5000
--select * from table(dbms_xplan.display(null,null,'ADVANCED'));
select * from table(dbms_xplan.display(null,null,'TYPICAL'));