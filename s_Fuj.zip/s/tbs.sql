prompt Freespace in Tablespace
prompt ========================
set linesize 100 pagesize 30 feedback 1 echo off wrap on
undefine tbsp
column tblspace format a12 heading "Tablespace"
column "Used Space(MB)" format 999999999
column "allocated size(MB)" format 999999999
column "maximum allowable (MB)" format 999999999
column "effective free(MB)" format 999999999
column "%FREE" format 999.99
set linesize 100 pagesize 30 feedback 1 echo off wrap on
column tblspace format a12 heading "Tablespace"
column "Used Space(MB)" format 999999999
column "allocated size(MB)" format 999999999
column "maximum allowable (MB)" format 999999999
column "effective free(MB)" format 999999999
column "%FREE" format 999.99
SELECT
(a.bytes - NVL(f.bytes,0))/1024/1024 "Used Space(MB)",
a.bytes/1024/1024 "allocated size(MB)",
a.maxbytes/1024/1024 "maximum allowable (MB)",
(NVL(f.bytes,0) + (a.maxbytes - a.bytes))/1024/1024 "effective
free(MB)",
100-round(((a.bytes - NVL(f.bytes,0))*100/a.maxbytes),2) "%FREE"
FROM
(select sum(bytes) bytes,
sum(greatest(maxbytes,bytes)) maxbytes
from sys.dba_data_files where tablespace_name='&&tbsp') a,
(select sum(bytes) bytes
from sys.dba_free_space where tablespace_name='&tbsp') f
/
