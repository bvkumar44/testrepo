@act
compute sum of cnt on report
break on report
select count(1) cnt,username
from gv$session 
group by username
order by 1;
