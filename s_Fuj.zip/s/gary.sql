select /*+ ORDERED */ l.sid, s.name, decode(m.lmode,0,'Waiting','Holder') hw
from v$lock l,
(select sid, lmode
from v$lock l
where id1 in
(select id1
from v$lock
where lmode=0)) m,
sys.obj$ s
where l.sid = m.sid
and l.type = 'TM'
and l.id1 = s.obj#;
