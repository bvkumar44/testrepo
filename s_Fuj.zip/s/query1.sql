DECLARE
   x_err_msg       VARCHAR2 (2000);
   x_error_code    NUMBER;
   v_group_id      NUMBER;
   v_item_id       NUMBER;
   v_search_item   NUMBER;
BEGIN
   FOR v1 IN (SELECT   *
                  FROM xx_so_items_new1
              ORDER BY 2)
   LOOP
      BEGIN
         v_group_id := NULL;

         SELECT bom_explosion_temp_s.NEXTVAL
           INTO v_group_id
           FROM DUAL;
      EXCEPTION
         WHEN OTHERS
         THEN
            NULL;
      END;
      bompxinq.exploder_userexit (verify_flag            => 0,
                                  org_id                 => 122,
                                  order_by               => 1,
                                  grp_id                 => v_group_id,
                                  session_id             => 0,
                                  levels_to_explode      => 20,
                                  bom_or_eng             => 1,
                                  impl_flag              => 1,
                                  plan_factor_flag       => 2,
                                  explode_option         => 2,
                                  module                 => 2,
                                  cst_type_id            => 0,
                                  std_comp_flag          => 1,
                                  expl_qty               => 1,
                                  item_id                => v1.inventory_item_id,
                                  unit_number_from       => '',
                                  unit_number_to         => '',
                                  alt_desg               => NULL,
                                  comp_code              => NULL,
                                  rev_date               => SYSDATE,
                                  show_rev               => 1,
                                  material_ctrl          => 1,
                                  lead_time              => 2,
                                  err_msg                => x_err_msg,
                                  ERROR_CODE             => x_error_code
                                 );
      FOR c2 IN (SELECT a.component_item_id, b.segment1, b.description
                   FROM bom_small_expl_temp a, mtl_system_items_b b
                  WHERE 1 = 1
                    AND a.component_item_id = b.inventory_item_id
                    AND a.organization_id = b.organization_id
                    AND b.organization_id = 122
                    AND a.component_item_id != v1.inventory_item_id
                    AND a.GROUP_ID = v_group_id)
      LOOP
         IF (c2.segment1 LIKE '%*%')
         THEN
            INSERT INTO xx_result_items1_new1
                 VALUES (v1.ORDERED_ITEM, v1.description, c2.segment1,
                         c2.description);
            COMMIT;
         END IF;
      END LOOP;

      DELETE FROM bom_small_expl_temp
            WHERE GROUP_ID = v_group_id;
      COMMIT;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      x_err_msg := SUBSTR ('Exception:' || SQLCODE || '-' || SQLERRM, 1, 100);
      DBMS_OUTPUT.put_line ('Error' || x_err_msg);
END;
/