set lines 190
select 	request_id,s.sid sid,S.INST_ID,s.serial# serial,to_char(logon_time,'dd/mm hh24:mi') dt,s.module module,s.action action,user_name uname,s.event,last_call_et,sql_id,blocking_session
from	gv$session s,gv$process p,apps.fnd_concurrent_requests fnd,apps.fnd_user fndu
where 	p.inst_id = s.inst_id
and	p.addr = s.paddr
and	p.spid = fnd.oracle_process_id
and     fnd.requested_by = fndu.user_id
and	fnd.status_code = 'R'
and	fnd.phase_code = 'R'
and module='WSHPSGL'
order by 1
/
