select user_concurrent_program_name,executable_name,execution_file_name,meaning executable_type
from fnd_executables_vl e,fnd_concurrent_programs_vl p,fnd_concurrent_requests r,fnd_lookups l
where e.executable_id=p.executable_id
and p.CONCURRENT_PROGRAM_ID=r.concurrent_program_id
and l.LOOKUP_CODE=e.execution_method_code
and l.lookup_type='CP_EXECUTION_METHOD_CODE'
and r.request_id = &request_id
/
