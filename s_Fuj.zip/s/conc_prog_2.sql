select count(1) cnt,
		round((actual_completion_date-actual_start_date)*(60*24),0) mints
from fnd_concurrent_requests where concurrent_program_id = 199819
group by round((actual_completion_date-actual_start_date)*(60*24),0)
order by 1
/
