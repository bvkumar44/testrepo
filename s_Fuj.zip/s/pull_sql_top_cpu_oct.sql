spool top_cpu_oct_sqls.lst ;
col sql_text for a64;
set long 200000 ;
set pages  0 ;
select sql_id,sql_text from dba_hist_sqltext
where sql_id in 
('cq0rcpu00kj6m', 
'csdksmgbjrfvb', 
'453wmu42zasuk', 
'3hzasn1ppwcnx', 
'bpzzyubs4bwcz', 
'1mr4u2r99v9vc', 
'8657bja7bp0u4 ',
'4f1p9061dqksm', 
'd9cqwwzwj6f1b', 
'324crpa7fu5gh', 
'61ra3j3bhj409', 
'cfacpz2857q7p', 
'b41tp1p0wtpu8', 
'da5vamwkpzbts', 
'cm4kb2305ru33', 
'cm4kb2305ru33', 
'61ra3j3bhj409', 
'1mr4u2r99v9vc', 
'bzarggtkwg6sf', 
'3043dndugmvdn')  ;
spool off ;

