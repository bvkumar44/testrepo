spool troshp_archive_detaols.lst ;
col segment_name for a40 word_wrapped ;
set lines 200 ;
set pages 400 ;	
  select  owner,segment_name,segment_type,bytes/1024/1024 sizemb,tablespace_name 
    from dba_segments where segment_name in
             ('FAMILIES',
	'FAMILY_IDS',
	'FAMILY_VALUES',
	'MACHINE_SETUP_PARAMETERS',
	'PERSONNEL_IDS_AND_USAGE',
	'RECIPES',
	'TRACK_PUNCH_ATTRIBUTES',
	'TRAFFIC_EQUIPMENT',
	'BACKFLUSH',
	'BUNDLES',
	'BUNDLE_ITEMS_TO_COMPLETE',
	'HARDWARE_PROCESSING',
	'LABEL_DATA',
	'LOADVER_MESSAGES',
	'LOAD_VER_DESCRIPTIONS',
	'MASTER_BUNDLE_IDS',
	'MASTER_BUNDLE_USAGE',
	'ORDER_HISTORY',
	'ORDER_ITEM_DEFINITION',
	'ORDER_STATUS',
	'ORDERS',
	'PICK_COMPONENTS',
	'PRODUCTION_HISTORY',
	'PRODUCTION_IDS',
	'PRODUCTION_RUNS',
	'PURCHASE_ORDERS',
	'SECTION_PROCESSING',
	'SECTIONS',
	'SERIAL_NUMBER_ASSIGNMENTS',
	'SHIP_CONFIRMATION_RECORDS',
	'TRIP_DATA',
	'LONG_LEAD_READY_TO_RELEASE',
	'MACH_VALUES_USED_ON_SECTIONS' )
and Owner='TROSHP_ADM'
                   order by 4 desc ;

spool off ;


