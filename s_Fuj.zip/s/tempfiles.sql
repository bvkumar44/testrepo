col file_name for a60
select round(sum(bytes/1024/1024/1024),0) GB from dba_temp_files;
select file_name,round(bytes/1024/1024,0) size_mb,round(maxbytes/1024/1024,0) max_mb from dba_temp_files;