col action for a15 trunc
col module for a15 trunc
col program for a15 trunc
col event for a15 trunc
col logon for a15
set pages 500
set lines 120

select a.sid sid,to_char(logon_time,'dd/mm hh:mi') logon,action,module,program,event,last_call_et lastet
from v$session a,v$session_wait b
where a.sid = b.sid
and   a.type!='BACKGROUND'
and b.event not like '%SQL%'
order by 2
/
