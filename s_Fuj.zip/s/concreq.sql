col argument_text for a60 trunc
col request_id for 9999999999
col pc for a2
col sc for a2
col sdt for a15
col edt for a15
col mints for 99999
col argument_text for a30 trunc
COL CONCURRENT_PROGRAM_NAME FOR A30
COL USER_CONCURRENT_PROGRAM_NAME FOR A30 TRUNC
set lines 180

select 	request_id,phase_code pc,status_code sc,to_char(actual_start_date,'dd/mm hh24:mi') sdt,
	to_char(actual_completion_date,'dd/mm hh24:mi') edt,
	(actual_completion_date-actual_start_date)*(60*24) mints,
	A.concurrent_program_id,argument_text,CONCURRENT_PROGRAM_NAME,USER_CONCURRENT_PROGRAM_NAME
from 	apps.fnd_concurrent_requests A, APPS.FND_CONCURRENT_PROGRAMS_VL B
 where  A.CONCURRENT_PROGRAM_ID = B.CONCURRENT_PROGRAM_ID
AND     A.request_id='&req_id';
