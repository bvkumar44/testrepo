col value for a15
select
  b.tablespace_name, B.TOTALMB , C_ACTIVE.ACTIVEMB, C_EXPIRED.EXPIREDMB, C_UNEXPIRED.UNEXPIREDMB,
     (B.TOTALMB - C_ACTIVE.ACTIVEMB - C_UNEXPIRED.UNEXPIREDMB) AvailableBeforeGetting1055
from 
    (select tablespace_name, trunc(sum(bytes)/1024/1024) TOTALMB from dba_data_files where tablespace_name = 'UNDOTBS1' group by tablespace_name) B,
     (select tablespace_name, trunc(sum(bytes)/1024/1024) ACTIVEMB from dba_undo_extents where STATUS='ACTIVE' and tablespace_name = 'UNDOTBS1' group by tablespace_name) C_ACTIVE,
     (select tablespace_name, trunc(sum(bytes)/1024/1024) EXPIREDMB from dba_undo_extents where STATUS='EXPIRED' and tablespace_name = 'UNDOTBS1' group by tablespace_name) C_EXPIRED,
     (select tablespace_name, trunc(sum(bytes)/1024/1024) UNEXPIREDMB from dba_undo_extents where STATUS='UNEXPIRED' and tablespace_name = 'UNDOTBS1' group by tablespace_name) C_UNEXPIRED
where C_ACTIVE.tablespace_name = B.tablespace_name
  and C_EXPIRED.tablespace_name = B.tablespace_name
  and C_UNEXPIRED.tablespace_name = B.tablespace_name;