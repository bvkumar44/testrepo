Update fnd_concurrent_requests
Set phase_code = 'C',
status_code='E'
where request_id in (83200758,83200351)
/
