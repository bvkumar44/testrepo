select
   s.sid, 
   s.username,
   r.name       "RBS name", 
   t.start_time,
   t.used_ublk  "Undo blocks",
   t.used_urec  "Undo recs"
 from
   v$session s,
   v$transaction t,
   v$rollname r
 where
   t.addr = s.taddr and
   r.usn  = t.xidusn;
