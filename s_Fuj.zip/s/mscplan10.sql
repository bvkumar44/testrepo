set escape '\'
undefine v_headerinfo
Define   v_headerinfo     =  '$Header: mscplan10.sql version 1 01-JUL-05 support $' 
undefine v_scriptlongname
Define   v_scriptlongname = 'Test to obtain all APS plan options't 
REM   =========================================================================
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA
REM   Oracle Support Services.  All rights reserved.
REM   =========================================================================
REM   PURPOSE:           Test to obtain all APS plan options
REM   PRODUCT:           Advanced Supply Chain Planning
REM   PRODUCT VERSIONS:  11.5
REM   PLATFORM:          Generic
REM   PARAMETERS:        Plan Name
REM   =========================================================================

REM   =========================================================================
REM   USAGE:             Run from SQL*PLUS with the APPS user.
REM                      This test takes a bit of time to run.
REM   EXAMPLE:           SQL>@mscplan10.sql
REM   OUTPUT:  TXT file: mscplan10_<date_timestamp>_diag.txt
REM   =========================================================================

REM   =========================================================================
REM   =========================================================================
REM  ================SQL PLUS Environment setup================================
SET serveroutput on size 1000000
SET verify off
SET feedback off
SET pagesize 60
SET arraysize 1
SET echo off
SET line 300
SET TERMOUT ON

REM ============== Show available plan names to SELECT from ===================
PROMPT ===The following are the available plans in this instance:=====
SELECT COMPILE_DESIGNATOR "Plan Name", plan_id "Plan ID"
from MSC_PLANS
order by COMPILE_DESIGNATOR;


REM ============== Define SQL Variables for input parameters ==================
VARIABLE v_plan_id       NUMBER;
VARIABLE  v_plan_name VARCHAR2(10);
VARIABLE v_days_bucket   NUMBER;



REM Get the plan name as we need it to obtain the plan_id.

PROMPT 
UNDEFINE plan_name_enterd

ACCEPT   plan_name_enterd prompt 'Please enter Plan Name: ' 
PROMPT 

REM SET TERMOUT OFF
begin
    :v_plan_name := (rtrim(ltrim('&plan_name_enterd')));
end;
/

DECLARE 
plan_id_entered NUMBER;

begin
SELECT plan_id 
into plan_id_entered
from msc_plans 
where compile_designator = :v_plan_name;
:v_plan_id :=((rtrim(ltrim(plan_id_entered))));
end;
/


REM ============ Spooling the output file======================================

column datevalue new_value mydatevalue 
set termout off
SELECT to_char(sysdate,'ddmmyyyy_hh24mi') datevalue from dual; 
define c1='_'
define pref='mscplan10'
define suff='diag'
define extn='.txt'
define v_spoolfilename ='&pref&c1&mydatevalue&c1&suff&extn'
spool  &v_spoolfilename

REM ========== Getting Plan Options =================================================
SELECT COMPILE_DESIGNATOR "Plan Name",
       DESCRIPTION "Description", 
       plan_id "Plan ID",
       DECODE(CURR_PLAN_TYPE,
       1,'Manufacturing Plan',
       2,'Production Plan',
       3,'Master Plan',
       to_char(CURR_PLAN_TYPE)) "Plan Type"
from msc_plans
where plan_id = :v_plan_id;

PROMPT
PROMPT MAIN TAB
PROMPT ==============================================================

SELECT DECODE(MP.CURR_PART_INCLUDE_TYPE,
       1,'All planned items',
       2,'Demand schedule items and all sales orders',
       3,'Supply schedule items only',
       4,'Demand and supply schedule items only',
       5,'Demand schedule and WIP components',
       6,'Demand schedule items only',
       7,'Demand schedule items/WIP components/all sales orders',
       to_char(MP.CURR_PART_INCLUDE_TYPE)) "Planned Items",
       MAS.ASSIGNMENT_SET_NAME "Assignment Set"
FROM   MSC_PLANS            MP,
       MSC_ASSIGNMENT_SETS  MAS
WHERE  MP.PLAN_ID = :v_plan_id
AND    MP.ASSIGNMENT_SET_ID    = MAS.ASSIGNMENT_SET_ID (+);

col DESCRIPTION format a40 heading 'Demand Priority Rule';
SELECT DECODE(MP.CURR_OPERATION_SCHEDULE_TYPE,
       1,'Operation start date',
       2,'Order start date', 
       to_char(MP.CURR_OPERATION_SCHEDULE_TYPE)) "Material Scheduling Method",
       MSR.DESCRIPTION 
FROM   MSC_PLANS MP, MSC_SCHEDULING_RULES MSR
WHERE  MP.PLAN_ID = :v_plan_id
AND    MP.CURR_DEM_PRIORITY_RULE_ID = MSR.rule_id (+);

col SUBSTITUTION_SET   format a40 heading 'End Item Substitution Set';
SELECT distinct MIS.SUBSTITUTION_SET,
       DECODE(MP.CURR_OVERWRITE_OPTION,
       1,'All',
       2,'Outside planning time fence',
       3,'None',
       to_char(MP.CURR_OVERWRITE_OPTION)) Overwrite
FROM   MSC_PLANS            MP,
       MSC_ITEM_SUBSTITUTES MIS
WHERE  MP.PLAN_ID = :v_plan_id
AND    MP.PLAN_ID = MIS.PLAN_ID (+);

col DEMAND_CLASS  format a40 heading  'Demand Class';
SELECT DEMAND_CLASS
FROM   MSC_PLAN_PARAMETERS_V
WHERE  PLAN_ID= :v_plan_id;

SELECT DECODE(MP.CURR_DEMAND_TIME_FENCE_FLAG,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(MP.CURR_DEMAND_TIME_FENCE_FLAG)) "Demand Time Fence Control",
       DECODE(MP.CURR_APPEND_PLANNED_ORDERS,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(MP.CURR_APPEND_PLANNED_ORDERS)) "Append Planned Orders"
FROM   MSC_PLANS            MP
WHERE  MP.PLAN_ID = :v_plan_id;

SELECT DECODE(MP.CURR_PLANNING_TIME_FENCE_FLAG,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(MP.CURR_PLANNING_TIME_FENCE_FLAG)) "Planning Time Fence Control",
       DECODE(MP.PLAN_INVENTORY_POINT,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(PLAN_INVENTORY_POINT)) "Move Jobs to PIP"
FROM   MSC_PLANS            MP
WHERE  MP.PLAN_ID = :v_plan_id;

SELECT DECODE(NVL(MP.DISPLAY_KPI,1),
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(MP.DISPLAY_KPI)) "Display KPI",
       DECODE(MP.LOT_FOR_LOT_FLAG,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(MP.LOT_FOR_LOT_FLAG)) "Lot for Lot"
FROM   MSC_PLANS            MP
WHERE  MP.PLAN_ID = :v_plan_id;

SELECT DECODE(MP.INCLUDE_CRITICAL_COMPONENTS,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(MP.INCLUDE_CRITICAL_COMPONENTS)) "Include Critical Components"
FROM   MSC_PLANS            MP
WHERE  MP.PLAN_ID = :v_plan_id;

PROMPT
PROMPT ***FORECAST ALLOCATION AND CONSUMPTION ZONE***
PROMPT ----------------------------------------------


SELECT DECODE(NVL(MP.FORECAST_ALLOCATION_METHOD,1), 
       1,'Do Not Spread Forecast',
       2,'Spread Forecast Evenly',
       to_char(MP.FORECAST_ALLOCATION_METHOD)) "Forecast Allocation Method"
FROM   MSC_PLANS            MP
WHERE  MP.PLAN_ID = :v_plan_id;


SELECT DECODE(MP.FORECAST_CONSUMPTION_METHOD,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(MP.FORECAST_CONSUMPTION_METHOD)) "Consume by Forecast Bucket",
       DECODE(MP.EXPLODE_FORECAST,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(MP.EXPLODE_FORECAST)) "Explode Forecast"
FROM   MSC_PLANS            MP
WHERE  MP.PLAN_ID = :v_plan_id;

col CURR_BACKWARD_DAYS  format  a40 heading 'Backward Days';
SELECT CURR_BACKWARD_DAYS  "Backward Days",
       CURR_FORWARD_DAYS   "Forward Days"
FROM   MSC_PLANS
WHERE  PLAN_ID = :v_plan_id;

PROMPT
PROMPT ***PEGGING ZONE****
PROMPT -------------------


SELECT DECODE(MP.CURR_FULL_PEGGING,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(MP.CURR_FULL_PEGGING)) "Enable Pegging",
       DECODE(MP.CURR_PRIORITY_PEGGING,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(MP.CURR_PRIORITY_PEGGING)) "Peg Supply by Demand Priority"
FROM   MSC_PLANS            MP
WHERE  MP.PLAN_ID = :v_plan_id;


SELECT DECODE(MP.CURR_RESERVATION_LEVEL,
       1,'Planning Group',
       2,'Project',
       3,'Project-Task',
       4,'None',
       to_char(MP.CURR_RESERVATION_LEVEL)) "Reservation Level",
       DECODE(MP.CURR_HARD_PEGGING_LEVEL,
       1,'Project',
       2,'Project-Task',
       3,'None',
       to_char(MP.CURR_HARD_PEGGING_LEVEL)) "Hard Pegging Level"
FROM   MSC_PLANS            MP
WHERE  MP.PLAN_ID = :v_plan_id;

PROMPT
PROMPT AGGREGATION TAB
PROMPT ==============================================================

col CURR_START_DATE format a40 heading 'Plan Start Date';
col CURR_CUTOFF_DATE format a40 heading 'Plan End Date';
SELECT CURR_START_DATE,
       CURR_CUTOFF_DATE
FROM   MSC_PLANS
WHERE  PLAN_ID = :v_plan_id;

col "Days Item"      format a20;
col "Days Resources" format a20;
col "Days Routings"  format a20;

SELECT DAILY_CUTOFF_BUCKET "Days Buckets",
       DECODE(DAILY_ITEM_AGGREGATION_LEVEL, 1,'Items',
                                            2,'Product Family',
                                            to_char(DAILY_ITEM_AGGREGATION_LEVEL)) "Days Item",
       DECODE(DAILY_RES_AGGREGATION_LEVEL,  1,'Individual',
                                            2,'Aggregate',
                                            to_char(DAILY_RES_AGGREGATION_LEVEL)) "Days Resources",
       DECODE(DAILY_RTG_AGGREGATION_LEVEL,  1,'Routings',
                                            2,'BOR',
                                            to_char(DAILY_RTG_AGGREGATION_LEVEL)) "Days Routings"
FROM   MSC_PLANS
WHERE  PLAN_ID = :v_plan_id;


col "Weeks Item"      format a20;
col "Weeks Resources" format a20;
col "Weeks Routings"  format a20;

SELECT WEEKLY_CUTOFF_BUCKET "Weeks Buckets",
       DECODE(WEEKLY_ITEM_AGGREGATION_LEVEL,1,'Items',
                                            2,'Product Family',
                                            to_char(WEEKLY_ITEM_AGGREGATION_LEVEL)) "Weeks Item",
       DECODE(WEEKLY_RES_AGGREGATION_LEVEL, 1,'Individual',
                                            2,'Aggregate',
                                            to_char(WEEKLY_RES_AGGREGATION_LEVEL)) "Weeks Resources",
       DECODE(WEEKLY_RTG_AGGREGATION_LEVEL, 1,'Routings',
                                            2,'BOR',
                                            to_char(WEEKLY_RTG_AGGREGATION_LEVEL)) "Weeks Routings"
FROM   MSC_PLANS
WHERE  PLAN_ID = :v_plan_id;

col "Period Item"      format a20;
col "Period Resources" format a20;
col "Period Routings"  format a20;

SELECT PERIOD_CUTOFF_BUCKET "Periods Buckets",
       DECODE(PERIOD_ITEM_AGGREGATION_LEVEL,1,'Items',
                                            2,'Product Family',
                                            to_char(PERIOD_ITEM_AGGREGATION_LEVEL)) "Period Item",
       DECODE(PERIOD_RES_AGGREGATION_LEVEL, 1,'Individual',
                                            2,'Aggregate',
                                            to_char(PERIOD_RES_AGGREGATION_LEVEL)) "Period Resources",
       DECODE(PERIOD_RTG_AGGREGATION_LEVEL, 1,'Routings',
                                            2,'BOR',
                                            to_char(PERIOD_RTG_AGGREGATION_LEVEL)) "Period Routings"
FROM   MSC_PLANS
WHERE  PLAN_ID = :v_plan_id;

PROMPT
PROMPT ORGANIZATIONS TAB
PROMPT ==============================================================

PROMPT
PROMPT ***GLOBAL DEMAND SCHEDULES ZONE***
PROMPT ----------------------------------

REM SELECT INPUT_NAME, 
REM INPUT_SCHEDULE_DESC, 
REM DECODE(DESIGNATOR_TYPE, 
REM 1,'????', 
REM 2,'????', 
REM 3,'????', 
REM to_char(DESIGNATOR_TYPE)) "Type", 
REM DECODE(SHIP_TO_CODE, 
REM 1,'????', 
REM 2,'????', 
REM 3,'????', to_char(SHIP_TO_CODE)) "Ship" 
REM FROM   MSC_PLAN_ORGS_V 
REM WHERE  PLAN_ID = :v_plan_id 
REM ORDER BY INPUT_NAME; 

PROMPT
PROMPT ***ORGANIZATIONS ZONE***
PROMPT ------------------------

col ORGANIZATION_CODE format a10 heading 'ORG';
col NetWIP            format a12 heading 'Net WIP';
col NetReservation    format a12 heading 'Net Reservations';
col NetPurchasing     format a12 heading 'Net Purchases';
col PlanSafetyStock   format a12 heading 'Plan Safety Stock';
col IncludeSalesOrder format a12 heading 'Include SO';
col BILL_OF_RESOURCES format a20 heading 'BOR';
col SIMULATION_SET    format a20 heading 'Simulation Set';
SELECT ORGANIZATION_CODE,
       DECODE(NET_WIP,            1,'Checked',
                                  2,'Unchecked',
                                  NULL,'Unchecked',
                                  to_char(NET_WIP)) NetWip,
       DECODE(NET_RESERVATIONS,   1,'Checked',
                                  2,'Unchecked',
                                  NULL,'Unchecked',
                                  to_char(NET_RESERVATIONS)) NetReservation,
       DECODE(NET_PURCHASING,     1,'Checked',
                                  2,'Unchecked',
                                  NULL,'Unchecked',
                                  to_char(NET_PURCHASING)) NetPurchasing,
       DECODE(PLAN_SAFETY_STOCK,  1,'Checked',
                                  2,'Unchecked',
                                  NULL,'Unchecked',
                                  to_char(PLAN_SAFETY_STOCK)) PlanSafetyStock,
       DECODE(INCLUDE_SALESORDER, 1,'Checked',
                                  2,'Unchecked',
                                  NULL,'Unchecked',
                                  to_char(INCLUDE_SALESORDER)) IncludeSalesOrder,
       BILL_OF_RESOURCES, 
       SIMULATION_SET
FROM   MSC_PLAN_ORGS_V
WHERE  PLAN_ID = :v_plan_id
ORDER BY ORGANIZATION_CODE;

PROMPT
PROMPT ***DEMAND SCHEDULES ZONE***
PROMPT ----------------------------

col INPUT_NAME           format a15 heading 'Schedule Name';
col INPUT_SCHEDULE_DESC  format a30 heading 'Description';
col DESIGNATOR_TYPE_TEXT format a5 heading 'Type';
col InterPlant           format a12 heading 'Inter Plant';
SELECT MSCORG.ORGANIZATION_CODE,
       MPSV.INPUT_NAME,
       MPSV.INPUT_SCHEDULE_DESC,
       MPSV.DESIGNATOR_TYPE_TEXT,
       DECODE(MPSV.INTERPLANT_DEMAND_FLAG, 1,'Checked',
                                      2,'Unchecked',
                                      NULL,'Unchecked',
                                      to_char(INTERPLANT_DEMAND_FLAG)) InterPlant
FROM   MSC_PLAN_SCHED_V MPSV,
       MSC_PLAN_ORGANIZATIONS MSCORG
WHERE  MPSV.PLAN_ID = :v_plan_id
AND    MSCORG.ORGANIZATION_ID = MPSV.ORGANIZATION_ID
AND    MSCORG.sr_instance_id = MPSV.sr_instance_id
AND    MPSV.PLAN_ID = MSCORG.PLAN_ID
AND    MPSV.INPUT_TYPE = 1       -- demand schedule
ORDER BY MSCORG.ORGANIZATION_CODE;

PROMPT
PROMPT *** SUPPLY SCHEDULES ZONE***
PROMPT ----------------------------

SELECT MSCORG.ORGANIZATION_CODE,
       MPSV.INPUT_NAME,
       MPSV.INPUT_SCHEDULE_DESC,
       MPSV.DESIGNATOR_TYPE_TEXT
FROM   MSC_PLAN_SCHED_V MPSV,
       MSC_PLAN_ORGANIZATIONS MSCORG
WHERE  MPSV.PLAN_ID = :v_plan_id
AND    MSCORG.ORGANIZATION_ID = MPSV.ORGANIZATION_ID
AND    MSCORG.sr_instance_id = MPSV.sr_instance_id
AND    MPSV.PLAN_ID = MSCORG.PLAN_ID
AND    MPSV.INPUT_TYPE != 1       -- supply schedule
ORDER BY MSCORG.ORGANIZATION_CODE;

PROMPT
PROMPT CONSTRAINTS TAB
PROMPT ==============================================================

PROMPT 
PROMPT Constrained Plan
PROMPT -----------------

DECLARE 
   l_mat_con  NUMBER;
   l_res_con  NUMBER;

BEGIN
select DAILY_MATERIAL_CONSTRAINTS
  into l_mat_con
  from MSC_PLANS
  WHERE plan_id = :v_plan_id;

SELECT DAILY_RESOURCE_CONSTRAINTS
   INTO  l_res_con
   FROM MSC_PLANS
  WHERE plan_id = :v_plan_id;

IF l_mat_con = 1 or l_res_con = 1 THEN
   DBMS_OUTPUT.PUT_LINE('CHECKED');
ELSE 
   DBMS_OUTPUT.PUT_LINE('UNCHECKED');
END IF;
END;
/

col EnforDmdDt format a25 heading 'Enforce Demand Due Dates';
col EnfCapCons format a30 heading 'Enforce Capacity Constraints';
SELECT DECODE(CURR_ENFORCE_DEM_DUE_DATES,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(CURR_ENFORCE_DEM_DUE_DATES)) EnforDmdDt,
       DECODE(CURR_ENFORCE_CAP_CONSTRAINTS,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(CURR_ENFORCE_CAP_CONSTRAINTS)) EnfCapCons
FROM   MSC_PLANS
WHERE  PLAN_ID = :v_plan_id;

col DAILY_CUTOFF_BUCKET format 999 heading 'Days Buckets';
col DailyResConstraint format a25 heading 'Days Res. Constraint';
col DailyMtlConstraint format a25 heading 'Days Mat. Constraint';
SELECT DAILY_CUTOFF_BUCKET,
       DECODE(DAILY_RESOURCE_CONSTRAINTS,   
       1,'Yes',
       2,'No',
       to_char(DAILY_RESOURCE_CONSTRAINTS)) DailyResConstraint,
       DECODE(DAILY_MATERIAL_CONSTRAINTS,   
       1,'Yes',
       2,'No',
       to_char(DAILY_MATERIAL_CONSTRAINTS)) DailyMtlConstraint
FROM   MSC_PLANS
WHERE  PLAN_ID = :v_plan_id;

col WEEKLY_CUTOFF_BUCKET format 999 heading 'Weeks Buckets';
col WeeklyResConstraint format a25 heading 'Weeks Res. Constraint';
col WeeklyMtlConstraint format a25 heading 'Weeks Mat. Constraint';

SELECT WEEKLY_CUTOFF_BUCKET,
       DECODE(WEEKLY_RESOURCE_CONSTRAINTS,  
       1,'Yes',
       2,'No',
       to_char(WEEKLY_RESOURCE_CONSTRAINTS)) WeeklyResConstraint,
       DECODE(WEEKLY_MATERIAL_CONSTRAINTS,  
       1,'Yes',
       2,'No',
       to_char(WEEKLY_MATERIAL_CONSTRAINTS)) WeeklyMtlConstraint
FROM   MSC_PLANS
WHERE  PLAN_ID = :v_plan_id;

col PERIOD_CUTOFF_BUCKET format 999 heading 'Period Buckets';
col PeriodResConstraint format a25 heading 'Period Res. Constraint';
col PeriodMtlConstraint format a25 heading 'Period Mat. Constraint';

SELECT PERIOD_CUTOFF_BUCKET,
       DECODE(PERIOD_RESOURCE_CONSTRAINTS,  
       1,'Yes',
       2,'No',
       to_char(PERIOD_RESOURCE_CONSTRAINTS)) PeriodResConstraint,
       DECODE(PERIOD_MATERIAL_CONSTRAINTS,  
       1,'Yes',
       2,'No',
       to_char(PERIOD_MATERIAL_CONSTRAINTS)) PeriodMtlConstraint
FROM   MSC_PLANS
WHERE  PLAN_ID = :v_plan_id;

PROMPT
PROMPT ***SCHEDULING ZONE***
PROMPT ----------------------

col DaysBucket          format 99999 heading 'Days Bucket Size';
col MIN_CUTOFF_BUCKET   format 99999 heading 'Minutes Bucket Size';
col HOUR_CUTOFF_BUCKET  format 99999 heading 'Hour Bucket Size';
SELECT MIN_CUTOFF_BUCKET,
       HOUR_CUTOFF_BUCKET,
       DAILY_CUTOFF_BUCKET-MIN_CUTOFF_BUCKET-HOUR_CUTOFF_BUCKET DaysBucket
FROM   MSC_PLANS
WHERE  PLAN_ID = :v_plan_id;

PROMPT 
PROMPT ***RESOURCE REQUIREMENTS ZONE***
PROMPT ---------------------------------

col PlanCapacity format a25 heading 'Calculate Resource Requirements';
col PlannedResource format a25 heading 'Planned Resources';
col CURR_BOTTLENECK_RES_GROUP format a25 heading 'Bottleneck Resource Group';
SELECT DECODE(CURR_PLAN_CAPACITY_FLAG,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(CURR_PLAN_CAPACITY_FLAG)) PlanCapacity,
       DECODE(CURR_PLANNED_RESOURCES,
       1,'All Resources',
       2,'Bottleneck Resources',
       to_char(CURR_PART_INCLUDE_TYPE)) PlannedResource,
       CURR_BOTTLENECK_RES_GROUP
FROM   MSC_PLANS            MP
WHERE  MP.PLAN_ID = :v_plan_id;

PROMPT
PROMPT OPTIMIZATION TAB
PROMPT ==============================================================

col OptimizeFlag  format a12 heading 'Optimize';
col SrcConstraint format a25 heading 'Enforce Sourcing Constraints';
SELECT DECODE(OPTIMIZE_FLAG,                1,'Checked',
                                            2,'Unchecked',
                                            NULL,'Unchecked',
                                            to_char(OPTIMIZE_FLAG)) OptimizeFlag,
       DECODE(CURR_ENFORCE_SRC_CONSTRAINTS, 1, 'Checked',
                                            2, 'Unchecked',
                                            NULL,'Unchecked',
                                            to_char(CURR_ENFORCE_SRC_CONSTRAINTS)) SrcConstraint
FROM   MSC_PLANS MP
WHERE  COMPILE_DESIGNATOR = :v_plan_name;

PROMPT 
PROMPT ***OBJECTIVES ZONE***
PROMPT ----------------------

col OBJECTIVE_WEIGHT_1 format 9999 heading 'Maximize inventory turns';
col OBJECTIVE_WEIGHT_2 format 9999 heading 'Maximize plan profits';
col OBJECTIVE_WEIGHT_4 format 9999 heading 'Maximize on-time delivery';
SELECT OBJECTIVE_WEIGHT_1,
       OBJECTIVE_WEIGHT_2,
       OBJECTIVE_WEIGHT_4
FROM   MSC_PLANS MP
WHERE  COMPILE_DESIGNATOR = :v_plan_name;

PROMPT
PROMPT ***PLAN LEVEL PENALTY FACTORS ZONE***
PROMPT --------------------------------------

col SupCap      format 99999 heading 'Exceeding material capacity';
col ResOver     format 99999 heading 'Exceeding resource capacity';
col TransCap    format 99999 heading 'Exceeding transportation capacity';
col DmdLate     format 99999 heading 'Demand Lateness';
SELECT SUPPLIER_CAP_OVER_UTIL_COST||'%' SupCap,
       RESOURCE_OVER_UTIL_COST||'%' ResOver
FROM   MSC_PLANS MP
WHERE  COMPILE_DESIGNATOR = :v_plan_name;

SELECT TRANSPORT_CAP_OVER_UTIL_COST||'%' TransCap,
       DMD_LATENESS_PENALTY_COST||'%' DmdLate
FROM   MSC_PLANS MP
WHERE  COMPILE_DESIGNATOR = :v_plan_name;

PROMPT
PROMPT DECISION RULES TAB
PROMPT ===================


col UseEndItmSub format a25 heading 'Use End Item Substitution';
col UseAltRes    format a25 heading 'Use Alternate Resources';
col UseSubComps  format a25 heading 'Use Substitute Components';
col UseAltBomRtg format a25 heading 'Use Alternate BOM/ROUTING';
col UseAltSrc    format a25 heading 'Use Alternate Sources';
SELECT DECODE(USE_END_ITEM_SUBSTITUTIONS,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(USE_END_ITEM_SUBSTITUTIONS)) UseEndItmSub,
       DECODE(USE_ALTERNATE_RESOURCES,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(USE_ALTERNATE_RESOURCES))    UseAltRes
FROM   MSC_PLANS MP
WHERE  PLAN_ID = :v_plan_id;


SELECT DECODE(USE_SUBSTITUTE_COMPONENTS,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(USE_SUBSTITUTE_COMPONENTS))  UseSubComps,
       DECODE(USE_ALTERNATE_BOM_ROUTING,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(USE_ALTERNATE_BOM_ROUTING))  UseAltBomRtg,
       DECODE(USE_ALTERNATE_SOURCES,
       1,'Checked',
       2,'Unchecked',
       NULL,'Unchecked',
       to_char(USE_ALTERNATE_SOURCES))      UseAltSrc
FROM   MSC_PLANS MP
WHERE  PLAN_ID = :v_plan_id;

PROMPT
PROMPT PLAN PARAMETERS NAMES WINDOW
PROMPT =============================

col ATP format a15 heading 'ATP';
col Production format a15 heading 'Production';
col Notifications format a15 heading 'Notifications';
col PlanType format a15 heading 'Plan Type';
col DISABLE_DATE format a15 heading 'Inactive Date';
select distinct DECODE(MD.INVENTORY_ATP_FLAG,
       1,'Checked',
       2,'Unchecked',
       to_char(DESIGNATOR_TYPE)) ATP,
       DECODE(MD.PRODUCTION,
       1,'Checked',
       2,'Unchecked',
       to_char(PRODUCTION)) Production,
       DECODE(MD.LAUNCH_WORKFLOW_FLAG,
       1,'Checked',
       2,'Unchecked',
       to_char(MD.LAUNCH_WORKFLOW_FLAG)) Notifications,
       DECODE(MD.DESIGNATOR_TYPE,
       1,'Unchecked',
       2,'Production',
       3,'Manufacturing',
       4,'Master',
       to_char(DESIGNATOR_TYPE)) PlanType,
       DISABLE_DATE 
FROM MSC_DESIGNATORS MD, MSC_PLANS MP
WHERE MD.DESIGNATOR = 'dtest2'
and MD.SR_INSTANCE_ID = MP.SR_INSTANCE_ID
AND MD.ORGANIZATION_ID = MP.ORGANIZATION_ID 
AND DESIGNATOR_TYPE IN (2,3,4) 
AND NVL(COPY_DESIGNATOR_ID,-1) = -1;


PROMPT ' '
PROMPT ' '
PROMPT END OF FILE


spool off