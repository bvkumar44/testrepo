col usr for a6
col sid for 9999
col module for a35 trunc
col action for a35 trunc
col used_ublk for 9999999999999999
set lines 130
set pages 1000
select username usr,sid,module,action,USED_UBLK,a.status,last_call_et from v$session a,v$transaction b where a.saddr = b.ses_addr and used_ublk >1
order by 5
/
