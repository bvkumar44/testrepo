set serveroutput on
DECLARE
  l_user_id NUMBER;
  CURSOR C1
  IS
    SELECT * FROM APPS_RO.USER_RESP_REQUESTS ;
BEGIN
  FOR I IN C1
  LOOP

    begin
       SELECT user_id INTO l_user_id FROM apps.fnd_user WHERE user_name=i.user_name;

         exception 
       when no_data_found
       then 
       dbms_output.put_line('User name'|| i.user_name|| ' does not exist');
      end;

    FND_USER_RESP_GROUPS_API.UPLOAD_ASSIGNMENT (l_USER_ID, -- User id of the user
      I.RESPONSIBILITY_ID,                                   -- Responsibility id for application admin
      I.APPLICATION_ID,                       -- Responsibility_application_id
      0,                                                     -- Security_group_id
      SYSDATE,                                               -- Start_date
      NULL,                                                  -- End_date
      NULL                                                   -- Description
      );

   END LOOP;
  COMMIT;
END;
/