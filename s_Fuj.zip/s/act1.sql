set pages 500
set lines 145
col object_name for a30
col module for a20 trunc
col action for a10 trunc 
col uname for a10 trunc
col event for a20 trunc
col mac for a15 trunc
col sql_id for a15
select inst_id isid,sid,serial#,action,module,last_call_et,status,event,machine mac,sql_id,to_char(logon_time,'dd/mm hh24:mi') dt
 from gv$session
where 1=1
and status='ACTIVE'
and event not like 'pipe%'
and event not like 'Streams%'
and event not like 'jobq slave%'
order by machine;