select name from v$database@&DBLink
/