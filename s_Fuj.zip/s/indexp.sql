col index_owner for a15
col column_expression for a50
select index_owner,index_name,column_expression,column_position from dba_ind_expressions where index_name='&index_name'
/
