undefine sql_id
set lines 160 pages 5000
--select * from TABLE(dbms_xplan.display_cursor('&sql_id',null,'ADVANCED'));
select * from TABLE(dbms_xplan.display_cursor('&sql_id',null,null));