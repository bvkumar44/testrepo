SELECT A.user_concurrent_program_name, NAME
  FROM fnd_concurrent_programs_tl A, fnd_concurrent_programs B, (SELECT NAME FROM v$database) 
  WHERE  user_concurrent_program_name 
IN ('Cost Manager','Manager: Lot Move Transactions','Process transaction interface','WIP Move Transaction Manager','Planning Manager')
AND a.application_id = b.application_id 
 AND a.concurrent_program_id = b.concurrent_program_id
AND   '1'  NOT IN    (SELECT '1' FROM fnd_concurrent_requests WHERE program_application_id = a.application_id   AND concurrent_program_id = a.concurrent_program_id  AND PHASE_CODE IN ('P','R'))
UNION -- Managers running for more than 30 minutes
SELECT A.user_concurrent_program_name, NAME  
  FROM fnd_concurrent_programs_tl A, fnd_concurrent_programs B, (SELECT NAME FROM v$database) D1
  WHERE  user_concurrent_program_name IN ('Cost Manager','Manager: Lot Move Transactions','Process transaction interface','WIP Move Transaction Manager','Planning Manager')
AND a.application_id = b.application_id 
 AND a.concurrent_program_id = b.concurrent_program_id
 AND    '1'  IN    (SELECT '1' FROM fnd_concurrent_requests WHERE program_application_id = a.application_id   AND concurrent_program_id = a.concurrent_program_id  AND PHASE_CODE = 'R'   AND actual_start_date <  SYSDATE  - (30/1440))
/
