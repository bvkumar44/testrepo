begin
mo_global.set_org_context(522,null,'SQLAP');
end;
/