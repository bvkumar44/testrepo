 select a.sid,serial#,action,module,last_call_et,status,event,username
  from v$session a,v$session_wait b
 where a.sid = b.sid
and event not like '%SQL%'
/
