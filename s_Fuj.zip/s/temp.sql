ttitle off
set linesize 132
column program form a22 wrap
column module form a12
column count form 999999
column bytes form 99,999,999,999,999
column extents form 999,999,999
column username form a14
column tablespace form a14
column contents form a14
compute sum of count on report
compute sum of bytes on report
compute sum of extents on report
break on report
SELECT s.sid,
       u.tablespace,
       u.contents,
       count(*) count,
       s.username,
      sum(u.extents) extents,
      sum(u.blocks*8192) bytes,
       s.program program,
       s.module
FROM v$session s, v$sort_usage u
WHERE s.saddr=u.session_addr
group by s.sid,s.program,s.module,s.username, u.tablespace, u.contents;
