col machine for a40
col module for a40
set lines 140 pages 1000
select machine,count(*) from gv$session where type!='BACKGROUND' group by machine order by 2 desc;