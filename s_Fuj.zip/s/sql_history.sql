set lines 140
col sql_profile for a30
col ela for 999999.99
col rows_processed_delta for 99999999
col executions_delta for 99999999999
col module for a10 trunc
select to_char(begin_interval_time,'mm/dd/yyyy hh24:mi') dt,
dhss.instance_number ins,
plan_hash_value,executions_delta,rows_processed_delta,sql_profile,(elapsed_time_delta/1000000) ela,
module
from dba_hist_sqlstat dhss,
dba_hist_snapshot dhs
where dhss.sql_id = '&sqlid'
and dhss.snap_id=dhs.snap_id
and dhss.instance_Number=dhs.instance_number
and begin_interval_time >= sysdate-3
order by begin_interval_time desc
/
