select request_id,to_char(ACTUAL_COMPLETION_DATE,'dd/mm/rr hh24:mi') dt,status_code,phase_code 
from fnd_concurrent_requests 
where status_code = 'E'
and phase_code = 'C'
and ACTUAL_COMPLETION_DATE >= to_date('03/03/08 19:10','DD/MM/RR HH24:MI')
and ACTUAL_COMPLETION_DATE <= to_date('03/03/08 19:25','DD/MM/RR HH24:MI')
/
