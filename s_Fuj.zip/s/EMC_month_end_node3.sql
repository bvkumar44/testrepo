spool emc_month_end_node3.lst;
set long 200000 ;
set lines 120 ;
set pages 0 ;
col sql_text for a80 word_wrapped ;
select sql_id,sql_text from dba_hist_sqltext
where sql_id in 
(
'8juvhx65t09u9',
'4uz6f7fa6wfxc',
'0j6s6vg0vpuvj',
'c4x145ubsx5hh',
'3qm9xd9a5q6q0',
'1f2urrjr5b7w7',
'8djgfqk5kmpzg',
'd52hdha71s92p',
'3vf06m366bumb',
'8shafw9p6gb6c',
'5wk03bur65nn3',
'c95pt37d9a0qw',
'8az3vrj1kbgbx',
'54tq89k6qy848',
'28dut2vb0rr60',
'09hrug39nj9ca',
'9rj8123zm8hra',
'329g1up9q3s6z',
'4xr1cpdz0ff8w',
'g9q7uwp6br59n',
'3d0nmp4wx049r',
'bhrk381uf43n6',
'9xqh9sm9uv572',
'0gy4js4qcjnbn',
'98s503n89xatw'  )  ;
spool off ;
