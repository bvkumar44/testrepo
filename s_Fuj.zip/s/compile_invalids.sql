DECLARE

BEGIN
for j in 1..2 loop
FOR CR in (select object_name from all_objects where status = 'INVALID' and object_type = 'VIEW' AND OWNER = 'APPS') LOOP
  BEGIN
    EXECUTE IMMEDIATE 'ALTER VIEW APPS.'||CR.OBJECT_NAME||' COMPILE';
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
END LOOP;
end loop;
COMMIT;

for k in 1..3 loop
FOR CR in (select object_name from all_objects where status = 'INVALID' and object_type = 'PACKAGE' AND OWNER = 'APPS') LOOP
  BEGIN
    EXECUTE IMMEDIATE 'ALTER PACKAGE '||CR.OBJECT_NAME||' COMPILE';
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
END LOOP;
end loop;
COMMIT;

FOR CR in (select object_name from all_objects where status = 'INVALID' and object_type = 'PACKAGE BODY' AND OWNER = 'APPS') LOOP
  BEGIN
    EXECUTE IMMEDIATE 'ALTER PACKAGE '||CR.OBJECT_NAME||' COMPILE BODY';
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
END LOOP;
COMMIT;

END;