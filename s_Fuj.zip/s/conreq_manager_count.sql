select  count(1) cnt,a.concurrent_queue_id mgrid,b.user_concurrent_queue_name mgrname
from    apps.fnd_concurrent_processes a,
        apps.fnd_concurrent_queues_vl b,
        apps.fnd_concurrent_requests c
where   a.concurrent_queue_id = b.concurrent_queue_id
and     c.controlling_manager = a.concurrent_process_id
and     c.actual_start_date >sysdate-40
group by a.concurrent_queue_id,b.user_concurrent_queue_name
/
