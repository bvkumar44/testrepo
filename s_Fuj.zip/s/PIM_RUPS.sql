select 'Current PIM Patch Level: '||ver||' ('||bug||')' "Description" from (
select x.* from
(select 1 seq,  '2714179' bug,'11.5.0' pv,'11i.EGO.A' ver from dual
union select 2, '3001751','11.5.0','11i.EGO.B' from dual
union select 3, '3298205','11.5.0','11i.EGO.C' from dual
union select 4, '3990439','11.5.0','11i.PLM_PF.D' from dual
union select 5, '4203793','11.5.0','11i.PLM_PF.E' from dual
union select 6, '4508296','12.0.0','R12.PLM_PF.A' from dual
union select 7, '6658960','12.0.0','R12.PLM_PF.B' from dual
union select 8,'10196957','12.0.0','R12.PLM_PF.C' from dual
) x,
(select product_version pv from fnd_product_installations
where application_id=431) i, ad_bugs bugs
where x.bug = bugs.bug_number and x.pv = i.pv order by 1 desc) where rownum = 1
union
select 'Current PIM Rollup: '||ver||' ('||bug||')' "Description" from (
select x.* from
( select 2 seq, '4574625' bug,'11.5.0' pv,'E2' ver from dual
union select 3, '4662995','11.5.0','E3' from dual
union select 4, '4743765','11.5.0','E4' from dual
union select 5, '4894197','11.5.0','E5' from dual
union select 6, '5031825','11.5.0','E6' from dual
union select 7, '5170870','11.5.0','E7' from dual
union select 8, '5239326','11.5.0','E8' from dual
union select 9, '5462432','11.5.0','E9' from dual
union select 10,'5671752','11.5.0','E10' from dual
union select 11,'5892657','11.5.0','E11' from dual
union select 12,'6192001','11.5.0','E12' from dual
union select 13,'6459400','11.5.0','E13' from dual
union select 14,'7037537','11.5.0','E14' from dual
union select 15,'7478311','11.5.0','E15' from dual
union select 16,'7705829','11.5.0','E16' from dual
union select 17,'8312398','11.5.0','E17' from dual
union select 18,'8540418','11.5.0','E18' from dual
union select 19,'8765480','11.5.0','E19' from dual
union select 20,'9153710','11.5.0','E20' from dual
union select 21,'9438994','11.5.0','E21' from dual
union select 22,'10098682','11.5.0','E22' from dual
union select 23,'8445429','12.0.0','R12 RUP7 PIM' from dual
) x,
(select product_version pv from fnd_product_installations
where application_id=431) i, ad_bugs bugs
where x.bug = bugs.bug_number and x.pv = i.pv order by 1 desc) where rownum = 1
union
select 'Product Installation: '||patch_level||': '||decode(status,
'I','Installed','S','Shared','Not Installed')
from fnd_product_installations
where application_id=431
order by 1;
