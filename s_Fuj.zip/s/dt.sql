select 	to_char(sysdate,'dd/mm/rr hh:mi') dt1,
	to_char((to_date(to_char(sysdate,'ddmmrr hh:mi'),'ddmmrr hh:mi') - 1230),'dd/mm/rr hh:mi') dt 
from dual
/
