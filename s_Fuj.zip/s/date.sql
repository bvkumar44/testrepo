select sysdate,systimestamp from dual
/