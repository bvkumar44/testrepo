col owner for a10 trunc
col db_link for a25 trunc
col username for a10 trunc
col host for a20 trunc
col created for a10 trunc
set lines 120
set pages 500
select * from dba_db_links;