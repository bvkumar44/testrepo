set pages 500
set lines 140
col module for a40 trunc
col action for a20 trunc noprint
col uname for a10 trunc
col event for a20 trunc

select 	request_id,s.sid sid,s.serial# serial,to_char(logon_time,'dd/mm hh24:mi') dt,s.module module,s.action action,user_name uname,sw.event
from	apps.v$session_wait sw,apps.v$session s,apps.v$process p,apps.fnd_concurrent_requests fnd,apps.fnd_user fndu
where 	sw.sid = s.sid
and	p.addr = s.paddr
and	p.spid = fnd.oracle_process_id
and     fnd.requested_by = fndu.user_id
and	fnd.status_code = 'R'
and	fnd.phase_code = 'R'
order by 1
/