select to_char(ACTUAL_START_DATE,'HH:MI:SS'),to_char(ACTUAL_COMPLETION_DATE,'HH:MI:SS'),argument_text from fnd_concurrent_requests
where CONCURRENT_PROGRAM_ID=&program_id order by 1
/
