set lines 150
col pct_temp_used for 999999
col mb_used for 999999
select 100*(u.tot/d.tot) "pct_temp_used" FROM
     (select sum(u.blocks) tot from gv$tempseg_usage u) u,
     (select sum(d.blocks) tot from dba_temp_files d) d;
col module for a30 trunc
col tablespace for a20 trunc
SELECT   S.sid,s.serial#, S.module,
         SUM (T.blocks) * TBS.block_size / 1024 / 1024 mb_used, 
  T.tablespace
FROM     gv$sort_usage T, gv$session S, dba_tablespaces TBS
WHERE    T.session_addr = S.saddr
AND	 T.inst_id = s.inst_id
AND      T.tablespace = TBS.tablespace_name
GROUP BY S.sid,S.serial#, S.module,TBS.block_size, T.tablespace
having SUM (T.blocks) * TBS.block_size / 1024 / 1024>50
order by 3;
col message for a100
select sid,message,sofar,totalwork,time_remaining from gv$session_longops where sofar!=totalwork;