col ublk for 99999999
col ubytes for 99999999

select segment_name, sum(blocks) ublk, sum(bytes)/1024 ubytes
from dba_undo_extents
where tablespace_name = 'APPS_UNDO'
group by segment_name
order by 2
/