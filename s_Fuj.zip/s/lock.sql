SELECT DECODE(request,0,'Holder: ','Waiter: ')||trim(sid) sess,
         id1, id2, lmode, request, type
    FROM V$LOCK
   WHERE sid !=1297 and (id1, id2, type) IN
             (SELECT id1, id2, type FROM V$LOCK WHERE sid !=1297 and request>0)
   ORDER BY id1, request
/
