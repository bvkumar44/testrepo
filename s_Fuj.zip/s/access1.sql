col sid for 99999
col owner for a10
col object for a20
col object for a30
col type for a15
set linesize 700
set pagesize 500
select * from gv$access where object like ('%&obj%')
/