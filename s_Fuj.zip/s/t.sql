set lines 130
undefine tname
col column_name for a30 head "col_nam"
col owner for a13
col table_name for a30 head "tab_name"
col table_owner for a13
col num_distinct for 99999999999 head "num_dist"
col index_name for a30 head "index_name"
col column_position for 99
col gb for 999
col mb for 99999
select 'EUEBQ' FROM DUAL;
select index_name,status,owner,table_owner,table_name from dba_indexes_GCEBQ where table_name=upper('&&tname') order by 1,2;
select index_name,column_name,column_position from dba_ind_columns_GCEBQ where table_name=upper('&&tname') order by 1,3,2;

select 'EUEBP' FROM DUAL;
select index_name,column_name,column_position from dba_ind_columns_EUEBP where table_name=upper('&&tname') order by 1,3,2;
select index_name,status,owner,table_owner,table_name from dba_indexes_EUEBP where table_name=upper('&&tname') order by 1,2;

