SQL> @longreq

REQUEST_ID        SID     SERIAL DT          MODULE                                   UNAME      EVENT
---------- ---------- ---------- ----------- ---------------------------------------- ---------- --------------------
  53164509       1250          9 17/05 11:16 INCFDH                                   OLSSONLA   enq: SS - contention
  53281994       2584          3 17/05 11:16 XXMRPCMPAR                               NAPOLIM    enq: SS - contention
  53291738       2589         24 17/05 11:16 01@<plcust/eucvsprd/XXAR/11.5.0/sql/MRAA GRANJACE   PL/SQL lock timer
  53293404       3948         13 17/05 11:16 MRCSAL1                                  OPRAMOM    enq: SS - contention
  53293607       3914         75 17/05 11:16 WSHINTERFACES                            MEYKNEFV   enq: SS - contention
  53293695       2632         22 17/05 11:16 INCFDH                                   OLSSONLA   enq: SS - contention
  53293902       2615         51 17/05 11:16 INV_CONSOLIDATE_ONHAND                   VERHARMA   enq: SS - contention
  53293918       3924       1566 17/05 11:16 01@<ust/eucvsprd/XXINV/11.5.0/sql/XXINVS BOZZOLP    PL/SQL lock timer
  53294015       1252       1646 17/05 11:16 INV_CONSOLIDATE_ONHAND                   VERHARMA   enq: SS - contention
  53294281       3916        100 17/05 11:16 INV_CONSOLIDATE_ONHAND                   VERHARMA   enq: SS - contention
  53294294       1242          1 17/05 11:16 CYCROL                                   FROQUEPA   db file sequential r
  53294575       2572         44 17/05 11:16 XXMRPCMPAR                               FERRA1A    enq: SS - contention
  53294647       1245         31 17/05 11:16 ALECDC                                   GRANJACE   enq: SS - contention
  53295259       1243         58 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295300       2579        237 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295330       2576         63 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295422       3910        202 17/05 11:16 XXMRPCMPAR                               NAPOLIM    enq: SS - contention
  53295453       2566         78 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295500       2567         97 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295580       1290         63 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295609       3880          4 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295657       1236        123 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295716       3913        395 17/05 11:17 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295732       1247        121 17/05 11:17 XXMRPCMPAR                               PORTAA     enq: SS - contention
  53297787       2585        379 17/05 11:19 ALECDC                                   GRANJACE   enq: SS - contention
  53298347       2530         71 17/05 11:19 ALECDC                                   GRANJACE   enq: SS - contention
  53299864       3871        224 17/05 11:20 ALECDC                                   GRANJACE   enq: SS - contention
  53300555       1238        366 17/05 11:21 ALECDC                                   JAGADES    enq: SS - contention
  53301502       2580          2 17/05 11:16 01@<t/eucvsprd/XXBOM/11.5.0/sql/XXBOMPIL ERKELEJA   PL/SQL lock timer
  53301633       1206        842 17/05 11:21 ALECDC                                   GRANJACE   enq: SS - contention
  53301634       1201        182 17/05 11:22 ALECDC                                   GRANJACE   enq: SS - contention
  53302444       2637        316 17/05 11:28 ALECDC                                   GRANJACE   enq: SS - contention
  53305264       1262         84 17/05 11:05 01@<gr/eucvsprd/appl/fnd/11.5.0/sql/aflo APPSMGR    rdbms ipc reply
  53315409       2601         58 17/05 11:05 FNDGSCST                                 SYSADMIN   sort segment request
  53317479       3926         17 17/05 11:05 ALECDC                                   PACHIGKP   enq: SS - contention
  53317556       1260          7 17/05 11:05 ALECDC                                   PACHIGKP   enq: SS - contention
  53317642       1248         41 17/05 11:16 01@<pplcust/eucvsprd/XXEC/11.5.0/sql/XXE JAKOBSCU   enq: SS - contention

37 rows selected.

SQL> @longreq

REQUEST_ID        SID     SERIAL DT          MODULE                                   UNAME      EVENT
---------- ---------- ---------- ----------- ---------------------------------------- ---------- --------------------
  53164509       1250          9 17/05 11:16 INCFDH                                   OLSSONLA   enq: SS - contention
  53281994       2584          3 17/05 11:16 XXMRPCMPAR                               NAPOLIM    enq: SS - contention
  53291738       2589         24 17/05 11:16 01@<plcust/eucvsprd/XXAR/11.5.0/sql/MRAA GRANJACE   PL/SQL lock timer
  53293404       3948         13 17/05 11:16 MRCSAL1                                  OPRAMOM    enq: SS - contention
  53293607       3914         75 17/05 11:16 WSHINTERFACES                            MEYKNEFV   enq: SS - contention
  53293695       2632         22 17/05 11:16 INCFDH                                   OLSSONLA   enq: SS - contention
  53293902       2615         51 17/05 11:16 INV_CONSOLIDATE_ONHAND                   VERHARMA   enq: SS - contention
  53293918       3924       1566 17/05 11:16 01@<ust/eucvsprd/XXINV/11.5.0/sql/XXINVS BOZZOLP    PL/SQL lock timer
  53294015       1252       1646 17/05 11:16 INV_CONSOLIDATE_ONHAND                   VERHARMA   enq: SS - contention
  53294281       3916        100 17/05 11:16 INV_CONSOLIDATE_ONHAND                   VERHARMA   enq: SS - contention
  53294294       1242          1 17/05 11:16 CYCROL                                   FROQUEPA   SQL*Net message from
  53294575       2572         44 17/05 11:16 XXMRPCMPAR                               FERRA1A    enq: SS - contention
  53294647       1245         31 17/05 11:16 ALECDC                                   GRANJACE   enq: SS - contention
  53295259       1243         58 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295300       2579        237 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295330       2576         63 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295422       3910        202 17/05 11:16 XXMRPCMPAR                               NAPOLIM    enq: SS - contention
  53295453       2566         78 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295500       2567         97 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295580       1290         63 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295609       3880          4 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295657       1236        123 17/05 11:16 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295716       3913        395 17/05 11:17 01@<cust/eucvsprd/XXEC/11.5.0/sql/XXECED KARLSSPE   enq: SS - contention
  53295732       1247        121 17/05 11:17 XXMRPCMPAR                               PORTAA     enq: SS - contention
  53297787       2585        379 17/05 11:19 ALECDC                                   GRANJACE   enq: SS - contention
  53298347       2530         71 17/05 11:19 ALECDC                                   GRANJACE   enq: SS - contention
  53299864       3871        224 17/05 11:20 ALECDC                                   GRANJACE   enq: SS - contention
  53300555       1238        366 17/05 11:21 ALECDC                                   JAGADES    enq: SS - contention
  53301502       2580          2 17/05 11:16 01@<t/eucvsprd/XXBOM/11.5.0/sql/XXBOMPIL ERKELEJA   PL/SQL lock timer
  53301633       1206        842 17/05 11:21 ALECDC                                   GRANJACE   enq: SS - contention
  53301634       1201        182 17/05 11:22 ALECDC                                   GRANJACE   enq: SS - contention
  53302444       2637        316 17/05 11:28 ALECDC                                   GRANJACE   enq: SS - contention
  53305264       1262         84 17/05 11:05 01@<gr/eucvsprd/appl/fnd/11.5.0/sql/aflo APPSMGR    rdbms ipc reply
  53315409       2601         58 17/05 11:05 FNDGSCST                                 SYSADMIN   sort segment request
  53317479       3926         17 17/05 11:05 ALECDC                                   PACHIGKP   enq: SS - contention
  53317556       1260          7 17/05 11:05 ALECDC                                   PACHIGKP   enq: SS - contention
  53317642       1248         41 17/05 11:16 01@<pplcust/eucvsprd/XXEC/11.5.0/sql/XXE JAKOBSCU   enq: SS - contention

37 rows selected.

SQL> @locks

SESS                   ID1        ID2      LMODE    REQUEST TY
--------------- ---------- ---------- ---------- ---------- --
Holder: 2601             2          1          6          0 SS
Waiter: 3925             2          1          0          6 SS
Waiter: 3946             2          1          0          6 SS
Waiter: 3977             2          1          0          6 SS
Waiter: 3912             2          1          0          6 SS
Waiter: 3948             2          1          0          6 SS
Waiter: 3871             2          1          0          6 SS
Waiter: 3930             2          1          0          6 SS
Waiter: 3913             2          1          0          6 SS
Waiter: 3916             2          1          0          6 SS
Waiter: 3880             2          1          0          6 SS
Waiter: 3910             2          1          0          6 SS
Waiter: 3914             2          1          0          6 SS
Waiter: 3953             2          1          0          6 SS
Waiter: 3958             2          1          0          6 SS
Waiter: 3926             2          1          0          6 SS
Waiter: 2625             2          1          0          6 SS
Waiter: 2656             2          1          0          6 SS
Waiter: 2528             2          1          0          6 SS
Waiter: 2632             2          1          0          6 SS
Waiter: 2574             2          1          0          6 SS
Waiter: 2529             2          1          0          6 SS
Waiter: 2637             2          1          0          6 SS
Waiter: 2585             2          1          0          6 SS
Waiter: 2530             2          1          0          6 SS
Waiter: 2603             2          1          0          6 SS
Waiter: 2615             2          1          0          6 SS
Waiter: 2567             2          1          0          6 SS
Waiter: 2566             2          1          0          6 SS
Waiter: 2579             2          1          0          6 SS
Waiter: 2576             2          1          0          6 SS
Waiter: 2584             2          1          0          6 SS
Waiter: 2572             2          1          0          6 SS
Waiter: 2575             2          1          0          6 SS
Waiter: 2630             2          1          0          6 SS
Waiter: 1257             2          1          0          6 SS
Waiter: 1278             2          1          0          6 SS
Waiter: 1196             2          1          0          6 SS
Waiter: 1315             2          1          0          6 SS
Waiter: 1250             2          1          0          6 SS
Waiter: 1316             2          1          0          6 SS
Waiter: 1259             2          1          0          6 SS
Waiter: 1193             2          1          0          6 SS
Waiter: 1198             2          1          0          6 SS
Waiter: 1245             2          1          0          6 SS
Waiter: 1201             2          1          0          6 SS
Waiter: 1206             2          1          0          6 SS
Waiter: 1238             2          1          0          6 SS
Waiter: 1247             2          1          0          6 SS
Waiter: 1236             2          1          0          6 SS
Waiter: 1252             2          1          0          6 SS
Waiter: 1290             2          1          0          6 SS
Waiter: 1243             2          1          0          6 SS
Waiter: 1248             2          1          0          6 SS
Waiter: 1244             2          1          0          6 SS
Waiter: 1295             2          1          0          6 SS
Waiter: 1293             2          1          0          6 SS
Waiter: 1260             2          1          0          6 SS
Holder: 3958       1900578    3449469          6          0 TX
Waiter: 1318       1900578    3449469          0          6 TX
Holder: 1318       2359319    1043554          6          0 TX
Waiter: 3963       2359319    1043554          0          6 TX
Waiter: 2610       2359319    1043554          0          6 TX
Waiter: 2590       2359319    1043554          0          6 TX
Waiter: 1289       2359319    1043554          0          6 TX
Waiter: 1296       2359319    1043554          0          6 TX
Waiter: 3965       2359319    1043554          0          6 TX
Waiter: 3876       2359319    1043554          0          6 TX
Waiter: 3959       2359319    1043554          0          6 TX
Waiter: 2570       2359319    1043554          0          6 TX

70 rows selected.

SQL> @sesses
Enter value for sid: 2601
old  10: and s.sid = &sid
new  10: and s.sid = 2601

Session Info
--------------------------------------------------------------------------------
 Sid, Serial#, Aud sid : 2601 , 58 , 128737618
     DB User / OS User : APPS   /   applmgr
    Machine - Terminal : usahsarmp093  -
FNDGSCST-Concurrent Request        OS Process Ids : 18565 (Client)  5623 - 186 (
Server)
   Client Program Name :


SQL> alter system kill session '2601,58';
alter system kill session '2601,58'
*
ERROR at line 1:
ORA-00031: session marked for kill


SQL>
SQL> @locks

SESS                   ID1        ID2      LMODE    REQUEST TY
--------------- ---------- ---------- ---------- ---------- --
Holder: 2601             2          1          6          0 SS
Waiter: 3925             2          1          0          6 SS
Waiter: 3946             2          1          0          6 SS
Waiter: 3977             2          1          0          6 SS
Waiter: 3912             2          1          0          6 SS
Waiter: 3948             2          1          0          6 SS
Waiter: 3871             2          1          0          6 SS
Waiter: 3930             2          1          0          6 SS
Waiter: 3913             2          1          0          6 SS
Waiter: 3916             2          1          0          6 SS
Waiter: 3880             2          1          0          6 SS
Waiter: 3910             2          1          0          6 SS
Waiter: 3914             2          1          0          6 SS
Waiter: 3953             2          1          0          6 SS
Waiter: 3958             2          1          0          6 SS
Waiter: 3926             2          1          0          6 SS
Waiter: 2625             2          1          0          6 SS
Waiter: 2656             2          1          0          6 SS
Waiter: 2528             2          1          0          6 SS
Waiter: 2632             2          1          0          6 SS
Waiter: 2574             2          1          0          6 SS
Waiter: 2529             2          1          0          6 SS
Waiter: 2637             2          1          0          6 SS
Waiter: 2585             2          1          0          6 SS
Waiter: 2530             2          1          0          6 SS
Waiter: 2603             2          1          0          6 SS
Waiter: 2615             2          1          0          6 SS
Waiter: 2567             2          1          0          6 SS
Waiter: 2566             2          1          0          6 SS
Waiter: 2579             2          1          0          6 SS
Waiter: 2576             2          1          0          6 SS
Waiter: 2584             2          1          0          6 SS
Waiter: 2572             2          1          0          6 SS
Waiter: 2575             2          1          0          6 SS
Waiter: 2630             2          1          0          6 SS
Waiter: 1257             2          1          0          6 SS
Waiter: 1278             2          1          0          6 SS
Waiter: 1196             2          1          0          6 SS
Waiter: 1315             2          1          0          6 SS
Waiter: 1250             2          1          0          6 SS
Waiter: 1316             2          1          0          6 SS
Waiter: 1259             2          1          0          6 SS
Waiter: 1193             2          1          0          6 SS
Waiter: 1198             2          1          0          6 SS
Waiter: 1245             2          1          0          6 SS
Waiter: 1201             2          1          0          6 SS
Waiter: 1206             2          1          0          6 SS
Waiter: 1238             2          1          0          6 SS
Waiter: 1247             2          1          0          6 SS
Waiter: 1236             2          1          0          6 SS
Waiter: 1252             2          1          0          6 SS
Waiter: 1290             2          1          0          6 SS
Waiter: 1243             2          1          0          6 SS
Waiter: 1248             2          1          0          6 SS
Waiter: 1244             2          1          0          6 SS
Waiter: 1295             2          1          0          6 SS
Waiter: 1293             2          1          0          6 SS
Waiter: 1260             2          1          0          6 SS
Holder: 3958       1900578    3449469          6          0 TX
Waiter: 1318       1900578    3449469          0          6 TX
Holder: 1318       2359319    1043554          6          0 TX
Waiter: 3963       2359319    1043554          0          6 TX
Waiter: 2610       2359319    1043554          0          6 TX
Waiter: 2590       2359319    1043554          0          6 TX
Waiter: 1289       2359319    1043554          0          6 TX
Waiter: 1296       2359319    1043554          0          6 TX
Waiter: 3965       2359319    1043554          0          6 TX
Waiter: 3876       2359319    1043554          0          6 TX
Waiter: 3959       2359319    1043554          0          6 TX
Waiter: 2570       2359319    1043554          0          6 TX

70 rows selected.

SQL> @locks

SESS                   ID1        ID2      LMODE    REQUEST TY
--------------- ---------- ---------- ---------- ---------- --
Holder: 2601             2          1          6          0 SS
Waiter: 3925             2          1          0          6 SS
Waiter: 3946             2          1          0          6 SS
Waiter: 3977             2          1          0          6 SS
Waiter: 3912             2          1          0          6 SS
Waiter: 3948             2          1          0          6 SS
Waiter: 3871             2          1          0          6 SS
Waiter: 3930             2          1          0          6 SS
Waiter: 3913             2          1          0          6 SS
Waiter: 3916             2          1          0          6 SS
Waiter: 3880             2          1          0          6 SS
Waiter: 3910             2          1          0          6 SS
Waiter: 3914             2          1          0          6 SS
Waiter: 3953             2          1          0          6 SS
Waiter: 3958             2          1          0          6 SS
Waiter: 3926             2          1          0          6 SS
Waiter: 2524             2          1          0          6 SS
Waiter: 2625             2          1          0          6 SS
Waiter: 2656             2          1          0          6 SS
Waiter: 2528             2          1          0          6 SS
Waiter: 2632             2          1          0          6 SS
Waiter: 2574             2          1          0          6 SS
Waiter: 2529             2          1          0          6 SS
Waiter: 2637             2          1          0          6 SS
Waiter: 2585             2          1          0          6 SS
Waiter: 2530             2          1          0          6 SS
Waiter: 2603             2          1          0          6 SS
Waiter: 2615             2          1          0          6 SS
Waiter: 2567             2          1          0          6 SS
Waiter: 2566             2          1          0          6 SS
Waiter: 2579             2          1          0          6 SS
Waiter: 2576             2          1          0          6 SS
Waiter: 2584             2          1          0          6 SS
Waiter: 2572             2          1          0          6 SS
Waiter: 2575             2          1          0          6 SS
Waiter: 2630             2          1          0          6 SS
Waiter: 1257             2          1          0          6 SS
Waiter: 1278             2          1          0          6 SS
Waiter: 1196             2          1          0          6 SS
Waiter: 1315             2          1          0          6 SS
Waiter: 1250             2          1          0          6 SS
Waiter: 1316             2          1          0          6 SS
Waiter: 1259             2          1          0          6 SS
Waiter: 1193             2          1          0          6 SS
Waiter: 1198             2          1          0          6 SS
Waiter: 1245             2          1          0          6 SS
Waiter: 1201             2          1          0          6 SS
Waiter: 1206             2          1          0          6 SS
Waiter: 1238             2          1          0          6 SS
Waiter: 1247             2          1          0          6 SS
Waiter: 1236             2          1          0          6 SS
Waiter: 1252             2          1          0          6 SS
Waiter: 1290             2          1          0          6 SS
Waiter: 1243             2          1          0          6 SS
Waiter: 1248             2          1          0          6 SS
Waiter: 1244             2          1          0          6 SS
Waiter: 1295             2          1          0          6 SS
Waiter: 1293             2          1          0          6 SS
Waiter: 1260             2          1          0          6 SS
Holder: 3958       1900578    3449469          6          0 TX
Waiter: 1318       1900578    3449469          0          6 TX
Holder: 1318       2359319    1043554          6          0 TX
Waiter: 3963       2359319    1043554          0          6 TX
Waiter: 2610       2359319    1043554          0          6 TX
Waiter: 2590       2359319    1043554          0          6 TX
Waiter: 1289       2359319    1043554          0          6 TX
Waiter: 1296       2359319    1043554          0          6 TX
Waiter: 3965       2359319    1043554          0          6 TX
Waiter: 3876       2359319    1043554          0          6 TX
Waiter: 3959       2359319    1043554          0          6 TX
Waiter: 2570       2359319    1043554          0          6 TX

71 rows selected.

SQL> @locks

SESS                   ID1        ID2      LMODE    REQUEST TY
--------------- ---------- ---------- ---------- ---------- --
Holder: 2601             2          1          6          0 SS
Waiter: 3925             2          1          0          6 SS
Waiter: 3946             2          1          0          6 SS
Waiter: 3977             2          1          0          6 SS
Waiter: 3912             2          1          0          6 SS
Waiter: 3948             2          1          0          6 SS
Waiter: 3871             2          1          0          6 SS
Waiter: 3930             2          1          0          6 SS
Waiter: 3913             2          1          0          6 SS
Waiter: 3916             2          1          0          6 SS
Waiter: 3880             2          1          0          6 SS
Waiter: 3910             2          1          0          6 SS
Waiter: 3914             2          1          0          6 SS
Waiter: 3953             2          1          0          6 SS
Waiter: 3958             2          1          0          6 SS
Waiter: 3926             2          1          0          6 SS
Waiter: 2524             2          1          0          6 SS
Waiter: 2625             2          1          0          6 SS
Waiter: 2656             2          1          0          6 SS
Waiter: 2528             2          1          0          6 SS
Waiter: 2632             2          1          0          6 SS
Waiter: 2574             2          1          0          6 SS
Waiter: 2529             2          1          0          6 SS
Waiter: 2637             2          1          0          6 SS
Waiter: 2585             2          1          0          6 SS
Waiter: 2530             2          1          0          6 SS
Waiter: 2603             2          1          0          6 SS
Waiter: 2615             2          1          0          6 SS
Waiter: 2567             2          1          0          6 SS
Waiter: 2566             2          1          0          6 SS
Waiter: 2579             2          1          0          6 SS
Waiter: 2576             2          1          0          6 SS
Waiter: 2584             2          1          0          6 SS
Waiter: 2572             2          1          0          6 SS
Waiter: 2575             2          1          0          6 SS
Waiter: 2630             2          1          0          6 SS
Waiter: 1257             2          1          0          6 SS
Waiter: 1278             2          1          0          6 SS
Waiter: 1196             2          1          0          6 SS
Waiter: 1315             2          1          0          6 SS
Waiter: 1250             2          1          0          6 SS
Waiter: 1316             2          1          0          6 SS
Waiter: 1259             2          1          0          6 SS
Waiter: 1193             2          1          0          6 SS
Waiter: 1198             2          1          0          6 SS
Waiter: 1245             2          1          0          6 SS
Waiter: 1201             2          1          0          6 SS
Waiter: 1206             2          1          0          6 SS
Waiter: 1238             2          1          0          6 SS
Waiter: 1247             2          1          0          6 SS
Waiter: 1236             2          1          0          6 SS
Waiter: 1252             2          1          0          6 SS
Waiter: 1290             2          1          0          6 SS
Waiter: 1243             2          1          0          6 SS
Waiter: 1248             2          1          0          6 SS
Waiter: 1244             2          1          0          6 SS
Waiter: 1295             2          1          0          6 SS
Waiter: 1293             2          1          0          6 SS
Waiter: 1260             2          1          0          6 SS
Holder: 3958       1900578    3449469          6          0 TX
Waiter: 1318       1900578    3449469          0          6 TX
Holder: 1318       2359319    1043554          6          0 TX
Waiter: 3963       2359319    1043554          0          6 TX
Waiter: 2610       2359319    1043554          0          6 TX
Waiter: 2590       2359319    1043554          0          6 TX
Waiter: 1289       2359319    1043554          0          6 TX
Waiter: 1296       2359319    1043554          0          6 TX
Waiter: 3965       2359319    1043554          0          6 TX
Waiter: 3876       2359319    1043554          0          6 TX
Waiter: 3959       2359319    1043554          0          6 TX
Waiter: 2570       2359319    1043554          0          6 TX

71 rows selected.

SQL> @locks

SESS                   ID1        ID2      LMODE    REQUEST TY
--------------- ---------- ---------- ---------- ---------- --
Holder: 2601             2          1          6          0 SS
Waiter: 3925             2          1          0          6 SS
Waiter: 3946             2          1          0          6 SS
Waiter: 3977             2          1          0          6 SS
Waiter: 3912             2          1          0          6 SS
Waiter: 3948             2          1          0          6 SS
Waiter: 3871             2          1          0          6 SS
Waiter: 3930             2          1          0          6 SS
Waiter: 3913             2          1          0          6 SS
Waiter: 3916             2          1          0          6 SS
Waiter: 3880             2          1          0          6 SS
Waiter: 3910             2          1          0          6 SS
Waiter: 3914             2          1          0          6 SS
Waiter: 3953             2          1          0          6 SS
Waiter: 3958             2          1          0          6 SS
Waiter: 3926             2          1          0          6 SS
Waiter: 2524             2          1          0          6 SS
Waiter: 2625             2          1          0          6 SS
Waiter: 2656             2          1          0          6 SS
Waiter: 2528             2          1          0          6 SS
Waiter: 2632             2          1          0          6 SS
Waiter: 2574             2          1          0          6 SS
Waiter: 2529             2          1          0          6 SS
Waiter: 2637             2          1          0          6 SS
Waiter: 2585             2          1          0          6 SS
Waiter: 2530             2          1          0          6 SS
Waiter: 2603             2          1          0          6 SS
Waiter: 2615             2          1          0          6 SS
Waiter: 2567             2          1          0          6 SS
Waiter: 2566             2          1          0          6 SS
Waiter: 2579             2          1          0          6 SS
Waiter: 2576             2          1          0          6 SS
Waiter: 2584             2          1          0          6 SS
Waiter: 2572             2          1          0          6 SS
Waiter: 2575             2          1          0          6 SS
Waiter: 2630             2          1          0          6 SS
Waiter: 1257             2          1          0          6 SS
Waiter: 1278             2          1          0          6 SS
Waiter: 1196             2          1          0          6 SS
Waiter: 1315             2          1          0          6 SS
Waiter: 1250             2          1          0          6 SS
Waiter: 1316             2          1          0          6 SS
Waiter: 1259             2          1          0          6 SS
Waiter: 1193             2          1          0          6 SS
Waiter: 1198             2          1          0          6 SS
Waiter: 1245             2          1          0          6 SS
Waiter: 1201             2          1          0          6 SS
Waiter: 1206             2          1          0          6 SS
Waiter: 1238             2          1          0          6 SS
Waiter: 1247             2          1          0          6 SS
Waiter: 1236             2          1          0          6 SS
Waiter: 1252             2          1          0          6 SS
Waiter: 1290             2          1          0          6 SS
Waiter: 1243             2          1          0          6 SS
Waiter: 1248             2          1          0          6 SS
Waiter: 1244             2          1          0          6 SS
Waiter: 1295             2          1          0          6 SS
Waiter: 1293             2          1          0          6 SS
Waiter: 1260             2          1          0          6 SS
Holder: 3958       1900578    3449469          6          0 TX
Waiter: 1318       1900578    3449469          0          6 TX
Holder: 1318       2359319    1043554          6          0 TX
Waiter: 3963       2359319    1043554          0          6 TX
Waiter: 2610       2359319    1043554          0          6 TX
Waiter: 2590       2359319    1043554          0          6 TX
Waiter: 1289       2359319    1043554          0          6 TX
Waiter: 1296       2359319    1043554          0          6 TX
Waiter: 3965       2359319    1043554          0          6 TX
Waiter: 3876       2359319    1043554          0          6 TX
Waiter: 3959       2359319    1043554          0          6 TX
Waiter: 2570       2359319    1043554          0          6 TX

71 rows selected.

SQL>