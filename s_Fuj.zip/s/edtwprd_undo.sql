select 	A.tablespace_name, a.TOTALMB , C_ACTIVE.ACTIVEMB, C_EXPIRED.EXPIREDMB, C_UNEXPIRED.UNEXPIREDMB,
   	(a.TOTALMB - C_ACTIVE.ACTIVEMB - C_UNEXPIRED.UNEXPIREDMB) AvailableBeforeGetting1055
from 	(select ddf.tablespace_name, trunc(sum(bytes)/1024/1024) TOTALMB from dba_data_files ddf,v$parameter vp
	  where vp.name = 'undo_tablespace' 
  	    and vp.value = ddf.tablespace_name
	  group by tablespace_name) a,
	(select tablespace_name, trunc(sum(bytes)/1024/1024) ACTIVEMB from dba_undo_extents where STATUS='ACTIVE' group by tablespace_name) C_ACTIVE,
	(select tablespace_name, trunc(sum(bytes)/1024/1024) EXPIREDMB from dba_undo_extents where STATUS='EXPIRED' group by tablespace_name) C_EXPIRED,
	(select tablespace_name, trunc(sum(bytes)/1024/1024) UNEXPIREDMB from dba_undo_extents where STATUS='UNEXPIRED' group by tablespace_name) C_UNEXPIRED
where 	C_ACTIVE.tablespace_name = 'UNDOTBS1'
  and 	C_EXPIRED.tablespace_name = 'UNDOTBS1'
  and 	C_UNEXPIRED.tablespace_name = 'UNDOTBS1'
--  and (a.TOTALMB - C_ACTIVE.ACTIVEMB - C_UNEXPIRED.UNEXPIREDMB) < 10000
/
