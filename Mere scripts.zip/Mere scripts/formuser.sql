set pages 500
set lines 100
col sid for 99999
col user_name for a10 trunc
col serial for 99999 
col action for a10 trunc

select b.sid sid,b.serial# serial,b.action action,d.user_name nam
from apps.fnd_logins a, 
v$session b, v$process c, apps.fnd_user d
where b.paddr = c.addr
and a.pid=c.pid
and a.spid = b.process
and d.user_id = a.user_id
AND d.user_name = '&n'
/


SELECT L.SID,S.SERIAL#,S.USERNAME,S.PROGRAM,
DECODE(L.TYPE,'RW','RW - Row Wait Enqueue',
'TM','TM - DML Enqueue',
'TX','TX - Trans Enqueue',
'UL','UL - User',L.TYPE||'System') RES,
T.NAME TAB,U.NAME OWNER,
L.ID1,L.ID2,
DECODE(L.LMODE,1,'No Lock',
2,'Row Share',
3,'Row Exclusive',
4,'Share',
5,'Shr Row Excl',
6,'Exclusive',NULL) LMODE,
DECODE(L.REQUEST,1,'No Lock',
2,'Row Share',
3,'Row Excl',
4,'Share',
5,'Shr Row Excl',
6,'Exclusive',NULL) REQUEST
FROM V$LOCK L, V$SESSION S,
SYS.USER$ U,SYS.OBJ$ T
WHERE L.SID = S.SID
AND S.TYPE != 'BACKGROUND'
AND T.OBJ# = L.ID1
AND U.USER# = T.OWNER#
AND T.NAME LIKE 'OE_%';  -- change table name as appropriate


col "Last SQL" for a30
select p.spid,s.sid,s.status,s.last_call_et/3600 last_call_et_hrs ,
s.sid,t.disk_reads, t.elapsed_time,lpad(t.sql_text,30) "Last SQL"
from gv$session s, gv$sqlarea t,gv$process p
where s.sql_address =t.address and
s.sql_hash_value =t.hash_value and
p.addr=s.paddr and
s.action like ('FRM%') 
order by spid;