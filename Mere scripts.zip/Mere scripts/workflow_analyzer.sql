SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE '~'
SET ESCAPE ON
WHENEVER SQLERROR EXIT

REM $Id: workflow_analyzer.sql, 200.13 2016/05/13 11:18:34 WILLIAM.BURBAGE@ORACLE.COM Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.41                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    workflow_analyzer.sql                                                |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |                                                                         |
REM | HISTORY                                                                 |
REM +=========================================================================+
REM REM
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i 12.0 12.1 12.2
REM 
REM MENU_TITLE: Workflow Analyzer
REM
REM MENU_START
REM
REM SQL: Run Workflow Analyzer
REM FNDLOAD: Load Workflow Analyzer as a Concurrent Program
REM
REM MENU_END 
REM
REM 
REM HELP_START  
REM 
REM  Workflow Analyzer Help [Doc ID: 1369938.1]
REM
REM  Compatible with: [11i|12.0|12.1|12.2] 
REM 
REM  Explanation of available options:
REM
REM    (1) Runs workflow_analyzer.sql as APPS user to create an HTML report
REM
REM    (2) Install Workflow Analyzer as Concurrent Program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to default request group: "System Administrator Reports"
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: FND_TOP
REM PROG_NAME: WF_ANALYZER_SQL
REM DEF_REQ_GROUP: System Administrator Reports
REM PROG_TEMPLATE: WFAZ.ldt
REM PROD_SHORT_NAME: FND 
REM CP_FILE: workflow_analyzer_cp.sql
REM APP_NAME: Application Object Library
REM  
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM  
REM
REM DEPENDENCIES_END
REM
REM OUTPUT_TYPE: UTL_FILE 
REM
REM ANALYZER_BUNDLE_END


declare

apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
	
BEGIN
 SELECT max(release_name) INTO apps_version
 FROM fnd_product_groups;

 apps_version := substr(apps_version,1,4);
 
 -- Validation to verify analyzer is run on proper e-Business application version
 if apps_version NOT IN ('11.5','12.0','12.1','12.2') then 
	dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** WARNING WARNING WARNING WARNING WARNING WARNING WARNING ***');
    dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** This instance is eBusiness Suite version '|| apps_version ||'           ');
    dbms_output.put_line('*** This Analyzer script is compatible for following version(s): ');
	dbms_output.put_line('***   11i,12.0,12.1,12.2 ');
    dbms_output.put_line('*** Note: the error below is intentional                    ');
    raise_application_error(-20001, 'ERROR: The script requires eBusiness versions 11i,12.0,12.1,12.2');
 end if;

END;
/

PROMPT



PROMPT
Prompt Workflow Analyzer is running...
PROMPT

DECLARE
   l_debug_mode VARCHAR2(1) := 'Y';




TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_8K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(500) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
g_mos_doc_url     VARCHAR2(500) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1369938.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;
g_dx_summary_error VARCHAR2(4000);
g_preserve_trailing_blanks BOOLEAN := false;

beginmin			number;
beginmax 			number;
maxitems			number;
g_cnt_item	    		number;
g_item_open   			number;
g_oldest_item 			number;
g_stuck_cnt			number;
g_disabled_cnt			number;
cls_cnt		 		number;
g_wfadmin_ntf_pref		VARCHAR2(8);
g_wfadmin_role 			varchar2(2000);
g_wfadmins_cnt			number;
g_wfadmin_display 		varchar2(360);
g_wfadmin_email  		varchar2(320);
g_ntfutil_ver                   varchar2(150);
g_errorntfcnt			number;
g_sysadmin_ntf_pref		VARCHAR2(8);
g_sysadmin_email		varchar2(320);
g_dee_open_cnt			number;
g_dee_clsd_cnt			number;
g_dee_open30_cnt		number;
g_total_error  			number;
g_open_error   			number;
g_closed_error 			number;
g_ntferr_cnt			number;
g_atgrup4			number;
g_last_ran			varchar2(22);
g_ninety_cnt			number;
g_hist_end			varchar2(22);
g_hist_begin			varchar2(22);
g_hist_recent			varchar2(22);		
g_hasrows			number;
g_hist_cnt   			number;
g_hist_days 			number;
g_hist_daily			number;	
ont_hist_end			varchar2(22);
ont_hist_begin			varchar2(22);
ont_hist_recent			varchar2(22);		
ont_hasrows			number;
ont_hist_cnt   			number;
ont_hist_days 			number;
ont_hist_daily			number;	
ont_hist_item     		varchar2(8);
ont_hist_key      		varchar2(240);
hcm_hist_end			varchar2(22);
hcm_hist_begin			varchar2(22);
hcm_hist_recent			varchar2(22);		
hcm_hasrows			number;
hcm_hist_cnt   			number;
hcm_hist_days 			number;
hcm_hist_daily			number;	
hcm_hist_item     		varchar2(8);
hcm_hist_key      		varchar2(240);
po_hist_end			varchar2(22);
po_hist_begin			varchar2(22);
po_hist_recent			varchar2(22);		
po_hasrows			number;
po_hist_cnt   			number;
po_hist_days 			number;
po_hist_daily			number;	
po_hist_item     		varchar2(8);
po_hist_key      		varchar2(240);
g_mailer_enabled 		varchar2(8);
g_hist_item     		varchar2(8);
g_hist_key      		varchar2(240);
g_stmt_log_cnt			number;
g_alldefrd			number;
g_prgall			number;
g_prgany			number;
g_prgcore			number;
g_wfitems			number;
g_stuckfreq			number; 
g_lastwfcqcup			date;
g_wfcqcup_hrs			number;
g_concprgms_cnt			number;
g_WFNTFPRG_APPLIED		number;
g_UNREFNTF_CNT			number;
g_omcnt				number;
g_olcnt				number;
g_chart_om_cnt			number;
g_hrcnt				number;
g_chart_hr_cnt			number;
g_po_cnt			number;
g_chart_po_cnt			number;
g_incomplpo			number;
g_orphline			number;
g_orphhdr			number;
g_logical_totals		number;
g_physical_totals		number;
g_diff_totals 			number;
g_rate				number;


----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
  
  -- ER #124 Show in unix session the error if parameter or additional validation failed.
  IF NOT g_is_concurrent THEN
	IF p_msg LIKE 'INVALID ARGUMENT:%' THEN
		-- from Parameters validations if exist
		dbms_output.put_line('**************************************************');
		dbms_output.put_line('**** ERROR  ERROR  ERROR  ERROR  ERROR  ERROR ****');
		dbms_output.put_line('**************************************************');
		dbms_output.put_line('**** The analyzer did not run to completion!');
		dbms_output.put_line('**** '||p_msg);
		dbms_output.put_line('**** Please rerun the analyzer with proper parameter value.');
	ELSIF p_msg LIKE 'PROGRAM ERROR%' THEN
		-- from calls in run_sig_sql and run_stored_sig which are seen in output only
		null;
	ELSE
		-- from Additional Validation if exist
		dbms_output.put_line('**************************************************');
		dbms_output.put_line('**** ERROR  ERROR  ERROR  ERROR  ERROR  ERROR ****');
		dbms_output.put_line('**************************************************');
		dbms_output.put_line('**** The analyzer did not run to completion!');
		dbms_output.put_line('**** '||p_msg);
    END IF;
   END IF;	
  
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

    l_log_file := 'WF_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'WF_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);
	dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file : '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>WF Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
              'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfL'||
              'T8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

-- Print title
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">EBS '|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1369938.1:SCRIPT">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/wfa_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\\2">\\2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\\[)([0-9]*\\.[0-9])(\\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\\2">Doc ID \\2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
	-- removed initCap per Standardization team in 3.0.34
    l_col_headings(i) := replace(l_desc_rec_tbl(i).col_name,'|','<br>');
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_sigxinfo_element     XMLDOM.DOMElement;
l_sigxinfo_node        XMLDOM.DOMNode;
l_xinfo_element        XMLDOM.DOMElement;
l_xinfo_node           XMLDOM.DOMNode;
l_xinfo_name_attr      XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

IF g_dx_summary_error IS NOT NULL THEN
   return;
END IF;   

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     IF g_rep_info(l_key) IS NOT NULL THEN
        l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));
     END IF;

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     IF g_parameters(l_key) IS NOT NULL THEN
        l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));
     END IF;

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);
   
   IF p_sig.extra_info.count > 0 THEN
      l_sigxinfo_element := XMLDOM.createElement(l_hidden_xml_doc,'sigxinfo');      
      l_sigxinfo_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_sigxinfo_element));      
      l_key := p_sig.extra_info.first;
      WHILE l_key IS NOT NULL LOOP
         l_xinfo_element := XMLDOM.createElement(l_hidden_xml_doc,'info');      
         l_xinfo_node := XMLDOM.appendChild(l_sigxinfo_node,XMLDOM.makeNode(l_xinfo_element));      
         l_xinfo_name_attr := XMLDOM.setAttributeNode(l_xinfo_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name')); 
         XMLDOM.setAttribute(l_xinfo_element, 'name',l_key);
         IF p_sig.extra_info(l_key) IS NOT NULL THEN
            l_node := XMLDOM.appendChild(l_xinfo_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,p_sig.extra_info(l_key))));         
         END IF;
         l_key := p_sig.extra_info.next(l_key);
      END LOOP;
   END IF;   
   
   IF p_sig.include_in_xml='Y' THEN

      IF p_sig.limit_rows='Y' THEN
         l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
      ELSE
         l_rows := least(p_col_rows(1).COUNT,50);
      END IF;
   
      FOR i IN 1..l_rows LOOP

         l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
         l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
         l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
         XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
         FOR j IN 1..p_col_headings.count LOOP
 
            l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
            l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
            l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
            XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
            l_value := p_col_rows(j)(i);

            IF p_sig_id = 'REC_PATCH_CHECK' THEN
               IF p_col_headings(j) = 'Patch' THEN
                  l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
               ELSIF p_col_headings(j) = 'Note' THEN
                  l_value := replace(replace(p_col_rows(j)(i),'['),']');
               END IF;
            END IF;
		 
		    -- Rtrim the column value if blanks are not to be preserved
             IF NOT g_preserve_trailing_blanks THEN
               l_value := RTRIM(l_value, ' ');
             END IF;

            IF l_value IS NOT NULL THEN
               l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));
            END IF;

          END LOOP;

       END LOOP;
     
     END IF;  --p_sig.include_in_xml='Y'            
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;

EXCEPTION 
   WHEN OTHERS THEN   
      g_dx_summary_error := '<DXSUMMGENERR><![CDATA['||SQLERRM||']]></DXSUMMGENERR>';
      print_log('DX Summary generation error: '||SQLERRM);

END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF g_dx_summary_error IS NOT NULL THEN
   print_out('<!-- ######BEGIN DX SUMMARY######','Y');
   print_out(g_dx_summary_error);
   print_out('######END DX SUMMARY######-->','Y');
   g_dx_summary_error:=null;
   return;
END IF;   

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

EXCEPTION 
   WHEN OTHERS THEN   
      print_log('Error in print_hidden_xml: '||SQLERRM);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml IN ('Y','P')) THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  	
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL &amp; info)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
		  
       -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;		  
		  
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
			
       -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;			
			
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);
		-- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;
		 
          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

    -----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;
	
  END IF;	
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div><br>');
END print_rep_subsection_end;


-----------------------------------------------
-- Diagnostic specific functions and procedures
-----------------------------------------------
----------------------------------------------------------------
-- Creates a Bar Chart for WF Runtime Data &                  --
-- a Gauge Graphic to indicate the amount of OLD data found   --
----------------------------------------------------------------
PROCEDURE show_gauge_chart IS
	clsd_index	number;
	open_index	number;
	year_index	number;
	emesg       VARCHAR2(250);
	
begin

print_log('  Processing Procedure: show_gauge_chart');

select min(to_char(begin_date, 'YYYY')) into beginmin
from wf_items;

select max(to_char(sysdate, 'YYYY')) into beginmax
from wf_items;

clsd_index := beginmin;

Select max(nvl(Count(Item_Key),0)) into maxitems
From Wf_Items
Group By To_Char(Begin_Date, 'YYYY')
order by To_Char(Begin_Date, 'YYYY');

print_out('<div class="divItem" id="sigWF_ENV">');

print_out('    <link rel="stylesheet" href="http://cdn.kendostatic.com/2014.3.1316/styles/kendo.common.min.css" />');
print_out('    <link rel="stylesheet" href="http://cdn.kendostatic.com/2014.3.1316/styles/kendo.default.min.css" />');
print_out('    <link rel="stylesheet" href="http://cdn.kendostatic.com/2014.3.1316/styles/kendo.dataviz.min.css" />');
print_out('    <link rel="stylesheet" href="http://cdn.kendostatic.com/2014.3.1316/styles/kendo.dataviz.default.min.css" />');
print_out('');
print_out('    <script src="http://cdn.kendostatic.com/2014.3.1316/js/jquery.min.js"></script>');
print_out('    <script src="http://cdn.kendostatic.com/2014.3.1316/js/kendo.all.min.js"></script>');
print_out('    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery.tablesorter/2.9.1/jquery.tablesorter.min.js"></script>');


print_out('<div id="container">');
print_out('<table border="0" cellpadding="0" cellspacing="0" width="100%">');
print_out('<tr>');
print_out('<td width="50%">');
print_out('<h3>Workflow Runtime Data Volume</h3>');
print_out('</td>');
print_out('<td width="50%">');
print_out('<h3>Workflow Runtime Data Age Gauge</h3>');
print_out('</td>');
print_out('</tr>');
print_out('<tr>');
print_out('<td width="50%">');
print_out('<div id="chart" style="width: 600px; height: 250px; float: left; vertical-align: top; margin: 5px 5px 5px 15px; ">');

print_out('<script>');
print_out('function createChart() {$("#chart").kendoChart({');
print_out('legend: {position: "top",visible: true},');
print_out('seriesDefaults: {type: "column",stack: true},');
print_out('series: [{name: "Closed",');
print_out('data: [');

WHILE clsd_index <= beginmax
LOOP
   BEGIN
      /* Loop thru the CLOSED items by year */

	select nvl(count(item_key),0) into cls_cnt
	from wf_items
	where to_char(begin_date,'YYYY')=clsd_index
	and end_date is not null;

      print_out(cls_cnt,'N');
      
      if (clsd_index = beginmax) then
      	 print_out('],','N');
      else 
      	 print_out(',','N');
      end if;
      
      clsd_index:=clsd_index+ 1;
      
   EXCEPTION
      WHEN OTHERS
      THEN
         clsd_index:=clsd_index+ 1;
   END;
END LOOP;

print_out('color: "#4D89F9"}, {name: "Open",data: [');

open_index := beginmin;

WHILE open_index <= beginmax
LOOP
   BEGIN
      /* Loop thru the OPEN items by year */

	select nvl(count(item_key),0) into cls_cnt
	from wf_items
	where to_char(begin_date,'YYYY')=open_index
	and end_date is null;

       print_out(cls_cnt,'N');
      
      if (open_index=beginmax) then
      	exit;
      else 
      	 print_out(',','N');
      end if;
      
      open_index:=open_index+ 1;
      
   EXCEPTION
      WHEN OTHERS
      THEN
         open_index:=open_index+ 1;
   END;
END LOOP;



print_out('],color: "#C6D9FD"}],valueAxis: {max: '||maxitems||',');
print_out('labels: {format: "{0}"},');
print_out('line: {visible: false},');
print_out('minorGridLines: {visible: true}},');
print_out('categoryAxis: {categories: [');

year_index := beginmin;

WHILE year_index <= beginmax
LOOP
   BEGIN
      /* Build the labels by year */

        print_out(year_index,'N');
      
      if (year_index=beginmax) then
      	exit;
      else 
      	 print_out(',','N');
      end if;
      
      year_index:=year_index+ 1;
      
   EXCEPTION
      WHEN OTHERS
      THEN
         year_index:=year_index+ 1;
   END;
END LOOP;

print_out('],majorGridLines: {visible: false}},');
print_out('tooltip: {visible: true,template: "#= series.name #: #= value #"}});}');
print_out('$(document).ready(createChart);$(document).bind("kendo:skinChange", createChart);');
print_out('</script>');


print_out('</div>');
print_out('</td>');
print_out('<td width="50%">');
print_out('<div id="gauge-graph" style="width: 400px; height: 250px; float: left; vertical-align: top; margin: 5px 5px 5px 15px;">');


if (g_oldest_item > 1095) THEN

  print_out('<img src="');
  print_out('https://chart.googleapis.com/chart?chxl=0:|critical|bad|good&chts=000000,20,c&chxt=y&chs=400x250&cht=gm&chd=t:10&chl=Excessive">');
  print_out('</div>');
  print_out('</td>');
  print_out('</tr>');
  print_out('</table>');
  print_out('<br>_____________________________________________________________________________________________________________________<br><br>');
    
  else   if (g_oldest_item > 365) THEN

  print_out('<img src="');
  print_out('https://chart.googleapis.com/chart?chxl=0:|critical|bad|good&chts=000000,20,c&chxt=y&chs=400x250&cht=gm&chd=t:50&chl=Poor">');
  print_out('</div>');
  print_out('</td>');
  print_out('</tr>');
  print_out('</table>');
  print_out('<br>_____________________________________________________________________________________________________________________<br><br>');
    
  else

  print_out('<img src="');
  print_out('https://chart.googleapis.com/chart?chxl=0:|critical|bad|good&chts=000000,20,c&chxt=y&chs=400x250&cht=gm&chd=t:90&chl=Healthy">');
  print_out('</div>');
  print_out('</td>');
  print_out('</tr>');
  print_out('</table>');
  print_out('<br>_____________________________________________________________________________________________________________________<br><br>');
    
  end if;
end if;

   
  if (g_cnt_item > 100) THEN
   
    print_out('<table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">');
    print_out('<tbody><tr><td> ');
    print_out('      <p><B>Note:</B> Once a Workflow is closed, all the transactional or runtime data that is stored in Workflow Runtime Tables (WF_*) becomes obsolete.<BR>');
    print_out('All the pertinent data is stored in the functional tables (FND_*, PO_*, AP_*, HR_*, OE_*, etc), like who approved what, for how much, for who, etc...)<br>');
    print_out('Remember that each row in WF_ITEMS is associated to 100s or 1,000s of rows in the other WF runtime tables, ');
    print_out('so it is important to purge this obsolete runtime data regularly.<br>');
    print_out('Once a workflow item is closed then all the runtime data associated to completing this workflow process is now obsolete and should be purged to make room for new workflows.<BR><br>');
    print_out('<b>Purging Workflow regularly is recommended to maintain good system performance.</b><br>');  
    print_out('All workflow child processes must be completed in order for the whole workflow to be eligible for purging.  A common problem for workflows not getting purged as expected, can be as simple as an open notification that was never acknowledged or closed.');
    print_out('Not responding to SYSADMIN error notifications (WFERROR) can cause many workflow process and all of the child processes to not become eligible for purge.<br>It is important to review and manage any workflow items that remain open or closed for a long ');
    print_out('period of time, especially if your functional team considers them to be closed.  There can be many reasons for this, not purging all workflows, or workflows closed incorrectly, or errors that do not get addressed, and repeat over and over.');
    print_out('There are many scripts and notes provided in this WF Analyzer output that can help you identify any problems and provide solutions to help you <b><i>take control of workflow</b></i>.<br><br>');
    print_out('Please review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\\\&sourceId=1369938.1\\\\&id=144806.1" target="_blank">Doc ID 144806.1</a> - A Detailed Approach To Purging Oracle Workflow Runtime Data ');
    print_out('for details on how to drill down and identify any OLD items are still open, and ways to close them so they can be purged.</p>');    
    print_out('</td></tr></tbody></table><BR>');

  else

    print_out('There are less than 100 items in the WF_ITEMS table.<BR><BR>');

  end if;

    print_out('</div></div><br>');
--  	print_out('</div></div><br><font style="font-size:x-small;">');
--    print_out('<a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');

  exception
	when others then 
	emesg := SQLERRM;
        print_out(emesg);
    	
END show_gauge_chart;

----------------------------------------------------------------
-- Display current DB Settings and the recommendations        --
-- for setting using best practices                           --
----------------------------------------------------------------
PROCEDURE show_db_settings IS
	
begin

print_out('<div class="divItem" id="sigDB_ENV">');

if (substr(g_rep_info('DB Version'),1,4) < '11.1') then

    print_out('<p><B>Note: JOB_QUEUE_PROCESSES for pre-11gR1 ('||g_rep_info('DB Version')||') databases:</B><BR>');
    print_out('Oracle Workflow requires job queue processes to handle propagation of Business Event System event messages by AQs.<BR>');
    print_out('<B>The recommended minimum number of JOB_QUEUE_PROCESSES for Oracle Workflow is 10.<BR> ');
    print_out('The maximum number of JOB_QUEUE_PROCESSES is :<BR> -    36 in Oracle8i<BR> - 1,000 in Oracle9i Database and higher, so set the value of JOB_QUEUE_PROCESSES accordingly.</B><BR>');
    print_out('The ideal setting for JOB_QUEUE_PROCESSES should be set to the maximum number of jobs that would ever be run concurrently on a system PLUS a few more.</B><BR><BR>');

    print_out('To determine the proper amount of JOB_QUEUE_PROCESSES for Oracle Workflow, follow the queries outlined in<BR> ');
    print_out('[578831.1] - How to determine the correct setting for JOB_QUEUE_PROCESSES.<br></p>');

	
  elsif (substr(g_rep_info('DB Version'),1,4) >= '11.1') then

    print_out('<p><B>Note: Significance of the JOB_QUEUE_PROCESSES for 11gR1+ ('||g_rep_info('DB Version')||') databases:</B><BR><BR>');
    print_out('Starting from 11gR1, The init.ora parameter job_queue_processes does NOT need to be set for AQ propagations.');
    print_out('AQ propagation is now likewise handled by DBMS_SCHEDULER jobs rather than DBMS_JOBS. ');
    print_out('Reason: propagation takes advantage of the event based scheduling features of DBMS_SCHEDULER for better scalability. ');
    print_out('If the value of the JOB_QUEUE_PROCESSES database initialization parameter is zero, then that parameter does not influence ');
    print_out('the number of Oracle Scheduler jobs that can run concurrently. ');
    print_out('However, if the value is non-zero, it effectively becomes the maximum number of Scheduler jobs and job queue jobs than can run concurrently. ');
    print_out('If a non-zero value is set, it should be large enough to accommodate a Scheduler job for each Messaging Gateway agent to be started.<BR><BR>');    
    
    print_out('<B>Oracle Workflow recommends to UNSET the JOB_QUEUE_PROCESSES parameter as per DB recommendations to enable the scheduling features of DBMS_SCHEDULER for better scalability.</B><BR><BR>');      
    
    print_out('To update the JOB_QUEUE_PROCESSES database parameter file (init.ora) file:');
    print_out('<blockquote><i>job_queue_processes=10</i></blockquote>');
    print_out('or set dynamically via');
    print_out('<blockquote><i>connect / as sysdba<br>alter system set job_queue_processes=10;</i></blockquote>Remember that after bouncing the DB, dynamic changes are lost, and the DB parameter file settings are used.<BR>');    
    print_out('To determine the proper setting of JOB_QUEUE_PROCESSES for Oracle Workflow, follow the queries outlined in <BR>');
    print_out('[578831.1] - How to determine the correct setting for JOB_QUEUE_PROCESSES.<br></p>');

  
  else 

    print_out('<p><B>Note: To determine the proper amount of JOB_QUEUE_PROCESSES for Oracle Workflow</B><BR>');
    print_out('Follow the queries outlined in ');
    print_out('[578831.1] - How to determine the correct setting for JOB_QUEUE_PROCESSES.<br></p>');


end if;
--  	print_out('</div><br>');
   	print_out('</div><br><font style="font-size:x-small;">');
    print_out('<a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');

end show_db_settings;

----------------------------------------------------------------
-- Display current AQ_TM_PROCESSES Settings and the           --
-- recommendations for setting using best practices           --
----------------------------------------------------------------
PROCEDURE show_aq_tm_proc_setting IS

begin

print_out('<div class="divItem" id="sigAQ_ENV">');

if (substr(g_rep_info('DB Version'),1,4) < '11.2') then

    print_out('<p><B>Note: AQ_TM_PROCESSES for pre-11gR2 ('||g_rep_info('DB Version')||') databases:</B><BR><BR>');
    print_out('The Oracle Streams AQ time manager process is called the Queue MONitor (QMON), a background process controlled by parameter AQ_TM_PROCESSES.<BR>');
    print_out('QMON processes are associated with the mechanisms for message expiration, retry, delay, maintaining queue statistics, removing PROCESSED messages ');
    print_out('from a queue table and updating the dequeue IOT as necessary.  QMON plays a part in both permanent and buffered message processing.<BR>');
    print_out('If a qmon process should fail, this should not cause the instance to fail. This is also the case with job queue processes.<BR>');
    print_out('QMON itself operates on queues but does not use a database queue for its own processing of tasks and time based operations, so it can ');
    print_out('be envisaged as a number of discrete tasks which are run by Queue Monitor processes or servers.');

    print_out('The AQ_TM_PROCESSES parameter is set in the (init.ora) database parameter file, and by default is set to 1.<br>');
    print_out('This value allows Advanced Queuing to start 1 AQ background process for Queue Monitoring, which is  ');
    print_out('usually sufficient for simple E-Business Suite instances.  <BR><B>However, this setting can be increased (dynamically) to improve queue maintenance performance.</B></p>');
    
    print_out('<B>Oracle highly recommends manually setting the aq_tm_processes parameter to a reasonable value (no greater than 5) which will leave some qmon slave processes to deal with buffered message operations.</B><BR><BR>');
      
    print_out('If this parameter is set to a non-zero value X, Oracle creates that number of QMNX processes starting from ora_qmn0_SID (where SID is the identifier of the database) ');
    print_out('up to ora_qmnX_SID ; if the parameter is not specified or is set to 0, then the QMON processes are not created. ');
    print_out('There can be a maximum of 10 QMON processes running on a single instance. <BR>For example the parameter can be set in the init.ora as follows :');
    print_out('<blockquote><i>aq_tm_processes=5</i></blockquote>');
    print_out('or set dynamically via');
    print_out('<blockquote><i>connect / as sysdba<br>alter system set aq_tm_processes=5;</i></blockquote>Remember that after bouncing the DB, dynamic changes are lost, and the DB parameter file settings are used.<BR>'); 
    
    print_out('It is recommended to NOT DISABLE the Queue Monitor processes by setting aq_tm_processes=0 on a permanent basis. As can be seen above, ');
    print_out('disabling will stop all related processing in relation to tasks outlined. This will likely have a significant affect on operation of queues - PROCESSED ');
    print_out('messages will not be removed and any time related, TM actions will not succeed, AQ objects will grow in size.<BR><BR>');
    print_out('To update the AQ_TM_PROCESSES database parameter, follow the steps outlined in <BR>');
    print_out('[305662.1] - Master Note for AQ Queue Monitor Process (QMON).<br></p>');

  elsif (substr(g_rep_info('DB Version'),1,4) >= '11.2') then

    print_out('<p><B>Note: Significance of the AQ_TM_PROCESSES for 11gR2+ ('||g_rep_info('DB Version')||') databases:</B><BR><BR>');
    print_out('Starting from 11gR2, Queue Monitoring can utilize a feature called "auto-tune".<br>');
    print_out('By default, AQ_TM_PROCESSES parameter is unspecified so it is able to adapt the number of AQ background processes to the system load.<br>');
    print_out('However, if you do specify a value, then that value is taken into account but the number of processes can still be auto-tuned and so the number of ');
    print_out('running qXXX processes can be different from what was specified by AQ_TM_PROCESSES.<BR><BR>');    
    
    print_out('<B>Oracle highly recommends that you leave the AQ_TM_PROCESSES parameter unspecified and let the system autotune.</B><BR><BR>');
    
    print_out('Note: For more information refer to [746313.1] - What should be the Correct Setting for Parameter AQ_TM_PROCESSES in E-Business Suite Instance?<br></p>');

    print_out('It should be noted that if AQ_TM_PROCESSES is explicitly specified then the process(es) started will only maintain persistent messages. ');
    print_out('For example if aq_tm_processes=1 then at least one queue monitor slave process will be dedicated to maintaining persistent messages. ');
    print_out('Other process can still be automatically started to maintain buffered messages. Up to and including version 11.1 if you explicitly set aq_tm_processes = 10 ');
    print_out('then there will be no processes available to maintain buffered messages. This should be borne in mind in environments which use Streams replication ');
    print_out('and from 10.2 onwards user enqueued buffered messages.<BR><BR>');

    print_out('It is also recommended to NOT DISABLE the Queue Monitor processes by setting aq_tm_processes=0 on a permanent basis. As can be seen above, ');
    print_out('disabling will stop all related processing in relation to tasks outlined. This will likely have a significant affect on operation of queues - PROCESSED ');
    print_out('messages will not be removed and any time related, TM actions will not succeed, AQ objects will grow in size.<BR>');

    print_out('<p><B>Note: There is a known issue viewing the true value of AQ_TM_PROCESSES for 10gR2+ (10.2) from the v$parameters table.</B><BR>');
    print_out('Review the details in [428441.1] - "Warning: Aq_tm_processes Is Set To 0" Message in Alert Log After Upgrade to 10.2.0.3 or Higher.<br>');
    print_out('Also of interest [809383.1] - Queue Monitor Auto-Tuning only uses 1 Qmon Slave Process for Persistent Queues.</p>');
    
    print_out('To check whether AQ_TM_PROCESSES Auto-Tuning is enabled, follow the steps outlined in<BR> ');
    print_out('[305662.1] - Master Note for AQ Queue Monitor Process (QMON) under Section : Significance of the AQ_TM_PROCESSES Parameter in 10.1 onwards<br></p>');
    
  else 

    print_out('<p><B>Note:</B> For more information refer to [746313.1] - What should be the Correct Setting for Parameter AQ_TM_PROCESSES in E-Business Suite Instance?<br></p>');

end if;
--   	print_out('</div><br>');
   	print_out('</div><br><font style="font-size:x-small;">');
    print_out('<a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');

end show_aq_tm_proc_setting;




----------------------------------------------------------------
-- Display current WF_ERRORS in a Pie Chart                   --
----------------------------------------------------------------
PROCEDURE wferrors IS
 	ntferr_cnt		number;
	ecxerr_cnt		number;	
	omerr_cnt		number;	
	poerr_cnt		number;	
	wferr_cnt		number;	
	ecxrate			number;	
	omrate			number;	
	porate			number;	
	wfrate			number;
	
begin

print_log('  Processing Procedure: wferrors to show chart');

	select nvl(max(rownum), 0) into ntferr_cnt
	from wf_notifications n
	where n.message_type like '%ERROR%';

	select nvl(max(rownum), 0) into ecxerr_cnt
	from wf_notifications n
	where n.message_type = 'ECXERROR';

	select nvl(max(rownum), 0) into omerr_cnt
	from wf_notifications n
	where n.message_type = 'OMERROR';

	select nvl(max(rownum), 0) into poerr_cnt
	from wf_notifications n
	where n.message_type = 'POERROR';

	select nvl(max(rownum), 0) into wferr_cnt
	from wf_notifications n
	where n.message_type = 'WFERROR';	

--	ntferr_cnt := '1400';
--	ecxerr_cnt := '300';
--	omerr_cnt := '400';
--	poerr_cnt := '200';
--	wferr_cnt := '500';
	
	print_out('<div class="divItem" id="sigWF_ERRORS_DIV">');	

  if (ntferr_cnt = 0) then

       	print_out('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
       	print_out('<tbody><tr><td> ');
       	print_out('<p><B>Well Done !!<BR><BR>');
       	print_out('There are no Notification Error Messages for this instance.</B><BR>');
       	print_out('You deserve a whole cake!!!<BR>');
       	print_out('</p></td></tr></tbody></table><BR>');
       
    elsif (ntferr_cnt < 100) then
 
 	print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');	
   	print_out('<tbody><tr><td> ');
  	print_out('<p><B>Attention:<BR>');
       	print_out('There are less that 100 Error Notifications found on this instance.</B><BR>');
       	print_out('Keep up the good work.... You deserve a piece of pie.<BR>');
       	print_out('</p></td></tr></tbody></table><BR>');  
  
    else 

	select round(ecxerr_cnt/ntferr_cnt,2)*100 into ecxrate from dual;	
	select round(omerr_cnt/ntferr_cnt,2)*100 into omrate from dual;
	select round(poerr_cnt/ntferr_cnt,2)*100 into porate from dual;
	select round(wferr_cnt/ntferr_cnt,2)*100 into wfrate from dual;
	
	print_out('<blockquote><img src="');
	print_out('https://chart.googleapis.com/chart?chs=500x200&chd=t:'||wfrate||','||porate||','||omrate||','||ecxrate||'&cht=p3&chtt=Workflow+Error+Notifications+by+Type');
	print_out('&chl=WFERROR|POERROR|OMERROR|ECXERROR&chdl='||wferr_cnt||'|'||poerr_cnt||'|'||omerr_cnt||'|'||ecxerr_cnt||'"><BR>');
	print_out('</blockquote>');
	

end if;
--  	print_out('</div><br>');
   	print_out('</div><br><font style="font-size:x-small;">');
    print_out('<a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');

EXCEPTION WHEN OTHERS THEN
  print_log('Error in wferrors');
  raise;	
end wferrors;


----------------------------------------------------------------
-- Display current Workflow Footprint in a graph              --
----------------------------------------------------------------
PROCEDURE wfruntime IS
 	l_wfcmtphy		number := 0;
	l_wfdigphy		number := 0;
	l_wfitmphy		number := 0;
	l_wiasphy		number := 0;
	l_wiashphy		number := 0;
	l_wfattrphy		number := 0;
	l_wfntfphy		number := 0;
	l_wfntfattr		number := 0;
	l_wfcmtphy2		number := 0;
	l_wfdigphy2		number := 0;
	l_wfitmphy2		number := 0;
	l_wiasphy2		number := 0;
	l_wiashphy2		number := 0;
	l_wfattrphy2	number := 0;
	l_wfntfphy2		number := 0;
	l_wfntfattr2    number := 0;
	l_test			varchar2(240);

begin

print_log('  Processing Procedure: wfruntime to show graph');

	select round((blocks*8192/1024/1024),2) into l_wfcmtphy
	from dba_tables 
	where table_name = 'WF_COMMENTS'
	and owner = 'APPLSYS';

	select round((blocks*8192/1024/1024),2) into l_wfdigphy
	from dba_tables 
	where table_name = 'WF_DIG_SIGS'
	and owner = 'APPLSYS';

	select round((blocks*8192/1024/1024),2) into l_wfitmphy
	from dba_tables 
	where table_name = 'WF_ITEMS'
	and owner = 'APPLSYS';

	select round((blocks*8192/1024/1024),2) into l_wiasphy
	from dba_tables 
	where table_name = 'WF_ITEM_ACTIVITY_STATUSES'
	and owner = 'APPLSYS';

	select round((blocks*8192/1024/1024),2) into l_wiashphy
	from dba_tables 
	where table_name = 'WF_ITEM_ACTIVITY_STATUSES_H'
	and owner = 'APPLSYS';

	select round((blocks*8192/1024/1024),2) into l_wfattrphy
	from dba_tables 
	where table_name = 'WF_ITEM_ATTRIBUTE_VALUES'
	and owner = 'APPLSYS';

	select round((blocks*8192/1024/1024),2) into l_wfntfphy
	from dba_tables 
	where table_name = 'WF_NOTIFICATIONS'
	and owner = 'APPLSYS';

	select round((blocks*8192/1024/1024),2) into l_wfntfattr
	from dba_tables 
	where table_name = 'WF_NOTIFICATION_ATTRIBUTES'
	and owner = 'APPLSYS';
	
	select round((num_rows*AVG_ROW_LEN)/1024/1024,2) into l_wfcmtphy2
	from dba_tables 
	where table_name = 'WF_COMMENTS'
	and owner = 'APPLSYS';

	select round((num_rows*AVG_ROW_LEN)/1024/1024,2) into l_wfdigphy2
	from dba_tables 
	where table_name = 'WF_DIG_SIGS'
	and owner = 'APPLSYS';

	select round((num_rows*AVG_ROW_LEN)/1024/1024,2) into l_wfitmphy2
	from dba_tables 
	where table_name = 'WF_ITEMS'
	and owner = 'APPLSYS';

	select round((num_rows*AVG_ROW_LEN)/1024/1024,2) into l_wiasphy2
	from dba_tables 
	where table_name = 'WF_ITEM_ACTIVITY_STATUSES'
	and owner = 'APPLSYS';

	select round((num_rows*AVG_ROW_LEN)/1024/1024,2) into l_wiashphy2
	from dba_tables 
	where table_name = 'WF_ITEM_ACTIVITY_STATUSES_H'
	and owner = 'APPLSYS';

	select round((num_rows*AVG_ROW_LEN)/1024/1024,2) into l_wfattrphy2
	from dba_tables 
	where table_name = 'WF_ITEM_ATTRIBUTE_VALUES'
	and owner = 'APPLSYS';

	select round((num_rows*AVG_ROW_LEN)/1024/1024,2) into l_wfntfphy2
	from dba_tables 
	where table_name = 'WF_NOTIFICATIONS'
	and owner = 'APPLSYS';

	select round((num_rows*AVG_ROW_LEN)/1024/1024,2) into l_wfntfattr2
	from dba_tables 
	where table_name = 'WF_NOTIFICATION_ATTRIBUTES'
	and owner = 'APPLSYS';
	
	print_out('<div class="divItem" id="sigWF_RUNTIME_DIV">');	

print_out('<img src="https://chart.googleapis.com/chart?chxl=0:|WF_NOTIFICATION_ATTRIBUTES|WF_NOTIFICATIONS|WF_ITEM_ATTRIBUTE_VALUES|WF_ITEM_ACTIVITY_STATUSES_H|WF_ITEM_ACTIVITY_STATUSES|WF_ITEMS|WF_DIG_SIGS|WF_COMMENTS&chdl=Logical_Data|Physical_Data&chxs=0,676767,11.5,0,lt,676767&chxtc=0,5&chxt=y,x&chds=a&chs=600x475&chma=0,0,0,5&chbh=20,5,10&cht=bhg');
  select '&chd=t:'||l_wfcmtphy||','||l_wfdigphy||','||l_wfitmphy||','||l_wiasphy||','||l_wiashphy||','||l_wfattrphy||','||l_wfntfphy||','||l_wfntfattr||'|'||l_wfcmtphy2||','||l_wfdigphy2||','||l_wfitmphy2||','||l_wiasphy2||','||l_wiashphy2||','||l_wfattrphy2||','||l_wfntfphy2||','||l_wfntfattr2 into l_test from dual;
  print_out('&chco=A2C180,3D7930');
  print_out(''||l_test||'');
  print_out('&chtt=Workflow+Runtime+Data+Tables" />');
  print_out('<br><br>');


  	print_out('</div><br>');
--   	print_out('</div><br><font style="font-size:x-small;">');
--    print_out('<a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');

EXCEPTION WHEN OTHERS THEN
  print_log('Error in wfruntime');
  raise;	
end wfruntime;

----------------------------------------------------------------
-- Display current Order Management Items in a Pie Chart      --
----------------------------------------------------------------
PROCEDURE om_items IS
	l_oeoh_cnt		number := 0;
	l_oeol_cnt		number := 0;
	l_closedomcnt	number := 0;
	l_openomcnt		number := 0;
	l_chart_om_cnt	number := 0;
	l_omerror_cnt	number := 0;
	l_oeoi_cnt		number := 0;
	l_oecogs_cnt	number := 0;
	l_oeoa_cnt		number := 0;
	l_oechg_cnt		number := 0;
	l_oeon_cnt		number := 0;
	l_oebh_cnt		number := 0;
	l_oewferr_cnt	number := 0;
	l_oeohrate		number := 0;
	l_oeolrate		number := 0;
	l_omerrorrate	number := 0;
	l_oeoirate		number := 0;
	l_oecogsrate	number := 0;
	l_oeoarate		number := 0;
	l_oechgrate		number := 0;
	l_oewferrrate	number := 0;
	l_oeonrate		number := 0;
	l_oebhrate		number := 0;
	
	
	
begin

print_log('  Processing Procedure: om_items to show chart');

select count(item_key) into l_oeoh_cnt
from wf_items
where item_type = 'OEOH';

select count(item_key) into l_oeol_cnt
from wf_items
where item_type = 'OEOL';

select sum(CNT_TOTAL) into l_chart_om_cnt from (
select count(item_key) as "CNT_TOTAL" 
from wf_items wi
where wi.item_type in ('OEOH', 'OEOL', 'OEOI', 'OECOGS', 'OEOA', 'OECHGORD','OEON','OEBH')
   or (wi.item_type like '%ERROR%' and wi.parent_item_type in ('OEOH', 'OEOL', 'OMERROR', 'OEOI', 'OECOGS', 'OEOA', 'OECHGORD','OEON','OEBH'))
   group by item_type);
	
	print_out('<div class="divItem" id="sigONT_ITEMS_DIV">');
    
if ((l_oeoh_cnt > 0) and (l_chart_om_cnt > 0)) THEN 
	
	select count(item_key) into l_closedomcnt
	from wf_items
	where item_type = 'OEOH'
	and end_date is not null;

	select count(item_key) into l_openomcnt
	from wf_items
	where item_type = 'OEOH'
	and end_date is null;

    print_out('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    print_out('<tbody><font face="Calibri"><tr><td> ');
    print_out('<p><b>Order Management is being used!</b><BR> ');
    print_out('There are ' || to_char(l_oeoh_cnt,'999,999,999,999') || ' Order Header (OEOH) workflow items found in WF_ITEMS, and ' || to_char(l_oeol_cnt,'999,999,999,999') || ' Order Lines (OEOL).<BR>');
    print_out('Currently ' || (round(l_openomcnt/l_oeoh_cnt, 2)*100) || '% (' || to_char(l_openomcnt,'999,999,999,999') || ') of OEOHs are OPEN,');
    print_out(' while ' || (round(l_closedomcnt/l_oeoh_cnt, 2)*100) || '% (' || to_char(l_closedomcnt,'999,999,999,999') || ') are CLOSED, but still found in the runtime tables.<BR><BR>');
    print_out('The following collection of information is a sample of the more complete Order Management Review that you can get from running OMSuiteDataChk.sql,');
    print_out(' found in <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\&sourceId=1369938.1\\&id=353991.1" target="_blank">Doc ID 353991.1</a>.<BR>');
    print_out('The purpose of the OMSuiteDataChk.sql script is to collect information related to data integrity in OM and Shipping products.<BR></p>');
    print_out('</td></tr></font></tbody> ');
    print_out('</table><BR>');


	select nvl(max(rownum), 0) into l_oeoh_cnt
	from wf_items wi
	where wi.item_type in ('OEOH');

	select nvl(max(rownum), 0) into l_oeol_cnt
	from wf_items wi
	where wi.item_type in ('OEOL');
	
	select nvl(max(rownum), 0) into l_omerror_cnt
	from wf_items wi
	where wi.item_type in ('OMERROR');
	
	select nvl(max(rownum), 0) into l_oeoi_cnt
	from wf_items wi
	where wi.item_type in ('OEOI');
	
	select nvl(max(rownum), 0) into l_oecogs_cnt
	from wf_items wi
	where wi.item_type in ('OECOGS');

	select nvl(max(rownum), 0) into l_oeoa_cnt
	from wf_items wi
	where wi.item_type in ('OEOA');
	
	select nvl(max(rownum), 0) into l_oechg_cnt
	from wf_items wi
	where wi.item_type in ('OECHGORD');
	
	select nvl(max(rownum), 0) into l_oeon_cnt
	from wf_items wi
	where wi.item_type in ('OEON');
	
	select nvl(max(rownum), 0) into l_oebh_cnt
	from wf_items wi
	where wi.item_type in ('OEBH');	
	
	select nvl(max(rownum), 0) into l_oewferr_cnt
	from wf_items wi
	where wi.item_type = 'WFERROR' and wi.parent_item_type in ('OEOH', 'OEOL', 'OMERROR', 'OEOI', 'OECOGS', 'OEOA', 'OECHGORD','OEON','OEBH');
	
	select round(l_oeoh_cnt/l_chart_om_cnt,2)*100 into l_oeohrate from dual;
	select round(l_oeol_cnt/l_chart_om_cnt,2)*100 into l_oeolrate from dual;
	select round(l_omerror_cnt/l_chart_om_cnt,2)*100 into l_omerrorrate from dual;
	select round(l_oeoi_cnt/l_chart_om_cnt,2)*100 into l_oeoirate from dual;
	select round(l_oecogs_cnt/l_chart_om_cnt,2)*100 into l_oecogsrate from dual;
	select round(l_oeoa_cnt/l_chart_om_cnt,2)*100 into l_oeoarate from dual;
	select round(l_oechg_cnt/l_chart_om_cnt,2)*100 into l_oechgrate from dual;
	select round(l_oewferr_cnt/l_chart_om_cnt,2)*100 into l_oewferrrate from dual;
	select round(l_oeon_cnt/l_chart_om_cnt,2)*100 into l_oeonrate from dual;
	select round(l_oebh_cnt/l_chart_om_cnt,2)*100 into l_oebhrate from dual;	

print_out('<BR><B><U>Show the status of the Order Management Workflows for this instance</B></U><BR>');

	print_out('<blockquote><img src="');
	print_out('https://chart.googleapis.com/chart?chs=550x270&chco=3072F3');
	print_out('&chd=t:'||l_oeohrate||','||l_oeolrate||','||l_omerrorrate||','||l_oeoirate||','||l_oecogsrate||','||l_oeoarate||','||l_oechgrate||','||l_oewferrrate||','||l_oeonrate||','||l_oebhrate||'');
	print_out('&cht=p3&chtt=Order+Management+Workflows');
	print_out('&chl=OEOH|OEOL|OMERROR|OEOI|OECOGS|OEOA|OECHGORD|WFERROR|OEON|OEBH');
	print_out('&chdl='||l_oeoh_cnt||'|'||l_oeol_cnt||'|'||l_omerror_cnt||'|'||l_oeoi_cnt||'|'||l_oecogs_cnt||'|'||l_oeoa_cnt||'|'||l_oechg_cnt||'|'||l_oewferr_cnt||'|'||l_oeon_cnt||'|'||l_oebh_cnt||'"><BR>');
	print_out('Item Types</blockquote>');
	
  	print_out('<table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">');
  	print_out('<tbody><tr><td> ');
  	print_out('<p><B>Attention:<BR>');
  	print_out('There are '||to_char(l_chart_om_cnt,'999,999,999,999')||' Order Management Workflows found on this instance.</B><BR>');
  	print_out('This includes OEOH, OEOL, OEOI, OECOGS, OEOA, OECHGORD,OEON, OEBH, plus OMERROR and WFERROR belonging to these workflows.<br><br>
For additional Order Management Specific Analyzers, please review the Order Management section under Manufacturing in [1545562.1] Product Support Analyzer Index.');
  	print_out('</p></td></tr></tbody></table><BR>');       
  
       
  elsif ((l_oeoh_cnt = 0) and (l_chart_om_cnt = 0)) THEN 
    
    print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    print_out('<tbody><font face="Calibri"><tr><td> ');
    print_out('<p><B>Attention:<br>');    
    print_out('<p><b>Order Management is not being used!</b><BR> ');
    print_out('There are no Order Header (OEOH) workflow items found in WF_ITEMS, so we will skip this section..<BR><br>');
    print_out('The following Table Headers may still display, however the queries are not run for this section..<BR>');
    print_out('</p></td></tr></font></tbody></table><BR>');

  else

    print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    print_out('<tbody><font face="Calibri"><tr><td> ');
    print_out('<p><B>Attention:<br>');    
    print_out('Order Management does not appear to be used on this instance, so we will skip this section.</b><BR><br> ');
    print_out('There are only ' || to_char(l_oeoh_cnt,'999,999,999,999') || ' Order Header (OEOH) workflow items found in WF_ITEMS.<BR>');
    print_out('The following Table Headers may still display, however the queries are not run for this section..<BR><BR>');
    print_out('</p></td></tr></font></tbody></table><BR>'); 

 end if;   

 --  	print_out('</div><br>');
   	print_out('</div><br><font style="font-size:x-small;">');
    print_out('<a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');

EXCEPTION WHEN OTHERS THEN
  print_log('Error in om_items');
  raise;	
end om_items;


----------------------------------------------------------------
-- Display current Human Resources Items in a Pie Chart       --
----------------------------------------------------------------
PROCEDURE hcm_items IS
	l_hrcnt			number := 0;
	l_chart_hr		number := 0;
	l_chrcnt		number := 0;
	l_ohrcnt		number := 0;
	l_c1 			number := 0;
	l_c2 			number := 0;
	l_c3 			number := 0;
	l_c4 			number := 0;
	l_c5 			number := 0;
	l_c6 			number := 0;
	l_c7 			number := 0;
	l_c8 			number := 0;
	l_c9 			number := 0;
	l_c10 			number := 0;
	l_hr_cnt 		number := 0;
	l_c11 			number := 0;
	l_c12 			number := 0;
	l_c13 			number := 0;
	l_c14 			number := 0;
	l_r1		 	number := 0;
	l_r2		 	number := 0;
	l_r3		 	number := 0;
	l_r4		 	number := 0;
	l_r5		 	number := 0;
	l_r6		 	number := 0;
	l_r7		 	number := 0;
	l_r8		 	number := 0;
	l_r9		 	number := 0;
	l_r10		 	number := 0;
	l_hrsrate		number := 0;
	l_r11		 	number := 0;
	l_r12		 	number := 0;
	l_r13		 	number := 0;
	l_r14		 	number := 0;


begin

print_log('  Processing Procedure: hcm_items to show chart');

select count(item_key) into l_hrcnt
from wf_items
where item_type = 'HRSSA';

select sum(CNT_TOTAL) into l_chart_hr from (
select count(item_key) as "CNT_TOTAL" 
from wf_items wi
where wi.item_type in ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'OTWF', 'PYASGWF', 'HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC', 'PSPERAVL')    
     or (wi.item_type like '%ERROR%' and wi.parent_item_type in ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'OTWF', 'PYASGWF', 'HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC', 'PSPERAVL'))
   group by item_type);
	
	print_out('<div class="divItem" id="sigHCM_ITEMS_DIV">');
	
if ((l_hrcnt > 0) and (l_chart_hr > 0)) THEN 
	
	select count(item_key) into l_chrcnt
	from wf_items
	where item_type = 'HRSSA'
	and end_date is not null;

	select count(item_key) into l_ohrcnt
	from wf_items
	where item_type = 'HRSSA'
	and end_date is null;
   
    print_out('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    print_out('<tbody><font face="Calibri"><tr><td> ');
    print_out('<p><b>Human Resources is being used!</b><BR> ');
    print_out('There are ' || to_char(l_hrcnt,'999,999,999,999') || ' HR (HRSSA) workflow items found in WF_ITEMS.<BR>');
    print_out('Currently ' || (round(l_ohrcnt/l_hrcnt, 2)*100) || '% (' || to_char(l_ohrcnt,'999,999,999,999') || ') of HRSSAs are OPEN,');
    print_out(' while ' || (round(l_chrcnt/l_hrcnt, 2)*100) || '% (' || to_char(l_chrcnt,'999,999,999,999') || ') are CLOSED, but still found in the runtime tables.<BR><BR>');
    print_out('The following collection of information is a sample of the more complete Human Resources Review that you can get from <a href="https://support.oracle.com/epmos/faces/documentdisplay?parent=analyzer&sourceid=1369938.1&id=1562530.1" target="_blank">Doc ID 1562530.1</a> - Human Capital Management (HCM) Technical Analyzer script ');
    print_out('(Human Resources, Self Service Human Resources, Payroll, Time and Labor, Benefits, iRecruitment, Learning Management).<BR></p>');
    print_out('</td></tr></font></tbody> ');
    print_out('</table><BR>');


	select nvl(max(rownum), 0) into l_c1
	from wf_items wi
	where wi.item_type in ('BENCWBFY');

	select nvl(max(rownum), 0) into l_c2
	from wf_items wi
	where wi.item_type in ('SSBEN');
	
	select nvl(max(rownum), 0) into l_c3
	from wf_items wi
	where wi.item_type in ('GHR_SF52');
	
	select nvl(max(rownum), 0) into l_c4
	from wf_items wi
	where wi.item_type in ('HXCEMP');
	
	select nvl(max(rownum), 0) into l_c5
	from wf_items wi
	where wi.item_type in ('HXCSAW');

	select nvl(max(rownum), 0) into l_c6
	from wf_items wi
	where wi.item_type in ('IRC_NTF');
	
	select nvl(max(rownum), 0) into l_c7
	from wf_items wi
	where wi.item_type in ('IRCOFFER');

	select nvl(max(rownum), 0) into l_c8
	from wf_items wi
	where wi.item_type in ('OTWF');
	
	select nvl(max(rownum), 0) into l_c9
	from wf_items wi
	where wi.item_type in ('PYASGWF');
	
	select nvl(max(rownum), 0) into l_c10
	from wf_items wi
	where wi.item_type in ('HRCKLTSK');
	
	select nvl(max(rownum), 0) into l_hr_cnt
	from wf_items wi
	where wi.item_type in ('HRSSA');

	select nvl(max(rownum), 0) into l_c11
	from wf_items wi
	where wi.item_type in ('HRWPM');
	
	select nvl(max(rownum), 0) into l_c12
	from wf_items wi
	where wi.item_type in ('HRRIRPRC');
	
	select nvl(max(rownum), 0) into l_c13
	from wf_items wi
	where wi.item_type in ('PSPERAVL');
	
	select nvl(max(rownum), 0) into l_c14
	from wf_items wi
	where wi.item_type = 'WFERROR' and wi.parent_item_type in ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'OTWF', 'PYASGWF', 'HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC', 'PSPERAVL');
	
 	select round(l_c1/l_chart_hr,2)*100 into l_r1 from dual;
 	select round(l_c2/l_chart_hr,2)*100 into l_r2 from dual;
 	select round(l_c3/l_chart_hr,2)*100 into l_r3 from dual;
 	select round(l_c4/l_chart_hr,2)*100 into l_r4 from dual;
 	select round(l_c5/l_chart_hr,2)*100 into l_r5 from dual;
 	select round(l_c6/l_chart_hr,2)*100 into l_r6 from dual;
 	select round(l_c7/l_chart_hr,2)*100 into l_r7 from dual;
 	select round(l_c8/l_chart_hr,2)*100 into l_r8 from dual;
 	select round(l_c9/l_chart_hr,2)*100 into l_r9 from dual;
 	select round(l_c10/l_chart_hr,2)*100 into l_r10 from dual;
 	select round(l_hr_cnt/l_chart_hr,2)*100 into l_hrsrate from dual;
 	select round(l_c11/l_chart_hr,2)*100 into l_r11 from dual;
 	select round(l_c12/l_chart_hr,2)*100 into l_r12 from dual;
 	select round(l_c13/l_chart_hr,2)*100 into l_r13 from dual;
 	select round(l_c14/l_chart_hr,2)*100 into l_r14 from dual;

print_out('<BR><B><U>Show the status of the Human Resources Workflows for this instance</B></U><BR><BR>');

	print_out('<blockquote><img src="');
	print_out('https://chart.googleapis.com/chart?chs=550x270&chco=7777CC');
	print_out('&chd=t:'||l_r1||','||l_r2||','||l_r3||','||l_r4||','||l_r5||','||l_r6||','||l_r7||','||l_r8||','||l_r9||','||l_r10||','||l_hrsrate||','||l_r11||','||l_r12||','||l_r13||'');
	print_out('&cht=p3&chtt=Human+Resources+Workflows');
	print_out('&chl=BENCWBFY|SSBEN|GHR_SF52|HXCEMP|HXCSAW|IRC_NTF|IRCOFFER|OTWF|PYASGWF|HRCKLTSK|HRSSA|HRWPM|HRRIRPRC|PSPERAVL');
	print_out('&chdl='||l_c1||'|'||l_c2||'|'||l_c3||'|'||l_c4||'|'||l_c5||'|'||l_c6||'|'||l_c7||'|'||l_c8||'|'||l_c9||'|'||l_c10||'|'||l_hr_cnt||'|'||l_c11||'|'||l_c12||'|'||l_c13||'"><BR>');
	print_out('Item Types</blockquote>');


  	print_out('<table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">');
  	print_out('<tbody><tr><td> ');
  	print_out('<p><B>Attention:<BR>');
  	print_out('There are '||to_char(l_chart_hr,'999,999,999,999')||' Human Resources Workflows found on this instance.</B><br><br>
For additional HR Specific Analyzers, please review the Human Capital Management section in <a href="https://support.oracle.com/epmos/faces/documentdisplay?parent=analyzer&sourceid=1369938.1&id=1545562.1" target="_blank">Doc ID 1545562.1</a> Product Support Analyzer Index.');
  	print_out('</p></td></tr></tbody></table><BR>');


  elsif ((l_hrcnt = 0) and (l_chart_hr = 0)) THEN 
    
    print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    print_out('<tbody><font face="Calibri"><tr><td> ');
    print_out('<p><B>Attention:<br>');    
    print_out('Order Management is not being used!</b><BR> ');
    print_out('There are no Human Resources (HRSSA) workflow items found in WF_ITEMS, so we will skip this section..<BR>');
    print_out('The following Table Headers may still display, however the queries are not run for this section..<BR>');
    print_out('</p></td></tr></font></tbody></table><BR>');

  else

    print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    print_out('<tbody><font face="Calibri"><tr><td> ');
    print_out('<p><B>Attention:<br>');    
    print_out('Human Resources does not appear to be used on this instance, so we will skip this section.</b><BR> ');
    print_out('There are only ' || to_char(l_hrcnt,'999,999,999,999') || ' Human Resources (HRSSA) workflow items found in WF_ITEMS.<BR>');
    print_out('The following Table Headers may still display, however the queries are not run for this section..<BR>');
    print_out('</p></td></tr></font></tbody></table><BR>');

 end if;   

  --  	print_out('</div><br>');
   	print_out('</div><br><font style="font-size:x-small;">');
    print_out('<a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');

EXCEPTION WHEN OTHERS THEN
  print_log('Error in hcm_items');
  raise;	
end hcm_items;


----------------------------------------------------------------
-- Display current Purchasing Workflow Items in a Pie Chart   --
----------------------------------------------------------------
PROCEDURE po_items IS
	l_po_cnt		number := 0;
	l_chart_po		number := 0;
	l_cpocnt		number := 0;
	l_opocnt		number := 0;
	l_c1			number := 0;
	l_c2			number := 0;
	l_c3			number := 0;
	l_c4			number := 0;
	l_c5			number := 0;
	l_c6			number := 0;
	l_c7			number := 0;
	l_c8			number := 0;
	l_c9			number := 0;
	l_c10			number := 0;
	l_poerr_cnt		number := 0;
	l_c11			number := 0;
	l_c12			number := 0;
	l_c13			number := 0;
	l_c14			number := 0;
	l_c15			number := 0;
	l_c16			number := 0;
	l_c17			number := 0;
	l_c18			number := 0;
	l_c19			number := 0;
	l_c20			number := 0;
	l_c21			number := 0;
	l_c22			number := 0;
	l_c23			number := 0;
	l_r1			number := 0;
	l_r2			number := 0;
	l_r3			number := 0;
	l_r4			number := 0;
	l_r5			number := 0;
	l_r6			number := 0;
	l_r7			number := 0;
	l_r8			number := 0;
	l_r9			number := 0;
	l_r10			number := 0;
	l_poerrate		number := 0;
	l_r11			number := 0;
	l_r12			number := 0;
	l_r13			number := 0;
	l_r14			number := 0;
	l_r15			number := 0;
	l_r16			number := 0;
	l_r17			number := 0;
	l_r18			number := 0;
	l_r19			number := 0;
	l_r20			number := 0;
	l_r21			number := 0;
	l_r22			number := 0;
	l_r23			number := 0;
		
	
begin

print_log('  Processing Procedure: po_items to show chart');

select count(item_key) into l_po_cnt
from wf_items
where item_type = 'POAPPRV';

select sum(CNT_TOTAL) into l_chart_po from (
select count(item_key) as "CNT_TOTAL" 
from wf_items wi
where wi.item_type in ('POAPPRV','REQAPPRV','POXML','POWFRQAG','PORCPT','APVRMDER','PONPBLSH','POSPOACK','PONAUCT','PORPOCHA','PODSNOTF','POSREGV2','POREQCHA','POWFPOAG','POSCHORD','POSASNNB','PONAPPRV','POSCHPDT','POAUTH','POWFDS','POERROR','POSBPR','CREATEPO')    
     or (wi.item_type like '%ERROR%' and wi.parent_item_type in ('POAPPRV','REQAPPRV','POXML','POWFRQAG','PORCPT','APVRMDER','PONPBLSH','POSPOACK','PONAUCT','PORPOCHA','PODSNOTF','POSREGV2','POREQCHA','POWFPOAG','POSCHORD','POSASNNB','PONAPPRV','POSCHPDT','POAUTH','POWFDS','POERROR','POSBPR','CREATEPO'))
   group by item_type);
	
	print_out('<div class="divItem" id="sigPO_ITEMS_DIV">');
	
if ((l_po_cnt > 0) and (l_chart_po > 0)) THEN 
	
	select count(item_key) into l_cpocnt
	from wf_items
	where item_type = 'POAPPRV'
	and end_date is not null;

	select count(item_key) into l_opocnt
	from wf_items
	where item_type = 'POAPPRV'
	and end_date is null;

    print_out('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    print_out('<tbody><font face="Calibri"><tr><td> ');
    print_out('<p><b>Purchasing is being used!</b><BR> ');
    print_out('There are ' || to_char(l_po_cnt,'999,999,999,999') || ' Purchasing Approval (POAPPRV) workflow items found in WF_ITEMS.<BR>');
    print_out('Currently ' || (round(l_opocnt/l_po_cnt, 2)*100) || '% (' || to_char(l_opocnt,'999,999,999,999') || ') of POAPPRVs are OPEN,');
    print_out(' while ' || (round(l_cpocnt/l_po_cnt, 2)*100) || '% (' || to_char(l_cpocnt,'999,999,999,999') || ') are CLOSED, but still found in the runtime tables.<BR>');

    if (g_rep_info('Apps Version') >= '12.0') then 
       print_out('<BR>The following collection of information is a sample of the more complete Purchasing Review that you can get from running the PO Approval analyzer');
       print_out('concurrent process or po_apprvl_analyzer.sql script.<br>');
       print_out('In order to install the PO Approval Analyzer, see <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\&sourceId=1369938.1\\&id=1525670.1" target="_blank">Doc ID 1525670.1</a>.</p>');
    else
	print_out('<br>');
    end if;

    print_out('</td></tr></font></tbody> ');
    print_out('</table><BR>');


	select nvl(max(rownum), 0) into l_c1
	from wf_items wi
	where wi.item_type in ('POAPPRV');

	select nvl(max(rownum), 0) into l_c2
	from wf_items wi
	where wi.item_type in ('REQAPPRV');
	
	select nvl(max(rownum), 0) into l_c3
	from wf_items wi
	where wi.item_type in ('POXML');
	
	select nvl(max(rownum), 0) into l_c4
	from wf_items wi
	where wi.item_type in ('POWFRQAG');
	
	select nvl(max(rownum), 0) into l_c5
	from wf_items wi
	where wi.item_type in ('PORCPT');

	select nvl(max(rownum), 0) into l_c6
	from wf_items wi
	where wi.item_type in ('APVRMDER');
	
	select nvl(max(rownum), 0) into l_c7
	from wf_items wi
	where wi.item_type in ('PONPBLSH');

	select nvl(max(rownum), 0) into l_c8
	from wf_items wi
	where wi.item_type in ('POSPOACK');
	
	select nvl(max(rownum), 0) into l_c9
	from wf_items wi
	where wi.item_type in ('PONAUCT');
	
	select nvl(max(rownum), 0) into l_c10
	from wf_items wi
	where wi.item_type in ('PORPOCHA');
	
	select nvl(max(rownum), 0) into l_poerr_cnt
	from wf_items wi
	where wi.item_type in ('POERROR');

	select nvl(max(rownum), 0) into l_c11
	from wf_items wi
	where wi.item_type in ('POSREGV2');
	
	select nvl(max(rownum), 0) into l_c12
	from wf_items wi
	where wi.item_type in ('POREQCHA');
	
	select nvl(max(rownum), 0) into l_c13
	from wf_items wi
	where wi.item_type in ('POWFPOAG');
	
	select nvl(max(rownum), 0) into l_c14
	from wf_items wi
	where wi.item_type in ('POSCHORD');
	
	select nvl(max(rownum), 0) into l_c15
	from wf_items wi
	where wi.item_type in ('POSASNNB');

	select nvl(max(rownum), 0) into l_c16
	from wf_items wi
	where wi.item_type in ('PONAPPRV');
	
	select nvl(max(rownum), 0) into l_c17
	from wf_items wi
	where wi.item_type in ('POSCHPDT');
	
	select nvl(max(rownum), 0) into l_c18
	from wf_items wi
	where wi.item_type in ('POAUTH');
	
	select nvl(max(rownum), 0) into l_c19
	from wf_items wi
	where wi.item_type in ('POWFDS');

	select nvl(max(rownum), 0) into l_c20
	from wf_items wi
	where wi.item_type in ('PODSNOTF');
	
	select nvl(max(rownum), 0) into l_c21
	from wf_items wi
	where wi.item_type in ('POSBPR');
	
	select nvl(max(rownum), 0) into l_c22
	from wf_items wi
	where wi.item_type in ('CREATEPO');

	select nvl(max(rownum), 0) into l_c23
	from wf_items wi
	where wi.item_type = 'WFERROR' and wi.parent_item_type in ('POAPPRV','REQAPPRV','POXML','POWFRQAG','PORCPT','APVRMDER','PONPBLSH','POSPOACK','PONAUCT','PORPOCHA','PODSNOTF','POSREGV2','POREQCHA','POWFPOAG','POSCHORD','POSASNNB','PONAPPRV','POSCHPDT','POAUTH','POWFDS','POERROR','POSBPR','CREATEPO');
	
 	select round(l_c1/l_chart_po,2)*100 into l_r1 from dual;
 	select round(l_c2/l_chart_po,2)*100 into l_r2 from dual;
 	select round(l_c3/l_chart_po,2)*100 into l_r3 from dual;
 	select round(l_c4/l_chart_po,2)*100 into l_r4 from dual;
 	select round(l_c5/l_chart_po,2)*100 into l_r5 from dual;
 	select round(l_c6/l_chart_po,2)*100 into l_r6 from dual;
 	select round(l_c7/l_chart_po,2)*100 into l_r7 from dual;
 	select round(l_c8/l_chart_po,2)*100 into l_r8 from dual;
 	select round(l_c9/l_chart_po,2)*100 into l_r9 from dual;
 	select round(l_c10/l_chart_po,2)*100 into l_r10 from dual;
 	select round(l_poerr_cnt/l_chart_po,2)*100 into l_poerrate from dual;
 	select round(l_c11/l_chart_po,2)*100 into l_r11 from dual;
 	select round(l_c12/l_chart_po,2)*100 into l_r12 from dual;
 	select round(l_c13/l_chart_po,2)*100 into l_r13 from dual;
 	select round(l_c14/l_chart_po,2)*100 into l_r14 from dual;
 	select round(l_c15/l_chart_po,2)*100 into l_r15 from dual;
 	select round(l_c16/l_chart_po,2)*100 into l_r16 from dual;
 	select round(l_c17/l_chart_po,2)*100 into l_r17 from dual;
 	select round(l_c18/l_chart_po,2)*100 into l_r18 from dual;
 	select round(l_c19/l_chart_po,2)*100 into l_r19 from dual; 	
 	select round(l_c20/l_chart_po,2)*100 into l_r20 from dual;
 	select round(l_c21/l_chart_po,2)*100 into l_r21 from dual;
 	select round(l_c22/l_chart_po,2)*100 into l_r22 from dual;
 	select round(l_c23/l_chart_po,2)*100 into l_r23 from dual;


print_out('<BR><B><U>Show the status of the Purchasing Workflows for this instance</B></U><BR><BR>');

	print_out('<blockquote><img src="');
	print_out('https://chart.googleapis.com/chart?chs=600x300&chco=006633');
	print_out('&chd=t:'||l_r1||','||l_r2||','||l_r3||','||l_r4||','||l_r5||','||l_r6||','||l_r7||','||l_r8||','||l_r9||','||l_r10||','||l_poerrate||','||l_r11||','||l_r12||','||l_r13||'');
	print_out('&cht=p3&chtt=Oracle+Purchasing+Workflows');
	print_out('&chl=POAPPRV|REQAPPRV|POXML|POWFRQAG|PORCPT|APVRMDER|PONPBLSH|POSPOACK|PONAUCT|PORPOCHA|PODSNOTF|POSREGV2|POREQCHA|POWFPOAG|POSCHORD|POSASNNB|PONAPPRV|POSCHPDT|POAUTH|POWFDS|POERROR|POSBPR|CREATEPO');
	print_out('&chdl='||l_c1||'|'||l_c2||'|'||l_c3||'|'||l_c4||'|'||l_c5||'|'||l_c6||'|'||l_c7||'|'||l_c8||'|'||l_c9||'|'||l_c10||'|'||l_poerr_cnt||'|'||l_c11||'|'||l_c12||'|'||l_c13||'|'||l_c14||'|'||l_c15||'|'||l_c16||'|'||l_c17||'|'||l_c18||'|'||l_c19||'|'||l_c20||'|'||l_c21||'|'||l_c22||'|'||l_c23||'"><BR>');
	print_out('Item Types</blockquote>');

  	print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
  	print_out('<tbody><tr><td> ');
  	print_out('<p><B>Attention:<BR>');
  	print_out('There are '||to_char(l_chart_po,'999,999,999,999')||' Purchasing Type Workflows found on this instance.</B><br><br>
For additional PO Specific Analyzers, please review the Procurement section under Manufacturing in [1545562.1] Product Support Analyzer Index.');
  	print_out('</p></td></tr></tbody></table><BR>');


  elsif ((l_po_cnt = 0) and (l_chart_po = 0)) THEN 
    
    print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    print_out('<tbody><font face="Calibri"><tr><td> ');
    print_out('<p><B>Attention:<br>');    
    print_out('<b>Oracle Purchasing is not being used!</b><BR> ');
    print_out('There are no Purchasing Approval (POAPPRV) workflow items found in WF_ITEMS, so we will skip this section..<BR>');
    print_out('The following Table Headers may still display, however the queries are not run for this section..<BR>');
    print_out('</p></td></tr></font></tbody></table><BR>');

  else

    print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    print_out('<tbody><font face="Calibri"><tr><td> ');
    print_out('<p><B>Attention:<br>');    
    print_out('Oracle Purchasing does not appear to be used on this instance, so we will skip this section.</b><BR> ');
    print_out('There are only ' || to_char(l_po_cnt,'999,999,999,999') || ' Purchasing Approval (POAPPRV) workflow items found in WF_ITEMS.<BR>');
    print_out('The following Table Headers may still display, however the queries are not run for this section..<BR>');
    print_out('</p></td></tr></font></tbody></table><BR>');

 end if;   
 
  --  	print_out('</div><br>');
   	print_out('</div><br><font style="font-size:x-small;">');
    print_out('<a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');

EXCEPTION WHEN OTHERS THEN
  print_log('Error in po_items');
  raise;	
end po_items;

-----------------------------------------------------------------------------
-- Display status of the Workflow Notification Mailer(s) for this instance --
-- Offer recommendations using best practices                              --
-----------------------------------------------------------------------------
PROCEDURE java_mailer_status IS
  v_comp_id 			number;
  l_mailer_cnt			number;
  l_mailer_status		VARCHAR2(30);
  l_corrid  			VARCHAR2(240);
  l_startup_mode		VARCHAR2(30);
  l_container_name		VARCHAR2(240);
  l_component_name		VARCHAR2(80);  
  l_email_override 		VARCHAR2(1996);
  l_expunge				VARCHAR2(1996);
  
cursor c_mailerIDs IS
	select fsc.COMPONENT_ID
	from APPS.FND_CONCURRENT_QUEUES_VL fcq, APPS.FND_CP_SERVICES fcs, 
	APPS.FND_CONCURRENT_PROCESSES fcp, fnd_svc_components fsc, FND_SVC_COMP_PARAM_VALS_V v
	where v.COMPONENT_ID=fsc.COMPONENT_ID
	and fcq.MANAGER_TYPE = fcs.SERVICE_ID 
	and fcs.SERVICE_HANDLE = 'FNDCPGSC' 
	and fsc.concurrent_queue_id = fcq.concurrent_queue_id(+)
	and fcq.concurrent_queue_id = fcp.concurrent_queue_id(+) 
	and fcq.application_id = fcp.queue_application_id(+) 
	and fcp.process_status_code(+) = 'A'
	and v.PARAMETER_NAME = 'PROCESSOR_IN_THREAD_COUNT'
	and fcq.USER_CONCURRENT_QUEUE_NAME = 'Workflow Mailer Service';

begin

	select nvl(max(rownum), 0) into l_mailer_cnt
	from APPS.FND_CONCURRENT_QUEUES_VL fcq, APPS.FND_CP_SERVICES fcs, 
	APPS.FND_CONCURRENT_PROCESSES fcp, fnd_svc_components fsc, FND_SVC_COMP_PARAM_VALS_V v
	where v.COMPONENT_ID=fsc.COMPONENT_ID
	and fcq.MANAGER_TYPE = fcs.SERVICE_ID 
	and fcs.SERVICE_HANDLE = 'FNDCPGSC' 
	and fsc.concurrent_queue_id = fcq.concurrent_queue_id(+)
	and fcq.concurrent_queue_id = fcp.concurrent_queue_id(+) 
	and fcq.application_id = fcp.queue_application_id(+) 
	and fcp.process_status_code(+) = 'A'
	and v.PARAMETER_NAME = 'PROCESSOR_IN_THREAD_COUNT'
	and fcq.USER_CONCURRENT_QUEUE_NAME = 'Workflow Mailer Service';
	
  print_out('<div class="divItem" id="sigJAVA_MLR">');

  if (l_mailer_cnt = 0) then

       print_out('There is no Mailer Service defined for this instance.<BR>');
       print_out('Check the setup of GSM to understand why the Mailer Service is not created or running.<BR><BR> ');

  elsif (l_mailer_cnt = 1) then
 
       print_out('There is only one Notification mailer found on this instance.<BR>');
       print_out('The Workflow Notification Mailer is the default seeded mailer that comes with EBS. <BR><BR> ');
  
  else 
  
       print_out('There are multiple mailers found on this instance.<BR>');
       print_out('The separate mailers will be looked at individually. <BR><BR> ');
       
  end if;
  
 
  OPEN c_mailerIDs;
  LOOP
  
    Fetch c_mailerIDs INTO v_comp_id;
  
    EXIT WHEN c_mailerIDs%NOTFOUND;

	 
    if (g_mailer_enabled = 'DISABLED') then  --MLR_DISABLED
       
        print_out('The '|| l_component_name ||' is currently ' || g_mailer_enabled || ', so no email notifications can be sent. <BR>');
       
    elsif (g_mailer_enabled = 'ENABLED') then  --MLR_ENABLED
       
       	select fsc.COMPONENT_STATUS into l_mailer_status
       	from APPS.FND_CONCURRENT_QUEUES_VL fcq, APPS.FND_CP_SERVICES fcs, 
       	APPS.FND_CONCURRENT_PROCESSES fcp, fnd_svc_components fsc, FND_SVC_COMP_PARAM_VALS_V v
       	where v.COMPONENT_ID=fsc.COMPONENT_ID
       	and fsc.COMPONENT_ID = v_comp_id
       	and fcq.MANAGER_TYPE = fcs.SERVICE_ID 
       	and fcs.SERVICE_HANDLE = 'FNDCPGSC' 
       	and fsc.concurrent_queue_id = fcq.concurrent_queue_id(+)
       	and fcq.concurrent_queue_id = fcp.concurrent_queue_id(+) 
       	and fcq.application_id = fcp.queue_application_id(+) 
       	and fcp.process_status_code(+) = 'A'
       	and v.PARAMETER_NAME = 'PROCESSOR_IN_THREAD_COUNT'
       	and fcq.USER_CONCURRENT_QUEUE_NAME = 'Workflow Mailer Service';

       	select nvl(fsc.CORRELATION_ID,'NULL') into l_corrid
       	from APPS.FND_CONCURRENT_QUEUES_VL fcq, APPS.FND_CP_SERVICES fcs, 
       	APPS.FND_CONCURRENT_PROCESSES fcp, fnd_svc_components fsc, FND_SVC_COMP_PARAM_VALS_V v
       	where v.COMPONENT_ID=fsc.COMPONENT_ID
       	and fsc.COMPONENT_ID = v_comp_id
       	and fcq.MANAGER_TYPE = fcs.SERVICE_ID 
       	and fcs.SERVICE_HANDLE = 'FNDCPGSC' 
       	and fsc.concurrent_queue_id = fcq.concurrent_queue_id(+)
       	and fcq.concurrent_queue_id = fcp.concurrent_queue_id(+) 
       	and fcq.application_id = fcp.queue_application_id(+) 
       	and fcp.process_status_code(+) = 'A'
       	and v.PARAMETER_NAME = 'PROCESSOR_IN_THREAD_COUNT'
       	and fcq.USER_CONCURRENT_QUEUE_NAME = 'Workflow Mailer Service';
       	
       	select fsc.STARTUP_MODE into l_startup_mode
       	from APPS.FND_CONCURRENT_QUEUES_VL fcq, APPS.FND_CP_SERVICES fcs, 
       	APPS.FND_CONCURRENT_PROCESSES fcp, fnd_svc_components fsc, FND_SVC_COMP_PARAM_VALS_V v
       	where v.COMPONENT_ID=fsc.COMPONENT_ID
       	and fsc.COMPONENT_ID = v_comp_id
       	and fcq.MANAGER_TYPE = fcs.SERVICE_ID 
       	and fcs.SERVICE_HANDLE = 'FNDCPGSC' 
       	and fsc.concurrent_queue_id = fcq.concurrent_queue_id(+)
       	and fcq.concurrent_queue_id = fcp.concurrent_queue_id(+) 
       	and fcq.application_id = fcp.queue_application_id(+) 
       	and fcp.process_status_code(+) = 'A'
       	and v.PARAMETER_NAME = 'PROCESSOR_IN_THREAD_COUNT'
       	and fcq.USER_CONCURRENT_QUEUE_NAME = 'Workflow Mailer Service';
       	
       	select fcq.USER_CONCURRENT_QUEUE_NAME into l_container_name
       	from APPS.FND_CONCURRENT_QUEUES_VL fcq, APPS.FND_CP_SERVICES fcs, 
       	APPS.FND_CONCURRENT_PROCESSES fcp, fnd_svc_components fsc, FND_SVC_COMP_PARAM_VALS_V v
       	where v.COMPONENT_ID=fsc.COMPONENT_ID
       	and fsc.COMPONENT_ID = v_comp_id
       	and fcq.MANAGER_TYPE = fcs.SERVICE_ID 
       	and fcs.SERVICE_HANDLE = 'FNDCPGSC' 
       	and fsc.concurrent_queue_id = fcq.concurrent_queue_id(+)
       	and fcq.concurrent_queue_id = fcp.concurrent_queue_id(+) 
       	and fcq.application_id = fcp.queue_application_id(+) 
       	and fcp.process_status_code(+) = 'A'
       	and v.PARAMETER_NAME = 'PROCESSOR_IN_THREAD_COUNT'
       	and fcq.USER_CONCURRENT_QUEUE_NAME = 'Workflow Mailer Service';
        
		select fsc.COMPONENT_NAME into l_component_name
		from APPS.FND_CONCURRENT_QUEUES_VL fcq, APPS.FND_CP_SERVICES fcs, 
		APPS.FND_CONCURRENT_PROCESSES fcp, fnd_svc_components fsc, FND_SVC_COMP_PARAM_VALS_V v
		where v.COMPONENT_ID=fsc.COMPONENT_ID
		and fsc.COMPONENT_ID = v_comp_id
		and fcq.MANAGER_TYPE = fcs.SERVICE_ID 
		and fcs.SERVICE_HANDLE = 'FNDCPGSC' 
		and fsc.concurrent_queue_id = fcq.concurrent_queue_id(+)
		and fcq.concurrent_queue_id = fcp.concurrent_queue_id(+) 
		and fcq.application_id = fcp.queue_application_id(+) 
		and fcp.process_status_code(+) = 'A'
		and v.PARAMETER_NAME = 'PROCESSOR_IN_THREAD_COUNT'
		and fcq.USER_CONCURRENT_QUEUE_NAME = 'Workflow Mailer Service';
       	
       	select v.PARAMETER_VALUE into l_email_override 
       	from FND_SVC_COMP_PARAM_VALS_V v, FND_SVC_COMPONENTS fsc
       	where v.COMPONENT_ID=fsc.COMPONENT_ID 
       	and fsc.COMPONENT_ID = v_comp_id
       	and v.parameter_name = 'TEST_ADDRESS'
       	order by fsc.COMPONENT_ID, v.parameter_name;
       
       	select v.PARAMETER_VALUE into l_expunge 
       	from FND_SVC_COMP_PARAM_VALS_V v, FND_SVC_COMPONENTS fsc
       	where v.COMPONENT_ID=fsc.COMPONENT_ID 
       	and fsc.COMPONENT_ID = v_comp_id
       	and v.parameter_name = 'EXPUNGE_ON_CLOSE';
       	     
      print_out('The mailer called "'|| l_component_name ||'" is ' || g_mailer_enabled || ' with a component status of '|| l_mailer_status ||'. ');
      
      print_out('<br>The mailer parameter called EXPUNGE_ON_CLOSE is set to "'|| l_expunge ||'" for this mailer.<br>');

 
	 if (l_email_override = 'NONE') then --MLR_EMAIL_OVERRIDE_DISABLED

	    print_out('<BR>The Email Override (Test Address) feature is DISABLED as ' || l_email_override || ' for '|| l_component_name ||'. ');
	    print_out('<BR>This means that all emails with correlation_id of '|| l_corrid ||' that get sent by '|| l_component_name ||' will be sent to their intended recipients as expected when the mailer is running.<BR><BR> ');

	 elsif (l_email_override is not null) then  --MLR_EMAIL_OVERRIDE_ENABLED

	    print_out('<BR>The Email Override (Test Address) feature is ENABLED to ' || l_email_override || ' for '|| l_component_name ||'.');
	    print_out('<BR>This means that all emails that get sent by  '|| l_component_name ||' are re-routed and sent to this single Override email address (' || l_email_override || ') when the '|| l_component_name ||' is running.');
	    print_out('<BR>Please ensure this email address is correct.');
	    print_out('<BR>This is a standard setup for a production cloned (TEST or DEV) instance to avoid duplicate emails being sent to users.<BR><BR> ');

         end if;

  
      if (l_mailer_status = 'DEACTIVATED_USER') then

          if (l_startup_mode = 'AUTOMATIC') then --MLR_STRTUP_AUTO

    		 print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
	         print_out('<tbody><tr><td> ');
	         print_out('<B>Warning:</B><BR>');
	         print_out('The Workflow Java Mailer "'|| l_component_name ||'" is currently not running.<BR>');
	         print_out('<B>Action:</B><BR>');
	         print_out('If using the Java Mailer to send email notifications and alerts, please bounce the container : '|| l_container_name ||'.<BR>'); 
	         print_out('via the Oracle Application Manager - Workflow Manager screen to automatically restart the component : '|| l_component_name ||'.<BR>');
	         print_out('Please review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\&sourceId=1369938.1\\&id=1191125.1" target="_blank">Note 1191125.1');
	         print_out('</a> - Troubleshooting Oracle Workflow Java Notification Mailer, for more information.<BR>');
	         print_out('If you need to test the Mailer setup, then please review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\&sourceId=1369938.1\\&id=748421.1" target="_blank">Note 748421.1');
	         print_out('</a> - Java Mailer Setup Diagnostic Test (ATGSuppJavaMailerSetup12.sh).<BR>');
			 print_out('</p></td></tr></tbody></table><BR>');
		 
          elsif (l_startup_mode = 'MANUAL') then  --MLR_STRTUP_MANUAL

    		 print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
			 print_out('<tbody><tr><td> ');
			 print_out('<p><B>Warning:</B><BR>');
			 print_out('The Workflow Java Mailer "'|| l_component_name ||'" is currently not running..<BR>');
			 print_out('<B>Action:</B><BR>');
			 print_out('If using the Java Mailer to send email notifications and alerts, please manually start the : '|| l_component_name ||'.<BR>');
             print_out('via the Oracle Application Manager - Workflow Manager screen.');
	         print_out('Please review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\&sourceId=1369938.1\\&id=1191125.1" target="_blank">Note 1191125.1');
	         print_out('</a> - Troubleshooting Oracle Workflow Java Notification Mailer, for more information.<BR>');
			 print_out('</p></td></tr></tbody></table><BR>');
       
          end if;
           
      elsif (l_mailer_status = 'DEACTIVATED_SYSTEM') then  --MLR_DEACTVD_SYSTEM
          
             print_out('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
	         print_out('<tbody><tr><td> ');
	         print_out('<p><B>Error:</B><BR>');
	         print_out('The Workflow Java Mailer "'|| l_component_name ||'" is currently down due to an error detected by the System.<BR><BR>');
	         print_out('<B>Action:<BR>');
	         print_out('Please review the email that was sent to SYSADMIN regarding this error.</B><BR>'); 
	         print_out('The Java Mailer is currently set to startup mode of '|| l_startup_mode ||'.<BR>');
	         print_out('Please review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\&sourceId=1369938.1\\&id=1191125.1" target="_blank">Note 1191125.1');
	         print_out('</a> - Troubleshooting Oracle Workflow Java Notification Mailer,<BR>');
	         print_out('Also review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\&sourceId=1369938.1\\&id=748421.1" target="_blank">Note 748421.1');
	         print_out('</a> - Java Mailer Setup Diagnostic Test (ATGSuppJavaMailerSetup12.sh), for more information.<BR>');
		     print_out('</p></td></tr></tbody></table><BR>');
		 
      elsif (l_mailer_status = 'NOT_CONFIGURED') then  --MLR_NOT_CONFIGURED
          
    		 print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
	         print_out('<tbody><tr><td> ');
	         print_out('<p><B>Warning:</B><BR>');
	         print_out('The Workflow Java Mailer "'|| l_component_name ||'" has been created, but is not configured completely.<BR>');
	         print_out('<B>Action:</B><BR>');
	         print_out('Please complete the configuration of the "'|| l_component_name ||'" using the Workflow Manager screens if you plan to use it.<BR>'); 
	         print_out('This Java Mailer is currently set to startup mode of '|| l_startup_mode ||'.<BR>');
	         print_out('Please review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\&sourceId=1369938.1\\&id=1191125.1" target="_blank">Note 1191125.1');
	         print_out('</a> - Troubleshooting Oracle Workflow Java Notification Mailer, <BR>');
	         print_out('Also review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\&sourceId=1369938.1\\&id=748421.1" target="_blank">Note 748421.1');
	         print_out('</a> - Java Mailer Setup Diagnostic Test (ATGSuppJavaMailerSetup12.sh), for more information.<BR>');
		     print_out('</p></td></tr></tbody></table><BR>');
		 
      elsif (l_mailer_status = 'STOPPED') then --MLR_STOPPED
        
             print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
	         print_out('<tbody><tr><td> ');
	         print_out('The Workflow Java Mailer "'|| l_component_name ||'" is currently stopped.<BR>');
		     print_out('</td></tr></tbody></table><BR>');

      elsif (l_mailer_status = 'STOPPED_ERROR') then --MLR_STOPPED_ERR
        
             print_out('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
	         print_out('<tbody><tr><td> ');
	         print_out('<p><B>Error:</B><BR>');
	         print_out('The Workflow Java Mailer "'|| l_component_name ||'" is currently stopped because of an Error.<BR>');
	         print_out('<B>Action:<BR>');
	         print_out('Please review the email that was sent to SYSADMIN regarding this error.</B><BR>'); 
	         print_out('The Java Mailer is currently set to startup mode of '|| l_startup_mode ||'.<BR>');
	         print_out('Please review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\&sourceId=1369938.1\\&id=1191125.1" target="_blank">Note 1191125.1');
	         print_out('</a> - Troubleshooting Oracle Workflow Java Notification Mailer,<BR>');
	         print_out('Also run the Mailer Diagnostic Setup checks found in <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\&sourceId=1369938.1\\&id=748421.1" target="_blank">');
	         print_out('Note 748421.1</a> - Java Mailer Setup Diagnostic Test (ATGSuppJavaMailerSetup12.sh), for more information.<BR>');
		     print_out('</td></tr></tbody></table><BR>');
		 
      elsif (l_mailer_status = 'RUNNING') then --MLR_IS_RUNNING
                   
             print_out('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
	         print_out('<tbody><tr><td> ');
	         print_out('The Workflow Java Mailer "'|| l_component_name ||'" is currently running.<BR>');
		     print_out('</td></tr></tbody></table><BR>');
	       
      end if;	  

   end if;

 END LOOP;

 CLOSE c_mailerIDs;

--    print_out('</div><br>');
    print_out('</div><br><font style="font-size:x-small;">');
    print_out('<a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');

EXCEPTION WHEN OTHERS THEN
  print_log('Error in java_mailer_status');
  raise;	
end java_mailer_status;



-------------------------
-- Recommended patches 
-------------------------

FUNCTION check_rec_patches_1 RETURN VARCHAR2 IS
 
  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);
 
  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN
 
debug('Begin recommended patches signature: check_rec_patches_1');
 
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);
 
IF substr(g_rep_info('Apps Version'),1,6) = '12.2.4' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20470720';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.2.4:18345086:SMTP AUTHENTICATION FAILS WITH SHARED MAIL BOX ACCOUNT';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.2.3' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19047391';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.2.3:19047391:WHILE ENABLING MLS LIGHTWEIGHT FNDNLINS.SQL NEVER ENDS';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.2.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19634693';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'ORACLE.APPS.FND.WF.BES.WEBSERVICEINVOKERSUBSCRIPTION IS NOT CLOSING THE CURSORS';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.1.3' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20230836';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'OWF:12.1.3+ Recommended Patch Collection DEC-2014';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20035289';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'OWF:12.1.3+ Recommended Patch Collection March-2015';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '19329720';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'Latest Recommended Patch Collection for OWF 12.1.3+ JUL 2014 (Superseded by 20230836)';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '18826085';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'Latest Recommended Patch Collection for OWF 12.1.3+ Jun 2014 (Superseded by 20230836)';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '17618508';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'Latest Recommended Patch Collection for OWF 12.1.3+ Dec 2013 (Superseded by 20230836)';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '14474358';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := '1OFF:12.1.3:WF MAILER CAN NOT CONNECT TO MAIL STORE WHEN SPECIFIC MIME TYPE IS RECEIVED';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '13786156';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '1OFF:12.1.3: MAILER IS THROWING "SAXPARSEEXCEPTION" ERROR WHEN #WFM_FROM MESSAGE ATTRIBUTE HAS FULL EMAIL ADDRESS';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '9379328';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := '1OFF:12.1.1:9320224:INBOUND MAILER GOING DOWN:REPLY BUTTON USED: ORACLE BEEHIVE EXTENSIONS FOR OUTLOOK';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '9055472';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := '1OFF:12.1.1:9084150:NOTIFICATION MAILER GOES DOWN DURING RESPONSE PROCESSING';
   l_col_rows(5)(9) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.1.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20230836';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'OWF:12.1.3+ Recommended Patch Collection DEC-2014';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.1.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '9379328';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.1.1:9320224:INBOUND MAILER GOING DOWN:REPLY BUTTON USED: ORACLE BEEHIVE';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '9055472';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:R12.1.1:9084150:INBOUND MAILER GOING DOWN:MORE INFO ISSUE AND RESPONSE ATTACHMENT';
   l_col_rows(5)(2) := '[1481221.1]';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.0.6' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '10428040';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.0.6:10012972:MAILER INBOUND PROCESSOR STOPS WORKING AFTER JAVAX.MAIL.MESSAGEREMOVEDEXCEPTION';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '9853165';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:12.0.6:9450904:GETINFOFROMMAIL API NEEDS TO IDENTIFY ROLE NAME ACCURATELY';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '9255725';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '1OFF:12.0.6:9169815:NULLPOINTEREXCEPTION WHEN 451 TIMEOUT WAITING FOR CLIENT INP';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '8627180';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '1OFF:12.0.6:PERFORMANCE ISSUE WITH WF_NOTIFICATION.SEND()';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '7709109';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := '1OFF:12.0.6:6767410:EMAIL NOTIFICATIONS DISPLAY ERROR MESSAGE AS INSUFFICIENT PRIVILEGE';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '7630298';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := '1OFF:7585376:12.0.6:ERROR INVALID ALTER SESSION ON SCRIPT WFNTFCU2.SQL';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '7606173';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '1OFF: 12.0.6: 7535451: APPLICATION/PDF IS NOT AN ALLOWED CONTENT_TYPE FOR THE BODYPART';
   l_col_rows(5)(7) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.0.4' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '7277944';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.0.4, 12.0.3: WORKFLOW MAILER DOWN WITH :JAVA.LANG.STRINGINDEXOUTOFBOUNDSEXCEPTION';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '18369765';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:11I.ATG_PF.H.RUP7: process activities are executed multiple times after an event-receiving activity ';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '17581731';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:11i.ATG_PF.H.RUP7:9506401:12.1.3 TEST: ORA-20002 WHEN ASSIGNING A ROLE HIERARCHY ';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '17504381';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '1OFF:11i.ATG_PF.H.RUP7:16317773:SMTPSENDFAILEDEXCEPTION CAUSING NOTIFICATION PREFERENCE DISABLED ';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '17341836';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '1OFF:11.5.10.RUP6:16589389: MAILER THROWS JAVAX.MAIL.INTERNET.ADDRESSEXCEPTION, WHEN EMAIL ADDRESS IS LONG FORMAT ';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '16482054';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := '1OFF:11.5.10.6RUP:10414698:MAILER INBOUND PROCESSOR STOPS WORKING AFTER JAVAX.MAIL.MESSAGEREMOVEDEXCEPTION';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '13029817';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := '1OFF:10414698:11I.ATG_PF.H.RUP7:MAILER INBOUND PROCESSOR STOPS WORKING AFTER JAVAX.MAIL.MESSAGEREMOVEDEXCEPTION ';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '9383048';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '1OFF:9361993:11.5.10.7:INBOUND MAILER GOING DOWN:REPLY BUTTON USED: ORACLE BEEHIVE ';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '9149988';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := '1OFF:11.5.10.7:9136998:NOTIFICATION MAILER GOES DOWN DURING RESPONSE PROCESSING ';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '8746145';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := '1OFF:11.5.10.6:7829071:ORA-06502 PL/SQL: NUMERIC OR VALUE IN WF_ENGINE ';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '7365544';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := '1OFF:7278229:ATG_PF.H RUP6: MAILER DOWN WITH:JAVA.LANG.STRINGINDEXOUTOFBOUNDSEX';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '7268412';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := '1OFF:6324545: MORE THAN 10 ATTACHEMENTS IN EMAIL AND CLOB ATTR IN MESSAGE BODY ISSUES';
   l_col_rows(5)(11) := '';

   l_col_rows(1)(12) := '6836141';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := '1OFF:6511028: WORKFLOW SERVICE CONTAINER CONSUMING A LOT TEMP LOBs';
   l_col_rows(5)(12) := '';

   l_col_rows(1)(13) := '6802716';
   l_col_rows(2)(13) := 'No';
   l_col_rows(3)(13) := NULL;
   l_col_rows(4)(13) := '1OFF:6242825: ENCODING FOR MAILTO URIS IN HTML RESPONSE E-MAILS REQUIRES CORRECTION';
   l_col_rows(5)(13) := '';

   l_col_rows(1)(14) := '6720592';
   l_col_rows(2)(14) := 'No';
   l_col_rows(3)(14) := NULL;
   l_col_rows(4)(14) := '1-OFF: NOTIFICATION MAILER TIME OUT MESSAGES, NEEDS RESTART AND MAILER PERFORMANCE ISSUE AFTER RUP5';
   l_col_rows(5)(14) := '';

   l_col_rows(1)(15) := '6441940';
   l_col_rows(2)(15) := 'No';
   l_col_rows(3)(15) := NULL;
   l_col_rows(4)(15) := 'MAILER WITH NON-NULL CORR ID DOES NOT PROCESS MESSAGES AFTER ATG PF.H RUP 5';
   l_col_rows(5)(15) := '';

   l_col_rows(1)(16) := '6412999';
   l_col_rows(2)(16) := 'No';
   l_col_rows(3)(16) := NULL;
   l_col_rows(4)(16) := '1-OFF: 6375615:JAVA MAILER PERFORMANCE AFTER APPLYING ATG RUP 5';
   l_col_rows(5)(16) := '';

   l_col_rows(1)(17) := '5749648';
   l_col_rows(2)(17) := 'No';
   l_col_rows(3)(17) := NULL;
   l_col_rows(4)(17) := '1OFF: EMAIL NOTIFICATIONS DISPLAY ERROR MESSAGE AS INSUFFICIENT PRIVILEGE';
   l_col_rows(5)(17) := '';

END IF;

   l_sig.title := 'Recommended Workflow Java Mailer Patches for '||g_rep_info('Apps Version')||'';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'There are recommended '||g_rep_info('Apps Version')||' Workflow Java Mailer patches that are not applied '||
        'on this instance';
   l_sig.solution := '<ul><li>Please review list above and schedule
        to apply any unappplied recommended Workflow Java Mailer patches as soon as possible</li>
        <li>Refer to the note indicated for more information about each patch</li></ul>';
   l_sig.success_msg := 'All recommended Workflow Java Mailer patches (if any) have been applied.';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';
 
  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      l_col_rows(1)(i) := '{'||l_col_rows(1)(i)||'}';
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;
 
--Render
  l_step := '60';
 
  l_step := '70';
  RETURN process_signature_results(
    'WF5_CHECK_WFMLR_PATCHES',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers
 
debug('End recommended patches signature: check_rec_patches_1');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_1 at step '||l_step);
  raise;
END check_rec_patches_1;

FUNCTION check_rec_patches_2 RETURN VARCHAR2 IS
 
  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);
 
  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN
 
debug('Begin recommended patches signature: check_rec_patches_2');
 
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);
 
IF substr(g_rep_info('Apps Version'),1,6) = '12.2.4' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21358307';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'OWF:12.2.4+ RECOMMENDED PATCH COLLECTION - JULY 2015';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '21223427';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'ISSUE WITH WEB SERVICE INVOCATION FROM JAVA CONCURRENT PROGRAM';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '21194582';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'OWF:12.2.4+ RECOMMENDED PATCH COLLECTION - JUNE 2015';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '21133574';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '1OFF:19048394:1OFF:18285400:ATGUI: WORKLIST HEADER AND HR SECURITY RELATED ISSUE';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '20774461';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := '1OFF:12.2.4:20277438:SET STARTTLS PROPERTY ONLY WHEN SMTP SERVER SUPPORTS SSL/TLS';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '20470720';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := '1OFF:12.2.4:18345086:SMTP AUTHENTICATION FAILS WITH SHARED MAIL BOX ACCOUNT';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '20378476';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '1OFF:12.2.2:ORA-20001: FND_CANT_UPDATE_USER_ROLEHAS BEEN DETECTED';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '20277651';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'JBO-25005: OBJECT NAME GRANTERLISTVO_USER.NAME';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '20245967';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := '1OFF:12.2.4: ADMINISTRATOR MONITOR REASSIGN PAGE ERRORS FOR REASSIGN ACTION';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '19547850';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := 'WORKLIST ACCESS - GRANTING - SWITCH USER BUTTON MISSING AFTER UPGRADE';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '18112492';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := 'INVALID ARGUMENT: OAFSLIDEOUTMENU_SKYROS.JS ERROR ON HOME PAGE';
   l_col_rows(5)(11) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.2.3' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21538803';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.2.3:21289350 FORWARD PORT: WF_DIRECTORY.ADD_LANGUAGE DOES NOT ADD MISSING';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19634693';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'ORACLE.APPS.FND.WF.BES.WEBSERVICEINVOKERSUBSCRIPTION IS NOT CLOSING THE CURSORS';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '19547850';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'WORKLIST ACCESS - GRANTING - SWITCH USER BUTTON MISSING AFTER UPGRADE';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '19047391';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '1OFF:12.2.3:19047391:WHILE ENABLING MLS LIGHTWEIGHT FNDNLINS.SQL NEVER ENDS';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '18112492';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'INVALID ARGUMENT: OAFSLIDEOUTMENU_SKYROS.JS ERROR ON HOME PAGE';
   l_col_rows(5)(5) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.2.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19634693';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'ORACLE.APPS.FND.WF.BES.WEBSERVICEINVOKERSUBSCRIPTION IS NOT CLOSING THE CURSORS';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19047391';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:12.2.3:19047391:WHILE ENABLING MLS LIGHTWEIGHT FNDNLINS.SQL NEVER ENDS';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.1.3' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21538802';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.1.3:WF_DIRECTORY.SETADHOCUSEREXPIRATION RESETS THE EMAIL ADDRESS OF ROLE';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20536609';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:12.1.3:20277438:SET STARTTLS PROPERTY ONLY WHEN SMTP SERVER SUPPORTS SSL/TLS PROTOCOL';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '20230836';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'OWF:12.1.3+ Recommended Patch Collection DEC-2014';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '20051244';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := ' 1OFF:16460079:IMPROPER ALIGNMENT OF NOTIFICATION HISTORY SECTION IN THE WORKFLOW';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '20035289';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'OWF:12.1.3+ Recommended Patch Collection March-2015';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '19516497';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := '1OFF:5472562:SUMBIT TIME FOR SCHEDULED EVENTS IS NOT SAVED IN OAM ADVANCED MAILER CONFIG';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '19474347';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '1OFF:R12.ATG_PF.B.delta.3:JBO-27122: ERROR IN STATUS MONITOR WHEN NOTIFICATION RESPONDED BY E-MAIL';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '19322157';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := '1OFF:12.1.3:19322157:CHILD WORKFLOW LAUNCHED WHEN EVENT IS RAISED INCORRECTLY DECREMENTS COUNTERS';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '18770191';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := '1OFF:12.1.3:18497619:WF_OAM_METRICS DOES NOT POPULATE DATA FOR WF_BPEL_QAGENT IN WF_AGENTS';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '18598754';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := '1OFF:18318416:WRONG PERFORMER NAME DISPLAYING IN MONITOR ACTIVITIES HISTORY';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '16383560';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := '1OFF:ATG_PF.B.DELTA.3:PURGE OBSOLETE WORKFLOW RUNTIME DATA RUNNING TOO LONG';
   l_col_rows(5)(11) := '';

   l_col_rows(1)(12) := '14474358';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := '1OFF:12.1.3:WF MAILER CAN NOT CONNECT TO MAIL STORE WHEN SPECIFIC MIME TYPE IS RECEIVED';
   l_col_rows(5)(12) := '';

   l_col_rows(1)(13) := '13786156';
   l_col_rows(2)(13) := 'No';
   l_col_rows(3)(13) := NULL;
   l_col_rows(4)(13) := '1OFF:12.1.3: MAILER IS THROWING "SAXPARSEEXCEPTION" ERROR WHEN #WFM_FROM MESSAGE ATTRIBUTE HAS FULL EMAIL ADDRESS';
   l_col_rows(5)(13) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.1.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '9379328';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.1.1:9320224:INBOUND MAILER GOING DOWN:REPLY BUTTON USED: ORACLE BEEHIVE EXTENSIONS FOR OUTLOOK';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '9055472';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:12.1.1:9084150:NOTIFICATION MAILER GOES DOWN DURING RESPONSE PROCESSING';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.0.6' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '18357775';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'BACKPORT:16091678:FND_USER_PREFERENCES IS GETTING UPDATED TO NULL';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '10428040';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:12.0.6:10012972:MAILER INBOUND PROCESSOR STOPS WORKING AFTER JAVAX.MAIL.MESSAGEREMOVEDEXCEPTION';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '9853165';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '1OFF:12.0.6:9450904:GETINFOFROMMAIL API NEEDS TO IDENTIFY ROLE NAME ACCURATELY';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '9255725';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '1OFF:12.0.6:9169815:NULLPOINTEREXCEPTION WHEN 451 TIMEOUT WAITING FOR CLIENT INP';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '8627180';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := '1OFF:12.0.6:PERFORMANCE ISSUE WITH WF_NOTIFICATION.SEND()';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '8330993';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := '1OFF:12.0.6:8308654:WF_STANDARD.INITIALIZEEVENTERROR USING ATTRIBUTE ERROR_DETAILS';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '7709109';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '1OFF:12.0.6:6767410:EMAIL NOTIFICATIONS DISPLAY ERROR MESSAGE AS INSUFFICIENT PRIVILEGE';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '7630298';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := '1OFF:7585376:12.0.6:ERROR INVALID ALTER SESSION ON SCRIPT WFNTFCU2.SQL';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '7606173';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := '1OFF:12.0.6: 7535451: APPLICATION/PDF IS NOT AN ALLOWED CONTENT_TYPE FOR THE BODYPART';
   l_col_rows(5)(9) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.0.4' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '10428040';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.0.6:10012972:MAILER INBOUND PROCESSOR STOPS WORKING AFTER JAVAX.MAIL.MESSAGEREMOVEDEXCEPTION';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '8340612';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:12.0.4:7842689:WF_ITEM.SET_END_DATE IS INCORRECTLY DECREMENTING THE #WAITFORDETAIL ATTRIBUTE';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '8201652';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '1OFF:12.0.4:7538770:FNDWFPR PERFORMANCE IS SLOWER THAN GENERATING SPEED';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '7829071';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '1OFF:12.0.4:ORA-06502 PL/SQL: NUMERIC OR VALUE IN WF_ENGINE_UTIL.NOTIFICATION_SEND';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '7277944';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := '1OFF:12.0.4, 12.0.3: WORKFLOW MAILER DOWN WITH :JAVA.LANG.STRINGINDEXOUTOFBOUNDSEXCEPTION';
   l_col_rows(5)(5) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '18369765';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:11I.ATG_PF.H.RUP7: process activities are executed multiple times after an event-receiving activity';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '17581731';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:11i.ATG_PF.H.RUP7:9506401:12.1.3 TEST: ORA-20002 WHEN ASSIGNING A ROLE HIERARCHY';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '17504381';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '1OFF:11i.ATG_PF.H.RUP7:16317773:SMTPSENDFAILEDEXCEPTION CAUSING NOTIFICATION PREFERENCE DISABLED';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '17341836';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '1OFF:11.5.10.RUP6:16589389: JAVAX.MAIL.INTERNET.ADDRESSEXCEPTION, IF EMAIL ADDRESS IS LONG FORMAT';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '16482054';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := '1OFF:11.5.10.6RUP:10414698:MAILER INBOUND PROCESSOR STOPS WORKING AFTER JAVAX.MAIL.MESSAGEREMOVEDEXCEPTION';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '13990300';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := '1OFF:11i.ATG_PF.H.RUP6: WORKFLOW PURGE REMOVES WORKFLOWS THAT ARE NOT END DATED';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '13029817';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '1OFF:10414698:11I.ATG_PF.H.RUP7:MAILER INBOUND PROCESSOR STOPS WORKING AFTER JAVAX.MAIL.MESSAGEREMOVEDEXCEPTION';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '9803639';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := '1OFF:11i.ATG_PF.H.RUP6:INDIRECT RESPONSIBILITIES NO LONGER IN TOP-HAT AFTER PATCH 9682633';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '9747572';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := '1OFF:11i.ATG_PF.H.RUP7:WFBG DOES NOT EXECUTE SELECTOR FUNCTION WHEN PROCESSING A SUBSEQUENT DEFERRED ACTIVITY';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '9383048';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := '1OFF:9361993:11.5.10.7:INBOUND MAILER GOING DOWN:REPLY BUTTON USED: ORACLE BEEHIVE';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '9199983';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := '1OFF:11.5.10.6RUP:7476877: WORKFLOW PURGE IS CRITICALLY AFFECTING PERFORMANCE';
   l_col_rows(5)(11) := '';

   l_col_rows(1)(12) := '9149988';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := '1OFF:11.5.10.7:9136998:NOTIFICATION MAILER GOES DOWN DURING RESPONSE PROCESSING';
   l_col_rows(5)(12) := '';

   l_col_rows(1)(13) := '8746145';
   l_col_rows(2)(13) := 'No';
   l_col_rows(3)(13) := NULL;
   l_col_rows(4)(13) := '1OFF:11.5.10.6:7829071:ORA-06502 PL/SQL: NUMERIC OR VALUE IN WF_ENGINE';
   l_col_rows(5)(13) := '';

   l_col_rows(1)(14) := '7365544';
   l_col_rows(2)(14) := 'No';
   l_col_rows(3)(14) := NULL;
   l_col_rows(4)(14) := '1OFF:7278229:ATG_PF.H RUP6: MAILER DOWN WITH:JAVA.LANG.STRINGINDEXOUTOFBOUNDSEX';
   l_col_rows(5)(14) := '';

   l_col_rows(1)(15) := '7268412';
   l_col_rows(2)(15) := 'No';
   l_col_rows(3)(15) := NULL;
   l_col_rows(4)(15) := '1OFF:6324545: MORE THAN 10 ATTACHEMENTS IN EMAIL AND CLOB ATTR IN MESSAGE BODY ISSUES';
   l_col_rows(5)(15) := '';

   l_col_rows(1)(16) := '6836141';
   l_col_rows(2)(16) := 'No';
   l_col_rows(3)(16) := NULL;
   l_col_rows(4)(16) := '1OFF:6511028: WORKFLOW SERVICE CONTAINER CONSUMING A LOT TEMP LOBs';
   l_col_rows(5)(16) := '';

   l_col_rows(1)(17) := '6802716';
   l_col_rows(2)(17) := 'No';
   l_col_rows(3)(17) := NULL;
   l_col_rows(4)(17) := '1OFF:11.5.10.5:6242825:ENCODING FOR MAILTO URIS IN HTML RESPONSE E-MAILS REQUIRES CORRECTION';
   l_col_rows(5)(17) := '';

   l_col_rows(1)(18) := '6720592';
   l_col_rows(2)(18) := 'No';
   l_col_rows(3)(18) := NULL;
   l_col_rows(4)(18) := '1OFF: NOTIFICATION MAILER TIME OUT MESSAGES, NEEDS RESTART AND MAILER PERFORMANCE ISSUE AFTER RUP5';
   l_col_rows(5)(18) := '';

   l_col_rows(1)(19) := '6441940';
   l_col_rows(2)(19) := 'No';
   l_col_rows(3)(19) := NULL;
   l_col_rows(4)(19) := 'MAILER WITH NON-NULL CORR ID DOES NOT PROCESS MESSAGES AFTER ATG PF.H RUP 5';
   l_col_rows(5)(19) := '';

   l_col_rows(1)(20) := '6412999';
   l_col_rows(2)(20) := 'No';
   l_col_rows(3)(20) := NULL;
   l_col_rows(4)(20) := '1OFF:6375615:11.5.10.5: JAVA MAILER PERFORMANCE AFTER ATG RUP5';
   l_col_rows(5)(20) := '';

   l_col_rows(1)(21) := '5904576';
   l_col_rows(2)(21) := 'No';
   l_col_rows(3)(21) := NULL;
   l_col_rows(4)(21) := 'CPUApr07: 5893412 FOR 11.5.10.CU2 to 11i.ATG_PF.H RUP4';
   l_col_rows(5)(21) := '';

   l_col_rows(1)(22) := '5904386';
   l_col_rows(2)(22) := 'No';
   l_col_rows(3)(22) := NULL;
   l_col_rows(4)(22) := 'CPUApr07: 5893412 for 11.5.7 to 11.5.9 with OWF.G RUP7 applied';
   l_col_rows(5)(22) := '';

   l_col_rows(1)(23) := '5749648';
   l_col_rows(2)(23) := 'No';
   l_col_rows(3)(23) := NULL;
   l_col_rows(4)(23) := '1OFF: EMAIL NOTIFICATIONS DISPLAY ERROR MESSAGE AS ''INSUFFICIENT PRIVILEGE''';
   l_col_rows(5)(23) := '';

   l_col_rows(1)(24) := '5571211';
   l_col_rows(2)(24) := 'No';
   l_col_rows(3)(24) := NULL;
   l_col_rows(4)(24) := 'CPUJan07: 4430164 for 11.5.7 to 11.5.9 with OWF.G RUP7 applied';
   l_col_rows(5)(24) := '';

   l_col_rows(1)(25) := '5571208';
   l_col_rows(2)(25) := 'No';
   l_col_rows(3)(25) := NULL;
   l_col_rows(4)(25) := 'CPUJan07: 4430164 FOR 11.5.10 to 11.5.10.4RUP';
   l_col_rows(5)(25) := '';

   l_col_rows(1)(26) := '5161817';
   l_col_rows(2)(26) := 'No';
   l_col_rows(3)(26) := NULL;
   l_col_rows(4)(26) := 'CPUJul06: 5161758 for pre-11.5.10 releases + Post-OWF.G RUP7 applied';
   l_col_rows(5)(26) := '';

   l_col_rows(1)(27) := '5161758';
   l_col_rows(2)(27) := 'No';
   l_col_rows(3)(27) := NULL;
   l_col_rows(4)(27) := 'CPUJul06: 5161758 for 11.5.10 - 11.5.10.RUP3';
   l_col_rows(5)(27) := '';

   l_col_rows(1)(28) := '5141277';
   l_col_rows(2)(28) := 'No';
   l_col_rows(3)(28) := NULL;
   l_col_rows(4)(28) := 'CPUJul06: 2144675 for 11.5.7 - 11.5.9.RUP7 (Post-OWF.G RUP7)';
   l_col_rows(5)(28) := '';

   l_col_rows(1)(29) := '4967899';
   l_col_rows(2)(29) := 'No';
   l_col_rows(3)(29) := NULL;
   l_col_rows(4)(29) := 'CPU Jan 06 : 4967899: 11.5.9 + OWF.G RUP 6/6.1/7';
   l_col_rows(5)(29) := '';

   l_col_rows(1)(30) := '4967880';
   l_col_rows(2)(30) := 'No';
   l_col_rows(3)(30) := NULL;
   l_col_rows(4)(30) := 'CPU Jan 06 : 4967880 For EBS 11.5.10/OWF.H/FND.H';
   l_col_rows(5)(30) := '';

   l_col_rows(1)(31) := '4967871';
   l_col_rows(2)(31) := 'No';
   l_col_rows(3)(31) := NULL;
   l_col_rows(4)(31) := 'CPU Jan 06 : 4967871 for EBS 11.5.10.CU1';
   l_col_rows(5)(31) := '';

   l_col_rows(1)(32) := '4928090';
   l_col_rows(2)(32) := 'No';
   l_col_rows(3)(32) := NULL;
   l_col_rows(4)(32) := 'CPU Jan 06 : 4928090 for EBS 11.5.10.CU2';
   l_col_rows(5)(32) := '';

   l_col_rows(1)(33) := '4634858';
   l_col_rows(2)(33) := 'No';
   l_col_rows(3)(33) := NULL;
   l_col_rows(4)(33) := 'CPU Jan 06 : 4634858 For 11.5.8-11.5.1 + post-FWK 5.7H V2';
   l_col_rows(5)(33) := '';

   l_col_rows(1)(34) := '4634849';
   l_col_rows(2)(34) := 'No';
   l_col_rows(3)(34) := NULL;
   l_col_rows(4)(34) := 'CPU Jan 06 : 4634849 For 11.5.8-11.5.1 + pre-OA Framework 5.7H - V2';
   l_col_rows(5)(34) := '';

   l_col_rows(1)(35) := '4608179';
   l_col_rows(2)(35) := 'No';
   l_col_rows(3)(35) := NULL;
   l_col_rows(4)(35) := 'CPU Oct 05 : 4608179';
   l_col_rows(5)(35) := '';

   l_col_rows(1)(36) := '4608004';
   l_col_rows(2)(36) := 'No';
   l_col_rows(3)(36) := NULL;
   l_col_rows(4)(36) := 'CPU Oct 05 : 4608004';
   l_col_rows(5)(36) := '';

   l_col_rows(1)(37) := '4607951';
   l_col_rows(2)(37) := 'No';
   l_col_rows(3)(37) := NULL;
   l_col_rows(4)(37) := 'CPU Oct 05 : 4607951';
   l_col_rows(5)(37) := '';

   l_col_rows(1)(38) := '4350962';
   l_col_rows(2)(38) := 'No';
   l_col_rows(3)(38) := NULL;
   l_col_rows(4)(38) := 'CPU Oct 05 : 4350962';
   l_col_rows(5)(38) := '';

   l_col_rows(1)(39) := '4319239';
   l_col_rows(2)(39) := 'No';
   l_col_rows(3)(39) := NULL;
   l_col_rows(4)(39) := 'CPU Oct 05 : 4319239';
   l_col_rows(5)(39) := '';

   l_col_rows(1)(40) := '4183856';
   l_col_rows(2)(40) := 'No';
   l_col_rows(3)(40) := NULL;
   l_col_rows(4)(40) := '2005-S072E';
   l_col_rows(5)(40) := '';

   l_col_rows(1)(41) := '4183846';
   l_col_rows(2)(41) := 'No';
   l_col_rows(3)(41) := NULL;
   l_col_rows(4)(41) := 'CPU Oct 05 : 2005-S071E';
   l_col_rows(5)(41) := '';

   l_col_rows(1)(42) := '3501599';
   l_col_rows(2)(42) := 'No';
   l_col_rows(3)(42) := NULL;
   l_col_rows(4)(42) := '11.5.9:MAILER FAILS WITH ORA-00604: ERROR OCCURRED AT RECURSIVE SQL LEVEL 1';
   l_col_rows(5)(42) := '';

   l_col_rows(1)(43) := '3073679';
   l_col_rows(2)(43) := 'No';
   l_col_rows(3)(43) := NULL;
   l_col_rows(4)(43) := 'INACTIVE FND_USER SHOWN AS ACTIVE IN WF_USERS VIEW';
   l_col_rows(5)(43) := '';

   l_col_rows(1)(44) := '3032192';
   l_col_rows(2)(44) := 'No';
   l_col_rows(3)(44) := NULL;
   l_col_rows(4)(44) := 'WFDS: WF_DIRECTORY.ASSIGNPARTITION() MIGHT RETURN 0 IF ORIG_SYSTEM IS LCASE';
   l_col_rows(5)(44) := '';

END IF;

   l_sig.title := 'Recommended Workflow Patches for '||g_rep_info('Apps Version')||'';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'There are recommended '||g_rep_info('Apps Version')||' workflow patches that are not applied '||
        'on this instance';
   l_sig.solution := '<ul><li>Please review list above and schedule
        to apply any unappplied recommended workflow patches as soon as possible</li>
        <li>Refer to the note indicated for more information about each patch</li></ul>';
   l_sig.success_msg := 'All recommended workflow patches (if any) have been applied.';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';
 
  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      l_col_rows(1)(i) := '{'||l_col_rows(1)(i)||'}';
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;
 
--Render
  l_step := '60';
 
  l_step := '70';
  RETURN process_signature_results(
    'WF6_WFREC_PATCHES',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers
 
debug('End recommended patches signature: check_rec_patches_2');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_2 at step '||l_step);
  raise;
END check_rec_patches_2;

FUNCTION check_rec_patches_3 RETURN VARCHAR2 IS
 
  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);
 
  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN
 
debug('Begin recommended patches signature: check_rec_patches_3');
 
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);
 
IF substr(g_rep_info('Apps Version'),1,6) = '12.2.3' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19133548';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.1.3:SET OVERRIDE ADDRESS FROM OAM UI THROWING SMTPSENDFAILEDEXCEPTION: 530 5.7.0 MUST ISSUE A STARTTLS';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '18842914';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:12.2.3:18839249 BACKPORT: MAILER NOT ABLE TO AUTHENTICATE TO SMTP SERVER NEEDING TLS SESSION FIRST (Superseded by 19133548)';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.1.3' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20536609';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.1.3:20277438:SET STARTTLS PROPERTY ONLY WHEN SMTP SERVER SUPPORTS SSL/TL';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20428664';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '11OFF:12.1.3:20137109:MAILER NOT USING CORRECT SMTP CONFIGURATION FOR UNSOLICITED AND INVALID EMAILS (Superseded by 20536609)';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '18770191';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '1OFF:12.1.3:18497619:WF_OAM_METRICS DOES NOT POPULATE DATA FOR WF_BPEL_QAGENT IN WF_AGENTS';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '18751696';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '1OFF:12.1.3:INCORRECT FROM IN ACTION HISTORY TABLE WHEN NOTIFICATION IS REASSIGNED';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '18345086';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := '1OFF:12.1.3: SMTP AUTHENTICATION FAILS WITH SHARED MAIL BOX ACCOUNT CONTAINING DOMAIN IN USERNAME (Superseded by 20428664)';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '17987270';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := '1OFF:12.1.3:17513104:TCH12C:INT1213:WIN64:WORKFLOW BACKGROUND PROCESS IS FAILING WITH ORA-06502';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '17756944';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '1OFF:12.1.3:MAILER NOT ABLE TO AUTHENTICATE TO SMTP SERVER NEEDING TLS SESSION FIRST';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '17704236';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := '1OFF:12.1.3:16868453: JAVAX.MAIL.INTERNET.ADDRESSEXCEPTION, WHEN EMAIL ADDRESS IS LONG FORMAT';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '16559330';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := '1OFF:15927384:WORKFLOW MAILER - SMTPADDRESSFAILEDEXCEPTION: 550 NOT AUTHENTICATED (Superseded by 16317773)';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '16397465';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := '1OFF: 12.1.3:SUMMARY NOTIFICATIONS ARE SENT MORE THAN ONE TIME (Superseded by 17704236)';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '16317773';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := '1OFF:12.1.3:SMTPSENDFAILEDEXCEPTION CAUSING NOTIFICATION PREFERENCE DISABLED (Superseded by 20230836)';
   l_col_rows(5)(11) := '';

   l_col_rows(1)(12) := '14676206';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := '1OFF:12.1.3:JAVAX.MAIL.SENDFAILEDEXCEPTION: 554 5.7.1 SENDER ADDRESS REJECTED: ACCESS DENIED';
   l_col_rows(5)(12) := '';

   l_col_rows(1)(13) := '14474358';
   l_col_rows(2)(13) := 'No';
   l_col_rows(3)(13) := NULL;
   l_col_rows(4)(13) := '1OFF:12.1.3:WF MAILER CAN NOT CONNECT TO MAIL STORE WHEN SPECIFIC MIME TYPE IS RECEIVED';
   l_col_rows(5)(13) := '';

   l_col_rows(1)(14) := '13903857';
   l_col_rows(2)(14) := 'No';
   l_col_rows(3)(14) := NULL;
   l_col_rows(4)(14) := '1OFF:12.1.3:SMTPSENDFAILEDEXCEPTION: [EOF] WHEN SENDING EMAIL NOTIFICATIONS (Superseded by 16559330)';
   l_col_rows(5)(14) := '';

   l_col_rows(1)(15) := '13786156';
   l_col_rows(2)(15) := 'No';
   l_col_rows(3)(15) := NULL;
   l_col_rows(4)(15) := '1OFF:12.1.3: MAILER IS THROWING "SAXPARSEEXCEPTION" ERROR WHEN #WFM_FROM MESSAGE ATTRIBUTE HAS FULL EMAIL ADDRESS (Superseded by 16397465)';
   l_col_rows(5)(15) := '';

   l_col_rows(1)(16) := '13609378';
   l_col_rows(2)(16) := 'No';
   l_col_rows(3)(16) := NULL;
   l_col_rows(4)(16) := '1OFF:12.1.3:MAILER FAILS TO DETECT SMTP AUTHENTICATION FOR SOME SERVERS (Superseded by 14676206)';
   l_col_rows(5)(16) := '';

   l_col_rows(1)(17) := '13543331';
   l_col_rows(2)(17) := 'No';
   l_col_rows(3)(17) := NULL;
   l_col_rows(4)(17) := '1OFF:12.1.3:13488289:MAILER IS THROWING PARSEEXCEPTION WHILE PARSING MIME MESSAGES HAVING CONTENT-TYPE PARAMETER VALUES NOT ENCLOSED WITHIN (Superseded by 14474358)';
   l_col_rows(5)(17) := '';

   l_col_rows(1)(18) := '13449810';
   l_col_rows(2)(18) := 'No';
   l_col_rows(3)(18) := NULL;
   l_col_rows(4)(18) := '1OFF:12.1.3:10413964:MAILER INBOUND PROCESSOR STOPS WORKING AFTER JAVAX.MAIL.MESSAGEREMOVEDEXCEPTION (Superseded by 20230836)';
   l_col_rows(5)(18) := '';

   l_col_rows(1)(19) := '12898568';
   l_col_rows(2)(19) := 'No';
   l_col_rows(3)(19) := NULL;
   l_col_rows(4)(19) := '1OFF:12.1.3:WF MAILER IS THROWING NULLPOINTER AND COM.SUN.MAIL.SMTP.SMTPSENDFAILEDEXCEPTION: [EOF] WHILE SENDING MESSAGES (Superseded by 13979673,13903857)';
   l_col_rows(5)(19) := '';

   l_col_rows(1)(20) := '12540549';
   l_col_rows(2)(20) := 'No';
   l_col_rows(3)(20) := NULL;
   l_col_rows(4)(20) := '1OFF:12.1.3:QUESTION BY PROXY IS NOT DISPLAYED IN EMAIL (Superseded by 13786156)';
   l_col_rows(5)(20) := '';

   l_col_rows(1)(21) := '11905988';
   l_col_rows(2)(21) := 'No';
   l_col_rows(3)(21) := NULL;
   l_col_rows(4)(21) := '1OFF:12.1.3:NOTIFICATION BODY CONTAINS UNEXPECTED URL PARAMETERS TEXT INSTEAD OF ACTUAL CONTENT (Superseded by 20230836)';
   l_col_rows(5)(21) := '';

   l_col_rows(1)(22) := '11684796';
   l_col_rows(2)(22) := 'No';
   l_col_rows(3)(22) := NULL;
   l_col_rows(4)(22) := '1OFF:12.1.3:VALUE OF SENT DATE FIELD IN EMAIL NOTIFICATIONS INTERMITTENTLY POPULATED (Superseded by 12540549)';
   l_col_rows(5)(22) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.1.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '13257382';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.1.2:10413964:MAILER INBOUND PROCESSOR STOPS WORKING AFTER JAVAX.MAIL.MESSAGEREMOVEDEXCEPTION (Superseded by 20230836)';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '11850834';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:12.1.2:9733998:GETTING ERROR JAVA.IO.IOEXCEPTION WHILE PARSING FOR NID IN THE INPUTSTREAM (Superseded by 20230836)';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '11678104';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '1OFF:12.1.2:9320224:INBOUND MAILER GOING DOWN:REPLY BUTTON USED: ORACLE BEEHIVE (Superseded by 20230836)';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '9868639';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '11OFF:12.1.2:9757926:GETTING JAVA.NET.MALFORMEDURLEXCEPTION WHILE SENDING OA FRAMEWORK BASED NOTIFICATION (Superseded by 20230836)';
   l_col_rows(5)(4) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.1.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '14699743';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:9757926:12.1.1:GETTING JAVA.NET.MALFORMEDURLEXCEPTION FOR AN ABSOLUTE URI WHILE SENDING OA FRAMEWORK BASED NOTIFICATION';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '12793695';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:12.1.1:WF_MAIL_UTIL.PARSECONTENTTYPE() API IS FAILING WHEN FILE NAME HAS CHINESE CHARACTERS IN THE CONTENTTYPE FIELD';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '12383369';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '1OFF:12.1.1:HTML TAGS APPEARED TOGETHER WITH THE MORE INFO ANSWER IN EMAIL NOTIFICATION';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '10276282';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'NLS: JAPANESE CHARS ARE GARBLED IN MS OUTLLOK 2007 English version for Multilingual User Interface (CUSTOM FIX For this customer, Applicable for R12.1.2/12.1.3)';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '9739567';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := '1OFF:12.1.1:9544115:PO APPROVAL NOTIFICATION DOES NOT REFRESH WITH CHANGE';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '9451829';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := '1OFF:12.1.1: 8802669:NTF DISAPPEARS AS MORE_INFO_ROLE IS UPDATED WITH EMAIL_ADDRESS';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '9437814';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '1OFF:12.1.1:9113411:NOTIFICATION FAILS TO BE GENERATED FOR *.DOCX ATTACHMENT';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '9251305';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := '1OFF:12.1.1:9180569 - CLOSED:  MAIL IS SENT WHEN AN FYI NTF IS CLOSED FROM UI';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '8832674';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := '1OFF:12.1.1:CONSOLIDATE POST 12.1.1 ONE-OFFs FOR OWF (bugs 5676227,8729116,7308460,8638909 ...)';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '8515763';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := '1OFF:12.1.1:EXTERNAL IRECRUITMENT REGISTRATION AND PASSWORD RESET DOES NOT WORK FOR HOTMAIL AND YAHOO USERS';
   l_col_rows(5)(10) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.0.6' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '211767973';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'BACKPORT:10394986:12.0.6:LOBSUBSTITUTE RETURNS INCORRECT RESULT IF THE TEMPLATE CONTAINS NOTIFICATION_ID';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '11875960';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'BACKPORT:12.0.6:9113411:NOTIFICATION FAILS TO BE GENERATED WHEN A DOCX DOCUMENT IS ATTACHED';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '9616995';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '1OFF:12.0.6:8341801:REQUEST MORE INFORMATION TEMPLATE SEEDING RANDOM USERS';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '8813679';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '1OFF:12.0.6:7718246:HEADER TABLE IN E-MAIL BODY APPEARS WITH SOLID BORDER';
   l_col_rows(5)(4) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,6) = '12.0.4' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '9801387';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:12.0.4:9411678:GETTING JAVA.IO.IOEXCEPTION WHILE PARSING FOR NID STRING (Superseded by 10428040:R12.OWF.A)';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '8772399';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:12.0.4:8645704:INVALID RFI EMAILS STOP THE MAILER FROM PROCESSING RESPONSES';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '8225521';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '1OFF:7007150:12.0.4:WORKFLOW SYSTEM SHOULD BE ACTUAL USER WHEN NOTIFICATION APPROVED BY MANY USERS';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '6767410';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '1-OFF:12.0.4:EMAIL NOTIFICATIONS DISPLAY ERROR MESSAGE AS INSUFFICIENT PRIVILEGE';
   l_col_rows(5)(4) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '18061822';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '1OFF:11.5.10.RUP7:13789492:UNEXPECTED URL PARAMETERS IN THE NOTIFICATION BODY ';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '17477210';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '1OFF:11I.ATG_PF.H.RUP7:MAILTO LINKS ARE NOT WORKING IN REDIFF MAIL ';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '17446951';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '1OFF:11.5.10.RUP7:14041989: MAILER IS THROWING SAXPARSEEXCEPTION IF #WFM_FROM ATTR HAS FULL EMAIL ADDRESS ';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '12927781';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '1OFF:9174194:11I.ATG_PF.H.RUP7:NULLPOINTEREXCEPTION AFTER 451 TIMEOUT WAITING FOR CLIENT INPUT ERROR ';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '12698085';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := '1OFF:11.5.10.7:10130433 BACKPORT: SHOW ACTUAL ERROR MESSAGE INSTEAD OF [WFMLR_DOCUMENT_ERROR] WHEN BUILDING NOTIFICATION CONTENT ';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '10369643';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'SYSTEM HANGS BECUASE OF NO SPACE CAUSED BY WF_NOTIFICATION_OUT GROWTH IN APPLSYS ';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '10114567';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '1OFF:11.5.10.RUP4:7248744:MAILER DOWN WITH :JAVA.LANG.STRINGINDEXOUTOFBOUNDSEXCEPTION ';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '9278820';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := '1OFF:11.5.10.RUP7:9113411:NOTIFICATION FAILS TO BE GENERATED WHEN A DOCX DOCUMENT IS ATTACHED ';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '8881538';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := '1OFF:11.5.10.6:7718246:HEADER TABLE IN E-MAIL BODY APPEARS WITH SOLID BORDER( INCLUDES 1OFFs 8651188, 8441656 and FIX OF BUG 6242825 FOR BLACKBERRY) ';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '8651188';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := '1OFF:11.5.10.6:8552982:FURTHER TOKEN SUBSTITUTION NOT WORKING IN TEXT RETURNED BY PLSQL DOC ATTRIBUTE ';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '8646317';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := '1OFF:11.5.10.5RUP:6613981/6162428: NO DATA FOUND IN WF_MAILER_PARAMETER ';
   l_col_rows(5)(11) := '';

   l_col_rows(1)(12) := '8487454';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := '1OFF:11.5.10.RUP6:6613981:NO DATA FOUND IN WF_MAILER_PARAMETER.GETVALUEFORCORR ';
   l_col_rows(5)(12) := '';

   l_col_rows(1)(13) := '8441656';
   l_col_rows(2)(13) := 'No';
   l_col_rows(3)(13) := NULL;
   l_col_rows(4)(13) := '1OFF:11.5.10.6:6993909:MULTIPART/RELATED DISABLES ATTACHMENT ICON IN EMAILS SENT BY MS EXCHANGE SERVER ';
   l_col_rows(5)(13) := '';

   l_col_rows(1)(14) := '8324328';
   l_col_rows(2)(14) := 'No';
   l_col_rows(3)(14) := NULL;
   l_col_rows(4)(14) := '1OFF:11.5.10.6:7595341:INVALID ALTER SESSION ERROR ON SCRIPT WFNTFCU2.SQL ';
   l_col_rows(5)(14) := '';

   l_col_rows(1)(15) := '7691035';
   l_col_rows(2)(15) := 'No';
   l_col_rows(3)(15) := NULL;
   l_col_rows(4)(15) := 'BPORT:7641725:11.5.10.RUP6:NOTIFICATIONS STUCK IN WF_NOTIFICATION_OUT AFTER THEY ARE REASSIGNED ';
   l_col_rows(5)(15) := '';

   l_col_rows(1)(16) := '6954271';
   l_col_rows(2)(16) := 'No';
   l_col_rows(3)(16) := NULL;
   l_col_rows(4)(16) := '1OFF:6528142:RUP5:email issue when APPLICATIONS SSO TYPE PROFILE set to PORTAL W/SSO ';
   l_col_rows(5)(16) := '';

   l_col_rows(1)(17) := '6901563';
   l_col_rows(2)(17) := 'No';
   l_col_rows(3)(17) := NULL;
   l_col_rows(4)(17) := 'BACKPORT: 6833151: INCONSISTENCY IN CORRID OF WF_NOTIFICATION_OUT AQ (Fix of 6441940 and 6833151) ';
   l_col_rows(5)(17) := '';

   l_col_rows(1)(18) := '6836141';
   l_col_rows(2)(18) := 'No';
   l_col_rows(3)(18) := NULL;
   l_col_rows(4)(18) := '1OFF:6511028: WORKFLOW SERVICE CONTAINER CONSUMING A LOT TEMP LOBs (Superseded by 7268412) ';
   l_col_rows(5)(18) := '';

   l_col_rows(1)(19) := '6716241';
   l_col_rows(2)(19) := 'No';
   l_col_rows(3)(19) := NULL;
   l_col_rows(4)(19) := '11.5.10.ATG.RUP5: 1-OFF: WF MANAGER UI ALLOWS ADDING 1 CUSTOM TAG ONLY ';
   l_col_rows(5)(19) := '';

   l_col_rows(1)(20) := '6616500';
   l_col_rows(2)(20) := 'No';
   l_col_rows(3)(20) := NULL;
   l_col_rows(4)(20) := '1OFF:5963671:ON11.5.10.2 RUP6: NOTIFICATION MAILER TIME OUT MSGS, NEEDS RESTART ';
   l_col_rows(5)(20) := '';

   l_col_rows(1)(21) := '6520421';
   l_col_rows(2)(21) := 'No';
   l_col_rows(3)(21) := NULL;
   l_col_rows(4)(21) := '11.5.10 ATG.RUP4: 6049086:USERS WITH SUMHTML PREF NOT RECEIVING MORE INFORMATION NOTIFICATIONS PROPERLY ';
   l_col_rows(5)(21) := '';

   l_col_rows(1)(22) := '6344618';
   l_col_rows(2)(22) := 'No';
   l_col_rows(3)(22) := NULL;
   l_col_rows(4)(22) := '11.5.10 ATG.RUP4: 6242825: ENCODING FOR MAILTO URIs IN HTML E-MAILS REQUIRES CORRECTION ';
   l_col_rows(5)(22) := '';

   l_col_rows(1)(23) := '5939442';
   l_col_rows(2)(23) := 'No';
   l_col_rows(3)(23) := NULL;
   l_col_rows(4)(23) := '11.5.10 ATG.RUP4: NULLPOINTEREXCEPTION, WORKFLOW MAILER DOES NOT START AFTER ATG_PF.H RUP4 (Superseded by 6241631-11i.ATG_PF.H.delta.7) ';
   l_col_rows(5)(23) := '';

   l_col_rows(1)(24) := '5665230';
   l_col_rows(2)(24) := 'No';
   l_col_rows(3)(24) := NULL;
   l_col_rows(4)(24) := '11.5.10 ATG.RUP4: ALERTS ARE NOT PICKING UP USER SPECIFIED REPLYTO ADDRESS (Superseded by 6241631-11i.ATG_PF.H.delta.7) ';
   l_col_rows(5)(24) := '';

   l_col_rows(1)(25) := '5479427';
   l_col_rows(2)(25) := 'No';
   l_col_rows(3)(25) := NULL;
   l_col_rows(4)(25) := '11.5.10 ATG.RUP4:STD PO APPROVAL E-MAIL RESPONSES FROM BLACKBERRY ARE REJECTED AS INVALID RESP (Superseded by 6241631-11i.ATG_PF.H.delta.7) ';
   l_col_rows(5)(25) := '';

   l_col_rows(1)(26) := '5402087';
   l_col_rows(2)(26) := 'No';
   l_col_rows(3)(26) := NULL;
   l_col_rows(4)(26) := '11.5.10. ATG.RUP4:5387425:STD PO APPROVAL E-MAIL RESPONSES FROM BLACKBERRY ARE REJECTED AS INVALID RESP (Superseded by 6241631-11i.ATG_PF.H.delta.7) ';
   l_col_rows(5)(26) := '';

END IF;

   l_sig.title := 'Development suggested Workflow Java Mailer Patches for '||g_rep_info('Apps Version')||'';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'There are Development suggested '||g_rep_info('Apps Version')||' Workflow Java Mailer patches that are not applied '||
        'on this instance';
   l_sig.solution := '<ul><li>Please review list above and schedule
        to apply any unappplied Development suggested Workflow Java Mailer patches as soon as possible</li>
        <li>Refer to the note indicated for more information about each patch</li></ul>';
   l_sig.success_msg := 'All Development suggested Workflow Java Mailer patches (if any) have been applied.';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'RS';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';
 
  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      l_col_rows(1)(i) := '{'||l_col_rows(1)(i)||'}';
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;
 
--Render
  l_step := '60';
 
  l_step := '70';
  RETURN process_signature_results(
    'WF5_CHECK_WFMLR_SUGG_PATCHES',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers
 
debug('End recommended patches signature: check_rec_patches_3');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_3 at step '||l_step);
  raise;
END check_rec_patches_3;




-------------------------
-- Signatures
-------------------------



PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- 'RSGT1' (RS greater than 1), 'RS' (row selected), 'NRS' (no row selected), '[count(*)] > [0]'
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') -- This is for AT use so internal only. Set to Y if want signature result to be printed at end of output file in DX Summary section
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;
  l_key      VARCHAR2(255);

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Clear FK values if the sig has children
  IF l_sig.child_sigs.count > 0 THEN
    l_key := g_sql_tokens.first;
    WHILE l_key is not null LOOP
      IF l_key like '##$$FK_$$##' THEN 
        g_sql_tokens.delete(l_key);
      END IF;
      l_key := g_sql_tokens.next(l_key);
    END LOOP;
  END IF;
  
  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--#######################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
PROCEDURE validate_parameters(
            p_max_output_rows              IN NUMBER      DEFAULT 30
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

IS

  l_revision                  VARCHAR2(25);
  l_date_char                 VARCHAR2(30);
  l_instance                  V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version              FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host                      V$INSTANCE.HOST_NAME%TYPE;
  l_key                       VARCHAR2(255);
  l_system_function_var       VARCHAR2(2000);
  l_index                     NUMBER:=1;

  invalid_parameters EXCEPTION;

  l_errorntfcnt		 	number;
  l_sysadmin_email	 	varchar2(320);
  l_sysadmin_ntf_pref	        varchar2(8);

  l_wfadmin_role 		varchar2(2000);
  l_wfadmins_cnt		number;
  l_wfadmin_display 	        varchar2(360);
  l_wfadmin_ntf_pref	        varchar2(8);
  l_wfadmin_email               varchar2(320);
  l_ntfutil_ver                 varchar2(150);
  dee_open_cnt		        number := 0;
  dee_clsd_cnt		        number := 0;
  dee_open30_cnt		number := 0;
  total_error  		        number := 0;
  open_error   		        number := 0;
  closed_error 		        number := 0;
  ntferr_cnt			number := 0;
  l_cnt_item	     	        number;
  l_item_open   	 	number;
  l_oldest_item 	 	number;
--wf_loop_hitory
	l_hist_end		varchar2(22);
	l_hist_begin		varchar2(22);
	l_hist_recent		varchar2(22);		
	l_hasrows		number;
	l_hist_cnt   		number;
	l_hist_days 		number;
	l_hist_daily		number;	
	l_hist_item     	varchar2(8);
	l_hist_key      	varchar2(240);
--om_loop_history
	l_ont_hist_end		varchar2(22);
	l_ont_hist_begin	varchar2(22);
	l_ont_hist_recent	varchar2(22);		
	l_ont_hasrows		number := 0;
	l_ont_hist_cnt   	number := 0;
	l_ont_hist_days 	number := 0;
	l_ont_hist_daily	number := 0;	
	l_ont_hist_item     	varchar2(8);
	l_ont_hist_key      	varchar2(240);
--hcm_loop_hitory
	l_hcm_hist_end		varchar2(22);
	l_hcm_hist_begin	varchar2(22);
	l_hcm_hist_recent	varchar2(22);		
	l_hcm_hasrows		number;
	l_hcm_hist_cnt   	number;
	l_hcm_hist_days 	number;
	l_hcm_hist_daily	number;	
	l_hcm_hist_item     	varchar2(8);
	l_hcm_hist_key      	varchar2(240);
--po_loop_history
	l_po_hist_end		varchar2(22);
	l_po_hist_begin		varchar2(22);
	l_po_hist_recent	varchar2(22);		
	l_po_hasrows		number := 0;
	l_po_hist_cnt   	number := 0;
	l_po_hist_days 		number := 0;
	l_po_hist_daily		number := 0;	
	l_po_hist_item     	varchar2(8);
	l_po_hist_key      	varchar2(240);
  l_stuck_cnt			number;
  l_disabled_cnt		number;
  l_jqp_cnt			number;
  l_atgrup4			number;
  l_alldefrd			number;
  l_prgall			number;
  l_prgany			number;
  l_prgcore			number;
  l_wfitems			number;
  l_stuckfreq			number;
  l_lastwfcqcup                 date;
  l_wfcqcup_hrs			number;
  l_concprgms_cnt		number;
  l_last_ran			varchar2(22);
  l_mailer_enabled 		varchar2(8);
  l_ninety_cnt			number;
  l_stmt_log_cnt		number := 0;
  l_WFNTFPRG_APPLIED 	        number := 0;
  l_UNREFNTF_CNT		number := 0;
  l_omcnt			number := 0;
  l_olcnt			number := 0;
  l_chart_om_cnt		number := 0;
  l_hrcnt			number := 0;
  l_chart_hr_cnt		number := 0;
  l_po_cnt			number := 0;
  l_chart_po_cnt		number := 0;
  l_incomplpo			number := 0;
  l_orphline			number := 0;
  l_orphhdr			number := 0;
  l_logical_totals		number := 0;
  l_physical_totals		number := 0;
  l_diff_totals 		number := 0;
  l_rate			number;
  l_db_version     	 	V$INSTANCE.VERSION%TYPE;


l_exists_val       VARCHAR2(2000);




  
BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
  l_revision := rtrim(replace('$Revision: 200.13 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2016/05/13 11:18:28 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
  g_rep_info('File Name') := 'workflow_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'); 
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1369938.1" target="_blank">(Note 1369938.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------

-- Validation to verify analyzer is run on proper e-Business application version
-- In case validation at the beginning is updated/removed, adding validation here also so execution fails
  IF substr(l_apps_version,1,4) NOT IN ('11.5','12.0','12.1','12.2') THEN
	print_log('eBusiness Suite version = '||l_apps_version);
	print_log('ERROR: This Analyzer script is compatible for following version(s): 11i,12.0,12.1,12.2');
	raise invalid_parameters;
  END IF;
  

  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');




debug('begin Additional Code: Additional Validation');
SELECT max(release_name) INTO l_apps_version
FROM fnd_product_groups;

SELECT instance_name, host_name, version
INTO l_instance, l_host, l_db_version
FROM v$instance;

select value into l_jqp_cnt 
from v$parameter where upper(name) = 'JOB_QUEUE_PROCESSES';

select notification_preference, nvl(email_address,'NOTSET') 
into l_sysadmin_ntf_pref, l_sysadmin_email 
from wf_local_roles where name = 'SYSADMIN';

	select wf_core.translate('WF_ADMIN_ROLE') into l_wfadmin_role from dual;

if (l_wfadmin_role = '*') then

	l_wfadmins_cnt := 1;
	l_wfadmin_display := 'Everybody is Workflow Administrator';
	l_wfadmin_ntf_pref := 'MAILHTML';
	l_wfadmin_email := 'Not Set';

else
	select nvl(max(rownum), 0) into l_wfadmins_cnt
	from wf_roles 
	where name in (select user_name from WF_USER_ROLE_ASSIGNMENTS where role_name = (select wf_core.translate('WF_ADMIN_ROLE') from dual));

	select r.display_name into l_wfadmin_display 
	from wf_roles r, wf_resources res 
	where res.name = 'WF_ADMIN_ROLE'
	and res.language = 'US'
	and res.text = r.NAME;

	select notification_preference into l_wfadmin_ntf_pref 
	from wf_local_roles r, wf_resources res 
	where res.name = 'WF_ADMIN_ROLE'
	and res.language = 'US'
	and res.text = r.NAME; 
	
	select decode(email_address, '','No Email Specified', email_address) into l_wfadmin_email 
	from wf_roles r, wf_resources res 
	where res.name = 'WF_ADMIN_ROLE'
	and res.language = 'US'
	and res.text = r.NAME;  
end if;

select *  into l_ntfutil_ver from 
(select "Version"
  from ( select afv1.version "Version",
	   rank()over(partition by af1.filename
	     order by afv1.version_segment1 desc,
	     afv1.version_segment2 desc,afv1.version_segment3 desc,
	     afv1.version_segment4 desc,afv1.version_segment5 desc,
	     afv1.version_segment6 desc,afv1.version_segment7 desc,
	     afv1.version_segment8 desc,afv1.version_segment9 desc,
	     afv1.version_segment10 desc,
	     afv1.translation_level desc) as rankUS
  from ad_files af1, ad_file_versions afv1
where af1.file_id = afv1.file_id
  and af1.filename = 'NtfUtil.class'
  and af1.subdir = 'java/wf/worklist/webui')
where rankUS = 1);

select count(n.notification_id) into dee_open_cnt
from wf_notifications n
where n.message_type like '%ERROR%'
and n.message_name like 'DEFAULT_EVENT%'
and n.status = 'OPEN';

select count(n.notification_id) into dee_open30_cnt
from wf_notifications n
where n.message_type = 'WFERROR'
and n.message_name like 'DEFAULT_EVENT%'
and n.begin_date > sysdate-30
and n.status = 'OPEN';

select count(n.notification_id) into dee_clsd_cnt
from wf_notifications n
where n.message_type = 'WFERROR'
and n.message_name like 'DEFAULT_EVENT%'
and n.status ! = 'OPEN';

select count(notification_id) into total_error
from WF_NOTIFICATIONS
where message_type like '%ERROR%';

select count(notification_id) into open_error
from WF_NOTIFICATIONS
where message_type like '%ERROR%'
and end_date is null;

select count(notification_id) into closed_error
from WF_NOTIFICATIONS
where message_type like '%ERROR%'
and end_date is not null;

select nvl(max(rownum), 0) into ntferr_cnt
from wf_notifications n
where n.message_type like '%ERROR%';
	
 if (total_error = 0) then
 total_error := 1;          --to avoid divide by zero errors
 end if;
 if (ntferr_cnt = 0) then
 ntferr_cnt :=1;          --to avoid divide by zero errors
 end if;	

select count(item_key) into l_cnt_item from wf_items;

select count(item_key) into l_item_open from wf_items where end_date is null;

select round(sysdate-(min(begin_date)),0) into l_oldest_item from wf_items;

----------------------------------------------------------------------
-- Identify Looping issues in the WF_ITEM_ACTIVITY_STATUSES_H Table --
----------------------------------------------------------------------
SELECT count(*) into l_hasrows FROM (SELECT sta.item_type 
FROM wf_item_activity_statuses_h sta, 
wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type LIKE '%' 
GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
HAVING COUNT(*) > 500 
ORDER BY COUNT(*) DESC);

if (l_hasrows>0) then

	SELECT * into l_hist_item FROM (SELECT sta.item_type 
	FROM wf_item_activity_statuses_h sta, 
	wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type LIKE '%' 
	GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
	HAVING COUNT(*) > 500 
	ORDER BY COUNT(*) DESC)
	WHERE ROWNUM = 1;

	select * into l_hist_key from (SELECT sta.item_key 
	FROM wf_item_activity_statuses_h sta, 
	wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type LIKE '%' 
	GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
	HAVING COUNT(*) > 500 
	ORDER BY COUNT(*) DESC)
	WHERE ROWNUM = 1;

	SELECT * into l_hist_end  
	FROM (SELECT wi.end_date from wf_items wi 
	      where wi.item_type = l_hist_item and wi.item_key = l_hist_key);

	SELECT * into l_hist_cnt FROM (SELECT count(sta.item_key) 
	FROM wf_item_activity_statuses_h sta, 
	wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type LIKE '%' 
	GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
	HAVING COUNT(*) > 500 
	ORDER BY COUNT(*) DESC)
	WHERE ROWNUM = 1;

	SELECT * into l_hist_begin
	FROM (SELECT to_char(wi.begin_date, 'Mon DD, YYYY') from  wf_items wi 
	      where wi.item_type = l_hist_item and wi.item_key = l_hist_key);

	select * into l_hist_days
	from (select round(sysdate-wi.begin_date,0) from wf_items wi 
	      where wi.item_type = l_hist_item and wi.item_key = l_hist_key);
	
	select * into l_hist_recent 
	FROM (SELECT to_char(max(h.begin_date),'Mon DD, YYYY') from wf_item_activity_statuses_h h
	where h.item_type = l_hist_item and h.item_key = l_hist_key);

--	select sysdate into :sysdate from dual;

end if;

	if ((l_hist_end is null) and (l_hist_days=0)) then 

		l_hist_daily := l_hist_cnt;

		elsif ((l_hist_end is null) and (l_hist_days > 0)) then 
		
		select ROUND((l_hist_cnt/l_hist_days),0) into l_hist_daily from dual;
	
 	  elsif ((l_hist_end is not null) and (l_hist_days = 0)) then 

		select ROUND((l_hist_cnt/l_hist_days),0) into l_hist_daily from dual;
		  
	  else 

		select ROUND((l_hist_cnt/l_hist_days),2) into l_hist_daily from dual;
		   
	end if; 
		
--------------------------------------------------------------------------
-- Identify ONT Looping issues in the WF_ITEM_ACTIVITY_STATUSES_H Table --
--------------------------------------------------------------------------

SELECT count(*) into l_ont_hasrows FROM (SELECT sta.item_type 
FROM wf_item_activity_statuses_h sta, 
wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type in ('OEOH', 'OEOL', 'OMERROR', 'OEOI', 'OECOGS', 'OEOA', 'OECHGORD','OEON','OEBH')
GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
HAVING COUNT(*) > 500 
ORDER BY COUNT(*) DESC);

if (l_ont_hasrows>0) then

	SELECT * into l_ont_hist_item FROM (SELECT sta.item_type 
	FROM wf_item_activity_statuses_h sta, 
	wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type in ('OEOH', 'OEOL', 'OMERROR', 'OEOI', 'OECOGS', 'OEOA', 'OECHGORD','OEON','OEBH') 
	GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
	HAVING COUNT(*) > 500 
	ORDER BY COUNT(*) DESC)
	WHERE ROWNUM = 1;

	select * into l_ont_hist_key from (SELECT sta.item_key 
	FROM wf_item_activity_statuses_h sta, 
	wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type in ('OEOH', 'OEOL', 'OMERROR', 'OEOI', 'OECOGS', 'OEOA', 'OECHGORD','OEON','OEBH') 
	GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
	HAVING COUNT(*) > 500 
	ORDER BY COUNT(*) DESC)
	WHERE ROWNUM = 1;

	SELECT * into l_ont_hist_end  
	FROM (SELECT wi.end_date from wf_items wi 
	      where wi.item_type = l_ont_hist_item and wi.item_key = l_ont_hist_key);

	SELECT * into l_ont_hist_cnt FROM (SELECT count(sta.item_key) 
	FROM wf_item_activity_statuses_h sta, 
	wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type in ('OEOH', 'OEOL', 'OMERROR', 'OEOI', 'OECOGS', 'OEOA', 'OECHGORD','OEON','OEBH') 
	GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
	HAVING COUNT(*) > 500 
	ORDER BY COUNT(*) DESC)
	WHERE ROWNUM = 1;

	SELECT * into l_ont_hist_begin
	FROM (SELECT to_char(wi.begin_date, 'Mon DD, YYYY') from  wf_items wi 
	      where wi.item_type = l_ont_hist_item and wi.item_key = l_ont_hist_key);

	select * into l_ont_hist_days
	from (select round(sysdate-wi.begin_date,0) from wf_items wi 
	      where wi.item_type = l_ont_hist_item and wi.item_key = l_ont_hist_key);
	
	select * into l_ont_hist_recent 
	FROM (SELECT to_char(max(h.begin_date),'Mon DD, YYYY') from wf_item_activity_statuses_h h
	where h.item_type = l_ont_hist_item and h.item_key = l_ont_hist_key);

end if;

	if ((l_ont_hist_end is null) and (l_ont_hist_days=0)) then 

		l_ont_hist_daily := l_ont_hist_cnt;

		elsif ((l_ont_hist_end is null) and (l_ont_hist_days > 0)) then 
		
		select ROUND((l_ont_hist_cnt/l_ont_hist_days),0) into l_ont_hist_daily from dual;
	
 	  elsif ((l_ont_hist_end is not null) and (l_ont_hist_days = 0)) then 

		select ROUND((l_ont_hist_cnt/l_ont_hist_days),0) into l_ont_hist_daily from dual;
		  
	  else 

		select ROUND((l_ont_hist_cnt/l_ont_hist_days),2) into l_ont_hist_daily from dual;
		   
	end if; 
--------------------------------------------------------------------------
-- Identify HCM Looping issues in the WF_ITEM_ACTIVITY_STATUSES_H Table --
--------------------------------------------------------------------------

SELECT count(*) into l_hcm_hasrows FROM (SELECT sta.item_type 
FROM wf_item_activity_statuses_h sta, 
wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key 
AND wfi.item_type in ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'OTWF', 'PYASGWF', 'HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC', 'PSPERAVL')
GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
HAVING COUNT(*) > 500 
ORDER BY COUNT(*) DESC);

if (l_hcm_hasrows>0) then

	SELECT * into l_hcm_hist_item FROM (SELECT sta.item_type 
	FROM wf_item_activity_statuses_h sta, 
	wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type in ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'OTWF', 'PYASGWF', 'HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC', 'PSPERAVL') 
	GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
	HAVING COUNT(*) > 500 
	ORDER BY COUNT(*) DESC)
	WHERE ROWNUM = 1;

	select * into l_hcm_hist_key from (SELECT sta.item_key 
	FROM wf_item_activity_statuses_h sta, 
	wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type in ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'OTWF', 'PYASGWF', 'HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC', 'PSPERAVL') 
	GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
	HAVING COUNT(*) > 500 
	ORDER BY COUNT(*) DESC)
	WHERE ROWNUM = 1;

	SELECT * into l_hcm_hist_end  
	FROM (SELECT wi.end_date from wf_items wi 
	      where wi.item_type = l_hcm_hist_item and wi.item_key = l_hcm_hist_key);

	SELECT * into l_hcm_hist_cnt FROM (SELECT count(sta.item_key) 
	FROM wf_item_activity_statuses_h sta, 
	wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type in ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'OTWF', 'PYASGWF', 'HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC', 'PSPERAVL')
	GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
	HAVING COUNT(*) > 500 
	ORDER BY COUNT(*) DESC)
	WHERE ROWNUM = 1;

	SELECT * into l_hcm_hist_begin
	FROM (SELECT to_char(wi.begin_date, 'Mon DD, YYYY') from  wf_items wi 
	      where wi.item_type = l_hcm_hist_item and wi.item_key = l_hcm_hist_key);

	select * into l_hcm_hist_days
	from (select round(sysdate-wi.begin_date,0) from wf_items wi 
	      where wi.item_type = l_hcm_hist_item and wi.item_key = l_hcm_hist_key);
	
	select * into l_hcm_hist_recent 
	FROM (SELECT to_char(max(h.begin_date),'Mon DD, YYYY') from wf_item_activity_statuses_h h
	where h.item_type = l_hcm_hist_item and h.item_key = l_hcm_hist_key);

end if;

	if ((l_hcm_hist_end is null) and (l_hcm_hist_days=0)) then 

		l_hcm_hist_daily := l_hcm_hist_cnt;

		elsif ((l_hcm_hist_end is null) and (l_hcm_hist_days > 0)) then 
		
		select ROUND((l_hcm_hist_cnt/l_hcm_hist_days),0) into l_hcm_hist_daily from dual;
	
 	  elsif ((l_hcm_hist_end is not null) and (l_hcm_hist_days = 0)) then 

		select ROUND((l_hcm_hist_cnt/l_hcm_hist_days),0) into l_hcm_hist_daily from dual;
		  
	  else 

		select ROUND((l_hcm_hist_cnt/l_hcm_hist_days),2) into l_hcm_hist_daily from dual;
		   
	end if; 

-------------------------------------------------------------------------
-- Identify PO Looping issues in the WF_ITEM_ACTIVITY_STATUSES_H Table --
-------------------------------------------------------------------------

SELECT count(*) into l_po_hasrows FROM (SELECT sta.item_type 
FROM wf_item_activity_statuses_h sta, 
wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type in ('POAPPRV','REQAPPRV','POXML','POWFRQAG','PORCPT','APVRMDER','PONPBLSH','POSPOACK','PONAUCT','PORPOCHA','PODSNOTF','POSREGV2','POREQCHA','POWFPOAG','POSCHORD','POSASNNB','PONAPPRV','POSCHPDT','POAUTH','POWFDS','POERROR','POSBPR','CREATEPO')
GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
HAVING COUNT(*) > 500 
ORDER BY COUNT(*) DESC);

if (l_po_hasrows>0) then

	SELECT * into l_po_hist_item FROM (SELECT sta.item_type 
	FROM wf_item_activity_statuses_h sta, 
	wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type in ('POAPPRV','REQAPPRV','POXML','POWFRQAG','PORCPT','APVRMDER','PONPBLSH','POSPOACK','PONAUCT','PORPOCHA','PODSNOTF','POSREGV2','POREQCHA','POWFPOAG','POSCHORD','POSASNNB','PONAPPRV','POSCHPDT','POAUTH','POWFDS','POERROR','POSBPR','CREATEPO')
	GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
	HAVING COUNT(*) > 500 
	ORDER BY COUNT(*) DESC)
	WHERE ROWNUM = 1;

	select * into l_po_hist_key from (SELECT sta.item_key 
	FROM wf_item_activity_statuses_h sta, 
	wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type in ('POAPPRV','REQAPPRV','POXML','POWFRQAG','PORCPT','APVRMDER','PONPBLSH','POSPOACK','PONAUCT','PORPOCHA','PODSNOTF','POSREGV2','POREQCHA','POWFPOAG','POSCHORD','POSASNNB','PONAPPRV','POSCHPDT','POAUTH','POWFDS','POERROR','POSBPR','CREATEPO')
	GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
	HAVING COUNT(*) > 500 
	ORDER BY COUNT(*) DESC)
	WHERE ROWNUM = 1;

	SELECT * into l_po_hist_end  
	FROM (SELECT wi.end_date from wf_items wi 
	      where wi.item_type = l_po_hist_item and wi.item_key = l_po_hist_key);

	SELECT * into l_po_hist_cnt FROM (SELECT count(sta.item_key) 
	FROM wf_item_activity_statuses_h sta, 
	wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key  = wfi.item_key AND wfi.item_type in ('POAPPRV','REQAPPRV','POXML','POWFRQAG','PORCPT','APVRMDER','PONPBLSH','POSPOACK','PONAUCT','PORPOCHA','PODSNOTF','POSREGV2','POREQCHA','POWFPOAG','POSCHORD','POSASNNB','PONAPPRV','POSCHPDT','POAUTH','POWFDS','POERROR','POSBPR','CREATEPO')
	GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, 'YYYY-MM-DD'), TO_CHAR(wfi.end_date, 'YYYY-MM-DD') 
	HAVING COUNT(*) > 500 
	ORDER BY COUNT(*) DESC)
	WHERE ROWNUM = 1;

	SELECT * into l_po_hist_begin
	FROM (SELECT to_char(wi.begin_date, 'Mon DD, YYYY') from  wf_items wi 
	      where wi.item_type = l_po_hist_item and wi.item_key = l_po_hist_key);

	select * into l_po_hist_days
	from (select round(sysdate-wi.begin_date,0) from wf_items wi 
	      where wi.item_type = l_po_hist_item and wi.item_key = l_po_hist_key);
	
	select * into l_po_hist_recent 
	FROM (SELECT to_char(max(h.begin_date),'Mon DD, YYYY') from wf_item_activity_statuses_h h
	where h.item_type = l_po_hist_item and h.item_key = l_po_hist_key);

end if;

	if ((l_po_hist_end is null) and (l_po_hist_days=0)) then 

		l_po_hist_daily := l_po_hist_cnt;

		elsif ((l_po_hist_end is null) and (l_po_hist_days > 0)) then 
		
		select ROUND((l_po_hist_cnt/l_po_hist_days),0) into l_po_hist_daily from dual;
	
 	  elsif ((l_po_hist_end is not null) and (l_po_hist_days = 0)) then 

		select ROUND((l_po_hist_cnt/l_po_hist_days),0) into l_po_hist_daily from dual;
		  
	  else 

		select ROUND((l_po_hist_cnt/l_po_hist_days),2) into l_po_hist_daily from dual;
		   
	end if; 

select count(notification_id) into l_errorntfcnt
from wf_notifications
where recipient_role = 'SYSADMIN'
and message_type like '%ERROR%';

select e.status into l_mailer_enabled
from wf_events e, WF_EVENT_SUBSCRIPTIONS s
where  e.GUID=s.EVENT_FILTER_GUID
and s.DESCRIPTION like '%WF_NOTIFICATION_OUT%'
and e.name = 'oracle.apps.wf.notification.send.group';

select count(s.item_key) into l_stuck_cnt
FROM wf_item_activity_statuses s,wf_process_activities p
WHERE p.instance_id = s.process_activity
and s.activity_status = 'ERROR'
AND s.activity_result_code = '#STUCK'
and s.end_date is null;

select count(name) into l_disabled_cnt
from wf_local_roles
where name not like 'FND_RESP%'
and user_flag = 'Y'
and status = 'ACTIVE'
and notification_preference = 'DISABLED';

select count(*) into l_atgrup4
from AD_BUGS b 
where b.BUG_NUMBER = '4676589';

select count(*) into l_WFNTFPRG_APPLIED
from AD_BUGS b 
where b.BUG_NUMBER = '3104909';

SELECT max(r.ACTUAL_COMPLETION_DATE) into l_last_ran
FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
and c.CONCURRENT_PROGRAM_NAME in ('FNDWFWITSTATCC') 
AND p.language = 'US' 
And R.Actual_Completion_Date Is Not Null
Order By R.Actual_Completion_Date Desc;

select sum(COUNT) into l_ninety_cnt from (  
select to_char(wi.begin_date, 'YYYY') TOTAL_OPENED, count(wi.item_key) COUNT  
from wf_items wi, wf_item_types wit, wf_item_types_tl witt  
where wi.ITEM_TYPE=wit.NAME and wi.end_date is null  
and wit.NAME=witt.NAME and witt.language = 'US' and wi.begin_date < (sysdate-90)
group by to_char(wi.begin_date, 'YYYY') );

select count(SC.COMPONENT_NAME) into l_stmt_log_cnt
 FROM FND_SVC_COMP_PARAM_VALS_V v, FND_SVC_COMPONENTS SC
 WHERE v.COMPONENT_ID=sc.COMPONENT_ID 
 AND v.parameter_name in ('COMPONENT_LOG_LEVEL')
and v.parameter_value = '1';

select count(rownum) into l_alldefrd
FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c 
WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID
and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
and c.CONCURRENT_PROGRAM_NAME = 'FNDWFBG' 
AND p.language = 'US' 
and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in ('P','R')
and substr(r.ARGUMENT_TEXT,0,instr(r.ARGUMENT_TEXT,',')-1) is NULL
and upper(TRIM(substr(r.ARGUMENT_TEXT,instr(r.ARGUMENT_TEXT,',',1,3)+1,(instr(r.ARGUMENT_TEXT,',',1,4)-1)-(instr(r.ARGUMENT_TEXT,',',1,3))))) in ('YES','Y');

select count(rownum) into l_prgall
FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c 
WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID
and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
and c.CONCURRENT_PROGRAM_NAME = 'FNDWFPR' 
AND p.language = 'US' 
and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in ('P','R')
and substr(r.ARGUMENT_TEXT,0,instr(r.ARGUMENT_TEXT,',')-1) is null
and TRIM(substr(r.ARGUMENT_TEXT,instr(r.ARGUMENT_TEXT,',',1,3)+1,(instr(r.ARGUMENT_TEXT,',',1,4)-1)-(instr(r.ARGUMENT_TEXT,',',1,3)))) = 'TEMP';

select count(rownum) into l_prgany
FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c 
WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID
and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
and c.CONCURRENT_PROGRAM_NAME = 'FNDWFPR' 
AND p.language = 'US' 
and r.PHASE_CODE in ('R','C')
and r.ACTUAL_COMPLETION_DATE > sysdate-30
and substr(r.ARGUMENT_TEXT,0,instr(r.ARGUMENT_TEXT,',')-1) is null
and TRIM(substr(r.ARGUMENT_TEXT,instr(r.ARGUMENT_TEXT,',',1,3)+1,(instr(r.ARGUMENT_TEXT,',',1,4)-1)-(instr(r.ARGUMENT_TEXT,',',1,3)))) = 'TEMP';

select count(distinct item_type) into l_wfitems from wf_items;

select count(rownum) into l_prgcore
FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c 
WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID
and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
and c.CONCURRENT_PROGRAM_NAME = 'FNDWFPR' 
AND p.language = 'US' 
and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in ('P','R')
and TRIM(substr(r.ARGUMENT_TEXT,instr(r.ARGUMENT_TEXT,',',1,3)+1,(instr(r.ARGUMENT_TEXT,',',1,4)-1)-(instr(r.ARGUMENT_TEXT,',',1,3)))) = 'TEMP'
and upper(TRIM(substr(r.ARGUMENT_TEXT,instr(r.ARGUMENT_TEXT,',',1,4)+1,(instr(r.ARGUMENT_TEXT,',',1,5)-1)-(instr(r.ARGUMENT_TEXT,',',1,4))))) in ('NO','N');


select count(rownum) into l_stuckfreq
FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c 
WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID
and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
and c.CONCURRENT_PROGRAM_NAME = 'FNDWFBG' 
AND p.language = 'US' 
and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in ('P')
and upper(TRIM(substr(r.ARGUMENT_TEXT,instr(r.ARGUMENT_TEXT,',',1,5)+1))) like 'Y%'
and r.RESUBMIT_INTERVAL_UNIT_CODE in ('HOURS','MINUTES');

select max(r.ACTUAL_COMPLETION_DATE) into l_lastwfcqcup
FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
and c.CONCURRENT_PROGRAM_NAME in ('FNDWFBES_CONTROL_QUEUE_CLEANUP') 
AND p.language = 'US';

select FLOOR(((sysdate-(select max(r.ACTUAL_COMPLETION_DATE)
FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
and c.CONCURRENT_PROGRAM_NAME in ('FNDWFBES_CONTROL_QUEUE_CLEANUP') 
AND p.language = 'US'))*24*60*60)/3600) into l_wfcqcup_hrs from dual;

select count(rownum) into l_concprgms_cnt from (
select r.REQUEST_ID "REQUEST_ID", u.user_name "REQUESTED_BY", r.PHASE_CODE "PHASE", r.ACTUAL_START_DATE "STARTED",
 c.CONCURRENT_PROGRAM_NAME "INTERNAL NAME", p.USER_CONCURRENT_PROGRAM_NAME "PROGRAM_NAME", r.ARGUMENT_TEXT "ARGUMENTS", 
 r.RESUBMIT_INTERVAL "EVERY", r.RESUBMIT_INTERVAL_UNIT_CODE "SO_OFTEN", r.RESUBMIT_END_DATE "RESUBMIT_END_DATE"
 FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
 and c.CONCURRENT_PROGRAM_NAME in ('FNDWFBG','FNDWFPR','FNDWFRET','JTFRSWSN','FNDWFSYNCUR','FNDWFLSC', 
 'FNDWFLIC','FNDWFDSURV','FNDCPPUR','FNDWFBES_CONTROL_QUEUE_CLEANUP','FNDWFAASTATCC','FNDWFMLRSTATCC',
 'FNDWFWITSTATCC','FNDWFBULKRESETNTFPREF') 
 AND p.language = 'US' 
 and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in ('P','R')
 order by c.CONCURRENT_PROGRAM_NAME, r.ARGUMENT_TEXT);

select count(notification_id) into l_UNREFNTF_CNT
from WF_NOTIFICATIONS WN
where not exists (select NULL from WF_ITEM_ACTIVITY_STATUSES WIAS
where WIAS.NOTIFICATION_ID = WN.GROUP_ID)
and not exists (select NULL from WF_ITEM_ACTIVITY_STATUSES_H WIAS
where WIAS.NOTIFICATION_ID = WN.GROUP_ID)
and wn.end_date is null;
 
select count(item_key) into l_omcnt
from wf_items
where item_type = 'OEOH';

select count(item_key) into l_olcnt
from wf_items
where item_type = 'OEOL';

select sum(CNT_TOTAL) into l_chart_om_cnt from (
select count(item_key) as "CNT_TOTAL" 
from wf_items wi
where wi.item_type in ('OEOH', 'OEOL', 'OEOI', 'OECOGS', 'OEOA', 'OECHGORD','OEON','OEBH')
or (wi.item_type like '%ERROR%' and wi.parent_item_type in ('OEOH', 'OEOL', 'OMERROR', 'OEOI', 'OECOGS', 'OEOA', 'OECHGORD','OEON','OEBH'))
group by item_type);

select count(item_key) into l_hrcnt
from wf_items
where item_type = 'HRSSA';

select sum(CNT_TOTAL) into l_chart_hr_cnt from (
select count(item_key) as "CNT_TOTAL" 
from wf_items wi
where wi.item_type in ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'OTWF', 'PYASGWF', 'HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC', 'PSPERAVL')    
or (wi.item_type like '%ERROR%' and wi.parent_item_type in ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'OTWF', 'PYASGWF', 'HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC', 'PSPERAVL'))
group by item_type);

select count(item_key) into l_po_cnt
from wf_items
where item_type = 'POAPPRV';

select sum(CNT_TOTAL) into l_chart_po_cnt from (
select count(item_key) as "CNT_TOTAL" 
from wf_items wi
where wi.item_type in ('POAPPRV','REQAPPRV','POXML','POWFRQAG','PORCPT','APVRMDER','PONPBLSH','POSPOACK','PONAUCT','PORPOCHA','PODSNOTF','POSREGV2','POREQCHA','POWFPOAG','POSCHORD','POSASNNB','PONAPPRV','POSCHPDT','POAUTH','POWFDS','POERROR','POSBPR','CREATEPO')    
or (wi.item_type like '%ERROR%' and wi.parent_item_type in ('POAPPRV','REQAPPRV','POXML','POWFRQAG','PORCPT','APVRMDER','PONPBLSH','POSPOACK','PONAUCT','PORPOCHA','PODSNOTF','POSREGV2','POREQCHA','POWFPOAG','POSCHORD','POSASNNB','PONAPPRV','POSCHPDT','POAUTH','POWFDS','POERROR','POSBPR','CREATEPO'))
group by item_type);

select count(rownum) into l_incomplpo from (
select i.parent_item_type, 
	   i.item_type,
	   i.item_key
  FROM wf_items i,
	   wf_item_activity_statuses ias
  WHERE i.parent_item_type = 'POAPPRV'
  AND   i.item_key = ias.item_key
  AND   i.item_type = ias.item_type
  AND   i.begin_date <= sysdate
  AND   ias.activity_status <> 'COMPLETE'
  AND   parent_item_key IN (
		  SELECT i1.item_key
		  FROM wf_items i1,
			   po_headers_all h
		  WHERE i1.item_key = h.wf_item_key
		  AND   i1.item_type = 'POAPPRV'
		  AND   h.authorization_status NOT IN ('IN PROCESS','PRE-APPROVED')
		  UNION
		  SELECT i1.item_key
		  FROM wf_items i1,
			   po_releases_all r
		  WHERE i1.item_key = r.wf_item_key
		  AND   i1.item_type = 'POAPPRV'
		  AND   r.authorization_status NOT IN ('IN PROCESS','PRE-APPROVED'))
  AND   ias.end_date is null);

select count(1) into l_orphline
from wf_items wi
where item_type = 'OEOL'
and parent_item_type = 'OEOH'
and end_date is null
and not exists (
select 1 from oe_order_lines_all
where line_id = to_number(wi.item_key));

select count(1) into l_orphhdr
from wf_items wi
where item_type = 'OEOH'
and end_date is null
and not exists (
select 1 from oe_order_headers_all
where header_id = to_number(wi.item_key));

select sum(LOGICAL_TOTAL) into l_logical_totals  from (
select   round(blocks*8192/1024/1024) as "LOGICAL_TOTAL"
from dba_tables 
where table_name in ('WF_ITEMS','WF_ITEM_ACTIVITY_STATUSES','WF_ITEM_ACTIVITY_STATUSES_H',
'WF_ITEM_ATTRIBUTE_VALUES','WF_NOTIFICATIONS','WF_COMMENTS','WF_DIG_SIGS')
and owner = 'APPLSYS' );

select sum(PHYSICAL_TOTAL) into l_physical_totals  from ( 
select round((num_rows*AVG_ROW_LEN)/1024/1024) as "PHYSICAL_TOTAL"
from dba_tables 
where table_name in ('WF_ITEMS','WF_ITEM_ACTIVITY_STATUSES','WF_ITEM_ACTIVITY_STATUSES_H',
'WF_ITEM_ATTRIBUTE_VALUES','WF_NOTIFICATIONS','WF_COMMENTS','WF_DIG_SIGS')
and owner = 'APPLSYS' );

select sum(TOTAL_DIFF) into l_diff_totals  from ( 
select round((blocks*8192/1024/1024)-(num_rows*AVG_ROW_LEN)/1024/1024) as "TOTAL_DIFF" 
from dba_tables 
where table_name in ('WF_ITEMS','WF_ITEM_ACTIVITY_STATUSES','WF_ITEM_ACTIVITY_STATUSES_H',
'WF_ITEM_ATTRIBUTE_VALUES','WF_NOTIFICATIONS','WF_COMMENTS','WF_DIG_SIGS')
and owner = 'APPLSYS' ); 

if (l_logical_totals>0) then
select ROUND(l_diff_totals/l_logical_totals,2)*100 into l_rate from dual;
else
l_rate:=0;
end if;

  g_sysadmin_ntf_pref := l_sysadmin_ntf_pref;
  g_sysadmin_email := l_sysadmin_email;
  g_wfadmin_role := l_wfadmin_role;
  g_wfadmins_cnt := l_wfadmins_cnt;
  g_wfadmin_display := l_wfadmin_display;
  g_wfadmin_ntf_pref := l_wfadmin_ntf_pref;
  g_wfadmin_email := l_wfadmin_email;
  g_ntfutil_ver := l_ntfutil_ver;
  g_dee_open_cnt := dee_open_cnt;
  g_dee_clsd_cnt := dee_clsd_cnt;
  g_dee_open30_cnt := dee_open30_cnt;
  g_total_error := total_error;
  g_open_error := open_error;
  g_closed_error := closed_error;
  g_ntferr_cnt	:= ntferr_cnt;
  g_errorntfcnt := l_errorntfcnt;
  g_cnt_item := l_cnt_item;
  g_item_open := l_item_open;
  g_oldest_item := l_oldest_item;

--wf_loop_history
	g_hist_end := l_hist_end;
	g_hist_begin := l_hist_begin;
	g_hist_recent := l_hist_recent;		
	g_hasrows := l_hasrows;
	g_hist_cnt := l_hist_cnt;
	g_hist_days := l_hist_days;
	g_hist_daily := l_hist_daily;	
	g_hist_item := l_hist_item;
	g_hist_key := l_hist_key;
--om_loop_history
	ont_hist_end := l_ont_hist_end;
	ont_hist_begin := l_ont_hist_begin;
	ont_hist_recent := l_ont_hist_recent;		
	ont_hasrows := l_ont_hasrows;
	ont_hist_cnt := l_ont_hist_cnt;
	ont_hist_days := l_ont_hist_days;
	ont_hist_daily := l_ont_hist_daily;	
	ont_hist_item := l_ont_hist_item;
	ont_hist_key := l_ont_hist_key;
--hcm_loop_history
	hcm_hist_end := l_hcm_hist_end;
	hcm_hist_begin := l_hcm_hist_begin;
	hcm_hist_recent := l_hcm_hist_recent;		
	hcm_hasrows := l_hcm_hasrows;
	hcm_hist_cnt := l_hcm_hist_cnt;
	hcm_hist_days := l_hcm_hist_days;
	hcm_hist_daily := l_hcm_hist_daily;	
	hcm_hist_item := l_hcm_hist_item;
	hcm_hist_key := l_hcm_hist_key;
--po_loop_history
	po_hist_end := l_po_hist_end;
	po_hist_begin := l_po_hist_begin;
	po_hist_recent := l_po_hist_recent;		
	po_hasrows := l_po_hasrows;
	po_hist_cnt := l_po_hist_cnt;
	po_hist_days := l_po_hist_days;
	po_hist_daily := l_po_hist_daily;	
	po_hist_item := l_po_hist_item;
	po_hist_key := l_po_hist_key;
  g_stuck_cnt := l_stuck_cnt;
  g_disabled_cnt := l_disabled_cnt;
  g_atgrup4 := l_atgrup4;
  g_last_ran := l_last_ran;
  g_stmt_log_cnt := l_stmt_log_cnt;
  g_alldefrd := l_alldefrd;
  g_mailer_enabled := l_mailer_enabled;
  g_prgall := l_prgall;
  g_prgany := l_prgany;
  g_prgcore := l_prgcore;
  g_wfitems := l_wfitems;
  g_stuckfreq := l_stuckfreq;
  g_lastwfcqcup := l_lastwfcqcup;
  g_wfcqcup_hrs := l_wfcqcup_hrs;
  g_concprgms_cnt := l_concprgms_cnt;
  g_WFNTFPRG_APPLIED := l_WFNTFPRG_APPLIED;
  g_UNREFNTF_CNT := l_UNREFNTF_CNT;
  g_omcnt := l_omcnt;
  g_olcnt := l_olcnt;
  g_chart_om_cnt := l_chart_om_cnt;
  g_hrcnt := l_hrcnt;
  g_chart_hr_cnt := l_chart_hr_cnt;
  g_po_cnt := l_po_cnt;
  g_chart_po_cnt := l_chart_po_cnt;
  g_incomplpo := l_incomplpo;
  g_orphline := l_orphline;
  g_orphhdr := l_orphhdr;
  g_logical_totals := l_logical_totals;
  g_physical_totals := l_physical_totals;
  g_diff_totals := l_diff_totals;
  g_rate := l_rate;

  g_rep_info('DB Version') := l_db_version;
  g_rep_info('JQP_Cnt') := l_jqp_cnt;
  g_ninety_cnt := l_ninety_cnt;debug('end Additional Code: Additional Validation');



  -- Create global hash for parameters. Numbers required for the output order

debug('begin populate parameters hash table');
   g_parameters(l_index||'. Maximum Rows to Display') := p_max_output_rows;
   l_index:=l_index+1;
   g_parameters(l_index||'. Debug Mode') := p_debug_mode;
   l_index:=l_index+1;
debug('end populate parameters hash table');



  l_key := g_parameters.first;
  -- Print parameters to the log
  print_log('Parameter Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_parameters(l_key));
    l_key := g_parameters.next(l_key);
  END LOOP;
  
  -- Create global hash of SQL token values

debug('begin populate sql tokens hash table');
debug('end populate sql tokens hash table');



  l_key := g_sql_tokens.first;
  -- Print token values to the log
 
  print_log('SQL Token Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;


EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN

   null;



debug('begin add_signature: WF2_NTF_ERRORS');
  add_signature(
      p_sig_id                 => 'WF2_NTF_ERRORS',
      p_sig_sql                => 'select n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN'') CLOSED,
	n.STATUS, n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference NTF_PREF,
	r.email_address, ''<div align="right">''||to_char(count(n.notification_id),''999,999,999,999'')||''</div>'' "Count"
	from wf_notifications n, wf_local_roles r
	where n.recipient_role = r.name
	and n.message_type like ''%ERROR%''
	group by n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN''), n.STATUS,
	n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference, r.email_address
	order by nvl(to_char(n.end_date, ''YYYY''),''OPEN''), count(n.notification_id) desc, n.recipient_role',
      p_title                  => 'Workflow Error Notifications by Type',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>There are '||to_char(g_ntferr_cnt,'999,999,999,999')||' Error Notifications of type (ECXERROR,OMERROR,POERROR,WFERROR) found on this '||g_rep_info('Instance')||' instance.</b>',
      p_solution               => 'Please review the above table to better understand the volume and status for these Error Notifications. <BR><BR>
  	 Also review : <br>
	 [1448095.1] - How to handle or reassign System : Error (WFERROR) Notifications that default to SYSADMIN.<br>
  	 [760386.1] - How to enable Bulk Notification Response Processing for Workflow in 11i and R12, for more details on ways to do this.',
	  p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_NTF_ERRORS');



debug('begin add_signature: WF4_WF_SCHED_CP1');
  add_signature(
      p_sig_id                 => 'WF4_WF_SCHED_CP1',
      p_sig_sql                => 'select r.REQUEST_ID "REQUEST_ID", u.user_name "REQUESTED_BY", r.PHASE_CODE "PHASE", r.ACTUAL_START_DATE "STARTED",
	 c.CONCURRENT_PROGRAM_NAME "INTERNAL NAME", p.USER_CONCURRENT_PROGRAM_NAME "PROGRAM_NAME", r.ARGUMENT_TEXT "ARGUMENTS", 
	 r.RESUBMIT_INTERVAL "EVERY", r.RESUBMIT_INTERVAL_UNIT_CODE "SO_OFTEN", r.RESUBMIT_END_DATE "RESUBMIT_END_DATE"
	 FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
	 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
	 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
	 and c.CONCURRENT_PROGRAM_NAME in (''FNDWFBG'',''FNDWFPR'',''FNDWFRET'',''JTFRSWSN'',''FNDWFSYNCUR'',''FNDWFLSC'', 
	 ''FNDWFLIC'',''FNDWFDSURV'',''FNDCPPUR'',''FNDWFBES_CONTROL_QUEUE_CLEANUP'',''FNDWFAASTATCC'',''FNDWFMLRSTATCC'',
	 ''FNDWFWITSTATCC'',''FNDWFBULKRESETNTFPREF'') 
	 AND p.language = ''US'' 
	 and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in (''P'',''R'')
	 order by c.CONCURRENT_PROGRAM_NAME, r.ARGUMENT_TEXT',
      p_title                  => 'Verify Workflow Concurrent Programs Scheduled to Run',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are No Workflow Background Processes (FNDWFBG) scheduled to run for ALL Item_Types.</B>',
      p_solution               => '<B>Please schedule the concurrent request "Workflow Background Process" to process deferred, timed-out, and identify stuck activities for ALL item_types using the guidelines listed above.</B><br>
	At a minimum, there needs to be at least one background process that can handle both deferred and timed-out activities in order to progress workflows.<BR><BR>
	For more information refer to [466535.1] - How to run the Workflow Background Engine per developments recommendations.<br><br>
    <b>The Workflow Administrators Guide requires that there is at least one background engine that can process deferred activities, check for  timed-out activities, and identify stuck processes.</b><br>
	At a minimum, there needs to be at least one background process that can handle both deferred and timed-out activities in order to progress workflows.<br>
	However, for performance reasons Oracle recommends running three (3) separate background engines at different intervals.<br>
	<ol><li><b>Run a Background Process to handle only DEFERRED activities every 5 to 60 minutes.</b></li>
		<li><b>Run a Background Process to handle only TIMED-OUT activities every 1 to 24 hours as needed.</b></li>
	- Timed-out and stuck activities are not processed from the queue but from the table directly, so Timed-out and stuck activities do not have a representing message in queue WF_DEFERRED_TABLE_M.<br>
	- For this reason they need to be queried up from the runtime tables and progressed as needed. When those records are found the internal Engine APIs are called to progress those workflows further.<br>
	- Timed-out activities are checked in table WF_ITEM_ACTIVITY_STATUSES when their status is ACTIVE, WAITING , NOTIFIED, SUSPEND, or DEFERRED.
	- This query on the table is strightforward and no performance issues are expected here.<br> 
	<li><b>Run a Background Process to identify STUCK Activities once a week to once a month, when the load on the system is low.</b></li>
	- Stuck activities do not have a clear pattern as cause but mainly they are caused by flaws in the WF definition like improper transition definitions.<br>
	- The query to determine activities that are STUCK is very expensive as it joins 3 WF runtime tables and one WF design table. <br>
	- This is why the Workflow Background Engine should run to identify STUCK Activities SEPARATELY and ONLY when load is not high and maybe once a week or so.<br>
	</ol>
	Please see [186361.1] - Workflow Background Process Performance Troubleshooting Guide for more information',
      p_success_msg            => '<B>Nice work !!<BR>
	 There is 1 Workflow Background Processes scheduled to run for deferred activities for ALL Item_Types!</b><BR><br>
	 Development recommends scheduling a Background Process to handle DEFERRED activities periodically every 5 to 60 minutes.<BR><br>
     Oracle Workflow requires several Concurrent Programs to be run to process, progress, cleanup, and purge workflow related information.<br>
	 This section verifies these required Workflow Concurrent Programs are scheduled as recommended.<br><br>
	 Note: This section is only looking at the scheduled jobs in FND_CONCURRENT_REQUESTS table, so jobs scheduled using other tools (DBMS_JOBS, CONSUB, or PL/SQL, etc) are not reflected here, so keep this in mind.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_WF_SCHED_CP1');



debug('begin add_signature: WF2_SYSADMIN1');
  add_signature(
      p_sig_id                 => 'WF2_SYSADMIN1',
      p_sig_sql                => 'select name, notification_preference, nvl(email_address,''NOTSET'') "EMAIL ADDRESS" from wf_local_roles where name = ''SYSADMIN''',
      p_title                  => 'SYSADMIN User Setup for Error Notifications',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>The SYSADMIN User e-mail is DISABLED!</b><br>',
      p_solution               => 'The SYSADMIN User is the default recipient for several types of notifications such as Workflow error notifications.<br>
	Currently there are '||to_char(g_errorntfcnt,'999,999,999,999')||' Error Notifications assigned to the SYSADMIN user.<BR><BR>
	Please specify how you want to receive these notifications by defining the notification preference and e-mail address for the SYSADMIN User.<BR>
	First correct the SYSADMIN User e-mail_address and change the notification_preference from DISABLED to a valid setting.<BR><BR>
	Please review System Administration Setup Tasks in the <a href="http://docs.oracle.com/cd/B25516_18/current/acrobat/115sacg.zip"
	target="_blank">Oracle Applications System Administrators Guide</a>, for information on how to change these settings.<BR>
	For additional solutions for distributing the workload of responding to SYSADMIN Error Notifications to other groups or individuals using WorkList Access or Notification Routing Rules, please review :<br>
	[1448095.1] - How to handle or reassign System : Error (WFERROR) Notifications that default to SYSADMIN.<br>',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );  debug('end add_signature: WF2_SYSADMIN1');



debug('begin add_signature: WF7_ONT_LOOPING1');
  l_info.delete;
  l_info('Comments') := 'The table output below is truncated to save space.<br>
						 Run this query to get the full list of Order Management Looping Activities.<br>';		
  add_signature(
      p_sig_id                 => 'WF7_ONT_LOOPING1',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", 
	''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key AND wfi.item_type in (''OEOH'',''OEOL'',''OMERROR'',''OEOI'',''OECOGS'', ''OEOA'',''OECHGORD'',''OEON'',''OEBH'') 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Order Management Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Order Management Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running Order Management Workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||ont_hist_item||'<br>
	 item_key : '||ont_hist_key||'<BR><BR> 
	 <B>This workflow process is still open, so this may be a problem. </B><BR>
	 It was started on '||ont_hist_begin||', and has most recently looped thru its process on '||ont_hist_recent||'. So far this one activity for item_type '||ont_hist_item||' and item_key '||ont_hist_key||' has looped '||to_char(ont_hist_cnt,'999,999,999,999')||' times since it started in '||ont_hist_begin||'.<BR><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(ont_hist_days,'999,999')||' days, which is about '||to_char(ont_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) for Order Management that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_ONT_LOOPING1');



debug('begin add_signature: WF2_WORKLIST_ACCESS');
  add_signature(
      p_sig_id                 => 'WF2_WORKLIST_ACCESS',
      p_sig_sql                => 'select parameter1, grantee_key, start_date, end_date, parameter2, instance_pk1_value
	 FROM fnd_grants
	 WHERE program_name = ''WORKFLOW_UI''
	 AND parameter1 = ''SYSADMIN''',
      p_title                  => 'SYSADMIN Worklist Access',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<b>There are no roles setup to access the WorkList of SYSADMIN user at this time</b>',
      p_solution               => '<b>The Oracle Workflow Advanced Worklist allows you to grant access to your worklist to another user.</b><br>
	 That user can then act as your proxy to handle the notifications in your list on your behalf. You can either grant a user access for a specific period or allow the users access to continue indefinitely. The Worklist Access feature lets you allow another user to handle your notifications without giving that user access to any other privileges or responsibilities that you have in Oracle Applications.<br><br>
	 To access other Worklists granted to you, simply click the Switch User button on the Advanced Worklist screen to display that users notifications instead of your own.<blockquote><img src="https://blogs.oracle.com/ebs/resource/Proactive/SwitchUserOld_web.gif"></blockquote>
	 When viewing another users Worklist, you can perform the following actions:<br>
	 <ul><li>View the details of the users notifications.</li>
	 <li>Respond to notifications that require a response.</li>
	 <li>Close notifications that do not require a response.</li>
	 <li>Reassign notifications to a different user.</li></ul>
For solutions on distributing the workload of responding to SYSADMIN Error Notifications to other groups or individuals using WorkList Access or Notification Routing Rules, please review :
[1448095.1] - How to handle or reassign System : Error (WFERROR) Notifications that default to SYSADMIN.',
      p_success_msg            => '<b>Excellent! SYSADMIN user has granted Worklist Access to another user(s).</b><br>
	 The users listed above can act as proxy to handle SYSADMIN notifications for which they have been granted access.<br><br>
	 It is possible to grant a user access for a specific period or allow the users access to continue indefinitely. The Worklist Access feature can allow another user to handle your notifications without giving that user access to any other privileges or responsibilities that you have in Oracle Applications.<br><br>
	 To access other Worklists granted to you, simply click the Switch User button on the Advanced Worklist to display the users notifications instead of your own.<blockquote><img src="https://blogs.oracle.com/ebs/resource/Proactive/SwitchUserOld_web.gif"></blockquote>
	 When viewing another users Worklist, you can perform the following actions:<br>
	 <ul><li>View the details of the users notifications.</li>
	 <li>Respond to notifications that require a response.</li>
	 <li>Close notifications that do not require a response.</li>
	 <li>Reassign notifications to a different user.</li></ul>
	 Above we verify who has been granted Worklist Access to the SYSADMIN Role in order to better manage and respond to the volume of error notifications sent to SYSADMIN.<br><br>
For solutions on distributing the workload of responding to SYSADMIN Error Notifications to other groups or individuals using WorkList Access or Notification Routing Rules, please review :
[1448095.1] - How to handle or reassign System : Error (WFERROR) Notifications that default to SYSADMIN.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_WORKLIST_ACCESS');



debug('begin add_signature: WF2_DISABLED1');
  add_signature(
      p_sig_id                 => 'WF2_DISABLED1',
      p_sig_sql                => 'select notification_preference, status, count(name)
	 from wf_local_roles
	 where name not like ''FND_RESP%''
	 and user_flag = ''Y''
	 group by notification_preference, status
	 order by status, notification_preference',
      p_title                  => 'Check for DISABLED Notification Preferences',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Notification Preferences set in this instance',
      p_solution               => '',
      p_success_msg            => '<B>Nice work!!<BR>
	 There are ZERO active Users with DISABLED notification preferences.</B>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_DISABLED1');



debug('begin add_signature: WF3_WF_AVG_6_MOS');
  add_signature(
      p_sig_id                 => 'WF3_WF_AVG_6_MOS',
      p_sig_sql                => 'select item_type "ITEM_TYPE", 
	''<div align="right">''||to_char(count(item_key),''999,999,999,999'')||''</div>'' "6_MONTHS", 
	''<div align="right">''||to_char(round(count(item_key)/6,0),''999,999,999,999'')||''</div>'' "MONTHLY", 
	''<div align="right">''||to_char(round(count(item_key)/180,0),''999,999,999,999'')||''</div>'' "DAILY"
	 from wf_items
	 where begin_date > sysdate-180
	 group by item_type
	 order by count(item_key) desc',
	  p_title                  => 'Average Volume of Opened Items in the past 6 Months, Monthly, and Daily',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<B>There are no new workflows started within the past 6 months on this instance.</B>',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','N'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_AVG_6_MOS');



debug('begin add_signature: WF1_ITEM_AGE1');
 add_signature(
      p_sig_id                 => 'WF1_ITEM_AGE1',
      p_sig_sql                => 'select ''WF_ITEMS table has a total of ''||count(item_key)||'' workflow items, the oldest item started ''||min(begin_date)||'', but still exists in the table.'' "WF_ITEMS" from wf_items',
      p_title                  => 'The overall Volume of Workflow Runtime Data is in need of Immediate Review!',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>The WF_ITEMS Table has obsolete workflow runtime data that is older than 3 years.</b><BR>
     This Gauge is merely a simple indicator about age and volume of Workflow runtime data on '||g_rep_info('Instance')||'.<br>
     It checks the oldest workflow on this instance, and displays GREEN if less than 1 year old, ORANGE if less than 3, and RED if older than 3 years.<br>
     Clean up your old Workflow Runtime Data and move the needle to green.   See below for more details.',
      p_solution               => '<ul>We reviewed all '||to_char(g_cnt_item,'999,999,999,999')||' rows in WF_ITEMS Table for Oracle Applications Release '|| g_rep_info('Apps Version')||' instance called '||g_rep_info('Instance')||' on '||g_rep_info('Host')||'<BR>
     Currently '||(round(g_item_open/g_cnt_item, 2)*100)||'% ('||to_char(g_item_open,'999,999,999,999')||') of WF_ITEMS 
	 are OPEN, while '||(round((g_cnt_item-g_item_open)/g_cnt_item, 2)*100)||'% ('||to_char((g_cnt_item-g_item_open),'999,999,999,999') ||') are CLOSED items but still exist in the runtime tables.</ul>',
      p_success_msg            => null,
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF1_ITEM_AGE1');



debug('begin add_signature: WF2_WFADMIN_ASTERISK');
  add_signature(
      p_sig_id                 => 'WF2_WFADMIN_ASTERISK',
      p_sig_sql                => 'select * from wf_resources res 
	where res.name = ''WF_ADMIN_ROLE''
	and res.language = ''US''',
      p_title                  => 'Workflow Administrator Role',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>The Workflow Administrator Role is set to Asterisk (*)!</b>',
      p_solution               => 'The Workflow Administrator role (WF_ADMIN_ROLE) for '||g_rep_info('Instance')||' is set to an Asterisk which allows EVERYONE access to Workflow Administrator Role permissions.<BR>
    This is not recommended for Production instances, but may be ok for Testing.  <BR>
    <b>Remember that the Workflow Administrator Role has permissions to full access of all workflows and notifications.</b><BR><BR>
    <B>Note:</B> For more information refer to <br>
	[453137.1]#asgnwfsysad - Oracle Workflow Best Practices Release 12 and Release 11i<br>
	[453137.1#asgnwfsysad] - Oracle Workflow Best Practices Release 12 and Release 11i<br>
	<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\\&sourceId=1369938.1\\&id=453137.1#asgnwfsysad" target="_blank">Doc ID 453137.1</a> - Oracle Workflow Best Practices Release 12 and Release 11i',
      p_success_msg            => '', 
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_WFADMIN_ASTERISK');



debug('begin add_signature: WF10_WF_REFERENCES');
  add_signature(
      p_sig_id                 => 'WF10_WF_REFERENCES',
      p_sig_sql                => 'select sysdate from dual',
      p_title                  => 'Workflow References',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Workflow References are not being displayed.',
      p_solution               => 'Check the SYSDATE setting on the instance.',
      p_success_msg            => '<h3>Additional Workflow References</h3>
[1425053.1] - How to run EBS Workflow Analyzer Tool as a Concurrent Request<br><br>
<a href="https://community.oracle.com/community/support/oracle_e-business_suite/core_workflow" target="_blank">My Oracle Support - Core Workflow Community]<br>
[1160285.1] - Application Technology Group (ATG) Product Information Center (PIC)<br>
[1320509.1] - E-Business Workflow Information Center (PIC)<br><br>

[1638535.1] - Oracle 12.1.3+ E-Business Suite Recommended Patch Collection 1 [RPC1]<br>
[186361.1] - Workflow Background Process Performance Troubleshooting Guide<br>
[453137.1] - Oracle Workflow Best Practices Release 12 and Release 11i<br>
[225165.1] - Patching Best Practices and Reducing Downtime<br>
[957426.1] - Health Check Alert: Invalid objects exist for one or more of your EBS applications<br>
[104457.1] - Invalid Objects In Oracle Applications FAQs<br>
[1191125.1] - Troubleshooting Oracle Workflow Java Notification Mailer<br>
[748421.1] - Java Mailer Setup Diagnostic Test (ATGSuppJavaMailerSetup12.sh)<br>
[831982.1] - A guide For Troubleshooting Workflow Notification Emails - Inbound and Outbound<br>
[1448095.1] - How to handle or reassign System : Error (WFERROR) Notifications that default to SYSADMIN<br>
[562551.1] - Workflow Java Mailer FAQ<br>
[760386.1] - How to enable Bulk Notification Response Processing for Workflow in 11i and R12<br>
[559996.1] - What Tables Does the Workflow Purge Obsolete Data Program (FNDWFPR) Touch?<br>
[277124.1] - FAQ on Purging Oracle Workflow Data<br>
[132254.1] - Speeding Up And Purging Workflow<br>
[1587923.1] - How to Close and Purge excessive WFERROR workflows and DEFAULT_EVENT_ERROR notifications from Workflow.<br>
[144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data<br>
[1378954.1] - bde_wf_process_tree.sql - For analyzing the Root Parent, Children, Grandchildren Associations of a Single Workflow Process<br>
[375095.1] - How to Purge XDPWFSTD Messages<br>
[311552.1] - How to Optimize the Purge Process in a High Transaction Applications Environment<br>
[878032.1] - How To Use Concurrent Program :Purge Order Management Workflow<br>
[388672.1] - How to Reorganize Workflow Tables<br>
[733335.1] - How to Start Workflow Components<br>
[255045.1] - bde_wf_err.sql - Profile of Workflow Activities in Error<br>
[751026.1] - Purge Obsolete Workflow Runtime Data - OEOH / OEOL Performance issues<br>
[398822.1] - Order Management Suite - Some Data Fix Patches and Scripts<br>
[397548.1] - Patch 5885900 Data Fix Closes Eligible Order Headers and Purge Associated OMERROR and WFERROR and Orphan Line Workflows<br>
[1358724.1] - Information About Order Management Purge Programs<br>
[113492.1] - Oracle Order Management Suite White Papers<br>
[947141.1] - How to Mass Retry Errored Workflows<br>
[458216.1] - How To Retry Multiple Errored Approval Workflow Processes After A Fix Or Patch Has Been Implemented<br>
[1545562.1] - Get Proactive with Oracle E-Business Suite - Product Support Analyzer Script Index<br>
',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('N','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: WF10_WF_REFERENCES');



debug('begin add_signature: WF6_WF_LOG_LEVELS');
  add_signature(
      p_sig_id                 => 'WF6_WF_LOG_LEVELS',
      p_sig_sql                => 'select SC.COMPONENT_NAME "COMPONENT NAME", sc.COMPONENT_TYPE "COMPONENT TYPE",
	 v.PARAMETER_DISPLAY_NAME "PARAMETER",
	 decode(v.PARAMETER_VALUE,
	 ''1'', ''1 = Statement'',
	 ''2'', ''2 = Procedure'',
	 ''3'', ''3 = Event'',
	 ''4'', ''4 = Exception'',
	 ''5'', ''5 = Error'',
	 ''6'', ''6 = Unexpected'',
	 ''N'', ''N = Not Enabled'',
	 ''Y'', ''Y = Enabled'') "VALUE"
	 FROM FND_SVC_COMP_PARAM_VALS_V v, FND_SVC_COMPONENTS SC
	 WHERE v.COMPONENT_ID=sc.COMPONENT_ID 
	 AND v.parameter_name in (''COMPONENT_LOG_LEVEL'',''DEBUG_MAIL_SESSION'')
	 ORDER BY sc.COMPONENT_TYPE, SC.COMPONENT_NAME, v.PARAMETER_VALUE',
      p_title                  => 'Check The Status of Workflow Log Levels and Mailer Debug Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'One or more of the Workflow Logs are set to STATEMENT level logging (1), which records the most amount of data!<br>
	 This can cause excessive logging if left un-checked.',
      p_solution               => 'Unless, actively troubleshooting a problem, consider changing these to a higher log level number, which actually records less data.
	<ul><li>1 for Statement - Most detail and robust logging level</li>
	    <li>2 for Procedure</li>
	    <li>3 for Event</li>
	    <li>4 for Exception</li>
	    <li>5 for Error</li>
		<li>6 for Unexpected - Least detail logging level</li>
	</ul>If troubleshooting Workflow Agent Listeners or Java Mailer issues, set individual Component Logging Levels to Statement Level logging (Log Level = 1) for the most detail and robust logging level.<br>
	Use $FND_TOP/sql/afsvcpup.sql - AF SVC Parameter UPdate script to change the logging levels.<br><br>
	Remember to reset, or lower the logging level after troubleshooting to not generate excessive log files. The Mailer Debug parameter (Debug Mail Session) should be ENABLED when troubleshooting issues with any Workflow Notification Mailer.',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF6_WF_LOG_LEVELS');



debug('begin add_signature: WF2_STUCK1');
  add_signature(
      p_sig_id                 => 'WF2_STUCK1',
      p_sig_sql                => 'select P.Process_Item_Type, P.Activity_Name, S.Activity_Status, S.Activity_Result_Code, 
	 Nvl(To_Char(Wi.End_Date,''YYYY''),''OPEN'') Wf_Status, To_Char(S.Begin_Date, ''YYYY'') Began, ''<div align="right">''||to_char(count(S.Item_Key),''999,999,999,999'')||''</div>'' "Count"
	 FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
	 WHERE P.Instance_Id = S.Process_Activity
	 AND Wi.Item_Type = S.Item_Type
	 AND wi.item_key = s.item_key
	 AND activity_status = ''ERROR''
	 AND activity_result_code = ''#STUCK''
	 AND S.End_Date Is Null
	 GROUP BY P.Process_Item_Type, P.Activity_Name, S.Activity_Status, S.Activity_Result_Code, 
	 to_char(wi.end_date,''YYYY''), To_Char(S.Begin_Date, ''YYYY'')
	 ORDER BY to_char(wi.end_date,''YYYY'') desc, To_Char(S.Begin_Date, ''YYYY'')',
      p_title                  => 'Workflow #STUCK Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>These Workflows are identified as STUCK Activities and CAN NOT progress on their own.</b>',
      p_solution               => 'These stuck activities need to be investigated, and either corrected in order to continue, or aborted and closed, so the workflow can be purged.<br><br>
	A process is identified as stuck when it has a status of ACTIVE, but cannot progress any further.<br>
	 Stuck activities do not have a clear pattern as cause but mainly they are caused by flaws in the WF definition like improper transition definitions. For example, a process could become stuck in the following situations:
	 <ul><li>A thread within a process leads to an activity that is not defined as an End activity but has no other activity modeled after it, and no other activity is active.</li>
	 <li>A process with only one thread loops back, but the pivot activity of the loop has the On Revisit property set to Ignore.</li>
	 <li>An activity returns a result for which no eligible transition exists. </li></ul>
	 For instance, if the function for a function activity returns an unexpected result value, and no default transition is modeled after that activity, the process cannot continue.<br><br>
	 <b>COMMON MISCONCEPTION for STUCK Activities - Running the Worklfow Background Process for STUCK activities fixes STUCK workflows.</b><br>
	 Not true.<br>
	 Running the concurrent request "Workflow Background Process" with Stuck=Yes only identifies these activities that cannot progress. The workflow engine changes the status of a stuck process to ERROR:#STUCK and executes the error process defined for it. This error process sends a notification to SYSADMIN to alert them of this issue, which they need to resolve. The query to determine these activities is very expensive as it joins 3 WF runtime tables and one WF design table. This is why the Workflow Background Engine should run separately when load is not high and only once a week or month.<br><br>
	 For more information on how to progress these Stuck Activities, refer to [453137.1] - Oracle Workflow Best Practices Release 12 and Release 11i',
      p_success_msg            => '<b>Nice work!!</b><br>
	 There are ZERO #STUCK Activities found.<br><br>
	 A process is identified as stuck when it has a status of ACTIVE, but cannot progress any further.<br>
	 Stuck activities do not have a clear pattern as cause but mainly they are caused by flaws in the WF definition like improper transition definitions. For example, a process could become stuck in the following situations:
	 <ul><li>A thread within a process leads to an activity that is not defined as an End activity but has no other activity modeled after it, and no other activity is active.</li>
	 <li>A process with only one thread loops back, but the pivot activity of the loop has the On Revisit property set to Ignore.</li>
	 <li>An activity returns a result for which no eligible transition exists. </li></ul>
	 For instance, if the function for a function activity returns an unexpected result value, and no default transition is modeled after that activity, the process cannot continue.<br><br>
	 For more information refer to [453137.1] - Oracle Workflow Best Practices Release 12 and Release 11i',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_STUCK1');



debug('begin add_signature: WF3_WF_RUNTIME_VOL1');
  add_signature(
      p_sig_id                 => 'WF3_WF_RUNTIME_VOL1',
      p_sig_sql                => 'select
	table_name "Workflow Table Name", 
	''<div align="right">''||to_char(round(blocks*8192/1024/1024),''999,999,999,999'')||''</div>'' "Logical Table Size",
	''<div align="right">''||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),''999,999,999,999'')||''</div>'' "Physical Table Data", 
	''<div align="right">''||to_char(round((blocks*8192/1024/1024)-(num_rows*AVG_ROW_LEN)/1024/1024),''999,999,999,999'')||''</div>'' "Difference"
	from dba_tables
	where table_name in (''WF_ITEMS'', ''WF_ITEM_ACTIVITY_STATUSES'', ''WF_ITEM_ACTIVITY_STATUSES_H'', 
	''WF_ITEM_ATTRIBUTE_VALUES'', ''WF_NOTIFICATIONS'', ''WF_NOTIFICATION_ATTRIBUTES'', ''WF_COMMENTS'', ''WF_DIG_SIGS'')
	and owner=''APPLSYS''
	union select 
	''<div align="right">TOTALS</div>'' "Workflow Table Name", 
	''<div align="right">'||to_char(g_logical_totals,'999,999,999,999')||'</div>'' "Logical Table Size",
	''<div align="right">'||to_char(g_physical_totals,'999,999,999,999')||'</div>'' "Physical Table Data", 
	''<div align="right">'||to_char(g_diff_totals,'999,999,999,999')||'</div>'' "Difference" from dual
	order by 1 desc',
      p_title                  => 'Volume of Workflow Runtime Data Tables (in MegaBytes)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'The Workflow Runtime Tables logical space which is used for all full-table scans is ' || g_rate || '% greater than the physical or actual tablespace being used.',
      p_solution               => 'It is recommended to have a DBA resize these tables to reset the HighWater Mark.<BR>
     There are several ways to coalesce, drop, recreate these workflow runtime tables.<BR><BR>
	 Please review [388672.1] - How to Reorganize Workflow Tables, for more details on ways to do this.',
      p_success_msg            => 'There was a problem identifying any Workflow Runtime Data running in this instance',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_RUNTIME_VOL1');



debug('begin add_signature: WF2_WF_ERROR_NTFS');
  add_signature(
      p_sig_id                 => 'WF2_WF_ERROR_NTFS',
      p_sig_sql                => 'select n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN'') CLOSED,
	n.STATUS, n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference NTF_PREF,
	r.email_address, ''<div align="right">''||to_char(count(n.notification_id),''999,999,999,999'')||''</div>'' "Count"
	from wf_notifications n, wf_local_roles r
	where n.recipient_role = r.name
	and n.message_type like ''%ERROR%''
	group by n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN''), n.STATUS,
	n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference, r.email_address
	order by nvl(to_char(n.end_date, ''YYYY''),''OPEN''), count(n.notification_id) desc, n.recipient_role',
      p_title                  => 'Workflow Error Notification Messages Summary Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>There are '||to_char(g_total_error,'999,999,999,999')||' Error Notifications,
	where '||to_char(g_open_error,'999,999,999,999')||' ('||(round(g_open_error/g_total_error,2)*100)||'%) are still OPEN,
	and '|| to_char(g_closed_error,'999,999,999,999') || ' are closed.</b><BR><BR>
	Additionally, ALL '|| to_char(g_dee_open_cnt,'999,999,999,999') || ' of the system generated Workflow Error Notifications (DEFAULT_EVENT_%_ERROR) that are assigned to SYSADMIN and remain OPEN were generated over 30 days ago and therefore are likely candidates to be closed and purged.<br>
	These system generated WFERROR messages do not belong to a parent workflow process and account for ('|| (round(g_dee_open_cnt/g_ntferr_cnt,2)*100) || '%) of the all Error notifications
	 of which '||to_char(g_open_error,'999,999,999,999')||'('||(round(g_open_error/g_total_error,2)*100)||'%) are still OPEN,
	 and '|| to_char(g_dee_clsd_cnt,'999,999,999,999') || ' (' || (round(g_closed_error/g_total_error,2)*100) || '%)  are closed.',
      p_solution               => 'Since these errors have not occured recently, it is recommended to remove these space consuming system generated Error notifications.<br>
	Follow the note below for steps to clean up SYSADMIN queue and easily remove these system generated error notifications.<br><br> 
	<B>Note:</B> For more information refer to [1587923.1] - How to Close and Purge excessive WFERROR workflows and DEFAULT_EVENT_ERROR notifications from Workflow.<br>',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_WF_ERROR_NTFS');



debug('begin add_signature: WF8_HCM_LOOPING1');
  l_info.delete;
  l_info('Comments') := 'The table output below is truncated to save space.<br>
						 Run this query to get the full list of Human Resources Looping Activities.<br>';		
  add_signature(
      p_sig_id                 => 'WF8_HCM_LOOPING1',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", 
	''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key 
	 AND wfi.item_type in (''BENCWBFY'',''SSBEN'',''GHR_SF52'',''HXCEMP'',''HXCSAW'',''IRC_NTF'', ''IRCOFFER'',''OTWF'',''PYASGWF'',''HRCKLTSK'',''HRSSA'',''HRWPM'',''HRRIRPRC'',''PSPERAVL'') 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Human Resources Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Human Resources Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running Human Resources Workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||hcm_hist_item||'<br>
	 item_key : '||hcm_hist_key||'<BR><BR> 
	 <B>This workflow process is still open, so this may be a problem. </B><BR>
	 It was started on '||hcm_hist_begin||', and has most recently looped thru its process on '||hcm_hist_recent||'. So far this one activity for item_type '||hcm_hist_item||' and item_key '||hcm_hist_key||' has looped '||to_char(hcm_hist_cnt,'999,999,999,999')||' times since it started in '||hcm_hist_begin||'.<BR><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(hcm_hist_days,'999,999')||' days, which is about '||to_char(hcm_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) for Human Resources that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF8_HCM_LOOPING1');



debug('begin add_signature: WF9_PO_LOOPING1');
  l_info.delete;
  l_info('Comments') := 'The table output below is truncated to save space.<br>
						 Run this query to get the full list of Human Resources Looping Activities.<br>';		
  add_signature(
      p_sig_id                 => 'WF9_PO_LOOPING1',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", 
	''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key 
	 AND wfi.item_type in (''POAPPRV'',''REQAPPRV'',''POXML'',''POWFRQAG'',''PORCPT'',''APVRMDER'',''PONPBLSH'',''POSPOACK'',''PONAUCT'',''PORPOCHA'',''PODSNOTF'',''POSREGV2'',''POREQCHA'',''POWFPOAG'',''POSCHORD'',''POSASNNB'',''PONAPPRV'',''POSCHPDT'',''POAUTH'',''POWFDS'',''POERROR'',''POSBPR'',''CREATEPO'') 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Purchasing Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Purchasing Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running Purchasing Workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||po_hist_item||'<br>
	 item_key : '||po_hist_key||'<BR><BR> 
	 <B>This workflow process is still open, so this may be a problem. </B><BR>
	 It was started on '||po_hist_begin||', and has most recently looped thru its process on '||po_hist_recent||'. So far this one activity for item_type '||po_hist_item||' and item_key '||po_hist_key||' has looped '||to_char(po_hist_cnt,'999,999,999,999')||' times since it started in '||po_hist_begin||'.<BR><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(po_hist_days,'999,999')||' days, which is about '||to_char(po_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) for Purchasing  that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_PO_LOOPING1');



debug('begin add_signature: WF9_SUMMARY_PO_WF');
  add_signature(
      p_sig_id                 => 'WF9_SUMMARY_PO_WF',
      p_sig_sql                => 'select wi.item_type "Item Type", wit.display_name "Display Name", wi.PARENT_ITEM_TYPE "Parent Item Type", nvl(to_char(wi.end_date, ''YYYY''),''OPEN'') "Closed", 
	''<div align="right">''||to_char(count(wi.item_key),''999,999,999,999'')||''</div>'' "COUNT"
	from wf_items wi, wf_item_types_tl wit
	where wi.item_type = wit.name 
	and wit.language = ''US''
	and (wi.item_type in (''POAPPRV'',''REQAPPRV'',''POXML'',''POWFRQAG'',''PORCPT'',''APVRMDER'',''PONPBLSH'',''POSPOACK'',''PONAUCT'',''PORPOCHA'',''PODSNOTF'',''POSREGV2'',''POREQCHA'',''POWFPOAG'',''POSCHORD'',''POSASNNB'',''PONAPPRV'',''POSCHPDT'',''POAUTH'',''POWFDS'',''POERROR'',''POSBPR'',''CREATEPO'')  or (wi.item_type like ''%ERROR%'' and wi.parent_item_type in (''POAPPRV'',''REQAPPRV'',''POXML'',''POWFRQAG'',''PORCPT'',''APVRMDER'',''PONPBLSH'',''POSPOACK'',''PONAUCT'',''PORPOCHA'',''PODSNOTF'',''POSREGV2'',''POREQCHA'',''POWFPOAG'',''POSCHORD'',''POSASNNB'',''PONAPPRV'',''POSCHPDT'',''POAUTH'',''POWFDS'',''POERROR'',''POSBPR'',''CREATEPO'')))
	group by wi.item_type, wit.display_name, wi.parent_item_type, to_char(wi.end_date, ''YYYY'')
	order by to_char(wi.end_date, ''YYYY'')',
      p_title                  => 'SUMMARY of All PO Workflow Processes By Item Type & Parent',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'SUMMARY of All PO Workflow Processes By Item Type & Parent<BR>',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_SUMMARY_PO_WF');



debug('begin add_signature: WF5_WF_ORPHAN_STATUS1');
  add_signature(
      p_sig_id                 => 'WF5_WF_ORPHAN_STATUS1',
      p_sig_sql                => 'select WN.MESSAGE_TYPE, wn.MESSAGE_NAME, wit.persistence_type PERSISTENCE, to_char(count(wn.notification_id),''999,999,999,999'') "COUNT"
	from WF_NOTIFICATIONS WN, WF_ITEM_TYPES WIT
	where wn.message_type = wit.name 
	and not exists (select NULL from WF_ITEM_ACTIVITY_STATUSES WIAS
	where WIAS.NOTIFICATION_ID = WN.GROUP_ID)
	and not exists (select NULL from WF_ITEM_ACTIVITY_STATUSES_H WIAS
	where WIAS.NOTIFICATION_ID = WN.GROUP_ID)
	and wn.end_date is null
	group by wn.message_type, wn.MESSAGE_NAME, wit.persistence_type
	order by wit.persistence_type, count(notification_id) desc',
      p_title                  => 'Check for Open Orphaned Notifications',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Open Orphaned or Unreferenced Notifications found!<BR><BR>',
      p_solution               => 'Please run $FND_TOP/sql/wfntfprg.sql to remove unreferenced notifications by following the instructions on the script header.<br> 
	For purging FNDCMMSG, XDPWFSTD, etc (which are PERMANENT) type of notifications, please uncomment the line 
	( Wf_Purge.Persistence_Type := "PERM" ) in the wfntfprg.sql as this type of message is of type PERMANENT persistence.<br>
	This should do the trick.<BR>',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF5_WF_ORPHAN_STATUS1');



debug('begin add_signature: WF1_AQ_TM_PROC1');
  add_signature(
      p_sig_id                 => 'WF1_AQ_TM_PROC1',
      p_sig_sql                => 'select 1 from v$parameter where name = ''aq_tm_processes'' and value = ''0''
	and (ismodified <> ''FALSE'' OR isdefault=''FALSE'')',
      p_title                  => 'Workflow Queue Monitor (AQ_TM_PROCESSES) Setting',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>The parameter AQ_TM_PROCESSES '||g_rep_info('Instance')||' is explicitly set to Zero (0)!<br>
	This means the time monitor process (QMN) is disabled!!!, and no workflows will be progressed.</b>
	This can also disrupt the operation of the database due to several system queue tables used when the standard database features are used.!<br>
	If it is set to zero, it is recommended to unset the parameter. However, this requires bouncing the database. 
	In the meantime, if the database cannot be immediately bounced, the recommended value to set it to is "1", and this can be done dynamically:
	<ul><i>conn / as sysdba<br>
	alter system set aq_tm_processes = 1;</i></ul><br>',
      p_solution               => 'Follow the comments below, and refer to [746313.1] - What should be the Correct Setting for Parameter AQ_TM_PROCESSES in E-Business Suite Instance?<br>',
      p_success_msg            => 'The parameter AQ_TM_PROCESSES is not explicitly set to Zero (0), which is fine.<br><br>
    <p><B>Note: AQ_TM_PROCESSES for pre-11gR2 ('||g_rep_info('DB Version')||') databases:</B><BR><BR>
    The Oracle Streams AQ time manager process is called the Queue MONitor (QMON), a background process controlled by parameter AQ_TM_PROCESSES.<BR>
    QMON processes are associated with the mechanisms for message expiration, retry, delay, maintaining queue statistics, removing PROCESSED messages 
    from a queue table and updating the dequeue IOT as necessary.  QMON plays a part in both permanent and buffered message processing.<BR>
    If a qmon process should fail, this should not cause the instance to fail. This is also the case with job queue processes.<BR>
    QMON itself operates on queues but does not use a database queue for its own processing of tasks and time based operations, so it can 
    be envisaged as a number of discrete tasks which are run by Queue Monitor processes or servers.

    The AQ_TM_PROCESSES parameter is set in the (init.ora) database parameter file, and by default is set to 1.<br>
    This value allows Advanced Queuing to start 1 AQ background process for Queue Monitoring, which is 
    usually sufficient for simple E-Business Suite instances.  <BR><B>However, this setting can be increased (dynamically) to improve queue maintenance performance.</B></p>
    
    <B>Oracle highly recommends manually setting the aq_tm_processes parameter to a reasonable value (no greater than 5) which will leave some qmon slave processes to deal with buffered message operations.</B><BR><BR>
      
    If this parameter is set to a non-zero value X, Oracle creates that number of QMNX processes starting from ora_qmn0_SID (where SID is the identifier of the database) 
    up to ora_qmnX_SID ; if the parameter is not specified or is set to 0, then the QMON processes are not created. 
    There can be a maximum of 10 QMON processes running on a single instance. <BR>For example the parameter can be set in the init.ora as follows :
    <ul><i>aq_tm_processes=5</i></ul>
    or set dynamically via
    <ul><i>connect / as sysdba<br>alter system set aq_tm_processes=5;</i></ul>Remember that after bouncing the DB, dynamic changes are lost, and the DB parameter file settings are used.<BR>
    
    It is recommended to NOT DISABLE the Queue Monitor processes by setting aq_tm_processes=0 on a permanent basis. As can be seen above, 
    disabling will stop all related processing in relation to tasks outlined. This will likely have a significant affect on operation of queues - PROCESSED 
    messages will not be removed and any time related, TM actions will not succeed, AQ objects will grow in size.<BR><BR>
    To update the AQ_TM_PROCESSES database parameter, follow the steps outlined in <BR>
    [305662.1] - Master Note for AQ Queue Monitor Process (QMON).<br></p>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF1_AQ_TM_PROC1');



debug('begin add_signature: WF1_DB_PARAMS1');
  add_signature(
      p_sig_id                 => 'WF1_DB_PARAMS1',
      p_sig_sql                => 'select name, value
    from v$parameter
    where upper(name) in (''AQ_TM_PROCESSES'',''JOB_QUEUE_PROCESSES'',''JOB_QUEUE_INTERVAL'',
    ''UTL_FILE_DIR'',''NLS_LANGUAGE'', ''NLS_TERRITORY'', ''CPU_COUNT'',
    ''PARALLEL_THREADS_PER_CPU'')',
      p_title                  => 'Workflow Database Parameter Settings',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>JOB_QUEUE_PROCESSES for '||g_rep_info('Instance')||' on pre-11gR1 ('||g_rep_info('DB Version')||') databases is set to ZERO!</B><BR>
    Oracle Workflow requires job queue processes to handle propagation of Business Event System event messages by AQs.',
      p_solution               => 'The recommended minimum number of JOB_QUEUE_PROCESSES for Oracle Workflow is 10.<br>
    The maximum number of JOB_QUEUE_PROCESSES is :<BR> -    36 in Oracle8i<BR> - 1,000 in Oracle9i Database and higher, so set the value of JOB_QUEUE_PROCESSES accordingly.<BR>
    The ideal setting for JOB_QUEUE_PROCESSES should be set to the maximum number of jobs that would ever be run concurrently on a system PLUS a few more.<BR><BR>
    To determine the proper amount of JOB_QUEUE_PROCESSES for Oracle Workflow, follow the queries outlined in<BR> 
    [578831.1] - How to determine the correct setting for JOB_QUEUE_PROCESSES.<br></p>',
      p_success_msg            => 'There is a problem identifying the Workflow Database Parameter Settings',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF1_DB_PARAMS1');



debug('begin add_signature: WF2_SYSADMIN2');
  add_signature(
      p_sig_id                 => 'WF2_SYSADMIN2',
      p_sig_sql                => 'select name, notification_preference, nvl(email_address,''NOTSET'') "EMAIL ADDRESS" from wf_local_roles where name = ''SYSADMIN''',
      p_title                  => 'SYSADMIN User Setup for Error Notifications',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>The SYSADMIN User is setup to NOT RECEIVE email notifications, which is fine.</b><br>',
      p_solution               => 'However, this means SYSADMIN can only access notifications through the Oracle Workflow Worklist Web page. <br>
    Please verify that the SYSADMIN User is actively processing the '||to_char(g_errorntfcnt,'999,999,999,999')||' Error Notifications that are currently assigned to this user. <br><br>
    Please review System Administration Setup Tasks in the <a href="http://docs.oracle.com/cd/B25516_18/current/acrobat/115sacg.zip"
    target="_blank">Oracle Applications System Administrators Guide</a>, for information on how to change these settings if needed.<BR>
    For additional solutions for distributing the workload of responding to SYSADMIN Error Notifications to other groups or individuals using WorkList Access or Notification Routing Rules, please review :<br>
    [1448095.1] - How to handle or reassign System : Error (WFERROR) Notifications that default to SYSADMIN.<br>',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );	
debug('end add_signature: WF2_SYSADMIN2');



debug('begin add_signature: WF2_NTF_ERROR_0');
  add_signature(
      p_sig_id                 => 'WF2_NTF_ERROR_0',
      p_sig_sql                => 'select n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN'') CLOSED,
	n.STATUS, n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference NTF_PREF,
	r.email_address, to
	_char(count(n.notification_id),''999,999,999,999'') COUNT
	from wf_notifications n, wf_local_roles r
	where n.recipient_role = r.name
	and n.message_type like ''%ERROR%''
	group by n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN''), n.STATUS,
	n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference, r.email_address
	order by nvl(to_char(n.end_date, ''YYYY''),''OPEN''), count(n.notification_id) desc, n.recipient_role',
      p_title                  => 'Workflow Error Notifications Summary Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are rows found',
      p_solution               => '',
      p_success_msg            => '<B>Well Done !!<BR><BR>
     There are no Notification Error Messages for this '||g_rep_info('Instance')||' instance.</B><BR>
     You deserve a whole cake!!!<BR>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      ); debug('end add_signature: WF2_NTF_ERROR_0');



debug('begin add_signature: WF2_WORKLIST_ACCESS2');
  add_signature(
      p_sig_id                 => 'WF2_WORKLIST_ACCESS2',
      p_sig_sql                => 'select parameter1, grantee_key, start_date, end_date, parameter2, instance_pk1_value
	 FROM fnd_grants
	 WHERE program_name = ''WORKFLOW_UI''
	 AND parameter1 = ''SYSADMIN''',
      p_title                  => 'SYSADMIN Worklist Access',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<b>There are no roles setup to access the WorkList of SYSADMIN user at this time</b>',
      p_solution               => '<b>It is now required to use a Proxy User to grant Worklist Access to another user.</b><br>
	 The user you select can then act as your proxy to handle the notifications in your list on your behalf. You can either grant a user access for a specific period or allow the user access to continue indefinitely. The Worklist Access feature lets you allow another user to handle your notifications without giving that user access to any other privileges or responsibilities that you have in Oracle Applications.<br><br>
	 To access other Worklists granted to you, simply click the Switch User button at the top right of the the Main Page to display the users notifications instead of your own.<blockquote><img src="https://blogs.oracle.com/ebs/resource/Proactive/SwitchUser_web.gif"></blockquote>
	 When viewing another users Worklist, you can perform the following actions:
	 <ul><li>View the details of the users notifications.</li>
	 <li>Respond to notifications that require a response.</li>
	 <li>Close notifications that do not require a response.</li>
	 <li>Reassign notifications to a different user.</li></ul><br><br>
	 For more details See : How To Add People (Grant Access) Through Preference--> Manage Proxies Setup [1378402.1].<br>
For solutions on distributing the workload of responding to SYSADMIN Error Notifications to other groups or individuals using WorkList Access or Notification Routing Rules, please review :
[1448095.1] - How to handle or reassign System : Error (WFERROR) Notifications that default to SYSADMIN.',
      p_success_msg            => '<b>Excellent! SYSADMIN user has granted Worklist Access to another user(s).</b><br>
	  Starting with R12.2.4 (or NtfUtil.class updated to v120.47.12020000.12 or higher), the ability to grant Oracle Workflow Worklist Access to another user is now part of the overall Proxy User Access Control feature for Oracle E-Business Suite that is provided through Oracle User Management. Use Oracle User Management to set up Proxy User access, including Worklist Access.<br>
	  
	 The user selected can then act as your proxy to handle the notifications in your list on your behalf. You can either grant a user access for a specific period or allow the user access to continue indefinitely. The Worklist Access feature lets you allow another user to handle your notifications without giving that user access to any other privileges or responsibilities that you have in Oracle Applications.<br><br>
	 To access other Worklists granted to you, simply click the Switch User button at the top right of the the Main Page to display the Users notifications instead of your own.<blockquote><img src="https://blogs.oracle.com/ebs/resource/Proactive/SwitchUser_web.gif"></blockquote>
	 When viewing another users Worklist, you can perform the following actions:
	 <ul><li>View the details of the users notifications.</li>
	 <li>Respond to notifications that require a response.</li>
	 <li>Close notifications that do not require a response.</li>
	 <li>Reassign notifications to a different user.</li></ul>
	 Above we verify who has been granted Worklist Access to the SYSADMIN Role in order to better manage and respond to the volume of error notifications sent to SYSADMIN.<br><br>
	 For more details See : How To Add People (Grant Access) Through Preference--> Manage Proxies Setup [1378402.1].<br>
For solutions on distributing the workload of responding to SYSADMIN Error Notifications to other groups or individuals using WorkList Access or Notification Routing Rules, please review :
[1448095.1] - How to handle or reassign System : Error (WFERROR) Notifications that default to SYSADMIN.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_WORKLIST_ACCESS2');



debug('begin add_signature: WF2_DISABLED2');
  add_signature(
      p_sig_id                 => 'WF2_DISABLED2',
      p_sig_sql                => 'select notification_preference, status, count(name)
	 from wf_local_roles
	 where name not like ''FND_RESP%''
	 and user_flag = ''Y''
	 group by notification_preference, status
	 order by status, notification_preference',
      p_title                  => 'Check for DISABLED Notification Preferences',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Notification Preferences set in this instance',
      p_solution               => '',
      p_success_msg            => '<B>There are a large number of active Users with DISABLED notification preferences!</B><br>
	 <br>It is recommended that these are looked into....<br>
	 Please verify the email addresses for the '||to_char((g_disabled_cnt),'999,999,999,999')||' active Users that have DISABLED notification preference using : 
	    <blockquote><i>select name, display_name, description, status, <br>
	    orig_system, email_address, notification_preference<br>
	    from wf_local_roles<br>
	    where notification_preference = ''DISABLED''<br>
		and status = ''ACTIVE''<br>
	    and user_flag = ''Y'';</i></blockquote><BR>
	 Please review [1326359.1] - Workflow Notification Email Preference is Disabled: How to Troubleshoot and Repair',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_DISABLED2');



debug('begin add_signature: WF2_WFADMIN_RESP');
  add_signature(
      p_sig_id                 => 'WF2_WFADMIN_RESP',
      p_sig_sql                => 'select r.name,r.display_name,r.orig_system,r.status
	from WF_USER_ROLE_ASSIGNMENTS_V wura, wf_roles r, fnd_user f
	where r.name = f.user_name
	and wura.user_name = r.name
	and wura.role_name = (select wf_core.translate(''WF_ADMIN_ROLE'') from dual)
	and ((wura.start_date < sysdate) and ((wura.end_date is null) or (wura.end_date > sysdate)))
	and ((f.start_date < sysdate) and ((f.end_date is null) or (f.end_date > sysdate)))
	order by r.name',
      p_title                  => 'Workflow Administrator Role',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There is a problem displaying the roles for Workflow Administrator Role permissions',
      p_solution               => '',
      p_success_msg            => '<b>Workflow Administrator Role is set to Responsibility "'||g_wfadmin_display||'"</b><br>
	 The Workflow Administrator role (WF_ADMIN_ROLE) for '||g_rep_info('Instance')||' is set to Responsibility ('||g_wfadmin_role||') also 
	 known as '||g_wfadmin_display||'.<BR>
	 There are mutiple active Users assigned to this Responsibility, all having Workflow Administrator Role permissions on this instance.<BR><br>
	 <b><font color="#FF0000">Please verify the above list of ACTIVE users assigned this ACTIVE responsibility is accurate!</font><br>Remember that the Workflow Administrator Role has permissions to full access of ALL workflows and notifications.</b>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_WFADMIN_RESP');



debug('begin add_signature: WF2_STUCK2');
  add_signature(
      p_sig_id                 => 'WF2_STUCK2',
      p_sig_sql                => 'select P.Process_Item_Type, P.Activity_Name, S.Activity_Status, S.Activity_Result_Code, 
	 Nvl(To_Char(Wi.End_Date,''YYYY''),''OPEN'') Wf_Status, To_Char(S.Begin_Date, ''YYYY'') Began, ''<div align="right">''||to_char(count(S.Item_Key),''999,999,999,999'')||''</div>'' "Count"
	 FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
	 WHERE P.Instance_Id = S.Process_Activity
	 AND Wi.Item_Type = S.Item_Type
	 AND wi.item_key = s.item_key
	 AND activity_status = ''ERROR''
	 AND activity_result_code = ''#STUCK''
	 AND S.End_Date Is Null
	 GROUP BY P.Process_Item_Type, P.Activity_Name, S.Activity_Status, S.Activity_Result_Code, 
	 to_char(wi.end_date,''YYYY''), To_Char(S.Begin_Date, ''YYYY'')
	 ORDER BY to_char(wi.end_date,''YYYY'') desc, To_Char(S.Begin_Date, ''YYYY'')',
      p_title                  => 'Workflow #STUCK Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>There are '||to_char(g_stuck_cnt,'999,999,999,999')||' #STUCK activities that are still open and CAN NOT progress on their own.</b>',
      p_solution               => 'These stuck activities need to be investigated, and either corrected in order to continue, or aborted and closed, so the workflow can be completed and purged.<br><br>
	 These workflows will not progress or complete on their own. It is recommended that these are looked into....<br>
	 Look for patterns in the same item_type, looking for the same wf_process_activities, date ranges, and check the root_activity_version for any patterns.<br>
	 Run the following query for more details about these ERROR #STUCK processes<br>
	 <blockquote><i>select p.PROCESS_ITEM_TYPE, wi.ITEM_KEY, p.ACTIVITY_NAME, s.ACTIVITY_STATUS, <br>
	 s.ACTIVITY_RESULT_CODE, wi.root_activity, wi.root_activity_version, wi.begin_date<br>
	 FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi<br>
	 WHERE p.instance_id = s.process_activity<br>
	 and wi.item_type = s.item_type<br>
	 and wi.item_key = s.item_key<br>
	 and activity_status = ''ERROR''<br>
	 and activity_result_code = ''#STUCK''<br>
	 order by wi.begin_date;</i></blockquote>
	 A process is identified as stuck when it has a status of ACTIVE, but cannot progress any further.<br>
	 Stuck activities do not have a clear pattern as cause but mainly they are caused by flaws in the WF definition like improper transition definitions. For example, a process could become stuck in the following situations:
	 <ul><li>A thread within a process leads to an activity that is not defined as an End activity but has no other activity modeled after it, and no other activity is active.</li>
	 <li>A process with only one thread loops back, but the pivot activity of the loop has the On Revisit property set to Ignore.</li>
	 <li>An activity returns a result for which no eligible transition exists. </li></ul>
	 For instance, if the function for a function activity returns an unexpected result value, and no default transition is modeled after that activity, the process cannot continue.<br><br>
	 <b>COMMON MISCONCEPTION for STUCK Activities - Running the Worklfow Background Process for STUCK activities fixes STUCK workflows.</b><br>
	 Not true.<br>
	 Running the concurrent request "Workflow Background Process" with Stuck=Yes only identifies these activities that cannot progress. The workflow engine changes the status of a stuck process to ERROR:#STUCK and executes the error process defined for it. This error process sends a notification to SYSADMIN to alert them of this issue, which they need to resolve. The query to determine these activities is very expensive as it joins 3 WF runtime tables and one WF design table. This is why the Workflow Background Engine should run separately when load is not high and only once a week or month.<br><br>
	 For more information on how to progress these Stuck Activities, refer to [453137.1] - Oracle Workflow Best Practices Release 12 and Release 11i',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_STUCK2');



debug('begin add_signature: WF2_WF_ERROR_NTFS2');
  add_signature(
      p_sig_id                 => 'WF2_WF_ERROR_NTFS2',
      p_sig_sql                => 'select n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN'') CLOSED,
	n.STATUS, n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference NTF_PREF,
	r.email_address, ''<div align="right">''||to_char(count(n.notification_id),''999,999,999,999'')||''</div>'' "Count"
	from wf_notifications n, wf_local_roles r
	where n.recipient_role = r.name
	and n.message_type like ''%ERROR%''
	group by n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN''), n.STATUS,
	n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference, r.email_address
	order by nvl(to_char(n.end_date, ''YYYY''),''OPEN''), count(n.notification_id) desc, n.recipient_role',
      p_title                  => 'Workflow Error Notification Messages Summary Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>There are ' || to_char(g_total_error,'999,999,999,999') || ' Error Notifications, 
	where ' || to_char(g_open_error,'999,999,999,999') || ' (' || (round(g_open_error/g_total_error,2)*100) || '%) are still OPEN, 
	and '|| to_char(g_closed_error,'999,999,999,999') || ' are closed.</b><BR><BR>		   
	Additionally, ALL ' || to_char(g_dee_open_cnt,'999,999,999,999') || ' of the system generated Workflow Error Notifications (DEFAULT_EVENT_%_ERROR) that are assigned to SYSADMIN and remain OPEN were generated within the past 30 days.<br> 
	These system generated WFERROR messages do not belong to a parent workflow process and account for ' || to_char(g_dee_open_cnt/g_ntferr_cnt) ||'('|| (round(g_dee_open_cnt/g_ntferr_cnt,2)*100) || '%) of the Error notifications
	 of which (' || (round(g_open_error/g_total_error,2)*100) || '%) are still OPEN,
	 and (' || (round(g_closed_error/g_total_error,2)*100) || '%)  are closed.',
      p_solution               => 'Since these errors have occured recently, it is recommended to first ensure that the issue is resolved and no longer raising system generated 
	Error notifications.<br> Next, follow the note below for steps to remove these system generated error notifications.<br><br>   
	Follow the note below for steps to clean up SYSADMIN queue and easily remove these system generated error notifications.<br><br> 	     
	<B>Note:</B> For more information refer to [1587923.1] - How to Close and Purge excessive WFERROR workflows and DEFAULT_EVENT_ERROR notifications from Workflow.<br>',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_WF_ERROR_NTFS2');



debug('begin add_signature: WF9_PO_LOOPING2');
  l_info.delete;
  l_info('Comments') := 'The table output below is truncated to save space.<br>
                         Run this query to get the full list of Looping Activities.<br>';		
  add_signature(
      p_sig_id                 => 'WF9_PO_LOOPING2',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", ''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key 
	 AND wfi.item_type in (''POAPPRV'',''REQAPPRV'',''POXML'',''POWFRQAG'',''PORCPT'',''APVRMDER'',''PONPBLSH'',''POSPOACK'',''PONAUCT'',''PORPOCHA'',''PODSNOTF'',''POSREGV2'',''POREQCHA'',''POWFPOAG'',''POSCHORD'',''POSASNNB'',''PONAPPRV'',''POSCHPDT'',''POAUTH'',''POWFDS'',''POERROR'',''POSBPR'',''CREATEPO'')
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Purchasing Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Purchasing Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running Purchasing Workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||po_hist_item||'<br>
	 item_key : '||po_hist_key||'<BR><BR> 
	 <B>This workflow process is still open, so this may be a problem. </B><BR>
	 It was started back on '||po_hist_begin||', and has most recently looped thru its process on '||po_hist_recent||'. So far this one activity for item_type '||po_hist_item||' and item_key '||po_hist_key||' has looped '||to_char(po_hist_cnt,'999,999,999,999')||' times since it started in '||po_hist_begin||'.<BR><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(po_hist_days,'999,999')||' days, which is about '||to_char(po_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) for Purchasing  that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_PO_LOOPING2');



debug('begin add_signature: WF9_PO_WF_STATUS');
  add_signature(
      p_sig_id                 => 'WF9_PO_WF_STATUS',
      p_sig_sql                => 'select  
	''<div align="right">''||to_char(NUM_ACTIVE,''999,999,999,999'')||''</div>'' "Active", 
	''<div align="right">''||to_char(NUM_COMPLETE,''999,999,999,999'')||''</div>'' "Completed", 
	''<div align="left">''||to_char(NUM_PURGEABLE,''999,999,999,999'')||''</div>'' "Purgeable", 
	''<div align="left">''||WIT.NAME||''</div>'' "Item Type", 
	''<div align="left">''||DISPLAY_NAME||''</div>'' "Display Name",
	''<div align="center">''||PERSISTENCE_TYPE||''</div>'' "Persistence Type",
	''<div align="center">''||PERSISTENCE_DAYS||''</div>'' "Persistence Days", 
	''<div align="right">''||to_char(NUM_ERROR,''999,999,999,999'')||''</div>'' "Errored",
	''<div align="right">''||to_char(NUM_DEFER,''999,999,999,999'')||''</div>'' "Deferred", 
	''<div align="right">''||to_char(NUM_SUSPEND,''999,999,999,999'')||''</div>'' "Suspended"
	from wf_item_types wit, wf_item_types_tl wtl
	where wit.name in (''POAPPRV'',''REQAPPRV'',''POXML'',''POWFRQAG'',''PORCPT'',''APVRMDER'',''PONPBLSH'',''POSPOACK'',''PONAUCT'',''PORPOCHA'',''PODSNOTF'',''POSREGV2'',''POREQCHA'',''POWFPOAG'',''POSCHORD'',''POSASNNB'',''PONAPPRV'',''POSCHPDT'',''POAUTH'',''POWFDS'',''POERROR'',''POSBPR'',''CREATEPO'')
	AND wtl.name = wit.name
	AND wtl.language = userenv(''LANG'')
	AND wit.NUM_ACTIVE is not NULL
	AND wit.NUM_ACTIVE <>0 
	order by PERSISTENCE_TYPE, NUM_COMPLETE desc',
      p_title                  => 'SUMMARY of PO Workflow Processes By Item Type and Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'SUMMARY of PO Workflow Processes By Item Type and Status',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_PO_WF_STATUS');



debug('begin add_signature: WF1_DB_PARAMS2');
  add_signature(
      p_sig_id                 => 'WF1_DB_PARAMS2',
      p_sig_sql                => 'select name, value
    from v$parameter
    where upper(name) in (''AQ_TM_PROCESSES'',''JOB_QUEUE_PROCESSES'',''JOB_QUEUE_INTERVAL'',
    ''UTL_FILE_DIR'',''NLS_LANGUAGE'', ''NLS_TERRITORY'', ''CPU_COUNT'',
    ''PARALLEL_THREADS_PER_CPU'')',
      p_title                  => 'Workflow Database Parameter Settings',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>JOB_QUEUE_PROCESSES for '||g_rep_info('Instance')||' on ('||g_rep_info('DB Version')||') databases is set to ZERO!</B><BR>
    Oracle Workflow requires job queue processes to handle propagation of Business Event System event messages by AQs.',
      p_solution               => '<B>Significance of the JOB_QUEUE_PROCESSES for 11gR1+ ('||g_rep_info('DB Version')||') databases:</B><BR><BR>

    Starting from 11gR1, The init.ora parameter job_queue_processes does NOT need to be set for AQ propagations.
    AQ propagation is now likewise handled by DBMS_SCHEDULER jobs rather than DBMS_JOBS.
    Reason: propagation takes advantage of the event based scheduling features of DBMS_SCHEDULER for better scalability. <br><br>
<b>JOB_QUEUE_PROCESSES is recommended to be be set to a value of 2 or higher, for optimal performance. </b>  <i>See [396009.1]</i><br><br>
This value can be tuned to meet the specific requirements of the Workflow module and customer needs,
based on the number of job queue processes needed to handle AQ event messages and for Workflow notification mailers.<br>
    If the value of the JOB_QUEUE_PROCESSES database initialization parameter is non-zero, it effectively becomes the maximum number of Scheduler jobs and job queue jobs than can run concurrently. 
    If a non-zero value is set, it should be large enough to accommodate a Scheduler job for each Messaging Gateway agent to be started.<BR><br>

    To determine the proper setting of JOB_QUEUE_PROCESSES for Oracle Workflow, follow the queries outlined in <BR>
    [578831.1] - How to determine the correct setting for JOB_QUEUE_PROCESSES.<br><br>
    To manually update the JOB_QUEUE_PROCESSES database parameter file (init.ora) file:
    <ul><i>job_queue_processes=2</i></ul>
    or set dynamically via
    <ul><i>connect / as sysdba<br>alter system set job_queue_processes=2;</i></ul>Remember that after bouncing the DB, dynamic changes are lost, and the DB parameter file settings are used.<BR>',
      p_success_msg            => 'There is a problem identifying the Workflow Database Parameter Settings',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF1_DB_PARAMS2');



debug('begin add_signature: WF1_ITEM_AGE2');
 add_signature(
      p_sig_id                 => 'WF1_ITEM_AGE2',
      p_sig_sql                => 'select ''WF_ITEMS table has a total of ''||count(item_key)||'' workflow items, the oldest item started ''||min(begin_date)||'', but still exists in the table.'' "WF_ITEMS" from wf_items',
      p_title                  => 'The overall Volume of Workflow Runtime Data is in need of Review!',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>The WF_ITEMS Table has obsolete workflow runtime data that is older than 1 year.</b><BR>
     This Gauge is merely a simple indicator about age and volume of Workflow runtime data on '||g_rep_info('Instance')||'.<br>
     It checks the oldest workflow on this instance, and displays GREEN if less than 1 year old, ORANGE if less than 3, and RED if older than 3 years.<br>
     Clean up your old Workflow Runtime Data and move the needle to green.   See below for more details.',
      p_solution               => '<ul>We reviewed all '||to_char(g_cnt_item,'999,999,999,999')||' rows in WF_ITEMS Table for Oracle Applications Release '|| g_rep_info('Apps Version')||' instance called '||g_rep_info('Instance')||' on '||g_rep_info('Host')||'<BR>
     Currently '||(round(g_item_open/g_cnt_item, 2)*100)||'% ('||to_char(g_item_open,'999,999,999,999')||') of WF_ITEMS 
	 are OPEN, while '||(round((g_cnt_item-g_item_open)/g_cnt_item, 2)*100)||'% ('||to_char((g_cnt_item-g_item_open),'999,999,999,999') ||') are CLOSED items but still exist in the runtime tables.</ul>',
      p_success_msg            => null,
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF1_ITEM_AGE2');



debug('begin add_signature: WF7_ONT_LOOPING2');
  l_info.delete;
  l_info('Comments') := 'The table output below is truncated to save space.<br>
                         Run this query to get the full list of Looping Activities.<br>';		
  add_signature(
      p_sig_id                 => 'WF7_ONT_LOOPING2',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", ''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key AND wfi.item_type in (''OEOH'',''OEOL'',''OMERROR'',''OEOI'',''OECOGS'', ''OEOA'',''OECHGORD'',''OEON'',''OEBH'') 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Order Management Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Order Management Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running Order Management Workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||ont_hist_item||'<br>
	 item_key : '||ont_hist_key||'<BR><BR> 
	 <B>This workflow process is still open, so this may be a problem. </B><BR>
	 It was started back on '||ont_hist_begin||', and has most recently looped thru its process on '||ont_hist_recent||'. So far this one activity for item_type '||ont_hist_item||' and item_key '||ont_hist_key||' has looped '||to_char(ont_hist_cnt,'999,999,999,999')||' times since it started in '||ont_hist_begin||'.<BR><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(ont_hist_days,'999,999')||' days, which is about '||to_char(ont_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) for Order Management that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_ONT_LOOPING2');



debug('begin add_signature: WF8_HCM_LOOPING2');
  l_info.delete;
  l_info('Comments') := 'The table output below is truncated to save space.<br>
                         Run this query to get the full list of Looping Activities.<br>';		
  add_signature(
      p_sig_id                 => 'WF8_HCM_LOOPING2',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", 
	''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key 
	 AND wfi.item_type in (''BENCWBFY'',''SSBEN'',''GHR_SF52'',''HXCEMP'',''HXCSAW'',''IRC_NTF'', ''IRCOFFER'',''OTWF'',''PYASGWF'',''HRCKLTSK'',''HRSSA'',''HRWPM'',''HRRIRPRC'',''PSPERAVL'')
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Human Resources Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Human Resources Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running Human Resources Workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||hcm_hist_item||'<br>
	 item_key : '||hcm_hist_key||'<BR><BR> 
	 <B>This workflow process is still open, so this may be a problem. </B><BR>
	 It was started back on '||hcm_hist_begin||', and has most recently looped thru its process on '||hcm_hist_recent||'. So far this one activity for item_type '||hcm_hist_item||' and item_key '||hcm_hist_key||' has looped '||to_char(hcm_hist_cnt,'999,999,999,999')||' times since it started in '||hcm_hist_begin||'.<BR><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(hcm_hist_days,'999,999')||' days, which is about '||to_char(hcm_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) for Human Resources that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF8_HCM_LOOPING2');



debug('begin add_signature: WF8_SUMMARY_HCM_WF');
  add_signature(
      p_sig_id                 => 'WF8_SUMMARY_HCM_WF',
      p_sig_sql                => 'select wi.item_type "Item Type", wit.display_name "Display Name", wi.PARENT_ITEM_TYPE "Parent Item Type", nvl(to_char(wi.end_date, ''YYYY''),''OPEN'') "Closed", 
	''<div align="right">''||to_char(count(wi.item_key),''999,999,999,999'')||''</div>'' "COUNT"
	from wf_items wi, wf_item_types_tl wit
	where wi.item_type = wit.name 
	and wit.language = ''US''
	and (wi.item_type in (''BENCWBFY'',''SSBEN'',''GHR_SF52'',''HXCEMP'',''HXCSAW'',''IRC_NTF'', ''IRCOFFER'',''OTWF'',''PYASGWF'',''HRCKLTSK'',''HRSSA'',''HRWPM'',''HRRIRPRC'',''PSPERAVL'')  or (wi.item_type like ''%ERROR%'' and wi.parent_item_type in (''BENCWBFY'',''SSBEN'',''GHR_SF52'',''HXCEMP'',''HXCSAW'',''IRC_NTF'',''IRCOFFER'', ''OTWF'',''PYASGWF'',''HRCKLTSK'',''HRSSA'',''HRWPM'',''HRRIRPRC'',''PSPERAVL'')))
	group by wi.item_type, wit.display_name, wi.parent_item_type, to_char(wi.end_date, ''YYYY'')
	order by to_char(wi.end_date, ''YYYY'')',
      p_title                  => 'SUMMARY of All HCM Workflow Processes By Item Type & Parent',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'SUMMARY of All HCM Workflow Processes By Item Type & Parent<BR>',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );	debug('end add_signature: WF8_SUMMARY_HCM_WF');



debug('begin add_signature: WF7_SUMMARY_ONT_WF');
  add_signature(
      p_sig_id                 => 'WF7_SUMMARY_ONT_WF',
      p_sig_sql                => 'select wi.item_type "Item Type", wit.display_name "Display Name", wi.PARENT_ITEM_TYPE "Parent Item Type", nvl(to_char(wi.end_date, ''YYYY''),''OPEN'') "Closed", 
	''<div align="right">''||to_char(count(wi.item_key),''999,999,999,999'')||''</div>'' "COUNT"
from wf_items wi, wf_item_types_tl wit
where wi.item_type = wit.name 
and wit.language = ''US''
and (wi.item_type in (''OEOH'', ''OEOL'', ''OEOI'', ''OECOGS'', ''OEOA'', ''OECHGORD'',''OEON'',''OEBH'')
     or (wi.item_type like ''%ERROR%'' and wi.parent_item_type in (''OEOH'', ''OEOL'', ''OMERROR'', ''OEOI'', ''OECOGS'', ''OEOA'', ''OECHGORD'',''OEON'',''OEBH'')))
group by wi.item_type, wit.display_name, wi.parent_item_type, to_char(wi.end_date, ''YYYY'')
order by to_char(wi.end_date, ''YYYY'')',
      p_title                  => 'SUMMARY of All Order Management Workflow Processes By Item Type & Parent',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'SUMMARY of All Order Management Workflow Processes By Item Type & Parent<BR>',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_SUMMARY_ONT_WF');



debug('begin add_signature: WF6_WF_LOG_LEVELS2');
  add_signature(
      p_sig_id                 => 'WF6_WF_LOG_LEVELS2',
      p_sig_sql                => 'select SC.COMPONENT_NAME "COMPONENT NAME", sc.COMPONENT_TYPE "COMPONENT TYPE",
	 v.PARAMETER_DISPLAY_NAME "PARAMETER",
	 decode(v.PARAMETER_VALUE,
	 ''1'', ''1 = Statement'',
	 ''2'', ''2 = Procedure'',
	 ''3'', ''3 = Event'',
	 ''4'', ''4 = Exception'',
	 ''5'', ''5 = Error'',
	 ''6'', ''6 = Unexpected'',
	 ''N'', ''N = Not Enabled'',
	 ''Y'', ''Y = Enabled'') "VALUE"
	 FROM FND_SVC_COMP_PARAM_VALS_V v, FND_SVC_COMPONENTS SC
	 WHERE v.COMPONENT_ID=sc.COMPONENT_ID 
	 AND v.parameter_name in (''COMPONENT_LOG_LEVEL'',''DEBUG_MAIL_SESSION'')
	 ORDER BY sc.COMPONENT_TYPE, SC.COMPONENT_NAME, v.PARAMETER_VALUE',
      p_title                  => 'Check The Status of Workflow Log Levels and Mailer Debug Status',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no log levels set for workflow logging',
      p_solution               => '',
      p_success_msg            => 'If troubleshooting Workflow Agent Listeners or Java Mailer issues, set individual Component Logging Levels to Statement Level logging (Log Level = 1) for the most detail and robust logging level.<br>
	Use $FND_TOP/sql/afsvcpup.sql - AF SVC Parameter UPdate script to change the logging levels.<br><br>
	Remember to reset, or lower the logging level after troubleshooting to not generate excessive log files. The Mailer Debug parameter (Debug Mail Session) should be ENABLED when troubleshooting issues with any Workflow Notification Mailer.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF6_WF_LOG_LEVELS2');



debug('begin add_signature: WF5_WF_ORPHAN_STATUS2');
  add_signature(	
      p_sig_id                 => 'WF5_WF_ORPHAN_STATUS2',
      p_sig_sql                => 'select WN.MESSAGE_TYPE, wn.MESSAGE_NAME, wit.persistence_type PERSISTENCE, to_char(count(wn.notification_id),''999,999,999,999'') "COUNT"
	from WF_NOTIFICATIONS WN, WF_ITEM_TYPES WIT
	where wn.message_type = wit.name 
	and not exists (select NULL from WF_ITEM_ACTIVITY_STATUSES WIAS
	where WIAS.NOTIFICATION_ID = WN.GROUP_ID)
	and not exists (select NULL from WF_ITEM_ACTIVITY_STATUSES_H WIAS
	where WIAS.NOTIFICATION_ID = WN.GROUP_ID)
	and wn.end_date is null
	group by wn.message_type, wn.MESSAGE_NAME, wit.persistence_type
	order by wit.persistence_type, count(notification_id) desc',
      p_title                  => 'Check for Open Orphaned Notifications',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Open Orphaned or Unreferenced Notifications found!<BR><BR>',
      p_solution               => 'Apply Patch 3104909 and run wfntfprg.sql to remove unreferenced notifications by following the instructions on the script header.</b><br>
	 For purging FNDCMMSG, XDPWFSTD, etc (which are PERMANENT) type of notifications, please uncomment the line 
	 ( Wf_Purge.Persistence_Type := "PERM" ) in the wfntfprg.sql as this type of message is of type PERMANENT persistence.<br>
	 This should do the trick.<BR>',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF5_WF_ORPHAN_STATUS2');



debug('begin add_signature: WF3_WF_OVER_90');
  add_signature(
      p_sig_id                 => 'WF3_WF_OVER_90',
      p_sig_sql                => 'select to_char(wi.begin_date, ''YYYY'') "OPENED", 
	''<div align="right">''||to_char(count(wi.item_key),''999,999,999,999'')||''</div>'' "COUNT"
	 from wf_items wi, wf_item_types wit, wf_item_types_tl witt
	 where wi.ITEM_TYPE=wit.NAME and wi.end_date is null 
	 and wit.NAME=witt.NAME and witt.language = ''US'' and wi.begin_date < sysdate-90 
	 group by to_char(wi.begin_date, ''YYYY'') 
	 order by to_char(wi.begin_date, ''YYYY'')',
	  p_title                  => 'Total OPEN Items Started Over 90 Days Ago',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are '||to_char(g_ninety_cnt,'999,999,999,999')||' OPEN item_types in WF_ITEMS table that were started over 90 days ago.</B>',
      p_solution               => 'Remember that once a Workflow is closed, its runtime data which is stored in Workflow Runtime Tables (WF_*) becomes obsolete.<BR>
     All pertinent information is stored in the functional tables (FND_*, PO_*, AP_*, HR_*, OE_*, etc), like who approved what, for how much, for whom, etc...) and that each single row in WF_ITEMS can represent 100s or 1000s of rows in the subsequent Workflow Runtime tables, 
     so it is important to close these open workflows once completed so they can be purged.<BR><BR>
     <B>Ask this Question: How long should these workflows take to complete?</B><BR>
     30 Days?... 60 Days?... 6 months?... 1 Year?<BR>
     There may be valid business reasons why these OPEN items still exist after 90 days so that should be taken into consideration.<BR>
     However, if this is not the case, then once a workflow item is closed then all the runtime data associated to completing this workflow is now obsolete and should be purged to make room for new workflows.<BR>
     Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data for details on how to drill down to discover the reason why these OLD items are still open, and ways to close them so they can be purged.',
      p_success_msg            => 'There are no OPEN workflow items that were started over 90 days ago on this instance.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','N'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_OVER_90');



debug('begin add_signature: WF3_WF_RUNTIME_VOL2');
  add_signature(
      p_sig_id                 => 'WF3_WF_RUNTIME_VOL2',
      p_sig_sql                => 'select
	table_name "Workflow Table Name", 
	''<div align="right">''||to_char(round(blocks*8192/1024/1024),''999,999,999,999'')||''</div>'' "Logical Table Size",
	''<div align="right">''||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),''999,999,999,999'')||''</div>'' "Physical Table Data", 
	''<div align="right">''||to_char(round((blocks*8192/1024/1024)-(num_rows*AVG_ROW_LEN)/1024/1024),''999,999,999,999'')||''</div>'' "Difference"
	from dba_tables
	where table_name in (''WF_ITEMS'', ''WF_ITEM_ACTIVITY_STATUSES'', ''WF_ITEM_ACTIVITY_STATUSES_H'', 
	''WF_ITEM_ATTRIBUTE_VALUES'', ''WF_NOTIFICATIONS'', ''WF_NOTIFICATION_ATTRIBUTES'', ''WF_COMMENTS'', ''WF_DIG_SIGS'')
	and owner=''APPLSYS''
	union select 
	''<div align="right">TOTALS</div>'' "Workflow Table Name", 
	''<div align="right">'||to_char(g_logical_totals,'999,999,999,999')||'</div>'' "Logical Table Size",
	''<div align="right">'||to_char(g_physical_totals,'999,999,999,999')||'</div>'' "Physical Table Data", 
	''<div align="right">'||to_char(g_diff_totals,'999,999,999,999')||'</div>'' "Difference" from dual
	order by 1 desc',
      p_title                  => 'Volume of Workflow Runtime Data Tables (in MegaBytes)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'The Workflow Runtime Tables logical space which is used for all full-table scans is only at '||g_rate||'% greater than the physical or actual tablespace being used.',
      p_solution               => 'It is recommended at levels above 30% to resize these tables to maintain or reset the table HighWater Mark for optimum performance.<br>
    Please have a DBA monitor these tables going forward to ensure they are being maintained at optimal levels.<BR><BR>
    Please review [388672.1] - How to Reorganize Workflow Tables, on how to manage workflow runtime tablespaces for optimal performance.',
      p_success_msg            => 'There was a problem identifying any Workflow Runtime Data running in this instance',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','N'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_RUNTIME_VOL2');



debug('begin add_signature: EBS_VERSION');
  add_signature(
      p_sig_id                 => 'EBS_VERSION',
      p_sig_sql                => 'SELECT instance_name, release_name, host_name,
          startup_time, version
          from fnd_product_groups, v$instance',
      p_title                  => 'E-Business Suite Version',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There is a problem identifying the EBS Instance Information',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: EBS_VERSION');



debug('begin add_signature: WF4_FNDWFBG_RAN');
  add_signature(
      p_sig_id                 => 'WF4_FNDWFBG_RAN',
      p_sig_sql                => 'select r.REQUEST_ID, u.user_name, p.USER_CONCURRENT_PROGRAM_NAME PROGRAM,
	 DECODE(r.STATUS_CODE, ''A'',''Waiting'',''B'',''B=Resuming'',''C'',''C=Normal'',
	 ''D'',''D=Cancelled'',''E'',''E=Error'',''G'',''G=Warning'',
	 ''H'',''H=On Hold'',''I'',''I=Normal'',''M'',''M=No Manager'',
	 ''P'',''P=Scheduled'',''Q'',''Q=Standby'',''R'',''R=Normal'',
	 ''S'',''S=Suspended'',''T'',''T=Terminating'',''U'',''U=Disabled'',
	 ''W'',''W=Paused'',''X'',''X=Terminated'',''Z'',''Z=Waiting'') STATUS,
	 DECODE(r.PHASE_CODE, ''C'',''Completed'',''I'',''I=Inactive'',''P'',''P=Pending'',''R'',''R=Running'') PHASE,
	 r.ACTUAL_START_DATE STARTED, r.ACTUAL_COMPLETION_DATE COMPLETED,
	 ROUND((r.actual_completion_date - r.actual_start_date)*1440, 2) TOTAL_MINS,
	 FLOOR(((r.actual_completion_date-r.actual_start_date)*24*60*60)/3600)||'':hrs ''||
	 FLOOR((((r.actual_completion_date-r.actual_start_date)*24*60*60)-
	 FLOOR(((r.actual_completion_date-r.actual_start_date)*24*60*60)/3600)*3600)/60)||'':Mins ''||
	 ROUND((((r.actual_completion_date-r.actual_start_date)*24*60*60)-
	 FLOOR(((r.actual_completion_date-r.actual_start_date)*24*60*60)/3600)*3600-
	 (FLOOR((((r.actual_completion_date-r.actual_start_date)*24*60*60)-
	 FLOOR(((r.actual_completion_date-r.actual_start_date)*24*60*60)/3600)*3600)/60)*60)))||'':Secs'' TIME_TO_RUN,
	 r.ARGUMENT_TEXT ARGUMENTS
	 FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
	 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
	 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
	 and c.CONCURRENT_PROGRAM_NAME = ''FNDWFBG''
	 AND p.language = ''US'' 
	 and r.ACTUAL_COMPLETION_DATE is not null
	 order by r.ACTUAL_START_DATE desc',
      p_title                  => 'Verify (last 30) Workflow Background Processes that have completed',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<B>There are no Workflow Background Processes (FNDWFBG) found!</b>',
      p_solution               => 'Please schedule the concurrent request "Workflow Background Process" to process deferred, timed-out, and identify stuck activities for ALL item_types using the guidelines listed above.<br>
	At a minimum, there needs to be at least one background process that can handle both deferred and timed-out activities in order to progress workflows.<BR><BR>
	For more information refer to [466535.1] - How to run the Workflow Background Engine per developments recommendations.<br><br>
    <b>The Workflow Administrators Guide requires that there is at least one background engine that can process deferred activities, check for  timed-out activities, and identify stuck processes.</b><br>
	At a minimum, there needs to be at least one background process that can handle both deferred and timed-out activities in order to progress workflows.<br>
	However, for performance reasons Oracle recommends running three (3) separate background engines at different intervals.<br>
	<ol><li><b>Run a Background Process to handle only DEFERRED activities every 5 to 60 minutes.</b></li>
		<li><b>Run a Background Process to handle only TIMED-OUT activities every 1 to 24 hours as needed.</b></li>
	- Timed-out and stuck activities are not processed from the queue but from the table directly, so Timed-out and stuck activities do not have a representing message in queue WF_DEFERRED_TABLE_M.<br>
	- For this reason they need to be queried up from the runtime tables and progressed as needed. When those records are found the internal Engine APIs are called to progress those workflows further.<br>
	- Timed-out activities are checked in table WF_ITEM_ACTIVITY_STATUSES when their status is ACTIVE, WAITING , NOTIFIED, SUSPEND, or DEFERRED.
	- This query on the table is strightforward and no performance issues are expected here.<br> 
	<li><b>Run a Background Process to identify STUCK Activities once a week to once a month, when the load on the system is low.</b></li>
	- Stuck activities do not have a clear pattern as cause but mainly they are caused by flaws in the WF definition like improper transition definitions.<br>
	- The query to determine activities that are STUCK is very expensive as it joins 3 WF runtime tables and one WF design table. <br>
	- This is why the Workflow Background Engine should run to identify STUCK Activities SEPARATELY and ONLY when load is not high and maybe once a week or so.<br>
	</ol>
	Please see [186361.1] - Workflow Background Process Performance Troubleshooting Guide for more information',
      p_success_msg            => 'The above table displays Concurrent requests that HAVE run and completed, regardless of how they were scheduled (DBMS_JOBS, CONSUB, or PL/SQL, etc), also keep in mind how often the Concurrent Requests Data is being purged.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_FNDWFBG_RAN');



debug('begin add_signature: WF4_WF_SCHED_CP2');
  add_signature(
      p_sig_id                 => 'WF4_WF_SCHED_CP2',
      p_sig_sql                => 'select r.REQUEST_ID "REQUEST_ID", u.user_name "REQUESTED_BY", r.PHASE_CODE "PHASE", r.ACTUAL_START_DATE "STARTED",
	 c.CONCURRENT_PROGRAM_NAME "INTERNAL NAME", p.USER_CONCURRENT_PROGRAM_NAME "PROGRAM_NAME", r.ARGUMENT_TEXT "ARGUMENTS", 
	 r.RESUBMIT_INTERVAL "EVERY", r.RESUBMIT_INTERVAL_UNIT_CODE "SO_OFTEN", r.RESUBMIT_END_DATE "RESUBMIT_END_DATE"
	 FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
	 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
	 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
	 and c.CONCURRENT_PROGRAM_NAME in (''FNDWFBG'',''FNDWFPR'',''FNDWFRET'',''JTFRSWSN'',''FNDWFSYNCUR'',''FNDWFLSC'', 
	 ''FNDWFLIC'',''FNDWFDSURV'',''FNDCPPUR'',''FNDWFBES_CONTROL_QUEUE_CLEANUP'',''FNDWFAASTATCC'',''FNDWFMLRSTATCC'',
	 ''FNDWFWITSTATCC'',''FNDWFBULKRESETNTFPREF'') 
	 AND p.language = ''US'' 
	 and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in (''P'',''R'')
	 order by c.CONCURRENT_PROGRAM_NAME, r.ARGUMENT_TEXT',
      p_title                  => 'Verify Workflow Concurrent Programs Scheduled to Run',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<B>There are no Workflow Background Processes scheduled to run for ALL Item_Types!</b>',
      p_solution               => '',
      p_success_msg            => '<B>There is '||to_char((g_alldefrd),'999,999,999,999')||' Workflow Background Processes (FNDWFBG) scheduled to run for deferred activities for ALL Item_Types!</b><BR><br>
	 Development recommends scheduling a Background Process to handle DEFERRED activities periodically every 5 to 60 minutes.<BR><br>
     Oracle Workflow requires several Concurrent Programs to be run to process, progress, cleanup, and purge workflow related information.<br>
	 This section verifies these required Workflow Concurrent Programs are scheduled as recommended.<br>
	 Note: This section is only looking at the scheduled jobs in FND_CONCURRENT_REQUESTS table, so jobs scheduled using other tools (DBMS_JOBS, CONSUB, or PL/SQL, etc) are not reflected here, so keep this in mind.<br><br>
	 <b>The Workflow Administrators Guide requires that there is at least one background engine that can process deferred activities, check for  timed-out activities, and identify stuck processes.</b><br>
	At a minimum, there needs to be at least one background process that can handle both deferred and timed-out activities in order to progress workflows.<br>
	However, for performance reasons Oracle recommends running three (3) separate background engines at different intervals.<br>
	<ol><li><b>Run a Background Process to handle only DEFERRED activities every 5 to 60 minutes.</b></li>
		<li><b>Run a Background Process to handle only TIMED-OUT activities every 1 to 24 hours as needed.</b></li>
	- Timed-out and stuck activities are not processed from the queue but from the table directly, so Timed-out and stuck activities do not have a representing message in queue WF_DEFERRED_TABLE_M.<br>
	- For this reason they need to be queried up from the runtime tables and progressed as needed. When those records are found the internal Engine APIs are called to progress those workflows further.<br>
	- Timed-out activities are checked in table WF_ITEM_ACTIVITY_STATUSES when their status is ACTIVE, WAITING , NOTIFIED, SUSPEND, or DEFERRED.
	- This query on the table is strightforward and no performance issues are expected here.<br> 
	<li><b>Run a Background Process to identify STUCK Activities once a week to once a month, when the load on the system is low.</b></li>
	- Stuck activities do not have a clear pattern as cause but mainly they are caused by flaws in the WF definition like improper transition definitions.<br>
	- The query to determine activities that are STUCK is very expensive as it joins 3 WF runtime tables and one WF design table. <br>
	- This is why the Workflow Background Engine should run to identify STUCK Activities SEPARATELY and ONLY when load is not high and maybe once a week or so.<br>
	</ol>
	Please see [186361.1] - Workflow Background Process Performance Troubleshooting Guide for more information',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_WF_SCHED_CP2');



debug('begin add_signature: WF1_AQ_TM_PROC2');
  add_signature(
      p_sig_id                 => 'WF1_AQ_TM_PROC2',
      p_sig_sql                => 'select 1 from v$parameter where name = ''aq_tm_processes'' and value = ''0''
	and (ismodified <> ''FALSE'' OR isdefault=''FALSE'')',
      p_title                  => 'Workflow Queue Monitor (AQ_TM_PROCESSES) Setting',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>The parameter AQ_TM_PROCESSES on '||g_rep_info('Instance')||' is explicitly set to Zero (0)!<br>
	This means the time monitor process (QMN) is disabled!!!, and no workflows will be progressed.</b>
	This can also disrupt the operation of the database due to several system queue tables used when the standard database features are used.!<br>
	If it is set to zero, it is recommended to unset the parameter. However, this requires bouncing the database. 
	In the meantime, if the database cannot be immediately bounced, the recommended value to set it to is "1", and this can be done dynamically:
	<ul><i>conn / as sysdba<br>
	alter system set aq_tm_processes = 1;</i></ul><br>',
      p_solution               => 'Follow the comments below, and refer to [746313.1] - What should be the Correct Setting for Parameter AQ_TM_PROCESSES in E-Business Suite Instance?<br>',
      p_success_msg            => 'The parameter AQ_TM_PROCESSES on '||g_rep_info('Instance')||' is not explicitly set to Zero (0), which is fine.<br><br>
    <p><B>Note: Significance of the AQ_TM_PROCESSES for 11gR2+ ('||g_rep_info('DB Version')||') databases:</B><BR><BR>
    Starting from 11gR2, Queue Monitoring can utilize a feature called "auto-tune".<br>
    By default, AQ_TM_PROCESSES parameter is unspecified so it is able to adapt the number of AQ background processes to the system load.<br>
    However, if you do specify a value, then that value is taken into account but the number of processes can still be auto-tuned and so the number of 
    running qXXX processes can be different from what was specified by AQ_TM_PROCESSES.<BR><BR>    
    
    <B>Oracle highly recommends that you leave the AQ_TM_PROCESSES parameter unspecified and let the system autotune.</B><BR><BR>
    
    Note: For more information refer to [746313.1] - What should be the Correct Setting for Parameter AQ_TM_PROCESSES in E-Business Suite Instance?<br></p>

    It should be noted that if AQ_TM_PROCESSES is explicitly specified then the process(es) started will only maintain persistent messages. 
    For example if aq_tm_processes=1 then at least one queue monitor slave process will be dedicated to maintaining persistent messages. 
    Other process can still be automatically started to maintain buffered messages. Up to and including version 11.1 if you explicitly set aq_tm_processes = 10 then there will be no processes available to maintain buffered messages. This should be borne in mind in environments which use Streams replication and from 10.2 onwards user enqueued buffered messages.<BR><BR>

    It is also recommended to NOT DISABLE the Queue Monitor processes by setting aq_tm_processes=0 on a permanent basis. As can be seen above, disabling will stop all related processing in relation to tasks outlined. This will likely have a significant affect on operation of queues - PROCESSED messages will not be removed and any time related, TM actions will not succeed, AQ objects will grow in size.<BR>

    <p><B>Note: There is a known issue viewing the true value of AQ_TM_PROCESSES for 10gR2+ (10.2) from the v$parameters table.</B><BR>
    Review the details in [428441.1] - "Warning: Aq_tm_processes Is Set To 0" Message in Alert Log After Upgrade to 10.2.0.3 or Higher.<br>
    Also of interest [809383.1] - Queue Monitor Auto-Tuning only uses 1 Qmon Slave Process for Persistent Queues.</p>
    
    To check whether AQ_TM_PROCESSES Auto-Tuning is enabled, follow the steps outlined in<BR> 
    [305662.1] - Master Note for AQ Queue Monitor Process (QMON) under Section : Significance of the AQ_TM_PROCESSES Parameter in 10.1 onwards<br></p>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF1_AQ_TM_PROC2');



debug('begin add_signature: WF4_WF_SCHED_CP3');
  add_signature(
      p_sig_id                 => 'WF4_WF_SCHED_CP3',
      p_sig_sql                => 'select r.REQUEST_ID "REQUEST_ID", u.user_name "REQUESTED_BY", r.PHASE_CODE "PHASE", r.ACTUAL_START_DATE "STARTED",
	 c.CONCURRENT_PROGRAM_NAME "INTERNAL NAME", p.USER_CONCURRENT_PROGRAM_NAME "PROGRAM_NAME", r.ARGUMENT_TEXT "ARGUMENTS", 
	 r.RESUBMIT_INTERVAL "EVERY", r.RESUBMIT_INTERVAL_UNIT_CODE "SO_OFTEN", r.RESUBMIT_END_DATE "RESUBMIT_END_DATE"
	 FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
	 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
	 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
	 and c.CONCURRENT_PROGRAM_NAME = (''FNDWFBG'')
	 AND p.language = ''US'' 
	 and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in (''P'',''R'')
	 order by c.CONCURRENT_PROGRAM_NAME, r.ARGUMENT_TEXT',
      p_title                  => 'Verify Workflow Background Process to identify STUCK Activities is Scheduled to Run',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There is '||to_char((g_stuckfreq),'999,999,999,999')||' Workflow Background Processes (FNDWFBG) to identify STUCK Activites scheduled periodically to run in hours or mintues, which may be scheduled to recur too frequently.</B>',
      p_solution               => '<b>Suggestion:<br>Workflow Development recommends scheduling a Workflow Background Process to identify STUCK Activities once a week to once a month, when the load on the system is low.</b><BR>
	Stuck activities do not have a clear pattern of cause but mainly they are caused by flaws in the WF definition like improper transition definitions.<br> 
	<b>The query to determine activities that are STUCK is very expensive</b> as it joins 3 WF runtime tables and one WF design table. <br>
	This is why the Workflow Background Engine should run to identify STUCK Activities SEPARATELY and ONLY when load is low and maybe once a week or as your business requires.<br><br>
	For more information refer to [466535.1] - How to run the Workflow Background Engine per developments recommendations.<br><br>
    <b>The Workflow Administrators Guide requires that there is at least one background engine that can process deferred activities, check for  timed-out activities, and identify stuck processes.</b><br>
	At a minimum, there needs to be at least one background process that can handle both deferred and timed-out activities in order to progress workflows.<br>
	However, for performance reasons Oracle recommends running three (3) separate background engines at different intervals.<br>
	<ol><li><b>Run a Background Process to handle only DEFERRED activities every 5 to 60 minutes.</b></li>
		<li><b>Run a Background Process to handle only TIMED-OUT activities every 1 to 24 hours as needed.</b></li>
	- Timed-out and stuck activities are not processed from the queue but from the table directly, so Timed-out and stuck activities do not have a representing message in queue WF_DEFERRED_TABLE_M.<br>
	- For this reason they need to be queried up from the runtime tables and progressed as needed. When those records are found the internal Engine APIs are called to progress those workflows further.<br>
	- Timed-out activities are checked in table WF_ITEM_ACTIVITY_STATUSES when their status is ACTIVE, WAITING , NOTIFIED, SUSPEND, or DEFERRED.
	- This query on the table is strightforward and no performance issues are expected here.<br> 
	<li><b>Run a Background Process to identify STUCK Activities once a week to once a month, when the load on the system is low.</b></li>
	- Stuck activities do not have a clear pattern as cause but mainly they are caused by flaws in the WF definition like improper transition definitions.<br>
	- The query to determine activities that are STUCK is very expensive as it joins 3 WF runtime tables and one WF design table. <br>
	- This is why the Workflow Background Engine should run to identify STUCK Activities SEPARATELY and ONLY when load is not high and maybe once a week or so.<br>
	</ol>
	Please see [186361.1] - Workflow Background Process Performance Troubleshooting Guide for more information',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_WF_SCHED_CP3');



debug('begin add_signature: WF4_WFBGDFRD');
  add_signature(
      p_sig_id                 => 'WF4_WFBGDFRD',
      p_sig_sql                => 'select corr_id, msg_state, 
	 ''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT"
	 from applsys.aq$wf_deferred_table_m
	 group by corr_id, msg_state
	 order by msg_state, count(*) desc',
      p_title                  => 'Display Activity Status of the Workflow Background Process Deferred Table (WF_DEFERRED_TABLE_M)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'The Workflow Background Process Deferred Table (WF_DEFERRED_TABLE_M) has little or no activity at this time<br>',
      p_solution               => 'This can indicate a problem with Workflows gettting processed.',
      p_success_msg            => 'The Workflow Background Process Deferred Table (WF_DEFERRED_TABLE_M) appears to be working as expected!',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_WFBGDFRD');



debug('begin add_signature: WF3_WF_SUMMARY1');
  add_signature(
      p_sig_id                 => 'WF3_WF_SUMMARY1',
      p_sig_sql                => 'select 
	''<div align="right">''||to_char(NUM_ACTIVE,''999,999,999,999'')||''</div>''  "ACTIVE", ''<div align="right">''||to_char(NUM_COMPLETE,''999,999,999,999'')||''</div>'' "COMPLETED", ''<div align="right">''||to_char(NUM_PURGEABLE,''999,999,999,999'')||''</div>'' "PURGEABLE", 
	 WIT.NAME "ITEM_NAME", DISPLAY_NAME "DISPLAY_NAME", 
	 PERSISTENCE_TYPE "PERSISTENCE_TYPE", PERSISTENCE_DAYS "PERSISTENCE_DAYS", 
	 ''<div align="right">''||to_char(NUM_ERROR,''999,999,999,999'')||''</div>'' "ERRORED", ''<div align="right">''||to_char(NUM_DEFER,''999,999,999,999'')||''</div>'' "DEFERRED", ''<div align="right">''||to_char(NUM_SUSPEND,''999,999,999,999'')||''</div>'' "SUSPENDED"
	 from wf_item_types wit, wf_item_types_tl wtl
	 where wit.name like (''%'')
	 AND wtl.name = wit.name
	 AND wtl.language = userenv(''LANG'')
	 AND wit.NUM_ACTIVE is not NULL
	 AND wit.NUM_ACTIVE <>0 
	 order by PERSISTENCE_TYPE, NUM_COMPLETE desc',
      p_title                  => 'Summary of Workflow Processes By Item Type',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<b>11i.ATG_PF.H.RUP4 (Patch 4676589) is NOT applied, so the above table will fail as expected.</b><br>',
      p_solution               => 'This table queries WF_ITEM_TYPES for columns that are added after 11i.ATG_PF.H.RUP4 (Patch 4676589).<BR>
     Please ignore this table and error.',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','N'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_SUMMARY1');



debug('begin add_signature: WF5_WF_ORPHAN_STATUS3');
  add_signature(
      p_sig_id                 => 'WF5_WF_ORPHAN_STATUS3',
      p_sig_sql                => 'select WN.MESSAGE_TYPE, wn.MESSAGE_NAME, wit.persistence_type PERSISTENCE, to_char(count(wn.notification_id),''999,999,999,999'') "COUNT"
	from WF_NOTIFICATIONS WN, WF_ITEM_TYPES WIT
	where wn.message_type = wit.name 
	and not exists (select NULL from WF_ITEM_ACTIVITY_STATUSES WIAS
	where WIAS.NOTIFICATION_ID = WN.GROUP_ID)
	and not exists (select NULL from WF_ITEM_ACTIVITY_STATUSES_H WIAS
	where WIAS.NOTIFICATION_ID = WN.GROUP_ID)
	and wn.end_date is null
	group by wn.message_type, wn.MESSAGE_NAME, wit.persistence_type
	order by wit.persistence_type, count(notification_id) desc',
      p_title                  => 'Check for Open Orphaned Notifications',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Open Orphaned or Unreferenced Notifications found!<BR><BR>',
      p_solution               => 'It does not appear that patch 3104909 is applied to this instance, so please download and apply Patch 3104909 and then 
	 run wfntfprg.sql to remove unreferenced notifications by following the instructions on the script header.<br> 
	 For purging FNDCMMSG, XDPWFSTD, etc (which are PERMANENT) type of notifications, please uncomment the line 
	 ( Wf_Purge.Persistence_Type := "PERM" ) in the wfntfprg.sql as this type of message is of type PERMANENT persistence.<br>
	 This should do the trick.<BR>',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF5_WF_ORPHAN_STATUS3');



debug('begin add_signature: WF6_WF_LOG_LOCATIONS');
  add_signature(
      p_sig_id                 => 'WF6_WF_LOG_LOCATIONS',
      p_sig_sql                => 'select fcq.concurrent_queue_name, fcp.last_update_date,
	 fcp.concurrent_process_id,flkup.meaning,fcp.logfile_name
	 FROM fnd_concurrent_queues fcq, fnd_concurrent_processes fcp, fnd_lookups flkup
	 WHERE concurrent_queue_name in (''WFMLRSVC'', ''WFALSNRSVC'',''WFWSSVC'')
	 AND fcq.concurrent_queue_id = fcp.concurrent_queue_id
	 AND fcq.application_id = fcp.queue_application_id
	 AND flkup.lookup_code=fcp.process_status_code
	 AND lookup_type =''CP_PROCESS_STATUS_CODE''
	 AND flkup.meaning=''Active''',
      p_title                  => 'Verify Workflow Services Current Logs',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no logs recorded at this time.',
      p_solution               => '',
      p_success_msg            => 'The current latest Workflow Agent Listener logs and Workflow Java Mailer logs are found in the locations listed above.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF6_WF_LOG_LOCATIONS');



debug('begin add_signature: WF7_WF_ONT_CP_CHK');
  add_signature(
      p_sig_id                 => 'WF7_WF_ONT_CP_CHK',
      p_sig_sql                => 'select r.REQUEST_ID "REQUEST_ID", u.user_name "REQUESTED_BY", r.PHASE_CODE "PHASE", r.ACTUAL_START_DATE "STARTED",
	 c.CONCURRENT_PROGRAM_NAME "INTERNAL NAME", p.USER_CONCURRENT_PROGRAM_NAME "PROGRAM_NAME", r.ARGUMENT_TEXT "ARGUMENTS", 
	 r.RESUBMIT_INTERVAL "EVERY", r.RESUBMIT_INTERVAL_UNIT_CODE "SO_OFTEN", r.RESUBMIT_END_DATE "RESUBMIT_END_DATE"
	 FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
	 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
	 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
	 and c.CONCURRENT_PROGRAM_NAME in (''OEXPWF'',''OEXVWF'',''OEXEXMBR'',''FNDWFBG'') 
	 AND p.language = ''US'' 
	 and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in (''P'',''R'')
	 order by c.CONCURRENT_PROGRAM_NAME, r.ARGUMENT_TEXT',
      p_title                  => 'Verify Order Management Workflow Concurrent Programs Scheduled to Run',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<B>There are no Workflow Background Processes (FNDWFBG) scheduled to run for ALL Item_Types!</b>',
      p_solution               => 'Workflow Development recommends scheduling a Workflow Background Process to identify STUCK Activities once a week to once a month, when the load on the system is low.<BR>
	Stuck activities do not have a clear pattern of cause but mainly they are caused by flaws in the WF definition like improper transition definitions.<br> 
	<b>The query to determine activities that are STUCK is very expensive</b> as it joins 3 WF runtime tables and one WF design table. <br>
	This is why the Workflow Background Engine should run to identify STUCK Activities SEPARATELY and ONLY when load is low and maybe once a week or as your business requires.<br><br>
	Please schedule the concurrent request "Workflow Background Process" to process deferred, timed-out, and identify stuck activities for ALL item_types using the guidelines listed above.<br>
	At a minimum, there needs to be at least one background process that can handle both deferred and timed-out activities in order to progress workflows.<BR><BR>
	For more information refer to [466535.1] - How to run the Workflow Background Engine per developments recommendations.<br><br>
    <b>The Workflow Administrators Guide requires that there is at least one background engine that can process deferred activities, check for  timed-out activities, and identify stuck processes.</b><br>
	At a minimum, there needs to be at least one background process that can handle both deferred and timed-out activities in order to progress workflows.<br>
	However, for performance reasons Oracle recommends running three (3) separate background engines at different intervals.<br>
	<ol><li><b>Run a Background Process to handle only DEFERRED activities every 5 to 60 minutes.</b></li>
		<li><b>Run a Background Process to handle only TIMED-OUT activities every 1 to 24 hours as needed.</b></li>
	- Timed-out and stuck activities are not processed from the queue but from the table directly, so Timed-out and stuck activities do not have a representing message in queue WF_DEFERRED_TABLE_M.<br>
	- For this reason they need to be queried up from the runtime tables and progressed as needed. When those records are found the internal Engine APIs are called to progress those workflows further.<br>
	- Timed-out activities are checked in table WF_ITEM_ACTIVITY_STATUSES when their status is ACTIVE, WAITING , NOTIFIED, SUSPEND, or DEFERRED.
	- This query on the table is strightforward and no performance issues are expected here.<br> 
	<li><b>Run a Background Process to identify STUCK Activities once a week to once a month, when the load on the system is low.</b></li>
	- Stuck activities do not have a clear pattern as cause but mainly they are caused by flaws in the WF definition like improper transition definitions.<br>
	- The query to determine activities that are STUCK is very expensive as it joins 3 WF runtime tables and one WF design table. <br>
	- This is why the Workflow Background Engine should run to identify STUCK Activities SEPARATELY and ONLY when load is not high and maybe once a week or so.<br>
	</ol>
	Please see [186361.1] - Workflow Background Process Performance Troubleshooting Guide for more information',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_WF_ONT_CP_CHK');



debug('begin add_signature: WF8_HCM_WF_SUMMARY');
  add_signature(
      p_sig_id                 => 'WF8_HCM_WF_SUMMARY',
      p_sig_sql                => 'select  
	''<div align="right">''||to_char(NUM_ACTIVE,''999,999,999,999'')||''</div>'' "ACTIVE",
	''<div align="right">''||to_char(NUM_COMPLETE,''999,999,999,999'')||''</div>'' "COMPLETED",
	''<div align="left">''||to_char(NUM_PURGEABLE,''999,999,999,999'')||''</div>'' "PURGEABLE",
	''<div align="left">''||WIT.NAME||''</div>'' "ITEM_NAME",
	''<div align="left">''||DISPLAY_NAME||''</div>'' "DISPLAY_NAME",
	''<div align="center">''||PERSISTENCE_TYPE||''</div>'' "PERSISTENCE_TYPE",
	''<div align="center">''||PERSISTENCE_DAYS||''</div>'' "PERSISTENCE_DAYS",
	''<div align="right">''||to_char(NUM_ERROR,''999,999,999,999'')||''</div>'' "ERRORED",
	''<div align="right">''||to_char(NUM_DEFER,''999,999,999,999'')||''</div>'' "DEFERRED",
	''<div align="right">''||to_char(NUM_SUSPEND,''999,999,999,999'')||''</div>'' "SUSPENDED"
	from wf_item_types wit, wf_item_types_tl wtl
	where wit.name in (''BENCWBFY'',''SSBEN'',''GHR_SF52'',''HXCEMP'',''HXCSAW'',''IRC_NTF'', ''IRCOFFER'',''OTWF'',''PYASGWF'',''HRCKLTSK'',''HRSSA'',''HRWPM'',''HRRIRPRC'',''PSPERAVL'')
	and wtl.name = wit.name
	and wtl.language = userenv(''LANG'')
	and wit.NUM_ACTIVE is not NULL
	and wit.NUM_ACTIVE <>0 
	order by PERSISTENCE_TYPE, NUM_COMPLETE desc',
      p_title                  => 'SUMMARY of HCM Workflow Processes By Item Type and Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'SUMMARY of HCM Workflow Processes By Item Type and Status<BR>',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF8_HCM_WF_SUMMARY');



debug('begin add_signature: WF8_HCM_LOOPING3');
  l_info.delete;
  l_info('Comments') := 'The table output below is truncated to save space.<br>
                         Run this query to get the full list of Looping Activities.<br>';		
  add_signature(
      p_sig_id                 => 'WF8_HCM_LOOPING3',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", 
	''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key 
	 AND wfi.item_type in (''BENCWBFY'',''SSBEN'',''GHR_SF52'',''HXCEMP'',''HXCSAW'',''IRC_NTF'', ''IRCOFFER'',''OTWF'',''PYASGWF'',''HRCKLTSK'',''HRSSA'',''HRWPM'',''HRRIRPRC'',''PSPERAVL'') 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Human Resources Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Human Resources Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running Human Resources Workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||hcm_hist_item||'<br>
	 item_key : '||hcm_hist_key||'<BR><BR>
     <B>This process has been closed since '||hcm_hist_end||'.</B><BR>
	 It was started on '||hcm_hist_begin||', and has most recently looped thru its process on '||hcm_hist_recent||'.<br><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(hcm_hist_days,'999,999')||' days, which is about '||to_char(hcm_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) for Human Resources that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF8_HCM_LOOPING3');



debug('begin add_signature: WF1_NODE_INFO');
  add_signature(
      p_sig_id                 => 'WF1_NODE_INFO',
      p_sig_sql                => 'SELECT substr(node_name, 1, 20) node_name, node_mode, server_address, substr(host, 1, 15) host,
       substr(domain, 1, 20) domain, substr(support_cp, 1, 3) cp, substr(support_web, 1, 3) web,
       substr(support_admin, 1, 3) ADMIN, substr(support_forms, 1, 3) FORMS,
       substr(SUPPORT_DB, 1, 3) db, substr(VIRTUAL_IP, 1, 30) virtual_ip 
       from fnd_nodes',
      p_title                  => 'Instance Node Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There is a problem identifying the EBS Instance Information',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: WF1_NODE_INFO');



debug('begin add_signature: WF1_ITEM_AGE3');
 add_signature(
      p_sig_id                 => 'WF1_ITEM_AGE3',
      p_sig_sql                => 'select ''WF_ITEMS table has a total of ''||count(item_key)||'' workflow items, the oldest item started ''||min(begin_date)||'', but still exists in the table.'' "WF_ITEMS" from wf_items',
      p_title                  => 'The overall Volume of Workflow Runtime Data is Healthy!',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>The WF_ITEMS Table has workflow runtime data that is less than 1 year old.</b><BR>
     This Gauge is merely a simple indicator about age and volume of Workflow runtime data on '||g_rep_info('Instance')||'.<br>
     It checks the oldest workflow on this instance, and displays GREEN if less than 1 year old, ORANGE if less than 3, and RED if older than 3 years.<br>
     Clean up your old Workflow Runtime Data and move the needle to green.   See below for more details.',
      p_solution               => '<ul>We reviewed all '||to_char(g_cnt_item,'999,999,999,999')||' rows in WF_ITEMS Table for Oracle Applications Release '|| g_rep_info('Apps Version')||' instance called '||g_rep_info('Instance')||' on '||g_rep_info('Host')||'<BR>
     Currently '||(round(g_item_open/g_cnt_item, 2)*100)||'% ('||to_char(g_item_open,'999,999,999,999')||') of WF_ITEMS 
	 are OPEN, while '||(round((g_cnt_item-g_item_open)/g_cnt_item, 2)*100)||'% ('||to_char((g_cnt_item-g_item_open),'999,999,999,999') ||') are CLOSED items but still exist in the runtime tables.</ul>',
      p_success_msg            => null,
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF1_ITEM_AGE3');



debug('begin add_signature: WF2_WF_SERVICES');
  add_signature(
      p_sig_id                 => 'WF2_WF_SERVICES',
      p_sig_sql                => 'select fcq.USER_CONCURRENT_QUEUE_NAME "CONTAINER", fsc.COMPONENT_NAME "COMPONENT",
	 DECODE(fcp.OS_PROCESS_ID,NULL,''Not Running'',fcp.OS_PROCESS_ID) "PROCID", fcq.MAX_PROCESSES "TARGET",
	 fcq.RUNNING_PROCESSES "ACTUAL", v.PARAMETER_VALUE "#THREADS", fcq.ENABLED_FLAG "ENABLED", fsc.COMPONENT_ID "COMPONENT_ID",
	 fsc.CORRELATION_ID "CORRELATION_ID", fsc.STARTUP_MODE "STARTUP_MODE", fsc.COMPONENT_STATUS "STATUS"
	 from APPS.FND_CONCURRENT_QUEUES_VL fcq, APPS.FND_CP_SERVICES fcs, 
	 APPS.FND_CONCURRENT_PROCESSES fcp, fnd_svc_components fsc, FND_SVC_COMP_PARAM_VALS_V v
	 where v.COMPONENT_ID=fsc.COMPONENT_ID
	 and fcq.MANAGER_TYPE = fcs.SERVICE_ID 
	 and fcs.SERVICE_HANDLE = ''FNDCPGSC'' 
	 and fsc.concurrent_queue_id = fcq.concurrent_queue_id(+)
	 and fcq.concurrent_queue_id = fcp.concurrent_queue_id(+)
	 and fcq.application_id = fcp.queue_application_id(+) 
	 and fcp.process_status_code(+) = ''A''
	 and v.PARAMETER_NAME = ''PROCESSOR_IN_THREAD_COUNT''
	 order by fcp.OS_PROCESS_ID, fsc.STARTUP_MODE',
      p_title                  => 'Check the Status of Workflow Services on '||g_rep_info('Instance')||'.',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no GSM Services running in this '||g_rep_info('Instance')||' instance',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','N'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_WF_SERVICES');



debug('begin add_signature: WF7_ONT_LOOPING3');
  l_info.delete;
  l_info('Comments') := 'The table output below is truncated to save space.<br>
                         Run this query to get the full list of Looping Activities.<br>';		
  add_signature(
      p_sig_id                 => 'WF7_ONT_LOOPING3',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", ''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key AND wfi.item_type in (''OEOH'',''OEOL'',''OMERROR'',''OEOI'',''OECOGS'', ''OEOA'',''OECHGORD'',''OEON'',''OEBH'') 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Order Management Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Order Management Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running Order Management Workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||ont_hist_item||'<br>
	 item_key : '||ont_hist_key||'<BR><BR>
     <B>This process has been closed since '||ont_hist_end||'.</B><BR>
	 It was started on '||ont_hist_begin||', and has most recently looped thru its process on '||ont_hist_recent||'.<br><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(ont_hist_days,'999,999')||' days, which is about '||to_char(ont_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) for Order Management that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_ONT_LOOPING3');



debug('begin add_signature: WF1_DB_PARAMS3');
  add_signature(
      p_sig_id                 => 'WF1_DB_PARAMS3',
      p_sig_sql                => 'select name, value
    from v$parameter
    where upper(name) in (''AQ_TM_PROCESSES'',''JOB_QUEUE_PROCESSES'',''JOB_QUEUE_INTERVAL'',
    ''UTL_FILE_DIR'',''NLS_LANGUAGE'', ''NLS_TERRITORY'', ''CPU_COUNT'',
    ''PARALLEL_THREADS_PER_CPU'')',
      p_title                  => 'Workflow Database Parameter Settings',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>JOB_QUEUE_PROCESSES for '||g_rep_info('Instance')||' on pre-11gR1 ('||g_rep_info('DB Version')||') databases is less than 10!</B><BR>
    Oracle Workflow requires job queue processes to handle propagation of Business Event System event messages by AQs.',
      p_solution               => 'The recommended minimum number of JOB_QUEUE_PROCESSES for Oracle Workflow is 10.<br>
    The maximum number of JOB_QUEUE_PROCESSES is :<BR> -    36 in Oracle8i<BR> - 1,000 in Oracle9i Database and higher, so set the value of JOB_QUEUE_PROCESSES accordingly.<BR>
    The ideal setting for JOB_QUEUE_PROCESSES should be set to the maximum number of jobs that would ever be run concurrently on a system PLUS a few more.<BR><BR>
    To determine the proper amount of JOB_QUEUE_PROCESSES for Oracle Workflow, follow the queries outlined in<BR> 
    [578831.1] - How to determine the correct setting for JOB_QUEUE_PROCESSES.<br>',
      p_success_msg            => 'There is a problem identifying the Workflow Database Parameter Settings',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF1_DB_PARAMS3');



debug('begin add_signature: WF1_AQ_TM_PROC3');
  add_signature(
      p_sig_id                 => 'WF1_AQ_TM_PROC3',
      p_sig_sql                => 'select 1 from v$parameter where name = ''aq_tm_processes'' and value = ''0''
	and (ismodified <> ''FALSE'' OR isdefault=''FALSE'')',
      p_title                  => 'Workflow Queue Monitor (AQ_TM_PROCESSES) Setting',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>The parameter AQ_TM_PROCESSES on '||g_rep_info('Instance')||' is explicitly set to Zero (0)!<br>
	This means the time monitor process (QMN) is disabled!!!, and no workflows will be progressed.</b>
	This can also disrupt the operation of the database due to several system queue tables used when the standard database features are used.!<br>
	If it is set to zero, it is recommended to unset the parameter. However, this requires bouncing the database. 
	In the meantime, if the database cannot be immediately bounced, the recommended value to set it to is "1", and this can be done dynamically:
	<ul><i>conn / as sysdba<br>
	alter system set aq_tm_processes = 1;</i></ul><br>',
      p_solution               => 'Follow the comments below, and refer to [746313.1] - What should be the Correct Setting for Parameter AQ_TM_PROCESSES in E-Business Suite Instance?<br>',
      p_success_msg            => 'The parameter AQ_TM_PROCESSES on '||g_rep_info('Instance')||' is not explicitly set to Zero (0), which is fine.<br><br>
    <p>Unable to determine the DB Version for this instance.<br>
	For more information refer to [746313.1] - What should be the Correct Setting for Parameter AQ_TM_PROCESSES in E-Business Suite Instance?<br></p>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF1_AQ_TM_PROC3');



debug('begin add_signature: WF9_PO_LOOPING3');
  l_info.delete;
  l_info('Comments') := 'The table output below is truncated to save space.<br>
                         Run this query to get the full list of Looping Activities.<br>';		
  add_signature(
      p_sig_id                 => 'WF9_PO_LOOPING3',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", ''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key 
	 AND wfi.item_type in (''POAPPRV'',''REQAPPRV'',''POXML'',''POWFRQAG'',''PORCPT'',''APVRMDER'',''PONPBLSH'',''POSPOACK'',''PONAUCT'',''PORPOCHA'',''PODSNOTF'',''POSREGV2'',''POREQCHA'',''POWFPOAG'',''POSCHORD'',''POSASNNB'',''PONAPPRV'',''POSCHPDT'',''POAUTH'',''POWFDS'',''POERROR'',''POSBPR'',''CREATEPO'') 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Purchasing Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Purchasing Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running Purchasing Workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||po_hist_item||'<br>
	 item_key : '||po_hist_key||'<BR><BR>
     <B>This process has been closed since '||po_hist_end||'.</B><BR>
	 It was started on '||po_hist_begin||', and has most recently looped thru its process on '||po_hist_recent||'.<br><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(po_hist_days,'999,999')||' days, which is about '||to_char(po_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) for Purchasing  that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_PO_LOOPING3');



debug('begin add_signature: WF2_WF_ERROR_NTFS3');
  add_signature(
      p_sig_id                 => 'WF2_WF_ERROR_NTFS3',
      p_sig_sql                => 'select n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN'') CLOSED,
	n.STATUS, n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference NTF_PREF,
	r.email_address, ''<div align="right">''||to_char(count(n.notification_id),''999,999,999,999'')||''</div>'' "Count"
	from wf_notifications n, wf_local_roles r
	where n.recipient_role = r.name
	and n.message_type like ''%ERROR%''
	group by n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN''), n.STATUS,
	n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference, r.email_address
	order by nvl(to_char(n.end_date, ''YYYY''),''OPEN''), count(n.notification_id) desc, n.recipient_role',
      p_title                  => 'Workflow Error Notification Messages Summary Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>There are ' || to_char(g_total_error,'999,999,999,999') || ' Error Notifications, 
	where ' || to_char(g_open_error,'999,999,999,999') || ' (' || (round(g_open_error/g_total_error,2)*100) || '%) are still OPEN, 
	and '|| to_char(g_closed_error,'999,999,999,999') || ' are closed.</b><BR><BR>		   
	Additionally, some of the ' || to_char(g_dee_open_cnt,'999,999,999,999') || ' system generated Workflow Error Notifications (DEFAULT_EVENT_%_ERROR) that 
	are assigned to SYSADMIN and remain OPEN were generated within the past 30 days.<br> 
	These system generated WFERROR messages do not belong to a parent workflow process and account 
	for ('|| (round(g_dee_open_cnt/g_ntferr_cnt,2)*100) || '%) of all the Error notifications where (' || (round(g_open_error/g_total_error,2)*100) || '%) are still OPEN,
	 and (' || (round(g_closed_error/g_total_error,2)*100) || '%)  are closed.',
      p_solution               => 'Since some of these errors have occured recently, it is recommended to first ensure that the issue is resolved and is no longer raising 
	system generated Error notifications.<br> Next, follow the note below for steps to easily remove these system generated error notifications.<br><br> 
	<B>Note:</B> For more information refer to [1587923.1] - How to Close and Purge excessive WFERROR workflows and DEFAULT_EVENT_ERROR notifications from Workflow.<br>',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_WF_ERROR_NTFS3');



debug('begin add_signature: WF2_STUCK3');
  add_signature(
      p_sig_id                 => 'WF2_STUCK3',
      p_sig_sql                => 'select P.Process_Item_Type, P.Activity_Name, S.Activity_Status, S.Activity_Result_Code, 
	 Nvl(To_Char(Wi.End_Date,''YYYY''),''OPEN'') Wf_Status, To_Char(S.Begin_Date, ''YYYY'') Began, ''<div align="right">''||to_char(count(S.Item_Key),''999,999,999,999'')||''</div>'' "Count"
	 FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
	 WHERE P.Instance_Id = S.Process_Activity
	 AND Wi.Item_Type = S.Item_Type
	 AND wi.item_key = s.item_key
	 AND activity_status = ''ERROR''
	 AND activity_result_code = ''#STUCK''
	 AND S.End_Date Is Null
	 GROUP BY P.Process_Item_Type, P.Activity_Name, S.Activity_Status, S.Activity_Result_Code, 
	 to_char(wi.end_date,''YYYY''), To_Char(S.Begin_Date, ''YYYY'')
	 ORDER BY to_char(wi.end_date,''YYYY'') desc, To_Char(S.Begin_Date, ''YYYY'')',
      p_title                  => 'Workflow #STUCK Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>There are '||to_char(g_stuck_cnt,'999,999,999,999')||' #STUCK activities that are still open and CAN NOT progress on their own.</b>',
      p_solution               => 'These stuck activities need to be investigated, and either corrected in order to continue, or aborted and closed, so the workflow can be completed and purged.<br><br>
	 These workflows will not progress or complete on their own. It is recommended that these are looked into....<br>
	 Look for patterns in the same item_type, looking for the same wf_process_activities, date ranges, and check the root_activity_version for any patterns.<br>
	 Run the following query for more details about these ERROR #STUCK processes<br>
	 <blockquote><i>select p.PROCESS_ITEM_TYPE, wi.ITEM_KEY, p.ACTIVITY_NAME, s.ACTIVITY_STATUS, <br>
	 s.ACTIVITY_RESULT_CODE, wi.root_activity, wi.root_activity_version, wi.begin_date<br>
	 FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi<br>
	 WHERE p.instance_id = s.process_activity<br>
	 and wi.item_type = s.item_type<br>
	 and wi.item_key = s.item_key<br>
	 and activity_status = ''ERROR''<br>
	 and activity_result_code = ''#STUCK''<br>
	 order by wi.begin_date;</i></blockquote>
	 A process is identified as stuck when it has a status of ACTIVE, but cannot progress any further.<br>
	 Stuck activities do not have a clear pattern as cause but mainly they are caused by flaws in the WF definition like improper transition definitions. For example, a process could become stuck in the following situations:
	 <ul><li>A thread within a process leads to an activity that is not defined as an End activity but has no other activity modeled after it, and no other activity is active.</li>
	 <li>A process with only one thread loops back, but the pivot activity of the loop has the On Revisit property set to Ignore.</li>
	 <li>An activity returns a result for which no eligible transition exists. </li></ul>
	 For instance, if the function for a function activity returns an unexpected result value, and no default transition is modeled after that activity, the process cannot continue.<br><br>
	 <b>COMMON MISCONCEPTION for STUCK Activities - Running the Worklfow Background Process for STUCK activities fixes STUCK workflows.</b><br>
	 Not true.<br>
	 Running the concurrent request "Workflow Background Process" with Stuck=Yes only identifies these activities that cannot progress. The workflow engine changes the status of a stuck process to ERROR:#STUCK and executes the error process defined for it. This error process sends a notification to SYSADMIN to alert them of this issue, which they need to resolve. The query to determine these activities is very expensive as it joins 3 WF runtime tables and one WF design table. This is why the Workflow Background Engine should run separately when load is not high and only once a week or month.<br><br>
	 For more information on how to progress these Stuck Activities, refer to [453137.1] - Oracle Workflow Best Practices Release 12 and Release 11i',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_STUCK3');



debug('begin add_signature: WF2_WFADMIN_RESP_1');
  add_signature(
      p_sig_id                 => 'WF2_WFADMIN_RESP_1',
      p_sig_sql                => 'select r.name, r.display_name, r.status, r.notification_preference, nvl(r.email_address,''NOTSET'') "EMAIL ADDRESS" 
	from wf_roles r, wf_resources res 
	where res.name = ''WF_ADMIN_ROLE''
	and res.language = ''US''
	and res.text = r.NAME',
      p_title                  => 'Workflow Administrator Role',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>The Workflow Administrator Role is set to Responsibility "'||g_wfadmin_display||'", with only one single user!</b>',
      p_solution               => 'The Workflow Administrator role (WF_ADMIN_ROLE) for '||g_rep_info('Instance')||' is set to Responsibility ('||g_wfadmin_role||') also 
	 known as '||g_wfadmin_display||', and there is only one User assigned to this Responsibility, so they alone have Workflow Administrator Role permissions on this instance.<BR>
     Please assign more people to this responsibility.<BR><BR>',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_WFADMIN_RESP_1');



debug('begin add_signature: WF2_DISABLED3');
  add_signature(
      p_sig_id                 => 'WF2_DISABLED3',
      p_sig_sql                => 'select notification_preference, status, ''<div align="right">''||to_char(count(name),''999,999,999,999'')||''</div>'' "Count"
	 from wf_local_roles
	 where name not like ''FND_RESP%''
	 and user_flag = ''Y''
	 group by notification_preference, status
	 order by status, notification_preference',
      p_title                  => 'Check for DISABLED Notification Preferences',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Notification Preferences set in this instance',
      p_solution               => '',
      p_success_msg            => '<B>There are '||to_char((g_disabled_cnt),'999,999,999,999')||' active Users that have their email notification preference set to DISABLED.</B><br>
	 This may be done by the users on purpose, or by the system because of a problem with a bad email address.<br>
	 <br>It is recommended to verify all the email addresses for these '||to_char((g_disabled_cnt),'999,999,999,999')||' active Users that have DISABLED notification preference using : <br>
	    <blockquote><i>select name, display_name, description, status, <br>
	    orig_system, email_address, notification_preference<br>
	    from wf_local_roles<br>
	    where notification_preference = ''DISABLED''<br>
		and status = ''ACTIVE''<br>
	    and user_flag = ''Y'';</i></blockquote><BR>
	 Please review [1326359.1] - Workflow Notification Email Preference is Disabled: How to Troubleshoot and Repair',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_DISABLED3');



debug('begin add_signature: WF2_SYSADMIN3');
  add_signature(
      p_sig_id                 => 'WF2_SYSADMIN3',
      p_sig_sql                => 'select name, notification_preference, nvl(email_address,''NOTSET'') "EMAIL ADDRESS" from wf_local_roles where name = ''SYSADMIN''',
      p_title                  => 'SYSADMIN User Setup for Error Notifications',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>The SYSADMIN User has not been setup correctly.  SYSADMIN e-mail address is not set, but the notification preference is set to send emails.</b><BR>
    Currently there are '||to_char(g_errorntfcnt,'999,999,999,999')||' Error Notifications assigned to the SYSADMIN user.',
      p_solution               => 'In Oracle Applications, you must particularly check the notification preference and e-mail address for the SYSADMIN User. <BR>
    The SYSADMIN User is the default recipient for several types of notifications such as Workflow error notifications.  
    You need to specify how you want to receive these notifications by defining the notification preference and e-mail address for the User: SYSADMIN.<BR>
    By default, the SYSADMIN User has a notification preference to receive e-mail notifications. <BR>To enable Oracle Workflow to send e-mail to the SYSADMIN user, 
    Login to Oracle Applications as SYSADMIN and navigate to the User Preferences window in top right corner and assign SYSADMIN an e-mail address that is fully qualified with a valid domain.<br> 
    However, if you want to access notifications only through the Oracle Workflow Worklist Web page, 
    then you should change the notification preference for SYSADMIN to "Do not send me mail" in the Preferences page. In this case you do not need to define an e-mail address. <br><br>
    Please review System Administration Setup Tasks in the <a href="http://docs.oracle.com/cd/B25516_18/current/acrobat/115sacg.zip"
    target="_blank">Oracle Applications System Administrators Guide</a>, for more information.<BR>
    For additional solutions for distributing the workload of responding to SYSADMIN Error Notifications to other groups or individuals using WorkList Access or Notification Routing Rules, please review :<br>
    [1448095.1] - How to handle or reassign System : Error (WFERROR) Notifications that default to SYSADMIN.<br>',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      ); 
debug('end add_signature: WF2_SYSADMIN3');



debug('begin add_signature: WF2_NTF_ERROR_1');
  add_signature(
      p_sig_id                 => 'WF2_NTF_ERROR_1',
      p_sig_sql                => 'select n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN'') CLOSED,
	n.STATUS, n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference NTF_PREF,
	r.email_address, ''<div align="right">''||to_char(count(n.notification_id),''999,999,999,999'')||''</div>'' "Count"
	from wf_notifications n, wf_local_roles r
	where n.recipient_role = r.name
	and n.message_type like ''%ERROR%''
	group by n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN''), n.STATUS,
	n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference, r.email_address
	order by nvl(to_char(n.end_date, ''YYYY''),''OPEN''), count(n.notification_id) desc, n.recipient_role',
      p_title                  => 'Workflow Error Notifications by Type',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are rows found',
      p_solution               => '',
      p_success_msg            => 'There are less that 100 Error Notifications found on this '||g_rep_info('Instance')||' instance.<BR>
     Keep up the good work.... You deserve a piece of pie.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_NTF_ERROR_1');



debug('begin add_signature: WF7_WF_DEFERRED_M');
  add_signature(
      p_sig_id                 => 'WF7_WF_DEFERRED_M',
      p_sig_sql                => 'select a.user_data.itemtype "Item Type", a.user_data.actid "Activity ID", 
	a.msg_state "Msg State", 
	''<div align="right">''||wpa.process_name||''</div>'' "Process Label", 
	''<div align="left">''||wpa.instance_label||''</div>'' "Activity Label", 
	''<div align="right">''||to_char(count(a.user_data.itemkey),''999,999,999,999'')||''</div>'' "Count"
	  from applsys.aq$wf_deferred_table_m a, wf_process_activities wpa 
	 where a.user_data.itemtype in (''OEOH'',''OEOL'',''OMERROR'',''OEOI'',''OECOGS'',''OEOA'', ''OECHGORD'',''OEON'',''OEBH'') 
	   and a.user_data.itemtype= wpa.process_item_type 
	   and a.user_data.actid=wpa.instance_id
	group by a.user_data.itemtype, a.user_data.actid, a.msg_state, wpa.process_name, wpa.instance_label
	order by count(a.user_data.itemkey) desc',
      p_title                  => 'Deferred Order Management Activities in Workflow Background Engine Table (WF_DEFERRED_TABLE_M)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Deferred Order Management Activities in Workflow Background Engine Table (WF_DEFERRED_TABLE_M)',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_WF_DEFERRED_M');



debug('begin add_signature: WF2_SYSADMIN4');
  add_signature(
      p_sig_id                 => 'WF2_SYSADMIN4',
      p_sig_sql                => 'select name, notification_preference, nvl(email_address,''NOTSET'') "EMAIL ADDRESS" from wf_local_roles where name = ''SYSADMIN''',
      p_title                  => 'SYSADMIN User Setup for Error Notifications',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'The SYSADMIN User appears to be setup to receive email notifications.',
      p_solution               => 'Please verify that the email_address ('||g_sysadmin_email||') is a valid email address and can recieve emails successully.<br>
    Also, please verify that the SYSADMIN User is actively processing the '||to_char(g_errorntfcnt,'999,999,999,999')||' Error Notifications that are currently assigned to this user. <br><br>
    Please review System Administration Setup Tasks in the <a href="http://docs.oracle.com/cd/B25516_18/current/acrobat/115sacg.zip"
    target="_blank">Oracle Applications System Administrators Guide</a>, for more information.<BR>
    For additional solutions for distributing the workload of responding to SYSADMIN Error Notifications to other groups or individuals using WorkList Access or Notification Routing Rules, please review :<br>
    [1448095.1] - How to handle or reassign System : Error (WFERROR) Notifications that default to SYSADMIN.<br>',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_SYSADMIN4');



debug('begin add_signature: WF2_DISABLED4');
  add_signature(
      p_sig_id                 => 'WF2_DISABLED4',
      p_sig_sql                => 'select notification_preference, status, ''<div align="right">''||to_char(count(name),''999,999,999,999'')||''</div>'' "Count"
	 from wf_local_roles
	 where name not like ''FND_RESP%''
	 and user_flag = ''Y''
	 group by notification_preference, status
	 order by status, notification_preference',
      p_title                  => 'Check for DISABLED Notification Preferences',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Notification Preferences set in this instance',
      p_solution               => '',
      p_success_msg            => '<b>There are a large number of active Users with DISABLED notification preferences!</B><br>
	 <br>It is recommended that these are looked into....<br>
	 Please verify the email addresses for the '||to_char((g_disabled_cnt),'999,999,999,999')||' active Users that have DISABLED notification preference using : 
	    <blockquote><i>select name, display_name, description, status, <br>
	    orig_system, email_address, notification_preference<br>
	    from wf_local_roles<br>
	    where notification_preference = ''DISABLED''<br>
		and status = ''ACTIVE''<br>
	    and user_flag = ''Y'';</i></blockquote>
	 For R12.2+ there is a new Concurrent program "Workflow Directory Services Bulk Reset DISABLED Notification Preference" (FNDWFBULKRESETNTFPREF).<br>
	 This program lets you reset the notification preference from DISABLED back to the original value for multiple users at once.<br>
	 Please additional information, please review [1326359.1] - Workflow Notification Email Preference is Disabled: How to Troubleshoot and Repair',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );	debug('end add_signature: WF2_DISABLED4');



debug('begin add_signature: WF2_WFADMIN_RESP_ZERO');
  add_signature(
      p_sig_id                 => 'WF2_WFADMIN_RESP_ZERO',
      p_sig_sql                => 'select r.name, r.display_name, r.status, r.notification_preference, nvl(r.email_address,''NOTSET'') "EMAIL ADDRESS" 
	from wf_roles r, wf_resources res 
	where res.name = ''WF_ADMIN_ROLE''
	and res.language = ''US''
	and res.text = r.NAME',
      p_title                  => 'Workflow Administrator Role',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>The Workflow Administrator Role is set to Responsibility '||g_wfadmin_display||', with no active users!</b>',
      p_solution               => 'The Workflow Administrator role (WF_ADMIN_ROLE) for '||g_rep_info('Instance')||' is set to Responsibility ('||g_wfadmin_role||') also known 
	 as '||g_wfadmin_display||', and there are no Users assigned to this Responsibility, so noone has Workflow Administrator Role permissions on this instance.<BR><br>
     Please assign someone this responsibility.',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_WFADMIN_RESP_ZERO');



debug('begin add_signature: WF2_WF_ERROR_NTFS4');
  add_signature(
      p_sig_id                 => 'WF2_WF_ERROR_NTFS4',
      p_sig_sql                => 'select n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN'') CLOSED,
	n.STATUS, n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference NTF_PREF,
	r.email_address, ''<div align="right">''||to_char(count(n.notification_id),''999,999,999,999'')||''</div>'' "Count"
	from wf_notifications n, wf_local_roles r
	where n.recipient_role = r.name
	and n.message_type like ''%ERROR%''
	group by n.message_type, n.MESSAGE_NAME, nvl(to_char(n.end_date, ''YYYY''),''OPEN''), n.STATUS,
	n.recipient_role, r.STATUS, r.ORIG_SYSTEM, r.notification_preference, r.email_address
	order by nvl(to_char(n.end_date, ''YYYY''),''OPEN''), count(n.notification_id) desc, n.recipient_role',
      p_title                  => 'Workflow Error Notification Messages Summary Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<b>There are ' || to_char(g_total_error,'999,999,999,999') || ' Error Notifications found on '||g_rep_info('Instance')||', 
	where ' || to_char(g_open_error,'999,999,999,999') || ' (' || (round(g_open_error/g_total_error,2)*100) || '%) are still OPEN, 
	and '|| to_char(g_closed_error,'999,999,999,999') || ' are closed.</b><BR>',
      p_solution               => 'These error notifications need to be viewed, corrected, and closed so their workflows can be completed and purged.<br><br>
On a good note, there are ZERO OPEN system generated (DEFAULT_EVENT%ERROR%) notifications found on '||g_rep_info('Instance')||', so all of the existing error notifications belong to a parent workflow processes and are not generated by the SYSTEM.<br>
Please review [760386.1] - How to enable Bulk Notification Response Processing for Workflow in 11i and R12, for more details on ways to do this.',
      p_success_msg            => '<B>Well Done !!</b><BR>
	There are no Error Notifications found on '||g_rep_info('Instance')||'.<br>
        Additionally, there are ZERO OPEN system generated (DEFAULT_EVENT%ERROR%) notifications.<br>
	You deserve a whole cake!!!<BR>',	
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );



debug('end add_signature: WF2_WF_ERROR_NTFS4');



debug('begin add_signature: WF9_PO_WF_IN_ERR');
  add_signature(
      p_sig_id                 => 'WF9_PO_WF_IN_ERR',
      p_sig_sql                => 'select  
	STA.ITEM_TYPE "ITEM_TYPE", STA.ACTIVITY_RESULT_CODE "RESULT",
	''<div align="right">''||PRA.PROCESS_NAME||''</div>'' "PROCESS_LABEL",
	''<div align="left">''||PRA.INSTANCE_LABEL||''</div>'' "ACTIVITY_LABEL",
	''<div align="right">''||to_char(count(*),''999,999,999,999'')||''</div>'' "ROWS"
	from  WF_ITEM_ACTIVITY_STATUSES  STA, WF_PROCESS_ACTIVITIES PRA
	where STA.ACTIVITY_STATUS = ''ERROR''
	and STA.PROCESS_ACTIVITY = PRA.INSTANCE_ID
	and STA.ITEM_TYPE in (''POAPPRV'',''REQAPPRV'',''POXML'',''POWFRQAG'',''PORCPT'',''APVRMDER'',''PONPBLSH'',''POSPOACK'',''PONAUCT'',''PORPOCHA'',''PODSNOTF'',''POSREGV2'',''POREQCHA'',''POWFPOAG'',''POSCHORD'',''POSASNNB'',''PONAPPRV'',''POSCHPDT'',''POAUTH'',''POWFDS'',''POERROR'',''POSBPR'',''CREATEPO'')
	group by STA.ITEM_TYPE, STA.ACTIVITY_RESULT_CODE, PRA.PROCESS_NAME, PRA.INSTANCE_LABEL
	order by STA.ITEM_TYPE, to_char(count(*)) desc',
      p_title                  => 'Purchasing Workflows in Error',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Purchasing Workflows in Error at this time.',
      p_solution               => 'Use bde_wf_err.sql script from [255045.1] to get details of any erroring activities.<BR>
	PO Exception6 management allows to retry failing PO activities. <BR>
	See [458216.1] - How To Retry Multiple Errored Approval Workflow Processes After A Fix Or Patch Has Been Implemented.<br>
	Also see [947141.1] - How to Mass Retry Errored Workflows?<br>',
      p_success_msg            => '<B>Excellent !!</B><BR>
     There are no Purchasing Workflows in Error.<BR>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_PO_WF_IN_ERR');



debug('begin add_signature: WF9_PO_LOOPING4');
  add_signature(
      p_sig_id                 => 'WF9_PO_LOOPING4',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", ''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key 
	 AND wfi.item_type in (''POAPPRV'',''REQAPPRV'',''POXML'',''POWFRQAG'',''PORCPT'',''APVRMDER'',''PONPBLSH'',''POSPOACK'',''PONAUCT'',''PORPOCHA'',''PODSNOTF'',''POSREGV2'',''POREQCHA'',''POWFPOAG'',''POSCHORD'',''POSASNNB'',''PONAPPRV'',''POSCHPDT'',''POAUTH'',''POWFDS'',''POERROR'',''POSBPR'',''CREATEPO'') 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Purchasing Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Purchasing Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running Order Management Workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||po_hist_item||'<br>
	 item_key : '||po_hist_key||'<BR><BR>
	 This process has been closed since '||po_hist_end||'.<br><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(po_hist_days,'999,999')||' days, which is about '||to_char(po_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) for Purchasing  that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_PO_LOOPING4');



debug('begin add_signature: WF1_DB_PARAMS4');
  add_signature(
      p_sig_id                 => 'WF1_DB_PARAMS4',
      p_sig_sql                => 'select name, value
    from v$parameter
    where upper(name) in (''AQ_TM_PROCESSES'',''JOB_QUEUE_PROCESSES'',''JOB_QUEUE_INTERVAL'',
    ''UTL_FILE_DIR'',''NLS_LANGUAGE'', ''NLS_TERRITORY'', ''CPU_COUNT'',
    ''PARALLEL_THREADS_PER_CPU'')',
      p_title                  => 'Workflow Database Parameter Settings',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>JOB_QUEUE_PROCESSES for '||g_rep_info('Instance')||' on ('||g_rep_info('DB Version')||') databases is less than 2!</B><BR>
    Oracle Workflow requires job queue processes to handle propagation of Business Event System event messages by AQs.',
      p_solution               => '<B>Significance of the JOB_QUEUE_PROCESSES for 11gR1+ ('||g_rep_info('DB Version')||') databases:</B><BR><BR>
    Starting from 11gR1, The init.ora parameter job_queue_processes does NOT need to be set for AQ propagations.
    AQ propagation is now likewise handled by DBMS_SCHEDULER jobs rather than DBMS_JOBS.
    Reason: propagation takes advantage of the event based scheduling features of DBMS_SCHEDULER for better scalability. <br><br>
<b>JOB_QUEUE_PROCESSES is recommended to be be set to a value of 2 or higher, for optimal performance. </b>  <i>See [396009.1]</i><br><br>
This value can be tuned to meet the specific requirements of the Workflow module and customer needs,
based on the number of job queue processes needed to handle AQ event messages and for Workflow notification mailers.<br>
    If the value of the JOB_QUEUE_PROCESSES database initialization parameter is non-zero, it effectively becomes the maximum number of Scheduler jobs and job queue jobs than can run concurrently. 
    If a non-zero value is set, it should be large enough to accommodate a Scheduler job for each Messaging Gateway agent to be started.<BR><br>

Starting in 11gR2, if job_queue_processes is set to 0 all job processes are stopped, which means that DBMS_SCHEDULER jobs, autotask jobs and DBMS_JOB jobs cannot run.
Whereas in previous versions, only DBMS_JOB jobs were disabled after changing job_queue_processes to 0, therefore, always make sure to set job_queue_processes to a non zero value to allow the scheduler jobs and autotask jobs to work.
<BR><BR>     

    To determine the proper setting of JOB_QUEUE_PROCESSES for Oracle Workflow, follow the queries outlined in <BR>
    [578831.1] - How to determine the correct setting for JOB_QUEUE_PROCESSES.<br><br>
	To manually update the JOB_QUEUE_PROCESSES database parameter file (init.ora) file:
    <ul><i>job_queue_processes=2</i></ul>
    or set dynamically via
    <ul><i>connect / as sysdba<br>alter system set job_queue_processes=2;</i></ul>Remember that after bouncing the DB, dynamic changes are lost, and the DB parameter file settings are used.<BR>',
      p_success_msg            => 'There is a problem identifying the Workflow Database Parameter Settings',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF1_DB_PARAMS4');



debug('begin add_signature: WF7_ONT_LOOPING4');
  add_signature(
      p_sig_id                 => 'WF7_ONT_LOOPING4',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", ''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key AND wfi.item_type in (''OEOH'',''OEOL'',''OMERROR'',''OEOI'',''OECOGS'', ''OEOA'',''OECHGORD'',''OEON'',''OEBH'') 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Order Management Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Order Management Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running Order Management Workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||ont_hist_item||'<br>
	 item_key : '||ont_hist_key||'<BR><BR>
	 This process has been closed since '||ont_hist_end||'.<br><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(ont_hist_days,'999,999')||' days, which is about '||to_char(ont_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) for Order Management that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_ONT_LOOPING4');



debug('begin add_signature: WF8_HCM_LOOPING4');
  add_signature(
      p_sig_id                 => 'WF8_HCM_LOOPING4',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", 
	''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key 
	 AND wfi.item_type in (''BENCWBFY'',''SSBEN'',''GHR_SF52'',''HXCEMP'',''HXCSAW'',''IRC_NTF'', ''IRCOFFER'',''OTWF'',''PYASGWF'',''HRCKLTSK'',''HRSSA'',''HRWPM'',''HRRIRPRC'',''PSPERAVL'') 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Human Resources Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Human Resources Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running Order Management Workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||hcm_hist_item||'<br>
	 item_key : '||hcm_hist_key||'<BR><BR>
	 This process has been closed since '||hcm_hist_end||'.<br><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(hcm_hist_days,'999,999')||' days, which is about '||to_char(hcm_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) for Human Resources that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF8_HCM_LOOPING4');



debug('begin add_signature: WF5_WF_ORPHAN_STATUS4');
  add_signature(
      p_sig_id                 => 'WF5_WF_ORPHAN_STATUS4',
      p_sig_sql                => 'select WN.MESSAGE_TYPE, wn.MESSAGE_NAME, wit.persistence_type PERSISTENCE, to_char(count(wn.notification_id),''999,999,999,999'') "COUNT"
	from WF_NOTIFICATIONS WN, WF_ITEM_TYPES WIT
	where wn.message_type = wit.name 
	and not exists (select NULL from WF_ITEM_ACTIVITY_STATUSES WIAS
	where WIAS.NOTIFICATION_ID = WN.GROUP_ID)
	and not exists (select NULL from WF_ITEM_ACTIVITY_STATUSES_H WIAS
	where WIAS.NOTIFICATION_ID = WN.GROUP_ID)
	and wn.end_date is null
	group by wn.message_type, wn.MESSAGE_NAME, wit.persistence_type
	order by wit.persistence_type, count(notification_id) desc',
      p_title                  => 'Check for Open Orphaned Notifications',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Open Orphaned or Unreferenced Notifications found!<BR><BR>',
      p_solution               => 'It does not appear that patch 3104909 is applied to this instance, so please download and apply Patch 3104909 and then 
	 run wfntfprg.sql to remove unreferenced notifications by following the instructions on the script header.<br> 
	 For purging FNDCMMSG, XDPWFSTD, etc (which are PERMANENT) type of notifications, please uncomment the line 
	 ( Wf_Purge.Persistence_Type := "PERM" ) in the wfntfprg.sql as this type of message is of type PERMANENT persistence.<br>
	 This should do the trick.<BR>',
      p_success_msg            => '<B>Well Done !!<BR><BR>
     There are ZERO open Orphaned or Unreferenced Workflow Notifications found !</B><br>
     Keep up the good work!!!<br><br>
	 In Oracle Workflow Notification System, there could be Notifications in the wf_notifications table without corresponding Workflow Item Status records in 
     wf_item_activity_statuses or wf_item_activity_statuses_h tables.<br>
     This could have resulted from a bug or due to sending FYI notifications outside of a Workflow Process.<br>
     Oracle Workflow provides a script <i><b>$FND_TOP/sql/wfntfprg.sql</b></i> which closes and purges such orphan notifications older than a given number of days.<br>
     For earlier releases of 11i, the script is available via patch 3104909, which we check has already been applied.<br>
     <p>For more information refer to [453137.1] - Oracle Workflow Best Practices Release 12 and Release 11i<br>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF5_WF_ORPHAN_STATUS4');



debug('begin add_signature: WF5_CONC_TIER_ENV');
  add_signature(
      p_sig_id                 => 'WF5_CONC_TIER_ENV',
      p_sig_sql                => 'select VARIABLE_NAME, VALUE 
	from FND_ENV_CONTEXT 
	where CONCURRENT_PROCESS_ID in 
	(select max(CONCURRENT_PROCESS_ID) from FND_CONCURRENT_PROCESSES
	where CONCURRENT_QUEUE_ID in (select CONCURRENT_QUEUE_ID from FND_CONCURRENT_QUEUES where CONCURRENT_QUEUE_NAME = ''WFMLRSVC'')
	and QUEUE_APPLICATION_ID in (select APPLICATION_ID from FND_APPLICATION
	where APPLICATION_SHORT_NAME = ''FND''))
	and VARIABLE_NAME in (''APPL_TOP'', ''APPLCSF'', ''APPLLOG'', ''FND_TOP'', ''AF_CLASSPATH'', ''AFJVAPRG'', ''AFJRETOP'', ''CLASSPATH'', ''PATH'', 
	''LD_LIBRARY_PATH'', ''ORACLE_HOME'')
	order by VARIABLE_NAME',
      p_title                  => 'Concurrent Tier Environment Settings for the Java Mailer',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'The Concurrent Tier Environment does not appear to be setup.',
      p_solution               => '',
      p_success_msg            => 'Displaying Concurrent Tier Environment settings for review.<br>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF5_CONC_TIER_ENV');



debug('begin add_signature: WF3_WF_SUMMARY2');
  add_signature(
      p_sig_id                 => 'WF3_WF_SUMMARY2',
      p_sig_sql                => 'select 
	''<div align="right">''||to_char(NUM_ACTIVE,''999,999,999,999'')||''</div>''  "ACTIVE", 
	''<div align="right">''||to_char(NUM_COMPLETE,''999,999,999,999'')||''</div>'' "COMPLETED", ''<div align="right">''||to_char(NUM_PURGEABLE,''999,999,999,999'')||''</div>'' "PURGEABLE",	 WIT.NAME "ITEM_NAME", DISPLAY_NAME "DISPLAY_NAME", 
	 PERSISTENCE_TYPE "PERSISTENCE_TYPE", PERSISTENCE_DAYS "PERSISTENCE_DAYS", 
	 ''<div align="right">''||to_char(NUM_ERROR,''999,999,999,999'')||''</div>'' "ERRORED", ''<div align="right">''||to_char(NUM_DEFER,''999,999,999,999'')||''</div>'' "DEFERRED", ''<div align="right">''||to_char(NUM_SUSPEND,''999,999,999,999'')||''</div>'' "SUSPENDED"
	 from wf_item_types wit, wf_item_types_tl wtl
	 where wit.name like (''%'')
	 AND wtl.name = wit.name
	 AND wtl.language = userenv(''LANG'')
	 AND wit.NUM_ACTIVE is not NULL
	 AND wit.NUM_ACTIVE <>0 
	 order by PERSISTENCE_TYPE, NUM_COMPLETE desc',
      p_title                  => 'Summary of Workflow Processes By Item Type',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no rows showing',
      p_solution               => '',
      p_success_msg            => '<b>Post 11i.ATG.rup4+, there are 3 new Concurrent Programs designed to gather Workflow Statistics that is displayed in OAM Workflow Manager - Workflow Metrics screens.<BR></b>
    These Concurrent Programs are set to run automatically every 24 hrs by default to refresh these workflow runtime table statistics.<BR>
    <li><B>Workflow Agent Activity Statistics (FNDWFAASTATCC)</B> - Gathers statistics for the Agent Activity graph in the Workflow System status page and for the agent activity list in the Agent Activity page.</li>
    <li><B>Workflow Mailer Statistics (FNDWFMLRSTATCC)</B> - Gathers statistics for the throughput graph in the Notification Mailer Throughput page.</li>
    <li><B>Workflow Work Items Statistics (FNDWFWITSTATCC)</B> - Gathers statistics for the Work Items graph in the Workflow System status page, for 
    the Completed Work Items list in the Workflow Purge page, and for the work item lists in the Active Work Items, Deferred Work Items, Suspended Work Items, and Errored Work Items pages.</li>
    If the list above does not match the list below, then please run these Workflow Statistics requests again.<BR><br>
    <b>Note: <br>There is not enough data to determine the last time FNDWFWITSTATCC was successfully run.</b><BR>
    Perhaps the request has not been run in a long time or all recent data has been purged.<BR>
    To refresh this data, please run the concurrent program Workflow Work Items Statistics (FNDWFWITSTATCC).',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','N'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_SUMMARY2');



debug('begin add_signature: WF3_WF_PURGEABLE');
  add_signature(
      p_sig_id                 => 'WF3_WF_PURGEABLE',
      p_sig_sql                => 'select 
	''<div align="right">''||to_char(COUNT(A.ITEM_KEY),''999,999,999,999'')||''</div>'' "CLOSED ITEMS", ''<div align="right">''||to_char(WF_PURGE.GETPURGEABLECOUNT(A.ITEM_TYPE),''999,999,999,999'')||''</div>'' "PURGEABLE",
	 A.ITEM_TYPE "ITEM TYPE", b.DISPLAY_NAME "DISPLAY NAME", b.PERSISTENCE_DAYS "PERSISTENCE DAYS"
	 FROM WF_ITEMS A, WF_ITEM_TYPES_VL B
	 WHERE A.ITEM_TYPE = B.NAME
	 and b.PERSISTENCE_TYPE = ''TEMP''
	 and a.END_DATE is not null
	 GROUP BY A.ITEM_TYPE, b.DISPLAY_NAME, b.PERSISTENCE_DAYS
	 order by 1 desc',
      p_title                  => 'Verify Closed and Purgeable TEMP Items',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Closed or Purgeable TEMP Items running in this instance',
      p_solution               => '',
      p_success_msg            => 'This table displays counts for ALL TEMPORARY persistence workflow item types that are closed... ie end_date is not null.<br>
	 It also shows how many of these closed workflows are eligible for purging, meaning if you ran the Purge Obsolete Workflow Runtime Data (FNDWFPR) now REM for TEMP items, they will be purged.<br><br>
	 If there are closed items that are not purgeable, (ie CLOSED ITEMS>PURGEABLE) then it may be because an associated child process is still open.<BR>To verify the end-dates of all workflows (item_keys) that are associated to a single workflow process, run the bde_wf_process_tree.sql
	 script found in [1378954.1] - bde_wf_process_tree.sql - For analyzing the Root Parent, Children, Grandchildren Associations of a Single Workflow Process',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','N'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_PURGEABLE');



debug('begin add_signature: WF4_WFBGINDX');
  add_signature(
      p_sig_id                 => 'WF4_WFBGINDX',
      p_sig_sql                => 'select index_name
	 from dba_ind_columns
	 where table_name like ''%WF_DEFERRED_TABLE_M%''
	 and index_name = ''WF_DEFERRED_TABLE_M_N1''
	 and index_owner = ''APPLSYS''',
      p_title                  => 'Verify Workflow Background Table Index exists',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<B>The Index: WF_DEFERRED_TABLE_M_N1 for Workflow Background Processing on table WF_DEFERRED_TABLE_M does not exist.</B>',
      p_solution               => 'It can be created as follows:<br><br>
     <i>CREATE INDEX WF_DEFERRED_TABLE_M_N1 ON WF_DEFERRED_TABLE_M(CORRID)<br>
     STORAGE (INITIAL 1M NEXT 1M MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0) TABLESPACE <tablespacename>;</i><br><br>
     For more information refer to [466535.1] - How to Resolve the Most Common Workflow Background Engine Problems<br>',
      p_success_msg            => 'The Background Process Index: WF_DEFERRED_TABLE_M_N1 on WF_DEFERRED_TABLE_M exists as expected.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','N'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_WFBGINDX');



debug('begin add_signature: WF4_WF_SCHED_CP4');
  add_signature(
      p_sig_id                 => 'WF4_WF_SCHED_CP4',
      p_sig_sql                => 'select r.REQUEST_ID "REQUEST_ID", u.user_name "REQUESTED_BY", r.PHASE_CODE "PHASE", r.ACTUAL_START_DATE "STARTED",
	 c.CONCURRENT_PROGRAM_NAME "INTERNAL NAME", p.USER_CONCURRENT_PROGRAM_NAME "PROGRAM_NAME", r.ARGUMENT_TEXT "ARGUMENTS", 
	 r.RESUBMIT_INTERVAL "EVERY", r.RESUBMIT_INTERVAL_UNIT_CODE "SO_OFTEN", r.RESUBMIT_END_DATE "RESUBMIT_END_DATE"
	 FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
	 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
	 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
	 and c.CONCURRENT_PROGRAM_NAME in (''FNDWFBG'',''FNDWFPR'',''FNDWFRET'',''JTFRSWSN'',''FNDWFSYNCUR'',''FNDWFLSC'', 
	 ''FNDWFLIC'',''FNDWFDSURV'',''FNDCPPUR'',''FNDWFBES_CONTROL_QUEUE_CLEANUP'',''FNDWFAASTATCC'',''FNDWFMLRSTATCC'',
	 ''FNDWFWITSTATCC'',''FNDWFBULKRESETNTFPREF'') 
	 AND p.language = ''US'' 
	 and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in (''P'',''R'')
	 order by c.CONCURRENT_PROGRAM_NAME, r.ARGUMENT_TEXT',
      p_title                  => 'Verify Workflow Concurrent Programs Scheduled to Run',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<B>There are no Workflow Background Processes (FNDWFBG) scheduled to run for ALL Item_Types!</b>',
      p_solution               => 'Workflow Development recommends scheduling a Workflow Background Process to identify STUCK Activities once a week to once a month, when the load on the system is low.<BR>
	Stuck activities do not have a clear pattern of cause but mainly they are caused by flaws in the WF definition like improper transition definitions.<br> 
	<b>The query to determine activities that are STUCK is very expensive</b> as it joins 3 WF runtime tables and one WF design table. <br>
	This is why the Workflow Background Engine should run to identify STUCK Activities SEPARATELY and ONLY when load is low and maybe once a week or as your business requires.<br><br>
	<B>Please schedule the concurrent request "Workflow Background Process" to process deferred, timed-out, and identify stuck activities for ALL item_types using the guidelines listed above.</B><br>
	At a minimum, there needs to be at least one background process that can handle both deferred and timed-out activities in order to progress workflows.<BR><BR>
	For more information refer to [466535.1] - How to run the Workflow Background Engine per developments recommendations.<br><br>
    <b>The Workflow Administrators Guide requires that there is at least one background engine that can process deferred activities, check for  timed-out activities, and identify stuck processes.</b><br>
	At a minimum, there needs to be at least one background process that can handle both deferred and timed-out activities in order to progress workflows.<br>
	However, for performance reasons Oracle recommends running three (3) separate background engines at different intervals.<br>
	<ol><li><b>Run a Background Process to handle only DEFERRED activities every 5 to 60 minutes.</b></li>
		<li><b>Run a Background Process to handle only TIMED-OUT activities every 1 to 24 hours as needed.</b></li>
	- Timed-out and stuck activities are not processed from the queue but from the table directly, so Timed-out and stuck activities do not have a representing message in queue WF_DEFERRED_TABLE_M.<br>
	- For this reason they need to be queried up from the runtime tables and progressed as needed. When those records are found the internal Engine APIs are called to progress those workflows further.<br>
	- Timed-out activities are checked in table WF_ITEM_ACTIVITY_STATUSES when their status is ACTIVE, WAITING , NOTIFIED, SUSPEND, or DEFERRED.
	- This query on the table is strightforward and no performance issues are expected here.<br> 
	<li><b>Run a Background Process to identify STUCK Activities once a week to once a month, when the load on the system is low.</b></li>
	- Stuck activities do not have a clear pattern as cause but mainly they are caused by flaws in the WF definition like improper transition definitions.<br>
	- The query to determine activities that are STUCK is very expensive as it joins 3 WF runtime tables and one WF design table. <br>
	- This is why the Workflow Background Engine should run to identify STUCK Activities SEPARATELY and ONLY when load is not high and maybe once a week or so.<br>
	</ol>
	Please see [186361.1] - Workflow Background Process Performance Troubleshooting Guide for more information',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_WF_SCHED_CP4');



debug('begin add_signature: WF4_WF_GRAPHMONITOR_VER');
  add_signature(
      p_sig_id                 => 'WF4_WF_GRAPHMONITOR_VER',
      p_sig_sql                => 'select sub.subdir, sub.filename, sub.version
                from (
                   select adf.subdir, adf.filename filename,
                   afv.version version,
                   rank()over(partition by adf.filename
                     order by afv.version_segment1 desc,
                     afv.version_segment2 desc,afv.version_segment3 desc,
                     afv.version_segment4 desc,afv.version_segment5 desc,
                     afv.version_segment6 desc,afv.version_segment7 desc,
                     afv.version_segment8 desc,afv.version_segment9 desc,
                     afv.version_segment10 desc,
                     afv.translation_level desc) as rank1
                   from ad_file_versions afv,
                     (
                     select filename, app_short_name, subdir, file_id
                     from ad_files
                     where upper(filename) like upper(''%GraphMonitorCO.class'') and subdir like ''%webui%''
                     ) adf
                   where adf.file_id = afv.file_id
                ) sub
                where rank1 = 1
                order by sub.filename',
      p_title                  => 'Check the Version of GraphMonitorCO.class',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There is a problem finding the version of GraphMonitorCO.class.',
      p_solution               => 'You got a problem.',
      p_success_msg            => 'Currently this is the latest version of GraphMonitorCO.class.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: WF4_WF_GRAPHMONITOR_VER');



debug('begin add_signature: WF4_FNDWFPR_RAN');
  add_signature(
      p_sig_id                 => 'WF4_FNDWFPR_RAN',
      p_sig_sql                => 'select r.REQUEST_ID "REQUEST ID", u.user_name "USER NAME", p.USER_CONCURRENT_PROGRAM_NAME "PROGRAM",
	 DECODE(r.STATUS_CODE, ''A'',''Waiting'',''B'',''B=Resuming'',''C'',''C=Normal'',
	 ''D'',''D=Cancelled'',''E'',''E=Error'',''G'',''G=Warning'',
	 ''H'',''H=On Hold'',''I'',''I=Normal'',''M'',''M=No Manager'',
	 ''P'',''P=Scheduled'',''Q'',''Q=Standby'',''R'',''R=Normal'',
	 ''S'',''S=Suspended'',''T'',''T=Terminating'',''U'',''U=Disabled'',
	 ''W'',''W=Paused'',''X'',''X=Terminated'',''Z'',''Z=Waiting'') "STATUS",
	 DECODE(r.PHASE_CODE, ''C'',''Completed'',''I'',''I=Inactive'',''P'',''P=Pending'',''R'',''R=Running'') "PHASE",
	 r.ACTUAL_START_DATE "STARTED", r.ACTUAL_COMPLETION_DATE "COMPLETED",
	 ROUND((r.actual_completion_date - r.actual_start_date)*1440, 2) "TOTAL MINS",
	 FLOOR(((r.actual_completion_date-r.actual_start_date)*24*60*60)/3600)||'':hrs ''||	FLOOR((((r.actual_completion_date-r.actual_start_date)*24*60*60)-FLOOR(((r.actual_completion_date-r.actual_start_date)*24*60*60)/3600)*3600)/60)||'':Mins ''||ROUND((((r.actual_completion_date-r.actual_start_date)*24*60*60)-FLOOR(((r.actual_completion_date-r.actual_start_date)*24*60*60)/3600)*3600-(FLOOR((((r.actual_completion_date-r.actual_start_date)*24*60*60)-FLOOR(((r.actual_completion_date-r.actual_start_date)*24*60*60)/3600)*3600)/60)*60)))||'':Secs'' "TIME TO RUN", 
	 r.ARGUMENT_TEXT "ARGUMENTS" FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
	 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
	 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
	 and c.CONCURRENT_PROGRAM_NAME = (''FNDWFPR'') 
	 AND p.language = ''US'' 
	 and r.ACTUAL_COMPLETION_DATE is not null
	 order by r.ACTUAL_START_DATE desc',
      p_title                  => 'Verify (last 30) Workflow Purge Concurrent Programs that have completed',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<B>There are no Concurrent Programs purging Workflow Runtime Data (FNDWFPR) found!</b>',
      p_solution               => '<B>Please schedule the concurrent request "Purge Obsolete Workflow Runtime Data" to process deferred, timed-out, and identify stuck activities for ALL item_types using the guidelines listed above.</B><br>
	At a minimum, there needs to be at least one background process that can handle both deferred and timed-out activities in order to progress workflows.<BR><BR>
	For more information refer to [466535.1] - How to run the Workflow Background Engine per developments recommendations.<br><br>
    <b>The Workflow Administrators Guide requires that there is at least one background engine that can process deferred activities, check for  timed-out activities, and identify stuck processes.</b><br>
	At a minimum, there needs to be at least one background process that can handle both deferred and timed-out activities in order to progress workflows.<br>
	However, for performance reasons Oracle recommends running three (3) separate background engines at different intervals.<br>
	<ol><li><b>Run a Background Process to handle only DEFERRED activities every 5 to 60 minutes.</b></li>
		<li><b>Run a Background Process to handle only TIMED-OUT activities every 1 to 24 hours as needed.</b></li>
	- Timed-out and stuck activities are not processed from the queue but from the table directly, so Timed-out and stuck activities do not have a representing message in queue WF_DEFERRED_TABLE_M.<br>
	- For this reason they need to be queried up from the runtime tables and progressed as needed. When those records are found the internal Engine APIs are called to progress those workflows further.<br>
	- Timed-out activities are checked in table WF_ITEM_ACTIVITY_STATUSES when their status is ACTIVE, WAITING , NOTIFIED, SUSPEND, or DEFERRED.
	- This query on the table is strightforward and no performance issues are expected here.<br> 
	<li><b>Run a Background Process to identify STUCK Activities once a week to once a month, when the load on the system is low.</b></li>
	- Stuck activities do not have a clear pattern as cause but mainly they are caused by flaws in the WF definition like improper transition definitions.<br>
	- The query to determine activities that are STUCK is very expensive as it joins 3 WF runtime tables and one WF design table. <br>
	- This is why the Workflow Background Engine should run to identify STUCK Activities SEPARATELY and ONLY when load is not high and maybe once a week or so.<br>
	</ol>
	Please see [186361.1] - Workflow Background Process Performance Troubleshooting Guide for more information',
      p_success_msg            => 'The above table displays Concurrent requests that HAVE run and completed, regardless of how they were scheduled (DBMS_JOBS, CONSUB, or PL/SQL, etc), also keep in mind how often the Concurrent Requests Data is being purged.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_FNDWFPR_RAN');



debug('begin add_signature: WF2_DISABLED5');
  add_signature(
      p_sig_id                 => 'WF2_DISABLED5',
      p_sig_sql                => 'select notification_preference, status, ''<div align="right">''||to_char(count(name),''999,999,999,999'')||''</div>'' "Count"
	 from wf_local_roles
	 where name not like ''FND_RESP%''
	 and user_flag = ''Y''
	 group by notification_preference, status
	 order by status, notification_preference',
      p_title                  => 'Check for DISABLED Notification Preferences',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Notification Preferences set in this instance',
      p_solution               => '',
      p_success_msg            => '<B>There are '||to_char((g_disabled_cnt),'999,999,999,999')||' active Users that have their email notification preference set to DISABLED.</B><br>
	 This may be done by the users on purpose, or by the system because of a problem with a bad email address.<br>
	 <br>It is recommended to verify all the email addresses for these '||to_char((g_disabled_cnt),'999,999,999,999')||' active Users that have DISABLED notification preference using : <br>
	    <blockquote><i>select name, display_name, description, status, <br>
	    orig_system, email_address, notification_preference<br>
	    from wf_local_roles<br>
	    where notification_preference = ''DISABLED''<br>
		and status = ''ACTIVE''<br>
	    and user_flag = ''Y'';</i></blockquote>  
	 For R12.2+ there is a new Concurrent program "Workflow Directory Services Bulk Reset DISABLED Notification Preference" (FNDWFBULKRESETNTFPREF).<br>
	 This program lets you reset the notification preference from DISABLED back to the original value for multiple users at once.<br>
	 Please review [1326359.1] - Workflow Notification Email Preference is Disabled: How to Troubleshoot and Repair',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_DISABLED5');



debug('begin add_signature: WF1_DB_PARAMS5');
   add_signature(
      p_sig_id                 => 'WF1_DB_PARAMS5',
      p_sig_sql                => 'select name, value
    from v$parameter
    where upper(name) in (''AQ_TM_PROCESSES'',''JOB_QUEUE_PROCESSES'',''JOB_QUEUE_INTERVAL'',
    ''UTL_FILE_DIR'',''NLS_LANGUAGE'', ''NLS_TERRITORY'', ''CPU_COUNT'',
    ''PARALLEL_THREADS_PER_CPU'')',
      p_title                  => 'Workflow Database Parameter Settings',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There is a problem identifying the Workflow Database Parameter Settings',
      p_solution               => null,
      p_success_msg            => '<B>JOB_QUEUE_PROCESSES for '||g_rep_info('Instance')||' on pre-11gR1 ('||g_rep_info('DB Version')||') databases is 2 or more!</B><BR>
    Oracle Workflow requires job queue processes to handle propagation of Business Event System event messages by AQs.<br>
    <B>The recommended minimum number of JOB_QUEUE_PROCESSES for Oracle Workflow is 2.</B><br>
    The maximum number of JOB_QUEUE_PROCESSES is :<BR> -    36 in Oracle8i<BR> - 1,000 in Oracle9i Database and higher, so set the value of JOB_QUEUE_PROCESSES accordingly.<BR>
    <B>The ideal setting for JOB_QUEUE_PROCESSES should be set to the maximum number of jobs that would ever be run concurrently on a system PLUS a few more.</B><BR><BR>
    To determine the proper amount of JOB_QUEUE_PROCESSES for Oracle Workflow, follow the queries outlined in<BR> 
    [578831.1] - How to determine the correct setting for JOB_QUEUE_PROCESSES.<br></p>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF1_DB_PARAMS5');



debug('begin add_signature: WF4_WF_PRGSCHED_CP1');
  add_signature(
      p_sig_id                 => 'WF4_WF_PRGSCHED_CP1',
      p_sig_sql                => 'select r.REQUEST_ID "REQUEST_ID", u.user_name "REQUESTED_BY", r.PHASE_CODE "PHASE", r.ACTUAL_START_DATE "STARTED",
	 c.CONCURRENT_PROGRAM_NAME "INTERNAL NAME", p.USER_CONCURRENT_PROGRAM_NAME "PROGRAM_NAME", r.ARGUMENT_TEXT "ARGUMENTS", 
	 r.RESUBMIT_INTERVAL "EVERY", r.RESUBMIT_INTERVAL_UNIT_CODE "SO_OFTEN", r.RESUBMIT_END_DATE "RESUBMIT_END_DATE"
	 FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
	 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
	 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
	 and c.CONCURRENT_PROGRAM_NAME = ''FNDWFPR'' 
	 AND p.language = ''US'' 
	 and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in (''P'',''R'')
	 order by c.CONCURRENT_PROGRAM_NAME, r.ARGUMENT_TEXT',
      p_title                  => 'Verify Workflow Purge Concurrent Programs are Scheduled to Run',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are No Purge Obsolete Workflow Runtime Data Concurrent Requests scheduled in FND_CONCURRENT_REQUESTS to run for ALL workflow Item_Types with TEMP persistence;<br>
     However there are indications that you are scheduling or running them recently from another source, like CRON, CONSUB, or PL/SQL, etc.</B>',
      p_solution               => 'There are '||to_char((g_prgany),'999,999,999,999')||' Purge Obsolete Workflow Runtime Data Concurrent requests that have ran in the past month to purge workflow for ALL Item_Types!<br>
     Development recommends scheduling the Workflow Purge program periodically based on your business volumes.<br>',
      p_success_msg            => '<B>Nice work !!<BR>
	 There are Workflow Concurrent Processes scheduled to run to Purge Runtime Data for ALL workflow Item_Types!</b><BR><br>
	 Note: This section is only looking at the scheduled jobs in FND_CONCURRENT_REQUESTS table, so jobs scheduled using other tools (DBMS_JOBS, CONSUB, or PL/SQL, etc) are not reflected here, so keep this in mind.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_WF_PRGSCHED_CP1');



debug('begin add_signature: WF2_WFADMIN_USER');
  add_signature(
      p_sig_id                 => 'WF2_WFADMIN_USER',
      p_sig_sql                => 'select r.name, r.display_name, r.status, r.notification_preference, nvl(r.email_address,''NOTSET'') "EMAIL ADDRESS" 
	 from wf_roles r, wf_resources res 
	 where res.name = ''WF_ADMIN_ROLE''
	 and res.language = ''US''
	 and res.text = r.NAME',
      p_title                  => 'Verify the Workflow Administrator Role',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Workflow Administrator Role is set user role "'||g_wfadmin_role||'"',
      p_solution               => 'The Workflow Administrator role (WF_ADMIN_ROLE) for '||g_rep_info('Instance')||' is set to a single Applications Username or 
	 role ('||g_wfadmin_role||') also known as "'||g_wfadmin_display||'".<BR>
	 This role '||g_wfadmin_role||' has a Notification Preference of '||g_wfadmin_ntf_pref||', and email address is set to '||g_wfadmin_email||'.<BR>
	 On this instance, you must log into Oracle Applications as '||g_wfadmin_role||' to utilize the Workflow Administrator Role permissions and control any and all workflows.<BR><BR>
	 <B>Note:</B> For more information refer to [453137.1] - Oracle Workflow Best Practices Release 12 and Release 11i
	 <br><br>
	[453137.1] - Oracle Workflow Best Practices Release 12 and Release 11i',
      p_success_msg            => '', 
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_WFADMIN_USER');



debug('begin add_signature: WF8_HCM_ERRORS');
  add_signature(
      p_sig_id                 => 'WF8_HCM_ERRORS',
      p_sig_sql                => 'select STA.ITEM_TYPE "Item Type", STA.ACTIVITY_RESULT_CODE "Result", 
	''<div align="right">''||PRA.PROCESS_NAME||''</div>'' "Process Label",
	''<div align="left">''||PRA.INSTANCE_LABEL||''</div>'' "Activity Label", 
	''<div align="right">''||to_char(count(*),''999,999,999,999'')||''</div>'' "Total Rows"
	 from  WF_ITEM_ACTIVITY_STATUSES  STA, WF_PROCESS_ACTIVITIES PRA
	 where STA.ACTIVITY_STATUS = ''ERROR''
	   and STA.PROCESS_ACTIVITY = PRA.INSTANCE_ID
	   and STA.ITEM_TYPE in (''BENCWBFY'',''SSBEN'',''GHR_SF52'',''HXCEMP'',''HXCSAW'',''IRC_NTF'', ''IRCOFFER'',''OTWF'',''PYASGWF'',''HRCKLTSK'',''HRSSA'',''HRWPM'',''HRRIRPRC'',''PSPERAVL'')
	 group by STA.ITEM_TYPE, STA.ACTIVITY_RESULT_CODE, PRA.PROCESS_NAME, PRA.INSTANCE_LABEL
	 order by STA.ITEM_TYPE, STA.ACTIVITY_RESULT_CODE, PRA.PROCESS_NAME, PRA.INSTANCE_LABEL',
      p_title                  => 'HCM Errors by Item Type, Result and Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'HCM Errors by Item Type, Result and Activities',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF8_HCM_ERRORS');



debug('begin add_signature: WF7_WF_DEFRD');
 add_signature(
      p_sig_id                 => 'WF7_WF_DEFRD',
      p_sig_sql                => 'select a.CORR_ID "Corr ID", a.msg_state "Msg State",
	''<div align="right">''||to_char(count(*),''999,999,999,999'')||''</div>'' "Count"
	 from APPLSYS.aq$WF_DEFERRED a
	 where a.corr_id like ''APPS:oracle.apps.ont.%''
	 group by a.CORR_ID, a.msg_state
	 order by count(*) desc, a.CORR_ID asc',
      p_title                  => 'Deferred Order Management Events in Workflow Deferred Queue Table (WF_DEFERRED)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Deferred Order Management Events in Workflow Deferred Queue Table (WF_DEFERRED)',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_WF_DEFRD');



debug('begin add_signature: WF2_SYSADMIN5');
    add_signature(
      p_sig_id                 => 'WF2_SYSADMIN5',
      p_sig_sql                => 'select name, notification_preference, nvl(email_address,''NOTSET'') "EMAIL ADDRESS" from wf_local_roles where name = ''SYSADMIN''',
      p_title                  => 'SYSADMIN User Setup for Error Notifications',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'It is unclear what the SYSADMIN User e-mail address is set to',
      p_solution               => 'Please verify that the SYSADMIN User is actively processing the '||to_char(g_errorntfcnt,'999,999,999,999')||' Error Notifications that are currently assigned to this user. <br><br>
    Please review System Administration Setup Tasks in the <a href="http://docs.oracle.com/cd/B25516_18/current/acrobat/115sacg.zip"
    target="_blank">Oracle Applications System Administrators Guide</a>, for more information.<BR>
    For additional solutions for distributing the workload of responding to SYSADMIN Error Notifications to other groups or individuals using WorkList Access or Notification Routing Rules, please review :<br>
    [1448095.1] - How to handle or reassign System : Error (WFERROR) Notifications that default to SYSADMIN.<br>',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_SYSADMIN5');



debug('begin add_signature: WF5_AUTOCLOSE_FYI');
  add_signature(
      p_sig_id                 => 'WF5_AUTOCLOSE_FYI',
      p_sig_sql                => 'select SC.COMPONENT_NAME, v.PARAMETER_DISPLAY_NAME, v.PARAMETER_VALUE
	from FND_SVC_COMP_PARAM_VALS_V v, FND_SVC_COMPONENTS SC
	where v.COMPONENT_ID=sc.COMPONENT_ID 
	and v.parameter_name = ''AUTOCLOSE_FYI''
	order by sc.COMPONENT_ID',
      p_title                  => 'Verify AutoClose_FYI Setting',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Verify AutoClose_FYI Setting does not appear to be setup.',
      p_solution               => '',
      p_success_msg            => 'Indicate whether this notification mailer automatically closes notifications that do not require a response, such as FYI (For Your Information)
	notifications, after sending the notifications by e-mail. This parameter is selected by default. <br>
	If Autoclose FYI is deselected, all FYI notifications will remain open in the Worklist until users manually close these notifications..<br>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF5_AUTOCLOSE_FYI');



debug('begin add_signature: WF3_WF_SUMMARY3');
  add_signature(
      p_sig_id                 => 'WF3_WF_SUMMARY3',
      p_sig_sql                => 'select ''<div align="right">''||to_char(NUM_ACTIVE,''999,999,999,999'')||''</div>''  "ACTIVE", 
	''<div align="right">''||to_char(NUM_COMPLETE,''999,999,999,999'')||''</div>'' "COMPLETED", ''<div align="right">''||to_char(NUM_PURGEABLE,''999,999,999,999'')||''</div>'' "PURGEABLE", 
	 WIT.NAME "ITEM_NAME", DISPLAY_NAME "DISPLAY_NAME", 
	 PERSISTENCE_TYPE "PERSISTENCE_TYPE", PERSISTENCE_DAYS "PERSISTENCE_DAYS", 
	 ''<div align="right">''||to_char(NUM_ERROR,''999,999,999,999'')||''</div>'' "ERRORED", ''<div align="right">''||to_char(NUM_DEFER,''999,999,999,999'')||''</div>'' "DEFERRED", ''<div align="right">''||to_char(NUM_SUSPEND,''999,999,999,999'')||''</div>'' "SUSPENDED"
	 from wf_item_types wit, wf_item_types_tl wtl
	 where wit.name like (''%'')
	 AND wtl.name = wit.name
	 AND wtl.language = userenv(''LANG'')
	 AND wit.NUM_ACTIVE is not NULL
	 AND wit.NUM_ACTIVE <>0 
	 order by PERSISTENCE_TYPE, NUM_COMPLETE desc',
	  p_title                  => 'Summary of Workflow Processes By Item Type',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no rows showing',
      p_solution               => '',
      p_success_msg            => '<b>Post 11i.ATG.rup4+, there are 3 new Concurrent Programs designed to gather Workflow Statistics that is displayed in OAM Workflow Manager - Workflow Metrics screens.</b><BR>
    These Concurrent Programs are set to run automatically every 24 hrs by default to refresh these workflow runtime table statistics.<BR>
    <li><B>Workflow Agent Activity Statistics (FNDWFAASTATCC)</B> - Gathers statistics for the Agent Activity graph in the Workflow System status page and for the agent activity list in the Agent Activity page.</li>
    <li><B>Workflow Mailer Statistics (FNDWFMLRSTATCC)</B> - Gathers statistics for the throughput graph in the Notification Mailer Throughput page.</li>
    <li><B>Workflow Work Items Statistics (FNDWFWITSTATCC)</B> - Gathers statistics for the Work Items graph in the Workflow System status page, for 
    the Completed Work Items list in the Workflow Purge page, and for the work item lists in the Active Work Items, Deferred Work Items, Suspended Work Items, and Errored Work Items pages.</li><br>
    <b>Note: <br>The concurrent program FNDWFWITSTATCC last ran on '||g_last_ran||', which is how current the data is in this table as well as OAM Workflow Manager.<BR>
    To refresh this data, please run the concurrent program Workflow Work Items Statistics (FNDWFWITSTATCC).</b>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','N'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_SUMMARY3');



debug('begin add_signature: WF9_PO_INCMPLT_WF');
  add_signature(
      p_sig_id                 => 'WF9_PO_INCMPLT_WF',
      p_sig_sql                => 'select i.parent_item_type "Parent Item Type", i.item_type "ITEM TYPE", 
	''<div align="right">''||to_char(count(i.item_key),''999,999,999,999'')||''</div>'' "COUNT"
	  FROM wf_items i,
		   wf_item_activity_statuses ias
	  WHERE i.parent_item_type = ''POAPPRV''
	  AND   i.item_key = ias.item_key
	  AND   i.item_type = ias.item_type
	  AND   i.begin_date <= sysdate
	  AND   ias.activity_status <> ''COMPLETE''
	  AND   parent_item_key IN (
			  SELECT i1.item_key
			  FROM wf_items i1,
				   po_headers_all h
			  WHERE i1.item_key = h.wf_item_key
			  AND   i1.item_type = ''POAPPRV''
			  AND   h.authorization_status NOT IN (''IN PROCESS'',''PRE-APPROVED'')
			  UNION
			  SELECT i1.item_key
			  FROM wf_items i1,
				   po_releases_all r
			  WHERE i1.item_key = r.wf_item_key
			  AND   i1.item_type = ''POAPPRV''
			  AND   r.authorization_status NOT IN (''IN PROCESS'',''PRE-APPROVED''))
	  AND   ias.end_date is null
	  group by i.parent_item_type, i.item_type',
      p_title                  => 'Incomplete Activities for Purchasing Workflows',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Incomplete WF Activities for Child Processes of Approved POs<BR>',
      p_solution               => 'Please run the PO Purge Workflow Script <i><b>purge_wf.sql</b></i> to identify and abort Purchasing workflows not being processed by the "Purge Obsolete Workflow Runtime Data" concurrent program.<br>
     Make running this script part of your Procurement Workflow best practices.<br><br>
     See [458886.1] to download the script and for all the information you need.',
      p_success_msg            => '<B>Excellent !!</B><BR>
     There are no Incomplete WF Activities for Child Processes of Approved POs.<BR>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_PO_INCMPLT_WF');



debug('begin add_signature: WF5_WF_NTF_STATUS');
  add_signature(
      p_sig_id                 => 'WF5_WF_NTF_STATUS',
      p_sig_sql                => 'select status, nvl(mail_status,''NULL''), count(notification_id)
	from wf_notifications
	group by status, mail_status
	order by status, count(notification_id) desc',
      p_title                  => 'Check Status of WF_NOTIFICATIONS Table',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Check Status of WF_NOTIFICATIONS Table does not appear to be setup.',
      p_solution               => '',
      p_success_msg            => 'Displays Summary status of WF_NOTIFICATIONS table.<br>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF5_WF_NTF_STATUS');



debug('begin add_signature: WF4_WF_PRGSCHED_CP2');
  add_signature(
      p_sig_id                 => 'WF4_WF_PRGSCHED_CP2',
      p_sig_sql                => 'select r.REQUEST_ID "REQUEST_ID", u.user_name "REQUESTED_BY", r.PHASE_CODE "PHASE", r.ACTUAL_START_DATE "STARTED",
	 c.CONCURRENT_PROGRAM_NAME "INTERNAL NAME", p.USER_CONCURRENT_PROGRAM_NAME "PROGRAM_NAME", r.ARGUMENT_TEXT "ARGUMENTS", 
	 r.RESUBMIT_INTERVAL "EVERY", r.RESUBMIT_INTERVAL_UNIT_CODE "SO_OFTEN", r.RESUBMIT_END_DATE "RESUBMIT_END_DATE"
	 FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
	 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
	 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
	 and c.CONCURRENT_PROGRAM_NAME = ''FNDWFPR'' 
	 AND p.language = ''US'' 
	 and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in (''P'',''R'')
	 order by c.CONCURRENT_PROGRAM_NAME, r.ARGUMENT_TEXT',
      p_title                  => 'Verify Workflow Purge Concurrent Programs are Scheduled to Run',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<B>There are No Purge Obsolete Workflow Runtime Data Concurrent Requests scheduled to run for ALL workflow Item_Types with TEMP persistence.</B><BR><BR>',
      p_solution               => '',
      p_success_msg            => '<B>Currently there are '||to_char((g_wfitems),'999,999,999,999')||' distinct workflow items_types actively being used on '||g_rep_info('Instance')||'.<br>
	Workflow Development recommends scheduling the concurrent request "Purge Obsolete Workflow Runtime Data" to purge workflow runtime data for ALL item_types using the following guidelines.</B><br>
	Oracle Workflow and Oracle XML Gateway access several tables that can grow quite large with obsolete workflow 
	information that is stored for all completed workflow processes, as well as obsolete information for XML transactions.
	The size of these tables and indexes can adversely affect performance.<br>
	These tables should be purged on a regular basis, using the Purge Obsolete Workflow Runtime Data concurrent program.<BR><BR>
	For more information refer to [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data.<br>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_WF_PRGSCHED_CP2');



debug('begin add_signature: WF9_PO_INCMPLT_CHILD');
  add_signature(
      p_sig_id                 => 'WF9_PO_INCMPLT_CHILD',
      p_sig_sql                => 'select i.parent_item_type "Parent Item Type", i.item_type "Item Type",
	''<div align="right">''||to_char(count(i.item_key),''999,999,999,999'')||''</div>'' "COUNT"
	 FROM wf_items i, wf_item_activity_statuses ias
	  WHERE i.parent_item_type = ''POAPPRV''
	  AND   i.item_key = ias.item_key
	  AND   i.item_type = ias.item_type
	  AND   i.begin_date <= sysdate
	  AND   ias.activity_status <> ''COMPLETE''
	  AND   NOT EXISTS (
			  SELECT 1 FROM po_headers_all h
			  WHERE h.wf_item_key = i.parent_item_key
			  UNION
			  SELECT 1 FROM po_releases_all r
			  WHERE r.wf_item_key = i.parent_item_key)
	  AND   ias.end_date is null
	  group by i.parent_item_type, i.item_type',
      p_title                  => 'Incomplete Activities for Child Processes not associated to a PO',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Incomplete Activities for Child Processes not associated to a PO<BR>',
      p_solution               => 'Please run the PO Purge Workflow Script <i><b>purge_wf.sql</b></i> to identify and abort Purchasing workflows not being processed by the "Purge Obsolete Workflow Runtime Data" concurrent program.<br>
    Make running this script part of your Procurement Workflow best practices.<br><br>
    See [458886.1] to download the script and for all the information you need.',
      p_success_msg            => '<B>Excellent !!</B><BR>
     There are no Incomplete Activities for Child Processes not associated to a PO.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_PO_INCMPLT_CHILD');



debug('begin add_signature: WF8_HCM_ERRORS_TO_CANCEL');
  add_signature(
      p_sig_id                 => 'WF8_HCM_ERRORS_TO_CANCEL',
      p_sig_sql                => 'select e.item_type "Item Type", e.parent_item_type "Parent Item Type",
	''<div align="right">''||to_char(count(e.item_key),''999,999,999,999'')||''</div>'' "Total Rows"
	from wf_items e
	where e.item_type like ''%ERROR%''
	and e.parent_item_type in (''BENCWBFY'',''SSBEN'',''GHR_SF52'',''HXCEMP'',''HXCSAW'',''IRC_NTF'', ''IRCOFFER'',''OTWF'',''PYASGWF'',''HRCKLTSK'',''HRSSA'',''HRWPM'',''HRRIRPRC'',''PSPERAVL'')
	and e.end_date is null
	and not exists(
		select 1 from wf_item_activity_statuses s
		where s.item_type =  e.parent_item_type
		and   s.item_key = e.parent_item_key
		and   s.activity_status = ''ERROR'')
	group by e.item_type, e.parent_item_type
	order by count(e.item_key) desc',
      p_title                  => 'Human Resources Workflow Error processes to cancel (that are no longer needed)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Dangling HR Workflow Error processes that should be closed (that are no longer needed)',
      p_solution               => 'Run this query to see the item_key:
	  <blockquote><i>
	  SELECT e.item_type "Item Type", e.item_key "Item Key", e.parent_item_type "Parent Item Type"<br>
	   from wf_items e<br>
	   where (e.item_typelike ''%ERROR%'')<br>
	   and e.parent_item_type in (''BENCWBFY'',''SSBEN'',''GHR_SF52'',''HXCEMP'',''HXCSAW'',''IRC_NTF'',<br> ''IRCOFFER'',''OTWF'',''PYASGWF'',''HRCKLTSK'',''HRSSA'',''HRWPM'',''HRRIRPRC'',''PSPERAVL'')<br>
	   and e.end_date is null<br>
	   and not exists(<br>
		   select 1 from wf_item_activity_statuses s<br>
		   where s.item_type =  e.parent_item_type<br>
		   and   s.item_key = e.parent_item_key<br>
		   and   s.activity_status = ''ERROR'');
		   </i></blockquote>To verify the end-dates of all workflows (item_keys) that are associated to a single workflow process, run the bde_wf_process_tree.sql script found in [1378954.1] - bde_wf_process_tree.sql - For analyzing the Root Parent, Children, Grandchildren Associations of a Single Workflow Process',
      p_success_msg            => 'There are no dangling HR Workflow Error processes',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF8_HCM_ERRORS_TO_CANCEL');



debug('begin add_signature: WF4_WF_CONTROL_Q');
	add_signature(
      p_sig_id                 => 'WF4_WF_CONTROL_Q',
      p_sig_sql                => 'select r.REQUEST_ID "REQUEST_ID", u.user_name "REQUESTED_BY", r.PHASE_CODE "PHASE", r.ACTUAL_START_DATE "STARTED",
	 c.CONCURRENT_PROGRAM_NAME "INTERNAL NAME", p.USER_CONCURRENT_PROGRAM_NAME "PROGRAM_NAME", r.ARGUMENT_TEXT "ARGUMENTS", 
	 r.RESUBMIT_INTERVAL "EVERY", r.RESUBMIT_INTERVAL_UNIT_CODE "SO_OFTEN", r.RESUBMIT_END_DATE "RESUBMIT_END_DATE"
	 FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
	 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
	 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
	 and c.CONCURRENT_PROGRAM_NAME = ''FNDWFBES_CONTROL_QUEUE_CLEANUP''
	 AND p.language = ''US'' 
	 and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in (''P'',''R'')
	 order by c.CONCURRENT_PROGRAM_NAME, r.ARGUMENT_TEXT',
      p_title                  => 'Verify Workflow Control Queue Cleanup Concurrent Program is Scheduled to Run',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<B>There are No Workflow Control Queue Cleanup Concurrent Requests scheduled to run.</B>',
      p_solution               => 'This is a seeded request that is automatically scheduled to be run every 12 hours by default.</br>
	Oracle recommends that this frequency not be changed.</br>
	The last Workflow Control Queue Cleanup concurrent program completed on '||to_char(g_lastwfcqcup,'DD-MON-RR HH24:MI:SS')||', which was '||g_wfcqcup_hrs||' hours ago.</br>
	Please re-schedule this Concurrent Program FNDWFBES_CONTROL_QUEUE_CLEANUP to periodically run every 12 hours.<BR>',
      p_success_msg            => 'The Workflow Control Queue Cleanup concurrent program appears to be scheduled correctly!</br></br>
	The last Workflow Control Queue Cleanup concurrent program completed on '||to_char(g_lastwfcqcup,'DD-MON-RR HH24:MI:SS')||', which was '||g_wfcqcup_hrs||' hours ago.</br></br>
	The Workflow Control Queue Cleanup concurrent program sends an event named oracle.apps.wf.bes.control.ping to check the 
	status of each subscriber to the WF_CONTROL queue. If the corresponding middle tier process is still alive, it sends back a response. 
	The next time the cleanup program runs, it checks whether responses have been received for each ping event sent during the previous run.
	If no response was received from a particular subscriber, that subscriber is removed.</br>
	The recommended frequency for performing cleanup is every twelve hours in order to allow enough time for subscribers to respond to the 
	ping event, the minimum wait time between two cleanup runs is thirty minutes.</br>
	If you run the procedure again less than thirty minutes after the previous run, it will not perform any processing.<br>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_WF_CONTROL_Q');



debug('begin add_signature: WF7_OM_WF_STATUS');
  add_signature(
      p_sig_id                 => 'WF7_OM_WF_STATUS',
      p_sig_sql                => 'select  
	''<div align="right">''||to_char(NUM_ACTIVE,''999,999,999,999'')||''</div>'' "Active", 
	''<div align="right">''||to_char(NUM_COMPLETE,''999,999,999,999'')||''</div>'' "Completed", 
	''<div align="left">''||to_char(NUM_PURGEABLE,''999,999,999,999'')||''</div>'' "Purgeable", 
	''<div align="left">''||WIT.NAME||''</div>'' "Item Type", 
	''<div align="left">''||DISPLAY_NAME||''</div>'' "Display Name",
	''<div align="center">''||PERSISTENCE_TYPE||''</div>'' "Persistence Type",
	''<div align="center">''||PERSISTENCE_DAYS||''</div>'' "Persistence Days", 
	''<div align="right">''||to_char(NUM_ERROR,''999,999,999,999'')||''</div>'' "Errored",
	''<div align="right">''||to_char(NUM_DEFER,''999,999,999,999'')||''</div>'' "Deferred", 
	''<div align="right">''||to_char(NUM_SUSPEND,''999,999,999,999'')||''</div>'' "Suspended"
	from wf_item_types wit, wf_item_types_tl wtl
	where wit.name in (''OEOH'',''OEOL'',''OMERROR'',''OEOI'',''OECOGS'',''OEOA'', ''OECHGORD'',''OEON'',''OEBH'')
	AND wtl.name = wit.name
	AND wtl.language = userenv(''LANG'')
	AND wit.NUM_ACTIVE is not NULL
	AND wit.NUM_ACTIVE <>0 
	order by PERSISTENCE_TYPE, NUM_COMPLETE desc',
      p_title                  => 'SUMMARY of OM Workflow Processes By Item Type and Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'SUMMARY of OM Workflow Processes By Item Type and Status',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_OM_WF_STATUS');



debug('begin add_signature: WF2_SYSADMINRR');
  add_signature(
      p_sig_id                 => 'WF2_SYSADMINRR',
      p_sig_sql                => 'select wrr.RULE_ID, wrr.ROLE, r.DESCRIPTION, wrr.ACTION, 
	 wrr.ACTION_ARGUMENT "TO", wrr.MESSAGE_TYPE, wrr.MESSAGE_NAME, 
	 wrr.BEGIN_DATE, wrr.END_DATE, wrr.RULE_COMMENT
	 FROM WF_ROUTING_RULES wrr, wf_local_roles r
	 WHERE wrr.ROLE = r.NAME
	 and wrr.role = ''SYSADMIN''',
      p_title                  => 'SYSADMIN Notification Routing Rules',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<b>There are no Routing Rules setup for SYSADMIN user at this time</b>',
      p_solution               => '<B>The Oracle Workflow Advanced Worklist provides an overview of all SYSADMIN notifications, from which one can drill down to :</b><br>
	 <ul><li>View individual notifications</li>
	 <li>Reassign notifications to another user</li>
	 <li>Request more information about a notification from another user</li>
	 <li>Respond to requests for information, and </li>
	 <li>Define (Vacation) Routing Rules to handle notifications automatically in your absence.</li></ul>

	 For companies that restrict access to the SYSADMIN user role, or do not assign a valid email address that multiple people can access, then assigning routing rules to manage SYSADMIN notifications automatically is a good idea. Oracle Workflow Vacation Routing Rules allows a user or administrator to define rules to perform the following actions automatically when a notification arrives:
	 <ul><li>Reassign the notification to another user</li>
	 <li>Respond to the notification with a predefined response</li>
	 <li>Close a notification that does not require a response</li>
	 <li>Deliver the notification to SYSADMIN worklist as usual, with no further action</li></ul>

	 The Vacation Rules page can be used to define rules for automatic notification processing, or the Workflow Administrator can also define rules for other users.',
      p_success_msg            => '<B>The Oracle Workflow Advanced Worklist provides an overview of all SYSADMIN notifications, from which one can drill down to :</b><br>
	 <ul><li>View individual notifications</li>
	 <li>Reassign notifications to another user</li>
	 <li>Request more information about a notification from another user</li>
	 <li>Respond to requests for information, and </li>
	 <li>Define (Vacation) Routing Rules to handle notifications automatically in your absence.</li></ul>

	 For companies that restrict access to the SYSADMIN user role, or do not assign a valid email address that multiple people can access, then assigning routing rules to manage SYSADMIN notifications automatically is a good idea. Oracle Workflow Vacation Routing Rules allows a user or administrator to define rules to perform the following actions automatically when a notification arrives:
	 <ul><li>Reassign the notification to another user</li>
	 <li>Respond to the notification with a predefined response</li>
	 <li>Close a notification that does not require a response</li>
	 <li>Deliver the notification to SYSADMIN worklist as usual, with no further action</li></ul>

	 The Vacation Rules page can be used to define rules for automatic notification processing, or the Workflow Administrator can also define rules for other users.<br>
	 Above we verify any Routing Rules defined for the SYSADMIN Role in order to respond to error notifications.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_SYSADMINRR');



debug('begin add_signature: WF1_DB_PARAMS6');
  add_signature(
      p_sig_id                 => 'WF1_DB_PARAMS6',
      p_sig_sql                => 'select name, value
    from v$parameter
    where upper(name) in (''AQ_TM_PROCESSES'',''JOB_QUEUE_PROCESSES'',''JOB_QUEUE_INTERVAL'',
    ''UTL_FILE_DIR'',''NLS_LANGUAGE'', ''NLS_TERRITORY'', ''CPU_COUNT'',
    ''PARALLEL_THREADS_PER_CPU'')',
      p_title                  => 'Workflow Database Parameter Settings',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There is a problem identifying the Workflow Database Parameter Settings',
      p_solution               => null,
      p_success_msg            => '<B>JOB_QUEUE_PROCESSES for '||g_rep_info('Instance')||' on 11gR1+ ('||g_rep_info('DB Version')||') databases is 2 or more!</B><BR>
    Oracle Workflow requires job queue processes to handle propagation of Business Event System event messages by AQs.<br>
    <B>Significance of the JOB_QUEUE_PROCESSES for 11gR1+ ('||g_rep_info('DB Version')||') databases:</B><BR><BR>
Starting from 11gR1, The init.ora parameter job_queue_processes does NOT need to be set for AQ propagations.
    AQ propagation is now likewise handled by DBMS_SCHEDULER jobs rather than DBMS_JOBS.
    Reason: propagation takes advantage of the event based scheduling features of DBMS_SCHEDULER for better scalability. <br>
<br><br>
<b>JOB_QUEUE_PROCESSES is recommended to be be set to a value of 2 or higher, for optimal performance. </b>  <i>See [396009.1]</i><br><br>
This value can be tuned to meet the specific requirements of the Workflow module and customer needs,
based on the number of job queue processes needed to handle AQ event messages and for Workflow notification mailers.<br>
    If the value of the JOB_QUEUE_PROCESSES database initialization parameter is non-zero, it effectively becomes the maximum number of Scheduler jobs and job queue jobs than can run concurrently. 
    If a non-zero value is set, it should be large enough to accommodate a Scheduler job for each Messaging Gateway agent to be started.<BR><br>

Starting in 11gR2, if job_queue_processes is set to 0 all job processes are stopped, which means that DBMS_SCHEDULER jobs, autotask jobs and DBMS_JOB jobs cannot run.
Whereas in previous versions, only DBMS_JOB jobs were disabled after changing job_queue_processes to 0, therefore, always make sure to set job_queue_processes to a non zero value to allow the scheduler jobs and autotask jobs to work.<b>Starting version 11.2 this is expected behavior.</b><br>
<BR><BR>     

When using previous versions, only DBMS_JOB jobs were disabled after changing job_queue_processes to 0.
Note that using version 11.2 all jobs are disabled, so also DBMS_SCHEDULER and Autotask jobs.<br><br>
       
    To determine the proper setting of JOB_QUEUE_PROCESSES for Oracle Workflow, follow the queries outlined in <BR>
    [578831.1] - How to determine the correct setting for JOB_QUEUE_PROCESSES.<br><br>
	To manually update the JOB_QUEUE_PROCESSES database parameter file (init.ora) file:
    <ul><i>job_queue_processes=2</i></ul>
    or set dynamically via
    <ul><i>connect / as sysdba<br>alter system set job_queue_processes=2;</i></ul>Remember that after bouncing the DB, dynamic changes are lost, and the DB parameter file settings are used.<BR>',


      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF1_DB_PARAMS6');



debug('begin add_signature: WF3_WF_VOL_BY_YR');
  add_signature(
      p_sig_id                 => 'WF3_WF_VOL_BY_YR',
      p_sig_sql                => 'select wi.item_type "ITEM_TYPE", witt.DISPLAY_NAME "DISPLAY_NAME", wit.PERSISTENCE_TYPE "PERSISTENCE",
	 nvl(wit.PERSISTENCE_DAYS,0) "P_DAYS", nvl(to_char(wi.end_date, ''YYYY''),''OPEN'') "CLOSED", ''<div align="right">''||to_char(count(wi.item_key),''999,999,999,999'')||''</div>'' "Count"
	 from wf_items wi, wf_item_types wit, wf_item_types_tl witt where wi.ITEM_TYPE=wit.NAME 
	 and wit.NAME=witt.NAME and witt.language = ''US''
	 group by wi.item_type, witt.DISPLAY_NAME, wit.PERSISTENCE_TYPE, 
	 wit.PERSISTENCE_DAYS, to_char(wi.end_date, ''YYYY'')
	 order by wit.PERSISTENCE_TYPE asc, nvl(to_char(wi.end_date, ''YYYY''),''OPEN'') asc, count(wi.item_key) desc',
	  p_title                  => 'Check the Volume of Open and Closed Items Annually',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no rows showing',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','N'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_VOL_BY_YR');



debug('begin add_signature: WF2_EBS_PROFILES');
  add_signature(
      p_sig_id                 => 'WF2_EBS_PROFILES',
      p_sig_sql                => 'select t.PROFILE_OPTION_ID, t.PROFILE_OPTION_NAME, z.language, z.USER_PROFILE_OPTION_NAME,
	 v.PROFILE_OPTION_VALUE, z.DESCRIPTION
	 from fnd_profile_options t, fnd_profile_option_values v, fnd_profile_options_tl z
	 where (v.PROFILE_OPTION_ID (+) = t.PROFILE_OPTION_ID)
	 and (v.level_id = 10001)
	 and (z.PROFILE_OPTION_NAME = t.PROFILE_OPTION_NAME)
	 and (t.PROFILE_OPTION_NAME in (''CONC_GSM_ENABLED'',''WF_VALIDATE_NTF_ACCESS'',''GUEST_USER_PWD'',
	 ''AFLOG_ENABLED'',''AFLOG_FILENAME'',''AFLOG_LEVEL'',''AFLOG_BUFFER_MODE'',''AFLOG_MODULE'',''FND_FWK_COMPATIBILITY_MODE'',
	 ''FND_VALIDATION_LEVEL'',''FND_MIGRATED_TO_JRAD'',''AMPOOL_ENABLED'',
	 ''FND_NTF_REASSIGN_MODE'',''WF_ROUTE_RULE_ALLOW_ALL''))
	 order by z.USER_PROFILE_OPTION_NAME',
      p_title                  => 'E-Business Suite Profile Settings',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<b>There are no Profiles set at this time</b>',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','N'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_EBS_PROFILES');



debug('begin add_signature: WF5_WF_NTF_OUT_STATUS');
  add_signature(
      p_sig_id                 => 'WF5_WF_NTF_OUT_STATUS',
      p_sig_sql                => 'select n.msg_state, count(*)
	from applsys.aq$wf_notification_out n
	group by n.msg_state',
      p_title                  => 'Check Status of WF_NOTIFICATION_OUT Table',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'The WF_NOTIFICATION_OUT Queue does not appear to have any messages.',
      p_solution               => '',
      p_success_msg            => 'Displays Summary status of WF_NOTIFICATION_OUT Queue table.<br>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF5_WF_NTF_OUT_STATUS');



debug('begin add_signature: WF4_WF_PRGSCHED_CP3');
  add_signature(
      p_sig_id                 => 'WF4_WF_PRGSCHED_CP3',
      p_sig_sql                => 'select r.REQUEST_ID "REQUEST_ID", u.user_name "REQUESTED_BY", r.PHASE_CODE "PHASE", r.ACTUAL_START_DATE "STARTED",
	 c.CONCURRENT_PROGRAM_NAME "INTERNAL NAME", p.USER_CONCURRENT_PROGRAM_NAME "PROGRAM_NAME", r.ARGUMENT_TEXT "ARGUMENTS", 
	 r.RESUBMIT_INTERVAL "EVERY", r.RESUBMIT_INTERVAL_UNIT_CODE "SO_OFTEN", r.RESUBMIT_END_DATE "RESUBMIT_END_DATE"
	 FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
	 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
	 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
	 and c.CONCURRENT_PROGRAM_NAME = ''FNDWFPR'' 
	 AND p.language = ''US'' 
	 and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in (''P'',''R'')
	 order by c.CONCURRENT_PROGRAM_NAME, r.ARGUMENT_TEXT',
      p_title                  => 'Verify Workflow Purge Concurrent Programs are Scheduled to Run',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<B>There are No Purge Obsolete Workflow Runtime Data Concurrent Requests scheduled to run for ALL workflow Item_Types with TEMP persistence.</B><BR><BR>',
      p_solution               => '',
      p_success_msg            => '<p><B>Nice work!!<BR>		
	There are '||to_char((g_prgall),'999,999,999,999')||' Purge Obsolete Workflow Runtime Data Concurrent requests scheduled to purge workflow for ALL Item_Types!</B><br>
	<br>Development recommends scheduling the Workflow Purge program periodically based on your business volumes.<br>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_WF_PRGSCHED_CP3');



debug('begin add_signature: WF3_WF_LOOPING1');
  l_info.delete;
  l_info('Comments') := 'The table output below is truncated to save space.<br>
						 Run this query to get the full list of Looping Activities.<br>';		
  add_signature(
      p_sig_id                 => 'WF3_WF_LOOPING1',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", 
	''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key AND wfi.item_type LIKE ''%'' 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||g_hist_item||'<br>
	 item_key : '||g_hist_key||'<BR><BR> 
	 <B>This workflow process is still open, so this may be a problem. </B><BR>
	 It was started on '||g_hist_begin||', and has most recently looped thru its process on '||g_hist_recent||'. So far this one activity for item_type '||g_hist_item||' and item_key '||g_hist_key||' has looped '||to_char(g_hist_cnt,'999,999,999,999')||' times since it started in '||g_hist_begin||'.<BR><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(g_hist_days,'999,999')||' days, which is about '||to_char(g_hist_daily,'999,999')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_LOOPING1');



debug('begin add_signature: WF9_PO_INCMPLT_APPRVD');
  add_signature(
      p_sig_id                 => 'WF9_PO_INCMPLT_APPRVD',
      p_sig_sql                => 'select i.item_type "Item Type", ias.activity_status "Activity Status", 
	''<div align="right">''||to_char(count(i.item_key),''999,999,999,999'')||''</div>'' "COUNT"
		FROM wf_item_activity_statuses ias, wf_items i
		WHERE ias.item_type = ''POAPPRV''
		AND ias.activity_status <> ''COMPLETE''
		AND EXISTS (
			SELECT 1 FROM po_headers_all h
			WHERE h.wf_item_key = ias.item_key
			AND h.authorization_status NOT IN (''IN PROCESS'',''PRE-APPROVED'')
			UNION
			SELECT 1 FROM po_releases_all r
			WHERE r.wf_item_key = ias.item_key
			AND r.authorization_status NOT IN (''IN PROCESS'',''PRE-APPROVED''))
		AND i.item_type = ias.item_type
		AND i.item_key = ias.item_key
		AND i.begin_date <= sysdate
		AND i.end_date is null
		group by i.item_type, ias.activity_status',
      p_title                  => 'Incomplete Activities for Approved POs',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Incomplete Activities for Approved POs',
      p_solution               => 'Please run the PO Purge Workflow Script <i><b>purge_wf.sql</b></i> to identify and abort Purchasing workflows not being processed by the "Purge Obsolete Workflow Runtime Data" concurrent program.<br>
	 Make running this script part of your Procurement Workflow best practices.<br><br>
     See [458886.1] to download the script and for all the information you need.',
      p_success_msg            => '<B>Excellent !!</B><BR>
     There are no Incomplete Activities for Approved POs.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_PO_INCMPLT_APPRVD');



debug('begin add_signature: WF7_ONT_ELIG_HDRS');
  add_signature(
      p_sig_id                 => 'WF7_ONT_ELIG_HDRS',
      p_sig_sql                => 'select * FROM (SELECT 
	P.INSTANCE_LABEL "Label", WAS.ITEM_KEY "Item Key", 
	H.ORDER_NUMBER "Order Number", H.ORG_ID "Org ID"
	FROM   WF_ITEM_ACTIVITY_STATUSES WAS,
	  WF_PROCESS_ACTIVITIES P, 
	  OE_ORDER_HEADERS_ALL H
	WHERE TO_NUMBER(WAS.ITEM_KEY) = H.HEADER_ID
	AND   WAS.PROCESS_ACTIVITY = P.INSTANCE_ID
	AND   P.ACTIVITY_ITEM_TYPE = ''OEOH''
	AND   P.ACTIVITY_NAME = ''CLOSE_WAIT_FOR_L''
	AND   WAS.ACTIVITY_STATUS = ''NOTIFIED''
	AND   WAS.ITEM_TYPE = ''OEOH''
	AND   NOT EXISTS ( SELECT /*+ NO_UNNEST */ 1
			  FROM   OE_ORDER_LINES_ALL
			  WHERE  HEADER_ID = TO_NUMBER(WAS.ITEM_KEY)
			  AND    OPEN_FLAG = ''Y''))
	where rownum < 31',
      p_title                  => 'Order Headers Eligible to be Closed but remains in Open Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Above Order Headers whose workflow are notified at "Close- Wait for Line" activity and have no open order lines.',
      p_solution               => 'Please refer to [397548.1] to fix above records via a patch.',
      p_success_msg            => '',	
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_ONT_ELIG_HDRS');



debug('begin add_signature: WF7_ONT_ERRORS');
  add_signature(
      p_sig_id                 => 'WF7_ONT_ERRORS',
      p_sig_sql                => 'SELECT * FROM (SELECT  
	STA.ITEM_TYPE "Item Type", 
	STA.ACTIVITY_RESULT_CODE "Result",
	''<div align="right">''||PRA.PROCESS_NAME||''</div>'' "Process Label", 
	''<div align="left">''||PRA.INSTANCE_LABEL||''</div>'' "Activity Label", 
	''<div align="right">''||to_char(count(STA.ITEM_KEY),''999,999,999,999'')||''</div>'' "Total Rows"
	 from  WF_ITEM_ACTIVITY_STATUSES  STA, WF_PROCESS_ACTIVITIES PRA
	 where STA.ACTIVITY_STATUS = ''ERROR''
	   and STA.PROCESS_ACTIVITY = PRA.INSTANCE_ID
	   and STA.ITEM_TYPE in (''OEOH'', ''OMERROR'', ''OEOL'', ''OEOI'', ''OECOGS'', ''OEOA'', ''OECHGORD'',''OEON'',''OEBH'')
	 group by STA.ITEM_TYPE, STA.ACTIVITY_RESULT_CODE, PRA.PROCESS_NAME, PRA.INSTANCE_LABEL
	 order by count(STA.ITEM_KEY) desc)
	where rownum < 31',
      p_title                  => 'Order Management Workflow Errors by Item Type, Result and Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Order Management Workflow Errors by Item Type, Result and Activities',
      p_solution               => 'Above is a summary of Order Management Workflow Errors that need to be addressed.<br><br>  See the following checks in this Section for known issues and solutions.<br>
Use bde_wf_err.sql script from [255045.1] to get details of any erroring activities.',
      p_success_msg            => 'Congratulations!!!<br> There are No Order Management Workflow Errors on this instance.<br><br>Nice work!!!<br>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_ONT_ERRORS');



debug('begin add_signature: WF4_WF_PRGSCHED_CP4');
  add_signature(
      p_sig_id                 => 'WF4_WF_PRGSCHED_CP4',
      p_sig_sql                => 'select r.REQUEST_ID "REQUEST_ID", u.user_name "REQUESTED_BY", r.PHASE_CODE "PHASE", r.ACTUAL_START_DATE "STARTED",
	 c.CONCURRENT_PROGRAM_NAME "INTERNAL NAME", p.USER_CONCURRENT_PROGRAM_NAME "PROGRAM_NAME", r.ARGUMENT_TEXT "ARGUMENTS", 
	 r.RESUBMIT_INTERVAL "EVERY", r.RESUBMIT_INTERVAL_UNIT_CODE "SO_OFTEN", r.RESUBMIT_END_DATE "RESUBMIT_END_DATE"
	 FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u 
	 WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id 
	 and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID 
	 and c.CONCURRENT_PROGRAM_NAME = ''FNDWFPR'' 
	 AND p.language = ''US'' 
	 and r.ACTUAL_COMPLETION_DATE is null and r.PHASE_CODE in (''P'',''R'')
	 order by c.CONCURRENT_PROGRAM_NAME, r.ARGUMENT_TEXT',
      p_title                  => 'Verify Workflow Purge Concurrent Programs are Scheduled to Run',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<B>There are No Purge Obsolete Workflow Runtime Data Concurrent Requests scheduled to run for ALL workflow Item_Types with TEMP persistence.</B><BR><BR>',
      p_solution               => '',
      p_success_msg            => '<p><B>Attention:<BR>
	The Purge Obsolete Workflow Runtime Data Concurrent request has a parameter called Core Workflow Only which by default is set to Yes. <BR>
	This purges only core runtime information associated with work items for performance gain during periods of high activity. <BR><BR>
	Suggestion:</b><br>
	Run a more comprehensive Purge Obsolete Workflow Runtime Data Concurrent request for ALL item_types by setting the Core Workflow Only value to NO.<br>
	This will purge obsolete runtime information associated with work items, including status information, any associated notifications, and it also purges obsolete design information, such as activities that are 
	no longer in use and expired ad hoc users and roles, and obsolete runtime information not associated with work items, such as notifications 
	that were not handled through a workflow process and, if the ECX: Purge ECX data with WF profile option is set to Y, Oracle XML Gateway 
	transactions that were not handled through a workflow process.<br>
	Schedule this comprehensive Purge request once a month or every 2 weeks as needed.<br><br>	
	For more information refer to [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data.<br>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF4_WF_PRGSCHED_CP4');



debug('begin add_signature: WF2_CC_GSM_ENABLED');
  add_signature(
      p_sig_id                 => 'WF2_CC_GSM_ENABLED',
      p_sig_sql                => 'select t.PROFILE_OPTION_ID, t.PROFILE_OPTION_NAME, z.language, z.USER_PROFILE_OPTION_NAME,
	 v.PROFILE_OPTION_VALUE, z.DESCRIPTION
	 from fnd_profile_options t, fnd_profile_option_values v, fnd_profile_options_tl z
	 where v.PROFILE_OPTION_ID (+) = t.PROFILE_OPTION_ID
	 and v.level_id = 10001
	 and z.PROFILE_OPTION_NAME = t.PROFILE_OPTION_NAME
	 and t.PROFILE_OPTION_NAME =  ''CONC_GSM_ENABLED''
     and v.PROFILE_OPTION_VALUE = ''Y''',
      p_title                  => 'Concurrent:GSM Enabled',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<b>The Profile "Concurrent:GSM Enabled" is NOT enabled as expected</b>',
      p_solution               => 'This profile needs to be set to "Y", to allow the GSM (Generic Services Manager) to enable running workflows.<br>
	 Generic Services Manager must be enabled in order to process workflows.<br>
	 Please review [1191125.1] - Troubleshooting Oracle Workflow Java Notification Mailer, for more information.',
      p_success_msg            => 'The Profile "Concurrent:GSM Enabled" is enabled as expected.<br>
	 This profile is currently set to Y, allows the GSM (Generic Services Manager) to enable running workflows.<br>
	 This is expected as GSM must be enabled in order to process workflow.<br>
	 Please review [1191125.1] - Troubleshooting Oracle Workflow Java Notification Mailer, for more information.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_CC_GSM_ENABLED');



debug('begin add_signature: WF3_WF_LOOPING2');
  l_info.delete;
  l_info('Comments') := 'The table output below is truncated to save space.<br>
                         Run this query to get the full list of Looping Activities.<br>';		
  add_signature(
      p_sig_id                 => 'WF3_WF_LOOPING2',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", ''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key AND wfi.item_type LIKE ''%'' 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||g_hist_item||'<br>
	 item_key : '||g_hist_key||'<BR><BR> 
	 <B>This workflow process is still open, so this may be a problem. </B><BR>
	 It was started back on '||g_hist_begin||', and has most recently looped thru its process on '||g_hist_recent||'. So far this one activity for item_type '||g_hist_item||' and item_key '||g_hist_key||' has looped '||to_char(g_hist_cnt,'999,999,999,999')||' times since it started in '||g_hist_begin||'.<BR><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(g_hist_days,'999,999')||' days, which is about '||to_char(g_hist_daily,'999,999')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_LOOPING2');



debug('begin add_signature: WF9_PO_ACCT_GEN');
  add_signature(
      p_sig_id                 => 'WF9_PO_ACCT_GEN',
      p_sig_sql                => 'select i.item_type "Item Type", to_char(i.begin_date,''YYYY-MM'') "Began", 
	nvl(to_char(i.end_date, ''YYYY''),''OPEN'') "CLOSED",
	''<div align="right">''||to_char(count(i.item_key),''999,999,999,999'')||''</div>'' "COUNT"
		FROM wf_items i
		WHERE i.item_type = ''POWFPOAG''
		AND i.end_date is null
		AND i.begin_date <= sysdate
		AND EXISTS (
		SELECT null FROM wf_items i2
		WHERE i2.end_date is null
		START WITH i2.item_type = i.item_type
		AND i2.item_key = i.item_key
		CONNECT BY PRIOR i2.item_type = i2.parent_item_type
		AND PRIOR i2.item_key = i2.parent_item_key
		UNION ALL
		SELECT null FROM wf_items i2
		WHERE i2.end_date is null
		START WITH i2.item_type = i.item_type
		AND i2.item_key = i.item_key
		CONNECT BY PRIOR i2.parent_item_type = i2.item_type
		AND PRIOR i2.parent_item_key = i2.item_key)
		group by i.item_type, to_char(i.begin_date,''YYYY-MM''),nvl(to_char(i.end_date, ''YYYY''),''OPEN'')
		ORDER BY to_char(i.begin_date,''YYYY-MM'')',
      p_title                  => 'PO Account Generator Workflows',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Incomplete WF Activities for PO Account Generator Workflows',
      p_solution               => 'Please run the PO Purge Workflow Script <i><b>purge_wf.sql</b></i> to identify and abort Purchasing workflows not being processed by the "Purge Obsolete Workflow Runtime Data" concurrent program.<br>
    Make running this script part of your Procurement Workflow best practices.<br><br>
    See [458886.1] to download the script and for all the information you need.',
      p_success_msg            => '<B>Excellent !!</B><BR>
     There are no Incomplete WF Activities for PO Account Generator Workflows.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_PO_ACCT_GEN');



debug('begin add_signature: WF7_ONT_ERR_CANCEL');
  add_signature(
      p_sig_id                 => 'WF7_ONT_ERR_CANCEL',
      p_sig_sql                => 'SELECT e.item_type "Item Type", e.parent_item_type "Parent Item Type",
	''<div align="right">''||to_char(count(e.item_type),''999,999,999,999'')||''</div>'' "Total Rows"
	   from wf_items e
	   where (e.item_type= ''WFERROR'' or e.item_type= ''OMERROR'')
	   and e.parent_item_type in (''OEOH'', ''OEOL'', ''OEOI'', ''OECOGS'', ''OEOA'', ''OECHGORD'',''OEON'',''OEBH'')
	   and e.end_date is null
	   and not exists(
		   select 1 from wf_item_activity_statuses s
		   where s.item_type =  e.parent_item_type
		   and   s.item_key = e.parent_item_key
		   and   s.activity_status = ''ERROR'')
	   group by e.item_type, e.parent_item_type
	   order by count(e.item_type) desc',
      p_title                  => 'Order Management Workflow Error processes to cancel (that are no longer needed)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Dangling Order Management Workflow Error processes that should be closed (that are no longer needed)',
      p_solution               => 'Run this query to see the item_key:
	  <blockquote><i>
	  SELECT e.item_type "Item Type", e.item_key "Item Key", e.parent_item_type "Parent Item Type"<br>
	   from wf_items e<br>
	   where (e.item_type= ''WFERROR'' or e.item_type= ''OMERROR'')<br>
	   and e.parent_item_type in (''OEOH'', ''OEOL'', ''OEOI'', ''OECOGS'', ''OEOA'', ''OECHGORD'',''OEON'',''OEBH'')<br>
	   and e.end_date is null<br>
	   and not exists(<br>
		   select 1 from wf_item_activity_statuses s<br>
		   where s.item_type =  e.parent_item_type<br>
		   and   s.item_key = e.parent_item_key<br>
		   and   s.activity_status = ''ERROR'');
		   </i></blockquote>To verify the end-dates of all workflows (item_keys) that are associated to a single workflow process, run the bde_wf_process_tree.sql script found in [1378954.1] - bde_wf_process_tree.sql - For analyzing the Root Parent, Children, Grandchildren Associations of a Single Workflow Process',
      p_success_msg            => 'There are no dangling Order Management Workflow Error processes',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_ONT_ERR_CANCEL');



debug('begin add_signature: WF9_PO_ICMPLT_REQ');
  add_signature(
      p_sig_id                 => 'WF9_PO_ICMPLT_REQ',
      p_sig_sql                => 'select i.parent_item_type "Parent Item Type", i.item_type "Item Type",
	''<div align="right">''||to_char(count(i.item_key),''999,999,999,999'')||''</div>'' "COUNT"
	  FROM wf_items i,
		   wf_item_activity_statuses ias
	  WHERE i.parent_item_type = ''REQAPPRV''
	  AND   i.item_key = ias.item_key
	  AND   i.item_type = ias.item_type
	  AND   i.begin_date <= sysdate
	  AND   ias.activity_status <> ''COMPLETE''
	  AND   parent_item_key IN (
			  SELECT i1.item_key
			  FROM wf_items i1,
				   po_requisition_headers_all r
			  WHERE i1.item_key = r.wf_item_key(+)
	  AND   i1.item_type = ''REQAPPRV''
	  AND   r.authorization_status NOT IN (''IN PROCESS'',''PRE-APPROVED''))
	  AND   ias.end_date is null
	  group by i.parent_item_type, i.item_type',
      p_title                  => 'Incomplete Activities for Requisition Workflows',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Incomplete WF Activities for Child Processes of Approved Requisitions<BR>',
      p_solution               => 'Please run the PO Purge Workflow Script <b><i>purge_wf.sql</b></i> to identify and abort Purchasing workflows not being processed by the "Purge Obsolete Workflow Runtime Data" concurrent program.<br>
    Make running this script part of your Procurement Workflow best practices.<br><br>
    See [458886.1] to download the script and for all the information you need.',
      p_success_msg            => '<B>Excellent !!</B><BR>
     There are no Incomplete WF Activities for Child Processes of Approved Requisitions.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_PO_ICMPLT_REQ');



debug('begin add_signature: WF2_WF_PROFILES');
  add_signature(
      p_sig_id                 => 'WF2_WF_PROFILES',
      p_sig_sql                => 'select t.PROFILE_OPTION_ID, t.PROFILE_OPTION_NAME, z.USER_PROFILE_OPTION_NAME,
	 nvl(v.PROFILE_OPTION_VALUE,''NOT SET - Replace with specific Web Server URL (non-virtual) if using load balancers'')
	 from fnd_profile_options t, fnd_profile_option_values v, fnd_profile_options_tl z
	 where (v.PROFILE_OPTION_ID (+) = t.PROFILE_OPTION_ID)
	 and ((v.level_id = 10001) or (v.level_id is null))
	 and (z.PROFILE_OPTION_NAME = t.PROFILE_OPTION_NAME)
	 and z.language = ''US''
	 and (t.PROFILE_OPTION_NAME in (''APPS_FRAMEWORK_AGENT'',''WF_MAIL_WEB_AGENT''))',
      p_title                  => 'Workflow Profile Settings',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<b>These Workflow Profiles are not found as expected</b>',
      p_solution               => 'These profiles need to be set to allow the workflow mailer to process workflows.',
      p_success_msg            => 'If WF_MAIL_WEB_AGENT is not set, then replace with specific Web Server URL (non-virtual) if using load balancers<br>
	 Also, reference [339718.1] - Java Notification Mailer Fails to Send Email Notifications from FormatterException with Framework Regions, Section 4.C for more details.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF2_WF_PROFILES');



debug('begin add_signature: WF3_WF_LOOPING3');
  l_info.delete;
  l_info('Comments') := 'The table output below is truncated to save space.<br>
                         Run this query to get the full list of Looping Activities.<br>';		
  add_signature(
      p_sig_id                 => 'WF3_WF_LOOPING3',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", ''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key AND wfi.item_type LIKE ''%'' 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||g_hist_item||'<br>
	 item_key : '||g_hist_key||'<BR><BR>
     <B>This process has been closed since '||g_hist_end||'.</B><BR>
	 It was started on '||g_hist_begin||', and has most recently looped thru its process on '||g_hist_recent||'.<br><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(g_hist_days,'999,999')||' days, which is about '||to_char(g_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_LOOPING3');



debug('begin add_signature: WF3_WF_LOOPING4');
  add_signature(
      p_sig_id                 => 'WF3_WF_LOOPING4',
      p_sig_sql                => 'select sta.item_type "ITEM_TYPE", sta.item_key "ITEM_KEY", ''<div align="right">''||to_char(COUNT(*),''999,999,999,999'')||''</div>'' "COUNT",
	 TO_CHAR(wfi.begin_date, ''YYYY-MM-DD'') "OPENED", TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') "CLOSED", wfi.user_key "DESCRIPTION"
	 FROM wf_item_activity_statuses_h sta, 
	 wf_items wfi WHERE sta.item_type = wfi.item_type AND sta.item_key = wfi.item_key AND wfi.item_type LIKE ''%'' 
	 GROUP BY sta.item_type, sta.item_key, wfi.USER_KEY, TO_CHAR(wfi.begin_date, ''YYYY-MM-DD''), 
	 TO_CHAR(wfi.end_date, ''YYYY-MM-DD'') 
	 HAVING COUNT(*) > 500 
	 ORDER BY COUNT(*) DESC',
      p_title                  => 'Check for excessive Looping Workflow Activities',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<B>There are Workflows with large Activity History, indicating that there is excessive looping happening</b><br>
	 It is normal for Workflow to use WAITS and other looping acitivities to process delayed responses and other criteria.<br>
	 Each revisit of a node replaces the previous data with the current activities status and stores the old activity information into a activities history table.<br>
	 Looking at this history table (WF_ITEM_ACTIVITY_STATUSES_H) can help to identify possible long running workflows that appear to be stuck in a loop over a long time, or a poorly designed workflow that is looping excessively and can cause performance issues.',
      p_solution               => 'Currently, the largest single activity found in the history table is for <br>
	 item_type : '||g_hist_item||'<br>
	 item_key : '||g_hist_key||'<BR><BR>
	 This process has been closed since '||g_hist_end||'.<br><br>
	 <B>This is a good place to start, as this single activity has been looping for '||to_char(g_hist_days,'999,999')||' days, which is about '||to_char(g_hist_daily,'999,999.99')||' times a day.</B><BR>
	 Please review [144806.1] - A Detailed Approach To Purging Oracle Workflow Runtime Data on how to drill down and discover how to purge this workflow data.',
      p_success_msg            => '<B>Well Done !!</B><BR><BR>
     There are NO ROWS found in the HISTORY table (wf_item_activity_statuses_h) that have over 500 rows associated to the same item_key.<BR>
     This is a good result, which means there is no major looping issues at this time.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF3_WF_LOOPING4');



debug('begin add_signature: WF9_REQ_INCMPLT_CHLD_ACTV');
  add_signature(
      p_sig_id                 => 'WF9_REQ_INCMPLT_CHLD_ACTV',
      p_sig_sql                => 'select i.parent_item_type "Parent Item Type", i.item_type "Item Type",
	''<div align="right">''||to_char(count(i.item_key),''999,999,999,999'')||''</div>'' "COUNT"
	FROM wf_items i,
		   wf_item_activity_statuses ias
	  WHERE i.parent_item_type = ''REQAPPRV''
	  AND   i.item_key = ias.item_key
	  AND   i.item_type = ias.item_type
	  AND   i.begin_date <= sysdate
	  AND   ias.activity_status <> ''COMPLETE''
	  AND   parent_item_key IN (
			  SELECT i1.item_key
			  FROM wf_items i1,
				   po_requisition_headers_all r
			  WHERE i1.item_key = r.wf_item_key(+)
			  AND   i1.item_type = ''REQAPPRV''
			  AND   r.wf_item_key is null
			  AND   r.wf_item_type is null)
	  AND   ias.end_date is null
	  group by i.parent_item_type, i.item_type',
      p_title                  => 'Incomplete Activities for Child Processes not associated to a Requisition',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Incomplete Activities for Child Processes not associated to a Requisition<BR>',
      p_solution               => 'Please run the PO Purge Workflow Script <b><i>purge_wf.sql</i></b> to identify and abort Purchasing workflows not being processed by the "Purge Obsolete Workflow Runtime Data" concurrent program.<br>
    Make running this script part of your Procurement Workflow best practices.<br><br>
    See [458886.1] to download the script and for all the information you need.',
      p_success_msg            => '<B>Excellent !!</B><BR>
     There are no Incomplete Activities for Child Processes not associated to a Requisition.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_REQ_INCMPLT_CHLD_ACTV');



debug('begin add_signature: WF7_ONT_LINE_OPEN');
  add_signature(
      p_sig_id                 => 'WF7_ONT_LINE_OPEN',
      p_sig_sql                => 'SELECT nvl(to_char(h.order_number), ''** Missing Record **'') "ORDER NO",
           l.header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.open_flag "OPEN",
           l.booked_flag "BOOKED",
           l.flow_status_code "STATUS",
           to_char(l.last_update_date, ''DD-MON-RR'') "LINE LAST UPDATED",
           hou.name "OPERATING UNIT"
    FROM  wf_items wi, 
          oe_order_headers_all h, 
          oe_order_lines_all l, 
          hr_operating_units hou
    WHERE l.org_id               = hou.organization_id
    AND   l.header_id = h.header_id (+)
    AND   to_number(wi.item_key) = l.line_id
    AND   wi.END_DATE is null
    AND   wi.item_type = ''OEOL''
    AND   l.open_flag = ''Y''
    AND   l.last_update_date > (sysdate-730)
    AND not exists (select ''WF is pending'' from
                wf_item_activity_statuses wias
                where to_number(wias.item_key) = l.line_id
                  and wias.item_type = ''OEOL'')
    AND nvl(l.transaction_phase_code, ''F'') = ''F''
    order by l.last_update_date DESC',
      p_title                  => 'Line Open and Workflow Initiated but not Started',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.<br><br>
For additional queries, please review the Order Management / Transportation Management section in [1545562.1] Product Support Analyzer Index.',
      p_solution               => '',
      p_success_msg            => 'There do not appear to be any Lines Open where Workflow Initiated but not Started',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_ONT_LINE_OPEN');



debug('begin add_signature: WF9_REQ_INCMPLT_WF_ACTV');
  add_signature(
      p_sig_id                 => 'WF9_REQ_INCMPLT_WF_ACTV',
      p_sig_sql                => 'select DISTINCT to_char(ias.begin_date,''YYYY'') "Begin Date", ias.item_type "Item Type",
	''<div align="right">''||to_char(count(ias.item_key),''999,999,999,999'')||''</div>'' "COUNT"
	  FROM wf_item_activity_statuses ias,
		   wf_items i,
		   po_requisition_headers_all r
	  WHERE ias.item_key = r.wf_item_key(+)
	  AND   ias.item_type = ''REQAPPRV''
	  AND   ias.activity_status <> ''COMPLETE''
	   AND   r.wf_item_key is null
	  AND   r.wf_item_type is null
	  AND   i.item_type = ias.item_type
	  AND   i.item_key = ias.item_key
	  AND   i.begin_date <= sysdate
	  AND   i.end_date is null
	  group by to_char(ias.begin_date,''YYYY''), ias.item_type',
      p_title                  => 'Incomplete Activities for Workflows not associated to a Requistion',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Incomplete Activities for Workflows not associated to a Requistion<BR>',
      p_solution               => 'Please run the PO Purge Workflow Script <b><i>purge_wf.sql</i></b> to identify and abort Purchasing workflows not being processed by the "Purge Obsolete Workflow Runtime Data" concurrent program.<br>
    Make running this script part of your Procurement Workflow best practices.<br><br>
    See [458886.1] to download the script and for all the information you need.',
      p_success_msg            => '<B>Excellent !!</B><BR>
     There are no Incomplete Activities for Workflows not associated to a Requistion.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_REQ_INCMPLT_WF_ACTV');



debug('begin add_signature: WF7_OEOL_WF_CLOSED');
  add_signature(
      p_sig_id                 => 'WF7_OEOL_WF_CLOSED',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           h.header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.open_flag "OPEN FLAG",
           l.cancelled_flag "CANC FLAG",
           l.flow_status_code "STATUS",
           to_char(l.last_update_date, ''DD-MON-RR'') "LINE LAST UPDATED",
           hou.name "OPERATING UNIT"
    FROM wf_items wi, 
         oe_order_headers_all h, 
         oe_order_lines_all l, 
         hr_operating_units hou
    WHERE h.org_id               = hou.organization_id
    AND   l.last_update_date > (sysdate-730)
    AND   l.header_id = h.header_id
    AND   to_number(wi.item_key) = l.line_id
    AND   wi.END_DATE is null
    AND   wi.item_type = ''OEOL''
    AND   l.open_flag = ''N''
  order by l.last_update_date DESC',
      p_title                  => 'Closed Sales Order Lines With Pending WF Activity Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => 'There are no Closed Sales Order Lines With Pending WF Activity',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_OEOL_WF_CLOSED');



debug('begin add_signature: WF7_OEOH_NO_OPEN_LINES');
  add_signature(
      p_sig_id                 => 'WF7_OEOH_NO_OPEN_LINES',
      p_sig_sql                => 'SELECT * FROM (SELECT 
	h.org_id "Org Id", h.order_number "Order #", 
	was.item_key "Header Id",
	h.flow_status_code "Header Status", 
	''<div align="center">''||h.open_flag||''</div>'' "Header Open",
	''<div align="center">''||h.cancelled_flag||''</div>'' "Header Cancel",
	to_char(h.last_update_date, ''MM/DD/RRRR'') "Last Update"
	from wf_item_activity_statuses was, wf_process_activities p, oe_order_headers_all h
	where to_number(was.item_key) = h.header_id
	and was.process_activity = p.instance_id
	and p.activity_item_type = ''OEOH''
	and p.activity_name = ''CLOSE_WAIT_FOR_L''
	and was.activity_status = ''NOTIFIED''
	and was.item_type = ''OEOH''
	and not exists (
	   select /*+ NO_INDEX (l oe_order_lines_n15) */1 from oe_order_lines_all
	   where  header_id = to_number(was.item_key)
	   and    open_flag = ''Y'')) 
	WHERE ROWNUM < 31',
      p_title                  => 'Top 30 Pending Header Flows with no open lines and no children workflows',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Top 30 Pending Header Flows with no open lines and no children workflows',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_OEOH_NO_OPEN_LINES');



debug('begin add_signature: WF9_INCMPLT_ACTV_APPRV_REQ');
  add_signature(
      p_sig_id                 => 'WF9_INCMPLT_ACTV_APPRV_REQ',
      p_sig_sql                => 'select i.item_type "Item Type", ias.activity_status "Activity Status", 
		r.authorization_status "Authorization Status", 
		''<div align="right">''||to_char(count(i.item_key),''999,999,999,999'')||''</div>'' "COUNT"
		  FROM wf_item_activity_statuses ias,
			   wf_items i,
			   po_requisition_headers_all r
		  WHERE ias.item_key = r.wf_item_key
		  AND   ias.item_type = ''REQAPPRV''
		  AND   ias.activity_status <> ''COMPLETE''
		  AND   r.authorization_status NOT IN (''IN PROCESS'',''PRE-APPROVED'')
		  AND   i.item_type = ias.item_type
		  AND   i.item_key = ias.item_key
		  AND   i.begin_date <= sysdate
		  AND   i.end_date is null
		  group by i.item_type, ias.activity_status, r.authorization_status
		  order by ias.activity_status',
      p_title                  => 'Incomplete Activities for Approved Requisitions',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Incomplete Activities for Approved Requisitions<BR>',
      p_solution               => 'Please run the PO Purge Workflow Script <b><i>purge_wf.sql</i></b> to identify and abort Purchasing workflows not being processed by the "Purge Obsolete Workflow Runtime Data" concurrent program.<br>
    Make running this script part of your Procurement Workflow best practices.<br><br>
    See [458886.1] to download the script and for all the information you need.',
      p_success_msg            => '<B>Excellent !!</B><BR>
     There are no Incomplete Activities for Approved Requisitions.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_INCMPLT_ACTV_APPRV_REQ');



debug('begin add_signature: WF7_OEOH_CLOSED_OPEN_LINES');
  add_signature(
      p_sig_id                 => 'WF7_OEOH_CLOSED_OPEN_LINES',
      p_sig_sql                => 'SELECT ''<div align="right">''||to_char(count(*),''999,999,999,999'')||''</div>'' "Count",
	to_char(min(h.last_update_date), ''DD-MON-RR'') "First Update Date", 
	to_char(max(h.last_update_date), ''DD-MON-RR'') "Last Update Date"
	from oe_order_headers_all h, oe_order_lines_all l
	where h.header_id = l.header_id
	and h.open_flag = ''N'' 
	and l.open_flag = ''Y''',
      p_title                  => 'Cancelled or Closed Headers with Open Lines',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are cancelled or Closed Headers with Open Lines',
      p_solution               => 'There are some data fix scripts to clean up data corruption issues.<br> 
Please refer to [398822.1] - Order Management Suite - Some Data Fix Patches and Scripts.',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','I'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_OEOH_CLOSED_OPEN_LINES');



debug('begin add_signature: WF9_REQ_ACCT_GEN_WF');
  add_signature(
      p_sig_id                 => 'WF9_REQ_ACCT_GEN_WF',
      p_sig_sql                => 'select i.item_type "Item Type", to_char(i.begin_date,''YYYY-MM'') "Began", 
	nvl(to_char(i.end_date, ''YYYY''),''OPEN'') "CLOSED",
	''<div align="right">''||to_char(count(i.item_key),''999,999,999,999'')||''</div>'' "COUNT"
	  FROM wf_items i
	  WHERE i.item_type = ''POWFRQAG''
	  AND   i.end_date is null
	  AND   i.begin_date <= sysdate
	  AND   (EXISTS (
			  SELECT null FROM wf_items i2
			  WHERE i2.end_date is null
			  START WITH i2.item_type = i.item_type
			  AND        i2.item_key = i.item_key
			  CONNECT BY PRIOR i2.item_type = i2.parent_item_type
			  AND        PRIOR i2.item_key = i2.parent_item_key
			  UNION ALL
			  SELECT null FROM wf_items i2
			  WHERE i2.end_date is null
			  START WITH i2.item_type = i.item_type
			  AND        i2.item_key = i.item_key
			  CONNECT BY PRIOR i2.parent_item_type = i2.item_type
			  AND        PRIOR i2.parent_item_key = i2.item_key))
	  group by i.item_type, to_char(i.begin_date,''YYYY-MM''),nvl(to_char(i.end_date, ''YYYY''),''OPEN'')
	  order by to_char(i.begin_date,''YYYY-MM'')',
      p_title                  => 'Requisition Account Generator Workflows',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are Incomplete Activities for Requisition Account Generator Workflows<BR>',
      p_solution               => 'Please run the PO Purge Workflow Script <b><i>purge_wf.sql</i></b> to identify and abort Purchasing workflows not being processed by the "Purge Obsolete Workflow Runtime Data" concurrent program.<br>
    Make running this script part of your Procurement Workflow best practices.<br><br>
    See [458886.1] to download the script and for all the information you need.',
      p_success_msg            => '<B>Excellent !!</B><BR>
     There are no Incomplete Activities for Requisition Account Generator Workflows.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF9_REQ_ACCT_GEN_WF');



debug('begin add_signature: WF7_ONT_ORPH_HDRS');
  add_signature(
      p_sig_id                 => 'WF7_ONT_ORPH_HDRS',
      p_sig_sql                => 'select item_type "Item Type", item_key "Item Key", begin_date "Begin Date", end_date "End Date", user_key "Description"
	from wf_items wi
	where item_type = ''OEOH''
	and end_date is null
	and not exists (
	select 1 from oe_order_headers_all
	where header_id = to_number(wi.item_key))
	order by begin_date',
      p_title                  => 'Order Management Orphaned OEOH Workflows',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are '||to_char(g_orphhdr,'999,999,999,999')||' Order Management header ids that exist in WF_ITEMS but not found in OE_ORDER_HEADERS_ALL !!!',
      p_solution               => 'Please run the following query to get the full list of Orphaned Order Management OEOH workflows and close them so all the associated workflow can then be purged.<br>
	<blockquote><i>select item_type "Item Type", item_key "Item Key", <br>
	begin_date "Begin Date", end_date "End Date", user_key "Description"<br>
	from wf_items wi<br>
	where item_type = ''OEOH''<br>
	and end_date is null<br>
	and not exists (<br>
	select 1 from oe_order_headers_all<br>
	where header_id = to_number(wi.item_key))<br>
	order by begin_date;</i></blockquote>
	Please review [398822.1] - Order Management Suite - Some Data Fix Patches and Scripts.',
      p_success_msg            => 'There are no Order Management header ids that exist in WF_items but not found in OE_ORDER_HEADERS_ALL!!!<BR><BR>This is GOOD !!',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_ONT_ORPH_HDRS');



debug('begin add_signature: WF7_ONT_ORPH_LINES');
  add_signature(
      p_sig_id                 => 'WF7_ONT_ORPH_LINES',
      p_sig_sql                => 'select item_type "Item Type", item_key "Item Key", begin_date "Begin Date", end_date "End Date", user_key "Description"
	from wf_items wi
	where item_type = ''OEOL''
	and parent_item_type = ''OEOH''
	and end_date is null
	and not exists (
	select 1 from oe_order_lines_all
	where line_id = to_number(wi.item_key))
	order by begin_date',
      p_title                  => 'Order Management Orphaned OEOL Workflows',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are '||to_char(g_orphline,'999,999,999,999')||' Order Lines that exist in WF_ITEMS but not found in OE_ORDER_LINES_ALL !!!',
      p_solution               => 'Please run the "Show SQL" query from above to get the full list of Orphaned Order Management workflows and close them so all the associated workflow can then be purged.<br>
	<blockquote><i>select item_type "Item Type", item_key "Item Key", <br>
	begin_date "Begin Date", end_date "End Date", user_key "Description"<br>
	from wf_items wi<br>
	where item_type = ''OEOL''<br>
	and parent_item_type = ''OEOH''<br>
	and end_date is null<br>
	and not exists (<br>
	select 1 from oe_order_lines_all<br>
	where line_id = to_number(wi.item_key))<br>
	order by begin_date;</i></blockquote>
	Please review [398822.1] - Order Management Suite - Some Data Fix Patches and Scripts.',
      p_success_msg            => 'There are no Order Lines that exist in WF_ITEMS but not found in OE_ORDER_LINES_ALL!!!<BR><BR>This is GOOD !!',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );debug('end add_signature: WF7_ONT_ORPH_LINES');

    

EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;


---------------------------------
-- MAIN ENTRY POINT
---------------------------------
PROCEDURE main(
            p_max_output_rows              IN NUMBER      DEFAULT 30
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;
  l_completion_status  BOOLEAN;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;

  IF g_is_concurrent THEN
     g_rep_info('Calling From'):='Concurrent Program';
  ELSE
     g_rep_info('Calling From'):='SQL Script';
  END IF;
  
  l_step := '10';
  initialize_files;
 
-- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'Workflow';

  l_step := '20';

   validate_parameters(
     p_max_output_rows              => p_max_output_rows
    ,p_debug_mode                   => p_debug_mode  );


  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');

debug('begin section: WF_ANZ_OVERVIEW');
start_section('Workflow Analyzer Overview');
show_gauge_chart;
if (g_oldest_item > 1095) THEN
	set_item_result(run_stored_sig('WF1_ITEM_AGE1'));
elsif (g_oldest_item > 365) THEN
	set_item_result(run_stored_sig('WF1_ITEM_AGE2'));			
else
	set_item_result(run_stored_sig('WF1_ITEM_AGE3'));
end if;	  
   set_item_result(run_stored_sig('EBS_VERSION'));
   set_item_result(run_stored_sig('WF1_NODE_INFO'));
if ((g_rep_info('JQP_Cnt')=0) and (substr(g_rep_info('DB Version'),1,4) < '11.1')) then
	set_item_result(run_stored_sig('WF1_DB_PARAMS1'));
elsif ((g_rep_info('JQP_Cnt')=0) and (substr(g_rep_info('DB Version'),1,4) >= '11.1') and (substr(g_rep_info('DB Version'),1,4) < '11.2')) then
	set_item_result(run_stored_sig('WF1_DB_PARAMS2'));
elsif ((g_rep_info('JQP_Cnt')=0) and (substr(g_rep_info('DB Version'),1,4) >= '11.2')) then
	set_item_result(run_stored_sig('WF1_DB_PARAMS7')); 	
elsif ((g_rep_info('JQP_Cnt')<2) and (substr(g_rep_info('DB Version'),1,4) < '11.1')) then
	set_item_result(run_stored_sig('WF1_DB_PARAMS3'));
elsif ((g_rep_info('JQP_Cnt')<2) and (substr(g_rep_info('DB Version'),1,4) >= '11.1')) then
	set_item_result(run_stored_sig('WF1_DB_PARAMS4'));	
elsif ((g_rep_info('JQP_Cnt')>=2) and (substr(g_rep_info('DB Version'),1,4) < '11.1')) then
	set_item_result(run_stored_sig('WF1_DB_PARAMS5'));
elsif ((g_rep_info('JQP_Cnt')>=2) and (substr(g_rep_info('DB Version'),1,4) >= '11.1')) then
	set_item_result(run_stored_sig('WF1_DB_PARAMS6'));  
else 
	print_log('DB Version '||g_rep_info('DB Version')||' is else');
end if;	  
if (substr(g_rep_info('DB Version'),1,4) < '11.2') then
	set_item_result(run_stored_sig('WF1_AQ_TM_PROC1'));
elsif (substr(g_rep_info('DB Version'),1,4) >= '11.2') then 
	set_item_result(run_stored_sig('WF1_AQ_TM_PROC2'));
else 
	set_item_result(run_stored_sig('WF1_AQ_TM_PROC3'));
end if;	  
end_section;
debug('end section: WF_ANZ_OVERVIEW');

debug('begin section: WF_ANZ_ADMIN');
start_section('Workflow Administration');
	if ((g_wfadmin_role like 'FND_RESP%') and (g_wfadmins_cnt = 0)) then
			set_item_result(run_stored_sig('WF2_WFADMIN_RESP_ZERO'));
	  elsif ((g_wfadmin_role like 'FND_RESP%') and (g_wfadmins_cnt = 1)) then
			set_item_result(run_stored_sig('WF2_WFADMIN_RESP_1'));
	  elsif ((g_wfadmin_role like 'FND_RESP%') and (g_wfadmins_cnt > 1)) then
			set_item_result(run_stored_sig('WF2_WFADMIN_RESP'));
	  elsif (g_wfadmin_role = '*') then
			set_item_result(run_stored_sig('WF2_WFADMIN_ASTERISK'));
	  else 
			set_item_result(run_stored_sig('WF2_WFADMIN_USER'));
	end if;
	if (g_sysadmin_ntf_pref = 'DISABLED') then
		set_item_result(run_stored_sig('WF2_SYSADMIN1'));
	  elsif (g_sysadmin_ntf_pref = 'QUERY') then
		set_item_result(run_stored_sig('WF2_SYSADMIN2'));
	  elsif ((g_sysadmin_email = 'NOTSET') and (g_sysadmin_ntf_pref <> 'QUERY')) then
		set_item_result(run_stored_sig('WF2_SYSADMIN3'));
	  elsif ((g_sysadmin_email <> 'NOTSET') and (g_sysadmin_ntf_pref <> 'QUERY')) then 
		set_item_result(run_stored_sig('WF2_SYSADMIN4'));
	  else 
	    set_item_result(run_stored_sig('WF2_SYSADMIN5'));	
	  end if;
wferrors;

 
	if (g_ntferr_cnt = 0) then
		set_item_result(run_stored_sig('WF2_NTF_ERROR_0'));
      elsif (g_ntferr_cnt < 100) then
		set_item_result(run_stored_sig('WF2_NTF_ERROR_1'));
      else 
		set_item_result(run_stored_sig('WF2_NTF_ERRORS'));
	end if;	
	if (g_dee_open_cnt>1)  then
		if (g_dee_open30_cnt = 0) then
			set_item_result(run_stored_sig('WF2_WF_ERROR_NTFS'));
		  elsif (g_dee_open_cnt = g_dee_open30_cnt) then
			set_item_result(run_stored_sig('WF2_WF_ERROR_NTFS2'));
		  else 
			set_item_result(run_stored_sig('WF2_WF_ERROR_NTFS3'));
		end if;
      else 
		set_item_result(run_stored_sig('WF2_WF_ERROR_NTFS4'));
	end if;  
	print_log('Instance Value g_ntfutil_ver = '||g_ntfutil_ver);
	if (g_ntfutil_ver >= '120.47.12020000.12' ) then
	    print_log('Following the steps for Using a Proxy user to grant worklist access');
        set_item_result(run_stored_sig('WF2_WORKLIST_ACCESS2'));
    else
	    print_log('Following old Worklist Access methods');
	    set_item_result(run_stored_sig('WF2_WORKLIST_ACCESS'));
	end if;
   set_item_result(run_stored_sig('WF2_SYSADMINRR'));
   set_item_result(run_stored_sig('WF2_EBS_PROFILES'));
   set_item_result(run_stored_sig('WF2_CC_GSM_ENABLED'));
   set_item_result(run_stored_sig('WF2_WF_PROFILES'));
	if (g_stuck_cnt = 0) then
		set_item_result(run_stored_sig('WF2_STUCK1'));
	  elsif (g_stuck_cnt < 50) then
		set_item_result(run_stored_sig('WF2_STUCK2'));
	  else 
		set_item_result(run_stored_sig('WF2_STUCK3'));
	end if;
	if (g_rep_info('Apps Version') < '12.2') then
		if (g_disabled_cnt = 0) then
			set_item_result(run_stored_sig('WF2_DISABLED1'));
		  elsif (g_disabled_cnt > 50) then
			set_item_result(run_stored_sig('WF2_DISABLED2'));	
		  else 
			set_item_result(run_stored_sig('WF2_DISABLED3'));  
		end if;
	
	elsif  (g_rep_info('Apps Version') >= '12.2')  then
		if (g_disabled_cnt = 0) then
			set_item_result(run_stored_sig('WF2_DISABLED1'));  
	      elsif (g_disabled_cnt > 50) then
			set_item_result(run_stored_sig('WF2_DISABLED4'));
	      else 
			set_item_result(run_stored_sig('WF2_DISABLED5'));	
		end if;
	end if; 
   set_item_result(run_stored_sig('WF2_WF_SERVICES'));
end_section;
debug('end section: WF_ANZ_ADMIN');

debug('begin section: WF_ANZ_FOOTPRINT');
start_section('Workflow Footprint');
	wfruntime;

	if (g_rate>29) then
	  set_item_result(run_stored_sig('WF3_WF_RUNTIME_VOL1'));
	else
	  set_item_result(run_stored_sig('WF3_WF_RUNTIME_VOL2'));
        end if;
   set_item_result(run_stored_sig('WF3_WF_PURGEABLE'));
	if ((g_rep_info('Apps Version') > '12.0') or (g_atgrup4 > 0)) then 
		g_atgrup4 := 1;
	else
		g_atgrup4 := 0; 
	end if;

	if ((g_last_ran is null) and (g_atgrup4 > 0)) then 
		set_item_result(run_stored_sig('WF3_WF_SUMMARY2'));
	elsif ((g_last_ran < sysdate) and (g_atgrup4 > 0)) then 
		set_item_result(run_stored_sig('WF3_WF_SUMMARY3'));
	else 
		set_item_result(run_stored_sig('WF3_WF_SUMMARY1'));
	end if;	 
	  set_item_result(run_stored_sig('WF3_WF_VOL_BY_YR'));
	  set_item_result(run_stored_sig('WF3_WF_AVG_6_MOS'));
	  set_item_result(run_stored_sig('WF3_WF_OVER_90'));


	if ((g_hist_end is null) and (g_hist_days=0)) then 
			set_item_result(run_stored_sig('WF3_WF_LOOPING1'));
		elsif ((g_hist_end is null) and (g_hist_days > 0)) then 	
			set_item_result(run_stored_sig('WF3_WF_LOOPING2'));	
		elsif ((g_hist_end is not null) and (g_hist_days = 0)) then 
			set_item_result(run_stored_sig('WF3_WF_LOOPING3'));      
		else
			set_item_result(run_stored_sig('WF3_WF_LOOPING4'));
	end if;
end_section;
debug('end section: WF_ANZ_FOOTPRINT');

debug('begin section: WF_ANZ_CP');
start_section('Workflow Concurrent Programs');
    if (g_concprgms_cnt	> 0) then
	if (g_alldefrd = 0) then
	    set_item_result(run_stored_sig('WF4_WF_SCHED_CP1'));
	elsif (g_alldefrd > 0) then
	    set_item_result(run_stored_sig('WF4_WF_SCHED_CP2'));
	end if;
			
	if (g_stuckfreq > 0) then
	    set_item_result(run_stored_sig('WF4_WF_SCHED_CP3'));
	end if;
	
	    if (g_prgall = 0) then
		if (g_prgany > 0) then
		  set_item_result(run_stored_sig('WF4_WF_PRGSCHED_CP1'));
		elsif (g_prgany = 0) then
		  set_item_result(run_stored_sig('WF4_WF_PRGSCHED_CP2'));
		end if;

		elsif (g_prgall > 0) then
			set_item_result(run_stored_sig('WF4_WF_PRGSCHED_CP3'));
		end if;
				
		if ((g_prgall > 0) and (g_prgcore = 0)) then
		  set_item_result(run_stored_sig('WF4_WF_PRGSCHED_CP4'));
		end if;
	
	elsif (g_concprgms_cnt = 0) then
	  set_item_result(run_stored_sig('WF4_WF_SCHED_CP4'));

     end if;
   set_item_result(run_stored_sig('WF4_FNDWFBG_RAN'));
   set_item_result(run_stored_sig('WF4_WFBGDFRD'));
   set_item_result(run_stored_sig('WF4_WFBGINDX'));
   set_item_result(run_stored_sig('WF4_WF_GRAPHMONITOR_VER'));
   set_item_result(run_stored_sig('WF4_FNDWFPR_RAN'));
   set_item_result(run_stored_sig('WF4_WF_CONTROL_Q'));
end_section;
debug('end section: WF_ANZ_CP');

debug('begin section: WF_ANZ_NTF');
start_section('Workflow Notification Mailer');
   set_item_result(check_rec_patches_1);
   set_item_result(check_rec_patches_3);
   set_item_result(run_stored_sig('WF2_WF_SERVICES'));
   set_item_result(run_stored_sig('WF5_CONC_TIER_ENV'));
   set_item_result(run_stored_sig('WF5_AUTOCLOSE_FYI'));
   set_item_result(run_stored_sig('WF5_WF_NTF_STATUS'));
   set_item_result(run_stored_sig('WF5_WF_NTF_OUT_STATUS'));
	 if (g_UNREFNTF_CNT > 0) then
		if (g_WFNTFPRG_APPLIED > 0) then 
		  set_item_result(run_stored_sig('WF5_WF_ORPHAN_STATUS1'));
			elsif (g_WFNTFPRG_APPLIED = 0) then 
              set_item_result(run_stored_sig('WF5_WF_ORPHAN_STATUS2'));			
		else
		  set_item_result(run_stored_sig('WF5_WF_ORPHAN_STATUS3'));
		end if;
	 else 
	   set_item_result(run_stored_sig('WF5_WF_ORPHAN_STATUS4'));
	 end if;
end_section;
debug('end section: WF_ANZ_NTF');

debug('begin section: WF_ANZ_PATCH');
start_section('Workflow Patch Levels');
   set_item_result(check_rec_patches_2);
	 if (g_stmt_log_cnt > 0) then
	   set_item_result(run_stored_sig('WF6_WF_LOG_LEVELS'));
	 else
	   set_item_result(run_stored_sig('WF6_WF_LOG_LEVELS2'));
	 end if;
   set_item_result(run_stored_sig('WF6_WF_LOG_LOCATIONS'));
end_section;
debug('end section: WF_ANZ_PATCH');

debug('begin section: WF_ANZ_OM');
IF g_chart_om_cnt > 0 THEN
   start_section('Order Management Specific Workflows');
om_items;

		print_log('ont_hist_end = '||ont_hist_end||'.');
		print_log('ont_hist_begin = '||ont_hist_begin||'.');
		print_log('ont_hist_recent = '||ont_hist_recent||'.');		
		print_log('ont_hasrows = '||ont_hasrows||'.');
		print_log('ont_hist_cnt = '||ont_hist_cnt||'.');
		print_log('ont_hist_days = '||ont_hist_days||'.');
		print_log('ont_hist_daily = '||ont_hist_daily||'.');	
		print_log('ont_hist_item = '||ont_hist_item||'.');
		print_log('ont_hist_key = '||ont_hist_key||'.');
      set_item_result(run_stored_sig('WF7_SUMMARY_ONT_WF'));
      set_item_result(run_stored_sig('WF7_WF_ONT_CP_CHK'));
      set_item_result(run_stored_sig('WF7_WF_DEFERRED_M'));
      set_item_result(run_stored_sig('WF7_WF_DEFRD'));
      set_item_result(run_stored_sig('WF7_OM_WF_STATUS'));
	    if ((ont_hist_end is null) and (ont_hist_days=0)) then 
			set_item_result(run_stored_sig('WF7_ONT_LOOPING1'));
		  elsif ((ont_hist_end is null) and (ont_hist_days > 0)) then 	
			set_item_result(run_stored_sig('WF7_ONT_LOOPING2'));	
		  elsif ((ont_hist_end is not null) and (ont_hist_days = 0)) then 
			set_item_result(run_stored_sig('WF7_ONT_LOOPING3'));      
		  else
			set_item_result(run_stored_sig('WF7_ONT_LOOPING4'));
	    end if;
      set_item_result(run_stored_sig('WF7_ONT_ELIG_HDRS'));
      set_item_result(run_stored_sig('WF7_ONT_ERRORS'));
      set_item_result(run_stored_sig('WF7_ONT_ERR_CANCEL'));
      set_item_result(run_stored_sig('WF7_ONT_LINE_OPEN'));
      set_item_result(run_stored_sig('WF7_OEOL_WF_CLOSED'));
      set_item_result(run_stored_sig('WF7_OEOH_NO_OPEN_LINES'));
      set_item_result(run_stored_sig('WF7_OEOH_CLOSED_OPEN_LINES'));
      set_item_result(run_stored_sig('WF7_ONT_ORPH_HDRS'));
      set_item_result(run_stored_sig('WF7_ONT_ORPH_LINES'));
   end_section;
END IF;
debug('end section: WF_ANZ_OM');

debug('begin section: WF_ANZ_HRMS');
IF g_chart_hr_cnt > 0 THEN
   start_section('Human Resources Specific Workflows');
hcm_items;

      set_item_result(run_stored_sig('WF8_SUMMARY_HCM_WF'));
      set_item_result(run_stored_sig('WF8_HCM_WF_SUMMARY'));
	    if ((hcm_hist_end is null) and (hcm_hist_days=0)) then 
			set_item_result(run_stored_sig('WF8_HCM_LOOPING1'));
		  elsif ((hcm_hist_end is null) and (hcm_hist_days > 0)) then 	
			set_item_result(run_stored_sig('WF8_HCM_LOOPING2'));	
		  elsif ((hcm_hist_end is not null) and (hcm_hist_days = 0)) then 
			set_item_result(run_stored_sig('WF8_HCM_LOOPING3'));      
		  else
			set_item_result(run_stored_sig('WF8_HCM_LOOPING4'));
	    end if;
      set_item_result(run_stored_sig('WF8_HCM_ERRORS'));
      set_item_result(run_stored_sig('WF8_HCM_ERRORS_TO_CANCEL'));
   end_section;
END IF;
debug('end section: WF_ANZ_HRMS');

debug('begin section: WF_ANZ_PO');
IF g_chart_po_cnt > 0 THEN
   start_section('Purchasing Specific Workflows');
po_items;
      set_item_result(run_stored_sig('WF9_SUMMARY_PO_WF'));
      set_item_result(run_stored_sig('WF9_PO_WF_STATUS'));
		if ((po_hist_end is null) and (po_hist_days=0)) then 
			set_item_result(run_stored_sig('WF9_PO_LOOPING1'));
		  elsif ((po_hist_end is null) and (po_hist_days > 0)) then 	
			set_item_result(run_stored_sig('WF9_PO_LOOPING2'));	
		  elsif ((po_hist_end is not null) and (po_hist_days = 0)) then 
			set_item_result(run_stored_sig('WF9_PO_LOOPING3'));      
		  else
			set_item_result(run_stored_sig('WF9_PO_LOOPING4'));
		end if;
      set_item_result(run_stored_sig('WF9_PO_WF_IN_ERR'));
      set_item_result(run_stored_sig('WF9_PO_INCMPLT_WF'));
      set_item_result(run_stored_sig('WF9_PO_INCMPLT_CHILD'));
      set_item_result(run_stored_sig('WF9_PO_INCMPLT_APPRVD'));
      set_item_result(run_stored_sig('WF9_PO_ACCT_GEN'));
      set_item_result(run_stored_sig('WF9_PO_ICMPLT_REQ'));
      set_item_result(run_stored_sig('WF9_REQ_INCMPLT_CHLD_ACTV'));
      set_item_result(run_stored_sig('WF9_REQ_INCMPLT_WF_ACTV'));
      set_item_result(run_stored_sig('WF9_INCMPLT_ACTV_APPRV_REQ'));
      set_item_result(run_stored_sig('WF9_REQ_ACCT_GEN_WF'));
   end_section;
END IF;
debug('end section: WF_ANZ_PO');

debug('begin section: WF_ANZ_REFS');
start_section('References');
   set_item_result(run_stored_sig('WF10_WF_REFERENCES'));
end_section;
debug('end section: WF_ANZ_REFS');



  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  print_out('<a href="https://community.oracle.com/thread/2923628" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the EBS ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 

  IF g_is_concurrent THEN
     l_completion_status:=FND_CONCURRENT.SET_COMPLETION_STATUS('NORMAL','');
  END IF;
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);

  IF g_is_concurrent THEN
     l_completion_status:=FND_CONCURRENT.SET_COMPLETION_STATUS('ERROR',g_errbuf);
  END IF; 
   
END main;


BEGIN
 
   null;




   main(  );


EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);



END;

/
show errors
exit; 
-- Exit required for bundling project so do not remove