set pages 500
set lines 100
col sid for 99999
col user_name for a10 trunc

select b.sid sid,d.user_name nam
from apps.fnd_logins a, 
v$session b, v$process c, apps.fnd_user d
where b.paddr = c.addr
and a.pid=c.pid
and a.spid = b.process
and d.user_id = a.user_id
and b.sid = '&n'
/


SELECT B.SESSION_ID AS SID,
NVL(B.ORACLE_USERNAME, '(oracle)') AS USERNAME,
A.OWNER AS OBJECT_OWNER,
A.OBJECT_NAME,
DECODE(B.LOCKED_MODE, 0, 'None',
1, 'Null (NULL)',
2, 'Row-S (SS)',
3, 'Row-X (SX)',
4, 'Share (S)',
5, 'S/Row-X (SSX)',
6, 'Exclusive (X)',
B.LOCKED_MODE) LOCKED_MODE,
B.OS_USER_NAME
FROM DBA_OBJECTS A,
V$LOCKED_OBJECT B
WHERE A.OBJECT_ID = B.OBJECT_ID
AND A.OBJECT_NAME in ('OE_ORDER_HEADERS_ALL','OE_ORDER_LINES_ALL')
ORDER BY 1, 2, 3, 4; 