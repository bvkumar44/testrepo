select 'ls -lrth *'||oracle_process_id||'*' SPID from apps.fnd_concurrent_requests where request_id=&Request_id
/