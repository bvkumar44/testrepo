set term off;
set feed off;

CREATE OR REPLACE PACKAGE XXARTO_GET_PWD AS
 FUNCTION decrypt (KEY IN VARCHAR2, VALUE IN VARCHAR2)
 RETURN VARCHAR2;
 END XXARTO_GET_PWD;
 /
 
CREATE OR REPLACE PACKAGE BODY XXARTO_GET_PWD AS
FUNCTION decrypt (KEY IN VARCHAR2, VALUE IN VARCHAR2)
RETURN VARCHAR2 AS
LANGUAGE JAVA NAME 'oracle.apps.fnd.security.WebSessionManagerProc.decrypt
(java.lang.String,java.lang.String) return java.lang.String';
END XXARTO_GET_PWD;
/

set term on feed on line 150;
col USER_NAME for a30
col DESCRIPTION for a30
col PASSWORD for a30

SELECT Usr.User_Name,
        Usr.Description,
        XXARTO_GET_PWD.Decrypt (
           (SELECT (SELECT XXARTO_GET_PWD.Decrypt (
                              Fnd_Web_Sec.Get_Guest_Username_Pwd,
                              Usertable.Encrypted_Foundation_Password)
                      FROM DUAL)
                      AS Apps_Password
              FROM applsys.Fnd_User Usertable
             WHERE Usertable.User_Name =
                      (SELECT SUBSTR (
                                 Fnd_Web_Sec.Get_Guest_Username_Pwd,
                                 1,
                                 INSTR (Fnd_Web_Sec.Get_Guest_Username_Pwd,
                                        '/')
                                 - 1)
                         FROM DUAL)),
           Usr.Encrypted_User_Password)
           Password
   FROM applsys.Fnd_User Usr
  WHERE Usr.User_Name = '&User_Name';

set term off;
set feed off;
drop package XXARTO_GET_PWD;
set term on;
set feed on;
 