select session_id,object_name nam
from v$locked_object a,dba_objects b
where a.object_id = b.object_id
/


SELECT B.SESSION_ID AS SID,
NVL(B.ORACLE_USERNAME, '(oracle)') AS USERNAME,
A.OWNER AS OBJECT_OWNER,
A.OBJECT_NAME,
DECODE(B.LOCKED_MODE, 0, 'None',
1, 'Null (NULL)',
2, 'Row-S (SS)',
3, 'Row-X (SX)',
4, 'Share (S)',
5, 'S/Row-X (SSX)',
6, 'Exclusive (X)',
B.LOCKED_MODE) LOCKED_MODE,
B.OS_USER_NAME
FROM DBA_OBJECTS A,
V$LOCKED_OBJECT B
WHERE A.OBJECT_ID = B.OBJECT_ID
AND A.OBJECT_NAME in ('OE_ORDER_HEADERS_ALL','OE_ORDER_LINES_ALL')
ORDER BY 1, 2, 3, 4;