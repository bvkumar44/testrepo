set lines 120
select a.inst_id,a.sid,serial#,action,module,last_call_et,status,b.event,sql_id
 from gv$session a,gv$session_wait b 
where a.sid = b.sid and
      a.inst_id = b.inst_id and
      a.sid in (&sid)
/
