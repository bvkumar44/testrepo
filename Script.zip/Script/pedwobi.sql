conn system/Pedwobi1@PEDWOBI
set time on
set sqlprompt PEDWOBI>