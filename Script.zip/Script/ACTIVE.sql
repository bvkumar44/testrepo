set pages 500
set lines 140
col module for a40 trunc
col action for a20 trunc 
col uname for a10 trunc
col event for a20 trunc
select sid,serial#,action,module,last_call_et,status,event
 from v$session
where type!='BACKGROUND'
AND event not like '%SQL%'
and event not like '%pipe%'
and event not like '%PL/SQL%'
and event not like '%Streams%';
