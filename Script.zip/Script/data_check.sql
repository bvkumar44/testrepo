REM
REM FILENAME
REM data_check.sql
REM DESCRIPTION
REM find the difference in data before/after the upgrade
REM NOTES
REM Usage: sqlplus <ofsa_user/ofsa_passwd> @data_check
REM
REM
REM $Id: data_check.sql,v 1.0 
REM
REM
REM +==============================+
select count (*) 
  from 
(
( select * from &old@DEV
  minus 
  select * from &new)
union all
( select * from &new
  minus
  select * from &old@DEV)
)
/