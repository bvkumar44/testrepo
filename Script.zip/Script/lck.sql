set lines 150
col sid for 9999
col module for a20 trunc
col action for a20 trunc
col program for a20 trunc
col nam for a30 
col owner for a10 trunc


select b.session_id sid ,c.object_name nam,c.owner,b.locked_mode mod
from  v$locked_object b ,dba_objects c
where c.object_id = b.object_id order by 2;



Hi,

1.Uploaded the trace file with binds and waits without tkprof (as suggested in the Note).

2.Uploaded the Screen shot for incompatibilities setup for APXIIMPT program.


3.The below Lock info sql dint return any rows .
select /*+ ORDERED */ l.sid, s.name, decode(m.lmode,0,'Waiting','Holder') hw
from v$lock l,
(select sid, lmode
from v$lock l
where id1 in
(select id1
from v$lock
where lmode=0)) m,
sys.obj$ s
where l.sid = m.sid
and l.type = 'TM'
and l.id1 = s.obj#;

