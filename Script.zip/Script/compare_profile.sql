select a.application_id,a.profile_option_id,a.level_id,a.level_value
from fnd_profile_option_values a,profile_option_values_25dec b
where 	a.application_id= b.application_id
and 	a.profile_option_id=b.profile_option_id
and 	a.level_id= b.level_id
and 	a.level_value= b.level_value 
and     a.profile_option_value!= b.profile_option_value
/
