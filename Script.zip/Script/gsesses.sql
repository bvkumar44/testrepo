select ' Sid, Serial#, Aud sid : '|| s.sid||' , '||s.serial#||' , '||
       s.audsid||chr(10)|| '     DB User / OS User : '||s.username||
       '   /   '||s.osuser||chr(10)|| '    Machine - Terminal : '||
       s.machine||'  -  '|| s.terminal||chr(10)|| s.module||'-'||s.action ||
       '        OS Process Ids : '||
       s.process||' (Client)  '||p.spid||' - '||p.pid||' (Server)'|| chr(10)||
       '   Client Program Name : '||s.program ||s.client_identifier "Session Info"
  from gv$process p,gv$session s
 where p.inst_id = s.inst_id
and p.addr = s.paddr
and s.sid = &sid;
/
