CONN APPS/k6apil@erpprod.world
set sqlprompt ERPPROD>