col object_name for a30 trunc
set lines 100
set pages 500

select /*+ RULE */ a.object_id,a.session_id,b.object_name from v$locked_object a,dba_objects b
where a.object_id = b.object_id order by 3;