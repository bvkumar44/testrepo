set linesize 150
set pagesize 150
col session_id for 9999999
col object_id for 9999999
col object_name for a40
select session_id,a.object_id,object_name from v$locked_object a ,dba_objects b where a.object_id = b.object_id order by 2
/
