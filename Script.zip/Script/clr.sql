CREATE OR REPLACE PACKAGE BODY APPS.gem_auto_quick_ship_core
IS

/* $Header: /usr/bpa/dev/gemini/cvsroot/11.5/adv_products/adv_shipping/quick_ship/gem_auto_quick_ship_core.sqb,v 1.34 2006/03/09 21:52:46 shmaho Exp $ */


   /*
   ||****************************************************************************
   || FUNCTION update_number_of_lpn
   || Desc: This function will update the number_of_lpn field of a delivery.
   ||****************************************************************************
   */
   FUNCTION update_number_of_lpn(usr             IN   bp_apps.appsUsr,
                                 txn             IN   bp_apps.appsTxn,
                                 vp_delivery_id  IN   NUMBER)
      RETURN BOOLEAN
   IS
      l_api_return_status        VARCHAR2(1);
      l_msg_count                NUMBER;
      l_msg_data                 VARCHAR2(2000);

      v_new_del_rec              WSH_DELIVERIES_PUB.delivery_pub_rec_type;
      v_del_id                   NUMBER;
      v_del_name                 VARCHAR2(30);

   BEGIN
      v_new_del_rec.delivery_id := vp_delivery_id;
      v_new_del_rec.number_of_lpn := NULL;

      WSH_DELIVERIES_PUB.create_update_delivery
      (
         p_api_version_number    =>  1.0,
         p_init_msg_list         =>  FND_API.G_TRUE,
         x_return_status         =>  l_api_return_status,
         x_msg_count             =>  l_msg_count,
         x_msg_data              =>  l_msg_data,
         p_action_code           =>  'UPDATE',
         p_delivery_info         =>  v_new_del_rec,
         p_delivery_name         =>  NULL,
         x_delivery_id           =>  v_del_id,
         x_name                  =>  v_del_name
      );
      IF (l_api_return_status != FND_API.G_RET_STS_SUCCESS) THEN
         bpascui.display_error('Update Del ERROR', fnd_msg_pub.get(1, NULL), usr.error_wait);
         co_debug.debug('gem_auto_quick_ship_core.update_number_of_lpn', 'ERROR: '||fnd_msg_pub.get(1, null));
         RETURN FALSE;
      END IF;

      RETURN TRUE;

   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN OTHERS THEN
         bpascui.display_error('update_number_of_lpn', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END update_number_of_lpn;



   /*
   ||****************************************************************************
   || Func: trip_validate
   || Desc: This function will make sure that the trip is valid
   ||****************************************************************************
   */
   FUNCTION trip_validate(usr          IN OUT bp_apps.AppsUsr,
                          txn          IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      CURSOR get_trips IS
         SELECT wt.name,
                wt.trip_id,
                wt.ship_method_code,
                msi.concatenated_segments vehicle,
                wt.vehicle_number
           FROM wsh_trips wt,
                mtl_system_items_b_kfv msi
          WHERE UPPER(wt.name) LIKE UPPER(txn.input || '%')
            AND wt.status_code = 'OP'
            AND msi.organization_id(+) = wt.vehicle_organization_id
            AND msi.inventory_item_id(+) = wt.vehicle_item_id
         ORDER BY wt.name;
   BEGIN
      IF (LENGTH(txn.input) > 30) THEN
         bp_apps.error_message(usr, txn, 1163);
         RETURN FALSE;
      END IF;

      IF (txn.input = 'NEW') THEN
         IF (NOT gem_auto_add_delivery_core.create_trip(usr, txn.trip_name)) THEN
            RETURN FALSE;
         END IF;
         txn.ship_method_code := NULL;
         txn.vehicle := NULL;
         txn.vehicle_number := NULL;
         SELECT wt.trip_id
           INTO txn.trip_id
           FROM wsh_trips wt
          WHERE wt.name = txn.trip_name;
         RETURN TRUE;
      ELSIF (INSTR(txn.input,'%') = 0) THEN
         BEGIN
            SELECT wt.name,
                   wt.trip_id,
                   wt.ship_method_code,
                   msi.concatenated_segments,
                   wt.vehicle_number
              INTO txn.trip_name,
                   txn.trip_id,
                   txn.ship_method_code,
                   txn.vehicle,
                   txn.vehicle_number
              FROM wsh_trips wt,
                   mtl_system_items_b_kfv msi,
                   wsh_carrier_ship_methods_v wcs
             WHERE wt.name = txn.input
               AND wt.status_code = 'OP'
               AND wcs.ship_method_code(+) = wt.ship_method_code
               AND wcs.organization_id(+) = usr.organization_id
               AND msi.organization_id(+) = wt.vehicle_organization_id
               AND msi.inventory_item_id(+) = wt.vehicle_item_id;

            RETURN TRUE;
         EXCEPTION
            WHEN no_data_found THEN
               NULL;
         END;
      END IF;
      bpl_aio.start_table;
      FOR trip_rec IN get_trips LOOP
         IF (NOT bpl_aio.table_row(trip_rec.name)) THEN
            EXIT;
         END IF;

         bpl_aio.put_variable('trip_name', trip_rec.name);
         bpl_aio.put_variable('trip_id', trip_rec.trip_id);
         bpl_aio.put_variable('ship_method_code', trip_rec.ship_method_code);
         bpl_aio.put_variable('vehicle', trip_rec.vehicle);
         bpl_aio.put_variable('vehicle_number', trip_rec.vehicle_number);
      END LOOP;

      IF (NOT bpl_aio.quick_pick(gem_fields.get_prompt('trip'))) THEN
         RETURN FALSE;
      END IF;

      txn.trip_name                := bpl_aio.get_variable('trip_name');
      txn.trip_id                  := bpl_aio.get_variable('trip_id');
      txn.ship_method_code         := bpl_aio.get_variable('ship_method_code');
      txn.vehicle                  := bpl_aio.get_variable('vehicle');
      txn.vehicle_number           := bpl_aio.get_variable('vehicle_number');
      RETURN TRUE;
   EXCEPTION
      WHEN no_data_found THEN
         bp_apps.error_message(usr, txn, 1219);
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.trip_validate', SQLERRM);
         bpascui.display_error('GAQSC01 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END trip_validate;

   /*
   ||****************************************************************************
   || Func: update_del_ship_method
   || Desc: The following function will update the delivery with the ship method
   ||****************************************************************************
   */
   FUNCTION update_del_ship_method (usr          IN OUT bp_apps.AppsUsr,
                                    txn          IN     bp_apps.AppsTxn,
                                    vp_del_id    IN     NUMBER,
                                    vp_code      IN     wsh_new_deliveries.ship_method_code%TYPE)
      RETURN BOOLEAN
   IS
      CURSOR get_details IS
         SELECT wdd.delivery_detail_id,
                wdd.intmed_ship_to_location_id,
                wdd.fob_code,
                wdd.freight_terms_code
           FROM wsh_delivery_details wdd,
                wsh_delivery_assignments wda
          WHERE wda.delivery_id = vp_del_id
            AND wdd.delivery_detail_id = wda.delivery_detail_id;

      l_api_return_status           VARCHAR2(1);
      l_msg_count                   NUMBER;
      l_msg_data                    VARCHAR2(2000);
      v_new_del_rec                 WSH_DELIVERIES_PUB.delivery_pub_rec_type;
      v_delivery_id                 NUMBER;
      v_delivery_name               VARCHAR2(30);

      v_idx                         NUMBER;
      v_changed_table               WSH_DELIVERY_DETAILS_PUB.ChangedAttributeTabType;
   BEGIN
      co_debug.debug('gem_auto_quick_ship_core.update_del_ship_method', 'Updating delivery '||vp_del_id||' with ship_method_code '||vp_code, co_debug.SEVERITY_MESSAGE);
      v_new_del_rec.delivery_id := vp_del_id;
      v_new_del_rec.ship_method_code := vp_code;
      WSH_DELIVERIES_PUB.create_update_delivery
      (
         p_api_version_number    =>  1.0,
         p_init_msg_list         =>  FND_API.G_TRUE,
         x_return_status         =>  l_api_return_status,
         x_msg_count             =>  l_msg_count,
         x_msg_data              =>  l_msg_data,
         p_action_code           =>  'UPDATE',
         p_delivery_info         =>  v_new_del_rec,
         p_delivery_name         =>  NULL,
         x_delivery_id           =>  v_delivery_id,
         x_name                  =>  v_delivery_name
      );
      IF (NOT bpa_request.post_api(usr,
                                   'WSH_DELIVERIES_PUB.create_update_delivery',
                                   l_api_return_status,
                                   l_msg_count,
                                   'Update Delivery Error')) THEN
         RETURN(FALSE);
      END IF;

      /* Now update details of delivery */
      v_idx := 0;
      FOR detail_rec IN get_details LOOP
         v_idx := v_idx + 1;
         v_changed_table(v_idx).delivery_detail_id    := detail_rec.delivery_detail_id;
         v_changed_table(v_idx).intmed_ship_to_org_id := detail_rec.intmed_ship_to_location_id;
         v_changed_table(v_idx).fob_code              := detail_rec.fob_code;
         v_changed_table(v_idx).freight_terms_code    := detail_rec.freight_terms_code;
         v_changed_table(v_idx).shipping_method_code  := vp_code;
      END LOOP;
      IF (v_idx > 0) THEN
         IF (NOT gem_auto_pack_lpn_core.assign_group_attributes(usr, v_changed_table)) THEN
            RETURN FALSE;
         END IF;
      END IF;

      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.update_del_ship_method', SQLERRM);
         bpascui.display_error('GAQSC02 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END update_del_ship_method;

   /*
   ||****************************************************************************
   || Func: delivery_to_trip_action
   || Desc: The function will perform the specified function on the delivery to
   ||       trip interelationship.
   ||****************************************************************************
   */
   FUNCTION delivery_to_trip_action(usr           IN OUT bp_apps.AppsUsr,
                                    vp_code       IN     VARCHAR2,
                                    vp_del_id     IN     NUMBER,
                                    vp_trip_id    IN     NUMBER,
                                    vp_del_rec    IN OUT update_delivery_rec)
      RETURN BOOLEAN
   IS
      l_api_return_status           VARCHAR2(1);
      l_msg_count                   NUMBER;
      l_msg_data                    VARCHAR2(2000);
      v_asg_pickup_stop_id          NUMBER;
      v_asg_pickup_loc_id           NUMBER;
      v_asg_pickup_loc_code         VARCHAR2(30);
      v_asg_pickup_arr_date         DATE;
      v_asg_pickup_dep_date         DATE;
      v_asg_dropoff_stop_id         NUMBER;
      v_asg_dropoff_loc_id          NUMBER;
      v_asg_dropoff_loc_code        VARCHAR2(30);
      v_asg_dropoff_arr_date        DATE;
      v_asg_dropoff_dep_date        DATE;
      v_trip_id                     NUMBER;
      v_trip_name                   VARCHAR2(30);
   BEGIN

      IF (vp_code = ASSIGN_TO_TRIP AND vp_del_rec.pick_up_stop_id IS NOT NULL) THEN
         v_asg_pickup_stop_id := vp_del_rec.pick_up_stop_id;
         v_asg_pickup_arr_date := vp_del_rec.arrival_date;
         v_asg_pickup_dep_date := vp_del_rec.depart_date;
         co_debug.debug('gem_auto_quick_ship_core.delivery_to_trip_action', 'Assigning to '||v_asg_pickup_stop_id||' '||v_asg_pickup_arr_date, co_debug.SEVERITY_MESSAGE);
      ELSIF (vp_code = UNASSIGN_FROM_TRIP) THEN
         SELECT wdl.delivery_id,
                wdl.pick_up_stop_id,
                wts.planned_arrival_date,
                wts.planned_departure_date
           INTO vp_del_rec.delivery_id,
                vp_del_rec.pick_up_stop_id,
                vp_del_rec.arrival_date,
                vp_del_rec.depart_date
           FROM wsh_trip_stops wts,
                wsh_delivery_legs wdl
          WHERE wdl.delivery_id = vp_del_id
            AND wts.stop_id = wdl.pick_up_stop_id;
      END IF;

      co_debug.debug('gem_auto_quick_ship_core.delivery_to_trip_action', 'Performing '||vp_code||' on '||vp_del_id||' to '||vp_trip_id, co_debug.SEVERITY_MESSAGE);

      WSH_DELIVERIES_PUB.Delivery_Action
      (
         p_api_version_number       => 1.0,
         p_init_msg_list            => FND_API.G_TRUE,
         x_return_status            => l_api_return_status,
         x_msg_count                => l_msg_count,
         x_msg_data                 => l_msg_data,
         p_action_code              => vp_code,
         p_delivery_id              => vp_del_id,
         p_delivery_name            => NULL,
         p_asg_trip_id              => vp_trip_id,
         p_asg_trip_name            => NULL,
         p_asg_pickup_stop_id       => v_asg_pickup_stop_id,
         p_asg_pickup_loc_id        => v_asg_pickup_loc_id,
         p_asg_pickup_loc_code      => v_asg_pickup_loc_code,
         p_asg_pickup_arr_date      => v_asg_pickup_arr_date,
         p_asg_pickup_dep_date      => v_asg_pickup_dep_date,
         p_asg_dropoff_stop_id      => v_asg_dropoff_stop_id,
         p_asg_dropoff_loc_id       => v_asg_dropoff_loc_id,
         p_asg_dropoff_loc_code     => v_asg_dropoff_loc_code,
         p_asg_dropoff_arr_date     => v_asg_dropoff_arr_date,
         p_asg_dropoff_dep_date     => v_asg_dropoff_dep_date,
         p_sc_action_flag           => 'S',
         p_sc_intransit_flag        => 'N',
         p_sc_close_trip_flag       => 'N',
         p_sc_create_bol_flag       => 'N',
         p_sc_stage_del_flag        => 'Y',
         p_sc_trip_ship_method      => NULL,
         p_sc_actual_dep_date       => NULL,
         p_sc_report_set_id         => NULL,
         p_sc_report_set_name       => NULL,
         p_sc_defer_interface_flag  => 'N',
         p_wv_override_flag         => 'N',
         x_trip_id                  => v_trip_id,
         x_trip_name                => v_trip_name
      );
      IF (NOT bpa_request.post_api(usr,
                                   'WSH_DELIVERIES_PUB.Delivery_Action',
                                   l_api_return_status,
                                   l_msg_count,
                                   'API Error')) THEN
         RETURN(FALSE);
      END IF;

      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.delivery_to_trip_action', SQLERRM);
         bpascui.display_error('GAQSC03 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END delivery_to_trip_action;

   /*
   ||****************************************************************************
   || Func: unassign_all_deliveries
   || Desc: This function will prepare each delivery on trip for reassignment.
   ||       it will pass PL/SQL table back of deliveries that were assigned.
   ||****************************************************************************
   */
   FUNCTION unassign_all_deliveries(usr                  IN OUT bp_apps.AppsUsr,
                                    txn                  IN     bp_apps.AppsTxn,
                                    vp_deliveries           OUT update_delivery_tbl)
      RETURN BOOLEAN
   IS
      CURSOR get_deliveries IS
         SELECT wdl.delivery_id
           FROM wsh_delivery_legs wdl,
                wsh_trip_stops wts
          WHERE wts.trip_id = txn.trip_id
            AND wdl.pick_up_stop_id = wts.stop_id;

      v_deliveries                  update_delivery_tbl;
      v_temp_del_rec                update_delivery_rec;
      v_idx                         NUMBER;
   BEGIN

      v_idx := 0;
      FOR del_rec IN get_deliveries LOOP
         v_idx := v_idx + 1;
         v_deliveries(v_idx) := v_temp_del_rec;
         IF (NOT delivery_to_trip_action(usr, UNASSIGN_FROM_TRIP, del_rec.delivery_id, txn.trip_id, v_deliveries(v_idx))) THEN
            RETURN FALSE;
         END IF;
      END LOOP;

      vp_deliveries := v_deliveries;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.unassign_all_deliveries', SQLERRM);
         bpascui.display_error('GAQSC04 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END unassign_all_deliveries;

   /*
   ||****************************************************************************
   || Func: assign_all_deliveries
   || Desc: The following function will assign all deliveries to the trip
   ||****************************************************************************
   */
   FUNCTION assign_all_deliveries(usr           IN OUT bp_apps.AppsUsr,
                                  txn           IN     bp_apps.AppsTxn,
                                  vp_deliveries IN OUT update_delivery_tbl)
      RETURN BOOLEAN
   IS
   BEGIN

      FOR i IN 1..vp_deliveries.COUNT LOOP
         IF (NOT delivery_to_trip_action(usr, ASSIGN_TO_TRIP, vp_deliveries(i).delivery_id, txn.trip_id, vp_deliveries(i))) THEN
            RETURN FALSE;
         END IF;
      END LOOP;

      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.assign_all_deliveries', SQLERRM);
         bpascui.display_error('GAQSC05 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END assign_all_deliveries;

   /*
   ||****************************************************************************
   || Func: update_trip_ship_method
   || Desc: The following function will update the trip with the ship method
   ||****************************************************************************
   */
   FUNCTION update_trip_ship_method(usr          IN OUT bp_apps.AppsUsr,
                                    txn          IN     bp_apps.AppsTxn,
                                    vp_code      IN     wsh_new_deliveries.ship_method_code%TYPE)
      RETURN BOOLEAN
   IS
      l_api_return_status         VARCHAR2(1);
      l_msg_count                 NUMBER;
      l_msg_data                  VARCHAR2(2000);
      v_trip_rec                  WSH_TRIPS_PUB.Trip_Pub_Rec_Type;
      v_trip_id                   NUMBER;
      v_trip_name                 VARCHAR2(30);
      v_deliveries                update_delivery_tbl;
   BEGIN
      co_debug.debug('gem_auto_quick_ship_core.update_del_ship_method', 'Updating trip '||txn.trip_name||' with ship_method_code '||vp_code, co_debug.SEVERITY_MESSAGE);
      IF (NOT unassign_all_deliveries(usr, txn, v_deliveries)) THEN
         RETURN FALSE;
      END IF;

      v_trip_rec.trip_id := txn.trip_id;
      v_trip_rec.name := txn.trip_name;
      v_trip_rec.ship_method_code := vp_code;
      WSH_TRIPS_PUB.create_update_trip
      (
         p_api_version_number   => 1.0,
         p_init_msg_list        => FND_API.G_TRUE,
         x_return_status        => l_api_return_status,
         x_msg_count            => l_msg_count,
         x_msg_data             => l_msg_data,
         p_action_code          => 'UPDATE',
         p_trip_info            => v_trip_rec,
         p_trip_name            => NULL,
         x_trip_id              => v_trip_id,
         x_trip_name            => v_trip_name
      );
      IF (NOT bpa_request.post_api(usr,
                                   'WSH_TRIPS_PUB.create_update_trip',
                                   l_api_return_status,
                                   l_msg_count,
                                   'Update Trip Error')) THEN
         RETURN(FALSE);
      END IF;

      FOR i IN 1..v_deliveries.COUNT LOOP
         IF (NOT update_del_ship_method(usr, txn, v_deliveries(i).delivery_id, vp_code)) THEN
            RETURN FALSE;
         END IF;
      END LOOP;

      IF (NOT assign_all_deliveries(usr, txn, v_deliveries)) THEN
         RETURN FALSE;
      END IF;

      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.update_trip_ship_method', SQLERRM);
         bpascui.display_error('GAQSC06 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END update_trip_ship_method;

   /*
   ||****************************************************************************
   || Func: delivery_validate
   || Desc: This function will make sure that the delivery is valid.
   ||****************************************************************************
   */
   FUNCTION delivery_validate(usr          IN OUT bp_apps.AppsUsr,
                              txn          IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      CURSOR get_deliveries IS
         SELECT wnd.name,
                wnd.delivery_id,
                wnd.ship_method_code,
                wnd.customer_id,
                wnd.initial_pickup_location_id ship_from_location_id,
                wnd.ultimate_dropoff_location_id deliver_to_location_id,
                wnd.intmed_ship_to_location_id,
                wnd.fob_code,
                wnd.freight_terms_code
           FROM wsh_new_deliveries wnd
          WHERE UPPER(wnd.name) LIKE UPPER(txn.input || '%')
            AND wnd.status_code = 'OP'
            AND NVL(wnd.organization_id, usr.organization_id) = usr.organization_id
            AND (wnd.ship_method_code IS NULL OR txn.ship_method_code IS NULL OR wnd.ship_method_code = txn.ship_method_code)
            AND NOT EXISTS (SELECT *
                              FROM wsh_delivery_legs wdl,
                                   wsh_trip_stops wts
                             WHERE wdl.delivery_id = wnd.delivery_id
                               AND wts.stop_id = wdl.pick_up_stop_id
                               AND wts.trip_id != txn.trip_id)
         ORDER BY wnd.name;

      v_profile_value         VARCHAR2(255);
      v_ship_method_code      wsh_new_deliveries.ship_method_code%TYPE;
      v_del_rec               update_delivery_rec;
      v_count                 NUMBER;
      v_del_seq               VARCHAR2(5);

   BEGIN
      IF (LENGTH(txn.input) > 30) THEN
         bp_apps.error_message(usr, txn, 1163);
         RETURN FALSE;
      END IF;

      IF (txn.input = 'NEW') THEN
         IF NOT (bp_apps.get_profile (usr, 'CO_DELIVERY_SEQUENCE', v_del_seq, FALSE)) THEN
            SELECT wsh_new_deliveries_s.NEXTVAL
              INTO txn.delivery_name
              FROM DUAL;
         ELSE
            IF (NOT bp_apps.get_profile(usr, 'CO_AUTO_DLY_PREFIX', v_profile_value, FALSE)) THEN
               v_profile_value := 'D';
            END IF;
            SELECT v_profile_value || LPAD(co_auto_delivery_s.nextval, 10 - LENGTH(v_profile_value), 0)
              INTO txn.delivery_name
              FROM dual;
         END IF;
         txn.delivery_id := NULL;
         txn.customer_id := NULL;
         txn.ship_from_location_id := NULL;
         txn.deliver_to_location_id := NULL;
         txn.intmed_ship_to_location_id := NULL;
         txn.fob_code := NULL;
         txn.freight_terms_code := NULL;
         RETURN TRUE;
      ELSIF (INSTR(txn.input, '%') = 0) THEN
         BEGIN
            SELECT wnd.name,
                   wnd.delivery_id,
                   wnd.ship_method_code,
                   wnd.customer_id,
                   wnd.initial_pickup_location_id ship_from_location_id,
                   wnd.ultimate_dropoff_location_id deliver_to_location_id,
                   wnd.intmed_ship_to_location_id,
                   wnd.fob_code,
                   wnd.freight_terms_code
              INTO txn.delivery_name,
                   txn.delivery_id,
                   v_ship_method_code,
                   txn.customer_id,
                   txn.ship_from_location_id,
                   txn.deliver_to_location_id,
                   txn.intmed_ship_to_location_id,
                   txn.fob_code,
                   txn.freight_terms_code
              FROM wsh_new_deliveries wnd
             WHERE wnd.name = txn.input
               AND wnd.status_code = 'OP'
               AND NVL(wnd.organization_id, usr.organization_id) = usr.organization_id
               AND (wnd.ship_method_code IS NULL OR txn.ship_method_code IS NULL OR wnd.ship_method_code = txn.ship_method_code)
               AND NOT EXISTS (SELECT *
                                 FROM wsh_delivery_legs wdl,
                                      wsh_trip_stops wts
                                WHERE wdl.delivery_id = wnd.delivery_id
                                  AND wts.stop_id = wdl.pick_up_stop_id
                                  AND wts.trip_id != txn.trip_id);
            co_debug.debug('gem_auto_quick_ship_core.delivery_validate', 'del ship_method_code = '||v_ship_method_code, co_debug.SEVERITY_MESSAGE);
            co_debug.debug('gem_auto_quick_ship_core.delivery_validate', 'trip ship_method_code = '||txn.ship_method_code, co_debug.SEVERITY_MESSAGE);
            /* Trip needs to be updated with ship method code */
            IF (v_ship_method_code IS NOT NULL AND txn.ship_method_code IS NULL) THEN
               IF (NOT update_trip_ship_method(usr, txn, v_ship_method_code)) THEN
                  RETURN FALSE;
               END IF;
               txn.ship_method_code := v_ship_method_code;
            /* Delivery needs to update ship method code to match trip */
            ELSIF (v_ship_method_code IS NULL AND txn.ship_method_code IS NOT NULL) THEN
               IF (NOT update_del_ship_method(usr, txn, txn.delivery_id, txn.ship_method_code)) THEN
                  RETURN FALSE;
               END IF;
            END IF;

            SELECT COUNT(1)
              INTO v_count
              FROM wsh_delivery_legs
             WHERE delivery_id = txn.delivery_id;

            IF (v_count = 0) THEN
               IF (NOT delivery_to_trip_action(usr, ASSIGN_TO_TRIP, txn.delivery_id, txn.trip_id, v_del_rec)) THEN
                  RETURN FALSE;
               END IF;
            END IF;
            RETURN TRUE;
         EXCEPTION
            WHEN no_data_found THEN
               NULL;
         END;
      END IF;

      bpl_aio.start_table;
      FOR del_rec IN get_deliveries LOOP
         IF (NOT bpl_aio.table_row(del_rec.name)) THEN
            EXIT;
         END IF;

         bpl_aio.put_variable('delivery_id', del_rec.delivery_id);
         bpl_aio.put_variable('delivery_name', del_rec.name);
         bpl_aio.put_variable('ship_method_code', del_rec.ship_method_code);
         bpl_aio.put_variable('customer_id', del_rec.customer_id);
         bpl_aio.put_variable('ship_from_location_id', del_rec.ship_from_location_id);
         bpl_aio.put_variable('deliver_to_location_id', del_rec.deliver_to_location_id);
         bpl_aio.put_variable('intmed_ship_to_location_id', del_rec.intmed_ship_to_location_id);
         bpl_aio.put_variable('fob_code', del_rec.fob_code);
         bpl_aio.put_variable('freight_terms_code', del_rec.freight_terms_code);
      END LOOP;

      IF (NOT bpl_aio.quick_pick(gem_fields.get_prompt('delivery'))) THEN
         RETURN FALSE;
      END IF;

      v_ship_method_code := bpl_aio.get_variable('ship_method_code');
      /* Trip needs to be updated with ship method code */
      IF (v_ship_method_code IS NOT NULL AND txn.ship_method_code IS NULL) THEN
         IF (NOT update_trip_ship_method(usr, txn, v_ship_method_code)) THEN
            RETURN FALSE;
         END IF;
         txn.ship_method_code := v_ship_method_code;
      /* Delivery needs to update ship method code to match trip */
      ELSIF (v_ship_method_code IS NULL AND txn.ship_method_code IS NOT NULL) THEN
         IF (NOT update_del_ship_method(usr, txn, bpl_aio.get_variable('delivery_id'), txn.ship_method_code)) THEN
            RETURN FALSE;
         END IF;
      END IF;

      SELECT COUNT(1)
        INTO v_count
        FROM wsh_delivery_legs
       WHERE delivery_id = txn.delivery_id;

      IF (v_count = 0) THEN
         IF (NOT delivery_to_trip_action(usr, ASSIGN_TO_TRIP, bpl_aio.get_variable('delivery_id'), txn.trip_id, v_del_rec)) THEN
            RETURN FALSE;
         END IF;
      END IF;

      txn.delivery_id                := bpl_aio.get_variable('delivery_id');
      txn.delivery_name              := bpl_aio.get_variable('delivery_name');
      txn.customer_id                := bpl_aio.get_variable('customer_id');
      txn.ship_from_location_id      := bpl_aio.get_variable('ship_from_location_id');
      txn.deliver_to_location_id     := bpl_aio.get_variable('deliver_to_location_id');
      txn.intmed_ship_to_location_id := bpl_aio.get_variable('intmed_ship_to_location_id');
      txn.fob_code                   := bpl_aio.get_variable('fob_code');
      txn.freight_terms_code         := bpl_aio.get_variable('freight_terms_code');

      RETURN TRUE;
   EXCEPTION
      WHEN no_data_found THEN
         bp_apps.error_message(usr, txn, 1168);
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.delivery_validate', SQLERRM);
         bpascui.display_error('GAQSC10 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END delivery_validate;

   /*
   ||****************************************************************************
   || Func: lpn_validate
   || Desc: This function will validate the given lpn.
   ||****************************************************************************
   */
   FUNCTION lpn_validate(usr        IN OUT bp_apps.AppsUsr,
                         txn        IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      CURSOR get_lpns IS
         SELECT wdd.container_name,
                wdd.delivery_detail_id,
                wdd.inventory_item_id,
                wdd.tracking_number,
                msi.concatenated_segments container_type,
                NVL(wdd.customer_id, txn.customer_id) customer_id,
                NVL(wdd.ship_from_location_id, txn.ship_from_location_id) ship_from_location_id,
                NVL(wdd.deliver_to_location_id, txn.deliver_to_location_id) deliver_to_location_id,
                NVL(wdd.intmed_ship_to_location_id, txn.intmed_ship_to_location_id) intmed_ship_to_location_id,
                NVL(wdd.fob_code, txn.fob_code) fob_code,
                NVL(wdd.freight_terms_code, txn.freight_terms_code) freight_terms_code,
                NVL(wdd.ship_method_code, txn.ship_method_code) ship_method_code
           FROM wsh_delivery_details wdd,
                mtl_system_items_b_kfv msi,
                wsh_delivery_assignments wda
          WHERE wdd.organization_id = usr.organization_id
            AND wdd.container_flag = 'Y'
            AND wdd.released_status = 'X'
            AND UPPER(wdd.container_name) LIKE UPPER(txn.input||'%')
            AND msi.organization_id = usr.organization_id
            AND msi.inventory_item_id = wdd.inventory_item_id
            AND msi.container_item_flag = 'Y'
            AND msi.shippable_item_flag = 'Y'
            --AND msi.weight_uom_code IS NOT NULL
            --AND msi.unit_weight IS NOT NULL
            --AND msi.volume_uom_code IS NOT NULL
            --AND msi.unit_volume IS NOT NULL
            --AND msi.maximum_load_weight IS NOT NULL
            --AND msi.internal_volume IS NOT NULL
            AND wda.delivery_detail_id = wdd.delivery_detail_id
            AND wda.parent_delivery_detail_id IS NULL
            AND NVL(wda.delivery_id, NVL(txn.delivery_id, -1)) = NVL(txn.delivery_id, -1)
            AND (txn.customer_id IS NULL OR wdd.customer_id IS NULL OR txn.customer_id = wdd.customer_id)
            AND (txn.ship_from_location_id IS NULL OR wdd.ship_from_location_id IS NULL OR txn.ship_from_location_id = wdd.ship_from_location_id)
            AND (txn.deliver_to_location_id IS NULL OR wdd.deliver_to_location_id IS NULL OR txn.deliver_to_location_id = wdd.deliver_to_location_id)
            AND (txn.intmed_ship_to_location_id IS NULL OR wdd.intmed_ship_to_location_id IS NULL OR txn.intmed_ship_to_location_id = wdd.intmed_ship_to_location_id)
            AND (txn.fob_code IS NULL OR wdd.fob_code IS NULL OR txn.fob_code = wdd.fob_code)
            AND (txn.freight_terms_code IS NULL OR wdd.freight_terms_code IS NULL OR txn.freight_terms_code = wdd.freight_terms_code)
            AND (txn.ship_method_code IS NULL OR wdd.ship_method_code IS NULL OR txn.ship_method_code = wdd.ship_method_code)
            AND NOT EXISTS (SELECT '*'
                              FROM co_inventory_lpns cil
                             WHERE cil.lpn = wdd.container_name)  -- Take out Inventory LPN
         ORDER BY wdd.container_name;

   v_count       NUMBER;
   v_char_input  BOOLEAN;

   BEGIN
      IF (LENGTH(txn.input) > 30) THEN
         bp_apps.error_message(usr, txn, 1163);
         RETURN FALSE;
      END IF;

      IF txn.input <> '0' AND SUBSTR(txn.input,1,1) = '0' THEN
         --if the user entered the lpn as 00123, we need to take it as 123.
         FOR i IN 1..LENGTH(txn.input) LOOP
            IF SUBSTR(txn.input,i,1) <> '0' THEN
               txn.input := SUBSTR(txn.input,i);
               EXIT;
            END IF;
         END LOOP;
      END IF;

      IF (txn.input = 'NEW') THEN
         RETURN TRUE;
      ELSE
         v_char_input := TRUE;
         --if user entered just characters, like 'abc' make it as 'abc0'
         --as Oracle API creates the container as 'abc0'
         FOR i IN 1..LENGTH(txn.input) LOOP
            IF (bpl.is_numeric(SUBSTR(txn.input,i,1))) THEN
               v_char_input := FALSE;
               EXIT;
            END IF;
         END LOOP;

         IF (v_char_input) THEN
             --user entered only characters. So if the input is 'abc' make it
             --as 'abc0'
             txn.input := txn.input || 0;
         END IF;

         BEGIN
            SELECT wdd.container_name,
                   wdd.delivery_detail_id,
                   wdd.inventory_item_id,
                   wdd.tracking_number,
                   msi.concatenated_segments container_type,
                   NVL(wdd.customer_id, txn.customer_id) customer_id,
                   NVL(wdd.ship_from_location_id, txn.ship_from_location_id) ship_from_location_id,
                   NVL(wdd.deliver_to_location_id, txn.deliver_to_location_id) deliver_to_location_id,
                   NVL(wdd.intmed_ship_to_location_id, txn.intmed_ship_to_location_id) intmed_ship_to_location_id,
                   NVL(wdd.fob_code, txn.fob_code) fob_code,
                   NVL(wdd.freight_terms_code, txn.freight_terms_code) freight_terms_code,
                   NVL(wdd.ship_method_code, txn.ship_method_code) ship_method_code
              INTO txn.container_num,
                   txn.container_id,
                   txn.container_item_id,
                   txn.tracking_num,
                   txn.container_name,
                   txn.customer_id,
                   txn.ship_from_location_id,
                   txn.deliver_to_location_id,
                   txn.intmed_ship_to_location_id,
                   txn.fob_code,
                   txn.freight_terms_code,
                   txn.ship_method_code
              FROM wsh_delivery_details wdd,
                   mtl_system_items_b_kfv msi,
                   wsh_delivery_assignments wda
             WHERE wdd.organization_id = usr.organization_id
               AND wdd.container_flag = 'Y'
               AND wdd.released_status = 'X'
               AND wdd.container_name = txn.input
               AND msi.organization_id = usr.organization_id
               AND msi.inventory_item_id = wdd.inventory_item_id
               AND msi.container_item_flag = 'Y'
               AND msi.shippable_item_flag = 'Y'
               --AND msi.weight_uom_code IS NOT NULL
               --AND msi.unit_weight IS NOT NULL
               --AND msi.volume_uom_code IS NOT NULL
               --AND msi.unit_volume IS NOT NULL
               --AND msi.maximum_load_weight IS NOT NULL
               --AND msi.internal_volume IS NOT NULL
               AND wda.delivery_detail_id = wdd.delivery_detail_id
               AND wda.parent_delivery_detail_id IS NULL
               AND NVL(wda.delivery_id, txn.delivery_id) = txn.delivery_id
               AND (txn.customer_id IS NULL OR wdd.customer_id IS NULL OR txn.customer_id = wdd.customer_id)
               AND (txn.ship_from_location_id IS NULL OR wdd.ship_from_location_id IS NULL OR txn.ship_from_location_id = wdd.ship_from_location_id)
               AND (txn.deliver_to_location_id IS NULL OR wdd.deliver_to_location_id IS NULL OR txn.deliver_to_location_id = wdd.deliver_to_location_id)
               AND (txn.intmed_ship_to_location_id IS NULL OR wdd.intmed_ship_to_location_id IS NULL OR txn.intmed_ship_to_location_id = wdd.intmed_ship_to_location_id)
               AND (txn.fob_code IS NULL OR wdd.fob_code IS NULL OR txn.fob_code = wdd.fob_code)
               AND (txn.freight_terms_code IS NULL OR wdd.freight_terms_code IS NULL OR txn.freight_terms_code = wdd.freight_terms_code)
               AND (txn.ship_method_code IS NULL OR wdd.ship_method_code IS NULL OR txn.ship_method_code = wdd.ship_method_code)
               AND NOT EXISTS (SELECT '*'
                                 FROM co_inventory_lpns cil
                                WHERE cil.lpn = wdd.container_name);  -- Take out Inventory LPN

            RETURN TRUE;
         EXCEPTION
            WHEN no_data_found THEN
               NULL;
         END;
      --END IF;

      bpl_aio.start_table;
      FOR lpn_rec IN get_lpns LOOP
         IF (NOT bpl_aio.table_row(lpn_rec.container_name, lpn_rec.container_type)) THEN
            EXIT;
         END IF;

         bpl_aio.put_variable('container_num', lpn_rec.container_name);
         bpl_aio.put_variable('container_id', lpn_rec.delivery_detail_id);
         bpl_aio.put_variable('container_item_id', lpn_rec.inventory_item_id);
         bpl_aio.put_variable('tracking_number', lpn_rec.tracking_number);
         bpl_aio.put_variable('container_name', lpn_rec.container_type);
         bpl_aio.put_variable('ship_method_code', lpn_rec.ship_method_code);
         bpl_aio.put_variable('customer_id', lpn_rec.customer_id);
         bpl_aio.put_variable('ship_from_location_id', lpn_rec.ship_from_location_id);
         bpl_aio.put_variable('deliver_to_location_id', lpn_rec.deliver_to_location_id);
         bpl_aio.put_variable('intmed_ship_to_location_id', lpn_rec.intmed_ship_to_location_id);
         bpl_aio.put_variable('fob_code', lpn_rec.fob_code);
         bpl_aio.put_variable('freight_terms_code', lpn_rec.freight_terms_code);
      END LOOP;

      IF (NOT bpl_aio.quick_pick(bpl_aio.table_header(gem_fields.get_prompt('lpn'), gem_fields.get_prompt('container_type')))) THEN
         RETURN FALSE;
      END IF;

      txn.container_num              := bpl_aio.get_variable('container_num');
      txn.container_id               := bpl_aio.get_variable('container_id');
      txn.container_item_id          := bpl_aio.get_variable('container_item_id');
      txn.tracking_num               := bpl_aio.get_variable('tracking_number');
      txn.container_name             := bpl_aio.get_variable('container_name');
      txn.ship_method_code           := bpl_aio.get_variable('ship_method_code');
      txn.customer_id                := bpl_aio.get_variable('customer_id');
      txn.ship_from_location_id      := bpl_aio.get_variable('ship_from_location_id');
      txn.deliver_to_location_id     := bpl_aio.get_variable('deliver_to_location_id');
      txn.intmed_ship_to_location_id := bpl_aio.get_variable('intmed_ship_to_location_id');
      txn.fob_code                   := bpl_aio.get_variable('fob_code');
      txn.freight_terms_code         := bpl_aio.get_variable('freight_terms_code');

      RETURN TRUE;
   END IF;

   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN no_data_found THEN
         --user entered LPN
         SELECT COUNT(*)
           INTO v_count
           FROM wsh_delivery_details
          WHERE container_name = txn.input
            AND container_flag = 'Y';
         IF (v_count = 0) THEN
            txn.container_num := txn.input;
            co_debug.debug('shipcore','new lpn');
            RETURN TRUE;
         ELSE
            bp_apps.error_message(usr, txn, 1209);
            RETURN FALSE;
         END IF;

      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.lpn_validate', SQLERRM);
         bpascui.display_error('GAQSC15 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END lpn_validate;

   /*
   ||****************************************************************************
   || Func: create_trip_if_can
   || Desc: This function will check if delivery has been created.  If it hasn't
   ||       it checks if
   ||****************************************************************************
   */
   FUNCTION create_trip_if_can(usr          IN OUT bp_apps.AppsUsr,
                               txn          IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      v_api_version      CONSTANT NUMBER         := 1.0;
      v_init_msg_list             VARCHAR2(1)    := FND_API.G_True;
      v_commit                    VARCHAR2(1)    := FND_API.G_False;
      v_validation_level          NUMBER         := FND_API.G_Valid_Level_Full;
      v_return_status             VARCHAR2(1);
      v_msg_count                 NUMBER;
      v_msg_data                  VARCHAR2(3000);
      v_delivery_rec_type         WSH_DELIVERIES_PUB.Delivery_Pub_Rec_Type;
      v_del_rec                   update_delivery_rec;
   BEGIN
      /* Don't do anything if delivery exists, or if we don't have enough information to create one */
      IF (txn.delivery_id IS NOT NULL OR txn.deliver_to_location_id IS NULL OR txn.ship_from_location_id IS NULL) THEN
         RETURN TRUE;
      END IF;

      co_debug.debug('gem_auto_quick_ship_core.create_trip_if_can', 'Creating delivery '||txn.delivery_name, co_debug.SEVERITY_MESSAGE);
      v_delivery_rec_type.NAME                         := txn.delivery_name;
      v_delivery_rec_type.ORGANIZATION_ID              := usr.organization_id;
      v_delivery_rec_type.CUSTOMER_ID                  := txn.customer_id;
      v_delivery_rec_type.INITIAL_PICKUP_LOCATION_ID   := txn.ship_from_location_id;
      v_delivery_rec_type.ULTIMATE_DROPOFF_LOCATION_ID := txn.deliver_to_location_id;
      v_delivery_rec_type.INTMED_SHIP_TO_LOCATION_ID   := txn.intmed_ship_to_location_id;
      v_delivery_rec_type.FOB_CODE                     := txn.fob_code;
      v_delivery_rec_type.FREIGHT_TERMS_CODE           := txn.freight_terms_code;
      v_delivery_rec_type.SHIP_METHOD_CODE             := txn.ship_method_code;
      WSH_DELIVERIES_PUB.Create_Update_Delivery(v_api_version,
                                                v_init_msg_list,
                                                v_return_status,
                                                v_msg_count,
                                                v_msg_data,
                                                'CREATE',
                                                v_delivery_rec_type,
                                                txn.delivery_name,
                                                txn.delivery_id,
                                                txn.delivery_name);
      IF (NOT bpa_request.post_api(usr,
                                   'WSH_DELIVERIES_PUB.Create_Update_Delivery',
                                   v_return_status,
                                   v_msg_count,
                                   'Create Del Error')) THEN
         RETURN(FALSE);
      END IF;

      co_debug.debug('gem_auto_quick_ship_core.create_trip_if_can', 'Created delivery '||txn.delivery_id, co_debug.SEVERITY_MESSAGE);
      IF (NOT delivery_to_trip_action(usr, ASSIGN_TO_TRIP, txn.delivery_id, txn.trip_id, v_del_rec)) THEN
         RETURN FALSE;
      END IF;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.create_trip_if_can', SQLERRM);
         bpascui.display_error('GAQSC16 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END create_trip_if_can;

   /*
   ||****************************************************************************
   || Func: update_shipping_attributes
   || Desc: This function will update public attributes on all delivery details
   ||       specified in table.
   ||****************************************************************************
   */
   FUNCTION update_shipping_attributes(usr                IN OUT bp_apps.AppsUsr,
                                       vp_changed_table   IN     WSH_DELIVERY_DETAILS_PUB.ChangedAttributeTabType)
      RETURN BOOLEAN
   IS
      l_api_version              CONSTANT NUMBER      := 1.0;
      l_init_msg_list                     VARCHAR2(1) := FND_API.G_TRUE;
      l_commit                            VARCHAR2(1) := FND_API.G_FALSE;
      l_validation_level                  NUMBER      := FND_API.G_VALID_LEVEL_FULL;
      l_msg_count                         NUMBER  := 0;
      l_msg_data                          VARCHAR2(3000) := NULL;
      l_return_status                     VARCHAR2(1) := NULL;
      l_source_code                       VARCHAR2(20) := 'WSH';
   BEGIN
      wsh_delivery_details_pub.Update_Shipping_Attributes (
            p_api_version_number       => l_api_version
            , p_init_msg_list          => l_init_msg_list
            , p_commit                 => l_commit
            , x_return_status          => l_return_status
            , x_msg_count              => l_msg_count
            , x_msg_data               => l_msg_data
            , p_changed_attributes     => vp_changed_table
            , p_source_code            => l_source_code
            , p_container_flag         => 'Y'  -- added in 11.5.8 to update container-specific
                                               -- attributes such as subinv, rev, lot, serial, etc...
      );
      co_debug.debug(usr, 'gem_auto_quick_ship_core.update_shipping_attributes', 'upd attr return stat, msg cnt '|| l_return_status ||' '||l_msg_count ) ;
      IF (NOT bpa_request.post_api(usr,
                                   'wsh_delivery_details_pub.Update_Shipping_Attributes',
                                   l_return_status,
                                   l_msg_count,
                                   'Update Attr Error')) THEN
         RETURN(FALSE);
      END IF;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.update_shipping_attributes', SQLERRM);
         bpascui.display_error('GAQSC17 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END update_shipping_attributes;

   /*
   ||****************************************************************************
   || Func: update_delivery_group
   || Desc: This function will update all attributes on the delivery.
   ||****************************************************************************
   */
   FUNCTION update_delivery_group(usr        IN OUT bp_apps.AppsUsr,
                                  txn        IN     bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      CURSOR get_lpns IS
         SELECT wda.delivery_detail_id
           FROM wsh_delivery_assignments wda
          WHERE wda.delivery_id = txn.delivery_id;

      l_api_return_status           VARCHAR2(1);
      l_msg_count                   NUMBER;
      l_msg_data                    VARCHAR2(2000);
      v_new_del_rec                 WSH_DELIVERIES_PUB.delivery_pub_rec_type;
      v_delivery_id                 NUMBER;
      v_delivery_name               VARCHAR2(30);
      v_changed_table               WSH_DELIVERY_DETAILS_PUB.ChangedAttributeTabType;
      v_idx                         NUMBER;
      v_del_rec                     update_delivery_rec;
   BEGIN
      IF (NOT update_trip_ship_method(usr, txn, txn.ship_method_code)) THEN
         RETURN FALSE;
      END IF;

      /* only do the following if the delivery exists */
      IF (txn.delivery_id IS NOT NULL) THEN
         /* Now update delivery specific attributes */
         IF (NOT delivery_to_trip_action(usr, UNASSIGN_FROM_TRIP, txn.delivery_id, txn.trip_id, v_del_rec)) THEN
            RETURN FALSE;
         END IF;

         co_debug.debug('gem_auto_quick_ship_core.update_del_ship_method', 'Updating delivery '||txn.delivery_name||' with group attributes ', co_debug.SEVERITY_MESSAGE);
         v_new_del_rec.delivery_id                  := txn.delivery_id;
         v_new_del_rec.customer_id                  := txn.customer_id;
         v_new_del_rec.initial_pickup_location_id   := txn.ship_from_location_id;
         v_new_del_rec.ultimate_dropoff_location_id := txn.deliver_to_location_id;
         v_new_del_rec.intmed_ship_to_location_id   := txn.intmed_ship_to_location_id;
         v_new_del_rec.fob_code                     := txn.fob_code;
         v_new_del_rec.freight_terms_code           := txn.freight_terms_code;
         WSH_DELIVERIES_PUB.create_update_delivery
         (
            p_api_version_number    =>  1.0,
            p_init_msg_list         =>  FND_API.G_TRUE,
            x_return_status         =>  l_api_return_status,
            x_msg_count             =>  l_msg_count,
            x_msg_data              =>  l_msg_data,
            p_action_code           =>  'UPDATE',
            p_delivery_info         =>  v_new_del_rec,
            p_delivery_name         =>  NULL,
            x_delivery_id           =>  v_delivery_id,
            x_name                  =>  v_delivery_name
         );
         IF (NOT bpa_request.post_api(usr,
                                      'WSH_DELIVERIES_PUB.create_update_delivery',
                                      l_api_return_status,
                                      l_msg_count,
                                      'Update Delivery Error')) THEN
            RETURN(FALSE);
         END IF;

         v_idx := 0;
         FOR lpn_rec IN get_lpns LOOP
            v_idx := v_idx + 1;
            v_changed_table(v_idx).delivery_detail_id    := lpn_rec.delivery_detail_id;
            v_changed_table(v_idx).intmed_ship_to_org_id := txn.intmed_ship_to_location_id;
            v_changed_table(v_idx).fob_code              := txn.fob_code;
            v_changed_table(v_idx).freight_terms_code    := txn.freight_terms_code;
            v_changed_table(v_idx).shipping_method_code  := txn.ship_method_code;
         END LOOP;
         IF (v_idx > 0) THEN
            IF (NOT gem_auto_pack_lpn_core.assign_group_attributes(usr, v_changed_table)) THEN
               RETURN FALSE;
            END IF;
         END IF;

         IF (NOT delivery_to_trip_action(usr, ASSIGN_TO_TRIP, txn.delivery_id, txn.trip_id, v_del_rec)) THEN
            RETURN FALSE;
         END IF;

         RETURN TRUE;
      END IF;

      RETURN TRUE;

   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.update_delivery_group', SQLERRM);
         bpascui.display_error('GAQSC18 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END update_delivery_group;

   /*
   ||****************************************************************************
   || Func: is_assigned_to_del
   || Desc: this function will return true if the lpn is already assigned to
   ||       to the delivery.
   ||****************************************************************************
   */
   FUNCTION is_assigned_to_del(usr          IN OUT bp_apps.AppsUsr,
                               txn          IN     bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      v_delivery_id        NUMBER;
   BEGIN
      SELECT wda.delivery_id
        INTO v_delivery_id
        FROM wsh_delivery_assignments wda
       WHERE wda.delivery_detail_id = txn.container_id;

      RETURN (v_delivery_id IS NOT NULL);
   END is_assigned_to_del;

   /*
   ||****************************************************************************
   || Proc; get_all_details
   || Desc: This procedure gets all details assigned to the root details.
   ||****************************************************************************
   */
   PROCEDURE get_all_details(usr          IN OUT bp_apps.AppsUsr,
                             vp_detail_id IN     NUMBER,
                             vp_table     IN OUT WSH_DELIVERY_DETAILS_PUB.ChangedAttributeTabType)
   IS
      CURSOR get_details IS
         SELECT wdd.container_flag,
                wdd.delivery_detail_id
           FROM wsh_delivery_details wdd,
                wsh_delivery_assignments wda
          WHERE wda.parent_delivery_detail_id = vp_detail_id
            AND wdd.delivery_detail_id = wda.delivery_detail_id;
   BEGIN
      FOR detail_rec IN get_details LOOP
         vp_table(vp_table.COUNT + 1).delivery_detail_id := detail_rec.delivery_detail_id;
         IF (detail_rec.container_flag = 'Y') THEN
            get_all_details(usr, detail_rec.delivery_detail_id, vp_table);
         END IF;
      END LOOP;
   END get_all_details;

   /*
   ||****************************************************************************
   || Func: assign_lpn_to_trip
   || Desc: This function will update the lpn shipping attributes and assign it
   ||       to the trip.
   ||****************************************************************************
   */
   FUNCTION assign_lpn_to_delivery(usr        IN OUT bp_apps.AppsUsr,
                               txn        IN     bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS

      v_changed_table               WSH_DELIVERY_DETAILS_PUB.ChangedAttributeTabType;

      v_api_version      CONSTANT NUMBER         := 1.0;
      v_init_msg_list             VARCHAR2(1)    := FND_API.G_True;
      v_commit                    VARCHAR2(1)    := FND_API.G_False;
      v_validation_level          NUMBER         := FND_API.G_Valid_Level_Full;
      v_return_status             VARCHAR2(1);
      v_msg_count                 NUMBER;
      v_msg_data                  VARCHAR2(3000);
      v_detail_table_type         WSH_UTIL_CORE.ID_Tab_Type;
      v_container_name            VARCHAR2(30);
      v_cont_instance_id          NUMBER;
      v_container_flag            VARCHAR2(10);
      v_delivery_flag             VARCHAR2(10);
      v_delivery_id               NUMBER;
      v_delivery_name             VARCHAR2(30);
      v_action_code               VARCHAR2(30);

      v_debug_customer_id         NUMBER;
      v_debug_fm_loc_id           NUMBER;
      v_debug_to_loc_id           NUMBER;
      v_debug_in_loc_id           NUMBER;
      v_debug_fob_code            wsh_delivery_details.fob_code%TYPE;
      v_debug_freight_terms_code  wsh_delivery_details.freight_terms_code%TYPE;
      v_debug_ship_method_code    wsh_delivery_details.ship_method_code%TYPE;
   BEGIN

      /* only do the following if the delivery exists */
      IF (txn.delivery_id IS NOT NULL) THEN
         /* First update all the details attached to container, and container to new shipping attriubtes */
         v_changed_table(1).delivery_detail_id := txn.container_id;
         get_all_details(usr, txn.container_id, v_changed_table);
         FOR v_idx IN 1..v_changed_table.COUNT LOOP
            v_changed_table(v_idx).intmed_ship_to_org_id := txn.intmed_ship_to_location_id;
            v_changed_table(v_idx).fob_code              := txn.fob_code;
            v_changed_table(v_idx).freight_terms_code    := txn.freight_terms_code;
            v_changed_table(v_idx).shipping_method_code  := txn.ship_method_code;
         END LOOP;

         IF (NOT gem_auto_pack_lpn_core.assign_group_attributes(usr, v_changed_table, txn.customer_id, txn.ship_from_location_id, txn.deliver_to_location_id)) THEN
            RETURN FALSE;
         END IF;

         SELECT wnd.ship_method_code,
                wnd.customer_id,
                wnd.initial_pickup_location_id ship_from_location_id,
                wnd.ultimate_dropoff_location_id deliver_to_location_id,
                wnd.intmed_ship_to_location_id,
                wnd.fob_code,
                wnd.freight_terms_code
           INTO v_debug_ship_method_code,
                v_debug_customer_id,
                v_debug_fm_loc_id,
                v_debug_to_loc_id,
                v_debug_in_loc_id,
                v_debug_fob_code,
                v_debug_freight_terms_code
           FROM wsh_new_deliveries wnd
          WHERE wnd.delivery_id = txn.delivery_id;
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'del customer_id = '||v_debug_customer_id, co_debug.SEVERITY_MESSAGE);
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'del from_loc_id = '||v_debug_fm_loc_id, co_debug.SEVERITY_MESSAGE);
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'del to   loc id = '||v_debug_to_loc_id, co_debug.SEVERITY_MESSAGE);
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'del intm loc id = '||v_debug_in_loc_id, co_debug.SEVERITY_MESSAGE);
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'del ship_method_code = '||v_debug_ship_method_code, co_debug.SEVERITY_MESSAGE);
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'del fob_code = '||v_debug_fob_code, co_debug.SEVERITY_MESSAGE);
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'del freigth_terms_code = '||v_debug_freight_terms_code, co_debug.SEVERITY_MESSAGE);

         SELECT wdd.customer_id,
                wdd.ship_from_location_id,
                wdd.deliver_to_location_id,
                wdd.intmed_ship_to_location_id,
                wdd.fob_code,
                wdd.freight_terms_code,
                wdd.ship_method_code
           INTO v_debug_customer_id,
                v_debug_fm_loc_id,
                v_debug_to_loc_id,
                v_debug_in_loc_id,
                v_debug_fob_code,
                v_debug_freight_terms_code,
                v_debug_ship_method_code
           FROM wsh_delivery_details wdd
          WHERE wdd.delivery_detail_id = txn.container_id;
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'lpn customer_id = '||v_debug_customer_id, co_debug.SEVERITY_MESSAGE);
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'lpn from_loc_id = '||v_debug_fm_loc_id, co_debug.SEVERITY_MESSAGE);
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'lpn to   loc id = '||v_debug_to_loc_id, co_debug.SEVERITY_MESSAGE);
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'lpn intm loc id = '||v_debug_in_loc_id, co_debug.SEVERITY_MESSAGE);
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'lpn ship_method_code = '||v_debug_ship_method_code, co_debug.SEVERITY_MESSAGE);
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'lpn fob_code = '||v_debug_fob_code, co_debug.SEVERITY_MESSAGE);
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'lpn freigth_terms_code = '||v_debug_freight_terms_code, co_debug.SEVERITY_MESSAGE);

         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_trip', 'Assigning '||txn.container_num||' to '||txn.delivery_name, co_debug.SEVERITY_MESSAGE);
         v_container_name    := NULL;
         v_cont_instance_id  := NULL;
         v_container_flag    := 'N';
         v_delivery_flag     := 'Y';
         v_delivery_name     := txn.delivery_name;
         v_delivery_id       := txn.delivery_id;
         v_action_code       := 'ASSIGN';
         v_detail_table_type(1) := txn.container_id;

         WSH_CONTAINER_PUB.Container_Actions (v_api_version,
                                              v_init_msg_list,
                                              v_commit,
                                              v_validation_level,
                                              v_return_status,
                                              v_msg_count,
                                              v_msg_data,
                                              v_detail_table_type,
                                              v_container_name,
                                              v_cont_instance_id,
                                              v_container_flag,
                                              v_delivery_flag,
                                              v_delivery_id,
                                              v_delivery_name,
                                              v_action_code);

         IF (v_return_status != FND_API.G_RET_STS_SUCCESS) THEN
            co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', 'ERROR: '||fnd_msg_pub.get(1, NULL));
            bpascui.display_error('Assing LPN API IO Error', fnd_msg_pub.get(1, NULL), usr.error_wait);
            RETURN FALSE;
         END IF;

         /* Update the number_of_lpn field of the delivery */
         IF (NOT update_number_of_lpn(usr, txn, txn.delivery_id)) THEN
            RETURN FALSE;
         END IF;
      END IF;

      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.assign_lpn_to_delivery', SQLERRM);
         bpascui.display_error('GAQSC19 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END assign_lpn_to_delivery;

   /*
   ||****************************************************************************
   || Func: container_type_validate
   || Desc: This function will validate the container type by wrapping the
   ||       validating from gem_auto_pack_lpn_core.
   ||****************************************************************************
   */
   FUNCTION container_type_validate(usr      IN OUT bp_apps.AppsUsr,
                                    txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      pack_txn.input := txn.input;
      IF (NOT gem_auto_pack_lpn_core.container_type_validate(usr, pack_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.container_item_id := pack_txn.container_item_id;
      txn.container_name := pack_txn.container_type;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.container_type_validate', SQLERRM);
         bpascui.display_error('GAQSC20 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END container_type_validate;

   /*
   ||****************************************************************************
   || Func: create_container
   || Desc: This function is a wrapper for
   ||       gem_auto_pack_lpn_core.get_new_container.
   ||****************************************************************************
   */
   FUNCTION create_container(usr      IN OUT bp_apps.AppsUsr,
                             txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      pack_txn.lpn := txn.container_num;
      pack_txn.container_item_id := txn.container_item_id;
      IF (NOT gem_auto_pack_lpn_core.get_new_container(usr, pack_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.container_id := pack_txn.container_id;
      txn.container_num := pack_txn.lpn;

      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.create_container', SQLERRM);
         bpascui.display_error('GAQSC21 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END create_container;

   /*
   ||****************************************************************************
   || Func: update_delivery_group_so
   || Desc: This function will take the delivery group attributes from the
   ||       order/header and populate them into txn record.
   ||****************************************************************************
   */
   FUNCTION update_delivery_group_so(usr        IN OUT bp_apps.AppsUsr,
                                     txn        IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
   BEGIN
      IF (gem_auto_quick_ship.lpn_method = gem_auto_quick_ship.SALES_ORDER) THEN
         BEGIN
            SELECT NVL(wdd.customer_id, txn.customer_id),
                   NVL(wdd.ship_from_location_id, txn.ship_from_location_id),
                   NVL(wdd.deliver_to_location_id, txn.deliver_to_location_id),
                   NVL(wdd.intmed_ship_to_location_id, txn.intmed_ship_to_location_id),
                   NVL(wdd.fob_code, txn.fob_code),
                   NVL(wdd.ship_method_code, txn.ship_method_code),
                   NVL(wdd.freight_terms_code, txn.freight_terms_code)
              INTO txn.customer_id,
                   txn.ship_from_location_id,
                   txn.deliver_to_location_id,
                   txn.intmed_ship_to_location_id,
                   txn.fob_code,
                   txn.ship_method_code,
                   txn.freight_terms_code
              FROM wsh_delivery_details wdd,
                   wsh_delivery_assignments wda
             WHERE wdd.source_header_id = txn.header_id
               AND wdd.source_line_id = txn.line_id
               AND wdd.released_status IN ('R', 'B', 'S')
               AND wdd.organization_id = usr.organization_id
               AND (NVL(wdd.requested_quantity, 0) -
                   NVL(wdd.shipped_quantity, 0)) > 0
               AND (txn.customer_id IS NULL OR wdd.customer_id IS NULL OR txn.customer_id = wdd.customer_id)
               AND (txn.ship_from_location_id IS NULL OR wdd.ship_from_location_id IS NULL OR txn.ship_from_location_id = wdd.ship_from_location_id)
               AND (txn.deliver_to_location_id IS NULL OR wdd.deliver_to_location_id IS NULL OR txn.deliver_to_location_id = wdd.deliver_to_location_id)
               AND (txn.intmed_ship_to_location_id IS NULL OR wdd.intmed_ship_to_location_id IS NULL OR txn.intmed_ship_to_location_id = wdd.intmed_ship_to_location_id)
               AND (txn.fob_code IS NULL OR wdd.fob_code IS NULL OR txn.fob_code = wdd.fob_code)
               AND (txn.freight_terms_code IS NULL OR wdd.freight_terms_code IS NULL OR txn.freight_terms_code = wdd.freight_terms_code)
               AND (txn.ship_method_code IS NULL OR wdd.ship_method_code IS NULL OR txn.ship_method_code = wdd.ship_method_code)
               AND wda.delivery_detail_id = wdd.delivery_detail_id
               AND wda.parent_delivery_detail_id IS NULL
               AND wda.delivery_id IS NULL
               AND NOT EXISTS (
                   SELECT 1
                     FROM mtl_material_transactions_temp mmtt
                    WHERE mmtt.transaction_header_id = wdd.attribute10)
               AND ROWNUM = 1;
               RETURN TRUE;
         EXCEPTION
            WHEN no_data_found THEN
               /* Specific search failed, trying more general search */
               SELECT NVL(wdd.customer_id, txn.customer_id),
                      NVL(wdd.ship_from_location_id, txn.ship_from_location_id),
                      NVL(wdd.deliver_to_location_id, txn.deliver_to_location_id),
                      NVL(wdd.intmed_ship_to_location_id, txn.intmed_ship_to_location_id)
                 INTO txn.customer_id,
                      txn.ship_from_location_id,
                      txn.deliver_to_location_id,
                      txn.intmed_ship_to_location_id
                 FROM wsh_delivery_details wdd
                WHERE wdd.source_header_id = txn.header_id
                  AND wdd.source_line_id = txn.line_id
                  AND wdd.organization_id = usr.organization_id
                  AND (txn.customer_id IS NULL OR wdd.customer_id IS NULL OR txn.customer_id = wdd.customer_id)
                  AND (txn.ship_from_location_id IS NULL OR wdd.ship_from_location_id IS NULL OR txn.ship_from_location_id = wdd.ship_from_location_id)
                  AND (txn.deliver_to_location_id IS NULL OR wdd.deliver_to_location_id IS NULL OR txn.deliver_to_location_id = wdd.deliver_to_location_id)
                  AND (txn.intmed_ship_to_location_id IS NULL OR wdd.intmed_ship_to_location_id IS NULL OR txn.intmed_ship_to_location_id = wdd.intmed_ship_to_location_id)
                  AND ROWNUM = 1;
               RETURN TRUE;
         END;
      ELSE
         SELECT NVL(wdd.customer_id, txn.customer_id),
                NVL(wdd.ship_from_location_id, txn.ship_from_location_id),
                NVL(wdd.deliver_to_location_id, txn.deliver_to_location_id),
                NVL(wdd.intmed_ship_to_location_id, txn.intmed_ship_to_location_id),
                NVL(wdd.fob_code, txn.fob_code),
                NVL(wdd.ship_method_code, txn.ship_method_code),
                NVL(wdd.freight_terms_code, txn.freight_terms_code)
           INTO txn.customer_id,
                txn.ship_from_location_id,
                txn.deliver_to_location_id,
                txn.intmed_ship_to_location_id,
                txn.fob_code,
                txn.ship_method_code,
                txn.freight_terms_code
           FROM wsh_delivery_details wdd
          WHERE wdd.delivery_detail_id = txn.delivery_detail_id;
       END IF;

       RETURN TRUE;
    EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.update_delivery_group_so', SQLERRM);
         bpascui.display_error('GAQSC23 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END update_delivery_group_so;


   /*
   ||****************************************************************************
   || Proc: copy_txn_to_pack
   || Desc: This procedure will take relevant info from pack lpn record to
   ||       txn record.  It allows to call gem_auto_pack_lpn_core functions and
   ||       procedures.
   ||****************************************************************************
   */
   PROCEDURE copy_txn_to_pack(txn      IN     bp_apps.AppsTxn,
                              pack_txn    OUT gem_auto_pack_lpn_core.pack_txn_type)
   IS
   BEGIN
      /* Setup globals */
      IF ( gem_auto_quick_ship.lpn_method = gem_auto_quick_ship.SALES_ORDER) THEN
         gem_auto_pack_lpn.lpn_method := gem_auto_pack_lpn.SALES_ORDER;
      ELSE
         gem_auto_pack_lpn.lpn_method := gem_auto_pack_lpn.DELIVERY_DETAIL;
      END IF;
      gem_auto_pack_lpn.trans_type           := gem_auto_pack_lpn.PACK_LPN_TYPE;
      gem_auto_pack_lpn.vg_is_reservable     := TRUE;
      gem_auto_pack_lpn.vg_stage_at_pack     := TRUE;
      gem_auto_pack_lpn.vg_allow_overpicking := gem_auto_quick_ship.vg_allow_overpicking;
      gem_auto_pack_lpn.vg_lot_based_pack    := gem_auto_quick_ship.vg_lot_based_pack;

      /* Txn specific columns */
      pack_txn.input                         := txn.input;
      pack_txn.customer_id                   := txn.customer_id;
      pack_txn.ship_from_location_id         := txn.ship_from_location_id;
      pack_txn.deliver_to_location_id        := txn.deliver_to_location_id;
      pack_txn.intmed_ship_to_location_id    := txn.intmed_ship_to_location_id;
      pack_txn.ship_method_code              := txn.ship_method_code;
      pack_txn.fob_code                      := txn.fob_code;
      pack_txn.freight_terms_code            := txn.freight_terms_code;
      pack_txn.header_id                     := txn.header_id;
      pack_txn.line_id                       := txn.line_id;
      pack_txn.delivery_detail_id            := txn.delivery_detail_id;
      pack_txn.is_ato_config_item            := txn.is_ato_config_item;
      pack_txn.ato_subinventory              := txn.ato_subinventory;
      pack_txn.ato_locator_id                := txn.ato_locator_id;
      pack_txn.ato_revision                  := txn.ato_revision;
      pack_txn.ato_lot_number                := txn.ato_lot_number;
      pack_txn.ato_avail_qty                 := txn.ato_avail_qty;
      pack_txn.is_loc_control                := txn.sub_loc_cc;
      pack_txn.is_item_loc_control           := txn.loc_cc;
      pack_txn.is_org_loc_control            := txn.org_loc_cc;
      pack_txn.transfer_subinventory         := txn.transfer_subinventory;
      pack_txn.transfer_to_location          := txn.transfer_locator;
      pack_txn.is_rev_control                := txn.rev_cc;
      pack_txn.is_lot_control                := txn.lot_cc;
      pack_txn.serial_control_code           := txn.serial_cc;
      pack_txn.revision                      := txn.item_revision;
      pack_txn.lot_number                    := txn.lot_number;
      pack_txn.subinventory                  := txn.subinventory_code;
      pack_txn.locator                       := txn.loc;
      pack_txn.locator_id                    := txn.locator_id;
      pack_txn.requested_quantity            := txn.quantity;
      pack_txn.transaction_quantity          := txn.transaction_quantity;
      pack_txn.transaction_uom               := txn.transaction_uom;
      pack_txn.subinv_avail_qty              := txn.available_quantity;
      pack_txn.is_reservable                 := TRUE;
      pack_txn.project_id                    := txn.project_id;
      pack_txn.task_id                       := txn.task_id;
      pack_txn.inventory_item_id             := txn.inventory_item_id;
      pack_txn.transaction_header_id         := txn.so_header_id;
      pack_txn.acct_period_id                := txn.acct_period_id;
      pack_txn.order_type                    := txn.order_type;
      pack_txn.serials_processed             := txn.serials_processed;
      pack_txn.reservable_type               := 1;  -- reservable item

   END copy_txn_to_pack;

   /*
   ||****************************************************************************
   || Func: order_number_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_pack_lpn_core.order_number_validate
   ||****************************************************************************
   */
   FUNCTION order_number_validate(usr      IN OUT bp_apps.AppsUsr,
                                  txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);
      pack_txn.delivery_id := txn.delivery_id;
      pack_txn.delivery := txn.delivery_name;

      IF (NOT gem_auto_pack_lpn_core.order_number_validate(usr, pack_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.order_number                       := pack_txn.order_number;
      txn.header_id                          := pack_txn.header_id;
      txn.order_type                         := pack_txn.order_type;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.order_number_validate', SQLERRM);
         bpascui.display_error('GAQSC25 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END order_number_validate;

   /*
   ||****************************************************************************
   || Func: order_line_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_pack_lpn_core.order_line_validate
   ||****************************************************************************
   */
   FUNCTION order_line_validate(usr          IN OUT bp_apps.AppsUsr,
                                txn          IN OUT bp_apps.AppsTxn,
                                vp_auto_fill IN     VARCHAR2 DEFAULT NULL)
      RETURN BOOLEAN
   IS
      pack_txn    gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);
      pack_txn.delivery_id := txn.delivery_id;
      pack_txn.delivery := txn.delivery_name;

      IF (NOT gem_auto_pack_lpn_core.order_line_validate(usr, pack_txn, vp_auto_fill)) THEN
         RETURN FALSE;
      END IF;

      txn.order_line                         := pack_txn.order_line;
      txn.line_id                            := pack_txn.line_id;
      txn.inventory_item_id                  := pack_txn.inventory_item_id;
      txn.item_name                          := pack_txn.item_name;
      txn.transaction_uom                    := pack_txn.transaction_uom;
      txn.rev_cc                             := pack_txn.is_rev_control;
      txn.serial_cc                          := pack_txn.serial_control_code;
      txn.lot_cc                             := pack_txn.is_lot_control;
      txn.loc_cc                             := pack_txn.is_item_loc_control;
      txn.is_ato_config_item                 := pack_txn.is_ato_config_item;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.order_line_validate', SQLERRM);
         bpascui.display_error('GAQSC26 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END order_line_validate;

   /*
   ||****************************************************************************
   || Func: delivery_detail_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_pack_lpn_core.delivery_detail_validate
   ||****************************************************************************
   */
   FUNCTION delivery_detail_validate(usr      IN OUT bp_apps.AppsUsr,
                                     txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      pack_txn          gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);
      pack_txn.delivery_id := txn.delivery_id;
      pack_txn.delivery := txn.delivery_name;

      IF (NOT gem_auto_pack_lpn_core.delivery_detail_validate(usr, pack_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.delivery_detail_id                 := pack_txn.delivery_detail_id;
      txn.header_id                          := pack_txn.header_id;
      txn.line_id                            := pack_txn.line_id;
      txn.transaction_uom                    := pack_txn.transaction_uom;
      txn.inventory_item_id                  := pack_txn.inventory_item_id;
      txn.item_name                          := pack_txn.item_name;
      txn.rev_cc                             := pack_txn.is_rev_control;
      txn.serial_cc                          := pack_txn.serial_control_code;
      txn.lot_cc                             := pack_txn.is_lot_control;
      txn.loc_cc                             := pack_txn.is_item_loc_control;
      txn.is_ato_config_item                 := pack_txn.is_ato_config_item;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.delivery_detail_validate', SQLERRM);
         bpascui.display_error('GAQSC27 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END delivery_detail_validate;

   /*
   ||****************************************************************************
   || Proc: get_requested_quantity
   || Desc: This procedure is a wrapper for
   ||       gem_auto_pack_lpn_core.get_requested_quantity.
   ||****************************************************************************
   */
   PROCEDURE get_requested_quantity(usr      IN OUT bp_apps.AppsUsr,
                                    txn      IN OUT bp_apps.AppsTxn)
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);

      gem_auto_pack_lpn_core.get_requested_quantity(usr, pack_txn);

      txn.quantity := pack_txn.requested_quantity;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.get_requested_quantity', SQLERRM);
         bpascui.display_error('GAQSC28 SQL Error', SQLERRM, usr.error_wait);
   END get_requested_quantity;

   /*
   ||****************************************************************************
   || Proc: get_transaction_info
   || Desc: This procedure is a wrapper for
   ||       gem_auto_pack_lpn_core.get_transaction_info
   ||****************************************************************************
   */
   PROCEDURE get_transaction_info  (usr      IN OUT bp_apps.AppsUsr,
                                    txn      IN OUT bp_apps.AppsTxn)
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);

      gem_auto_pack_lpn_core.get_transaction_info(usr, pack_txn);

      txn.org_loc_cc             := pack_txn.is_org_loc_control;
      txn.transfer_subinventory  := pack_txn.transfer_subinventory;
      txn.transfer_locator       := pack_txn.transfer_to_location;
      txn.acct_period_id         := pack_txn.acct_period_id;
      co_debug.debug('gem_auto_quick_ship_core.get_transaction_info', 'Acct period ID = '||txn.acct_period_id, co_debug.SEVERITY_MESSAGE);

   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.get_transaction_info', SQLERRM);
         bpascui.display_error('GAQSC29 SQL Error', SQLERRM, usr.error_wait);
   END get_transaction_info;


   /*
   ||****************************************************************************
   || Proc; update_transfer_locator
   || Desc: This function will update the transfer_to_location field for a
   ||       locator with correct project/task based on from locator.  If the
   ||       locator does not exist it is auto generated.
   ||****************************************************************************
   */
   PROCEDURE update_transfer_locator(usr      IN OUT bp_apps.AppsUsr,
                                     txn      IN OUT bp_apps.AppsTxn)

   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);
      gem_auto_pack_lpn_core.update_transfer_locator(usr, pack_txn);

      txn.project_id          := pack_txn.project_id;
      txn.task_id             := pack_txn.task_id;
      txn.transfer_locator    := pack_txn.transfer_to_location;
      co_debug.debug('gem_auto_quick_ship_core.update_transfer_locator', 'project_id = '||txn.project_id, co_debug.SEVERITY_MESSAGE);
      co_debug.debug('gem_auto_quick_ship_core.update_transfer_locator', 'task_id = '||txn.task_id, co_debug.SEVERITY_MESSAGE);
      co_debug.debug('gem_auto_quick_ship_core.update_transfer_locator', 'transfer_locator = '||txn.transfer_locator, co_debug.SEVERITY_MESSAGE);

   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.update_transfer_locator', SQLERRM);
         bpascui.display_error('update_transfer_locator', SQLERRM, usr.error_wait);
   END update_transfer_locator;


   /*
   ||****************************************************************************
   || Func: get_ato_reservation
   || Desc: This function will get reservations for the ato job.
   ||****************************************************************************
   */
   FUNCTION get_ato_reservation(usr      IN OUT bp_apps.AppsUsr,
                                txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      IF (NOT txn.is_ato_config_item) THEN
         RETURN TRUE;
      END IF;

      copy_txn_to_pack(txn, pack_txn);
      IF (NOT gem_auto_pack_lpn_core.get_ato_reservation(usr, pack_txn)) THEN
         bp_apps.error_message(usr, txn, 1364);
         RETURN FALSE;
      END IF;
      txn.ato_subinventory    := pack_txn.ato_subinventory;
      txn.ato_locator_id      := pack_txn.ato_locator_id;
      txn.ato_revision        := pack_txn.ato_revision;
      txn.ato_lot_number      := pack_txn.ato_lot_number;
      txn.ato_avail_qty       := pack_txn.ato_avail_qty;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.get_ato_reservation', SQLERRM);
         bpascui.display_error('GAQSC30 SQL Error', SQLERRM, usr.error_wait);
   END get_ato_reservation;

   /*
   ||****************************************************************************
   || Func; lot_base_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_pack_lpn_core.lot_base_validate
   ||****************************************************************************
   */
   FUNCTION lot_base_validate(usr      IN OUT bp_apps.AppsUsr,
                              txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);

      IF (NOT gem_auto_pack_lpn_core.lot_base_validate(usr, pack_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.lot_number          := pack_txn.lot_number;
      txn.subinventory_code   := pack_txn.subinventory;
      txn.sub_loc_cc          := pack_txn.is_loc_control;
      txn.loc                 := pack_txn.locator;
      txn.locator_id          := pack_txn.locator_id;
      txn.available_quantity  := pack_txn.subinv_avail_qty;
      txn.project_id          := pack_txn.project_id;
      txn.task_id             := pack_txn.task_id;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.lot_base_validate', SQLERRM);
         bpascui.display_error('GAQSC35 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END lot_base_validate;

   /*
   ||****************************************************************************
   || Func: subinventory_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_pack_lpn_core.subinventory_validate
   ||****************************************************************************
   */
   FUNCTION subinventory_validate(usr                 IN OUT bp_apps.AppsUsr,
                                  txn                 IN OUT bp_apps.AppsTxn,
                                  vp_auto_fill_set    IN     BOOLEAN := FALSE,
                                  vp_auto_fill_prompt IN     VARCHAR2 DEFAULT NULL,
                                  vp_def_project_id   IN OUT NUMBER,
                                  vp_def_task_id      IN OUT NUMBER,
                                  vp_def_project      IN OUT pjm_projects_mtll_v.project_name%TYPE,
                                  vp_def_task         IN OUT pjm_tasks_mtll_v.task_number%TYPE)
      RETURN BOOLEAN
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);
      co_debug.debug('gem_auto_quick_ship_core.subinventory_validate', 'input = '||pack_txn.input, co_debug.SEVERITY_MESSAGE);
      co_debug.debug('gem_auto_quick_ship_core.subinventory_validate', 'item_id = '||pack_txn.inventory_item_id, co_debug.SEVERITY_MESSAGE);
      co_debug.debug('gem_auto_quick_ship_core.subinventory_validate', 'header_id = '||pack_txn.header_id, co_debug.SEVERITY_MESSAGE);
      co_debug.debug('gem_auto_quick_ship_core.subinventory_validate', 'line_id = '||pack_txn.line_id, co_debug.SEVERITY_MESSAGE);

      IF (NOT gem_auto_pack_lpn_core.subinventory_validate(usr,
                                                           pack_txn,
                                                           'Quick Ship',
                                                           vp_auto_fill_set,
                                                           vp_auto_fill_prompt,
                                                           vp_def_project_id,
                                                           vp_def_task_id,
                                                           vp_def_project,
                                                           vp_def_task )) THEN
         RETURN FALSE;
      END IF;

      txn.sub_loc_cc             := pack_txn.is_loc_control;
      txn.subinventory_code      := pack_txn.subinventory;
      txn.available_quantity     := pack_txn.subinv_avail_qty;

      /* Inventory LPN dummy segment support */
      txn.locator_id             := pack_txn.locator_id;

      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.subinventory_validate', SQLERRM);
         bpascui.display_error('GAQSC36 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END subinventory_validate;

   /*
   ||****************************************************************************
   || Func: is_locator_control
   || Desc: Determines if locator control based on org/subinv/item levels.
   ||****************************************************************************
   */
   FUNCTION is_locator_control(txn     IN    bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
   BEGIN
      IF (txn.org_loc_cc = 1) THEN
         RETURN FALSE;
      ELSIF (txn.org_loc_cc = 4) THEN
         IF (txn.sub_loc_cc = 1) THEN
            RETURN FALSE;
         ELSIF (txn.sub_loc_cc = 5) THEN
            RETURN txn.loc_cc != 1;
         ELSE
            RETURN TRUE;
         END IF;
      ELSE
         RETURN TRUE;
      END IF;
   END is_locator_control;

   /*
   ||****************************************************************************
   || Func: locator_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_pack_lpn_core.locator_validate
   ||****************************************************************************
   */
   FUNCTION locator_validate(usr                   IN OUT bp_apps.AppsUsr,
                             txn                   IN OUT bp_apps.AppsTxn,
                             flds                  IN OUT appsui.flds_table,
                             vp_field_name         IN     VARCHAR2 DEFAULT 'LOC',
                             vp_auto_fill_set      IN     BOOLEAN := FALSE,
                             vp_project_id         IN     NUMBER DEFAULT NULL,
                             vp_task_id            IN     NUMBER DEFAULT NULL,
                             vp_auto_fill_prompt   IN     VARCHAR2 DEFAULT NULL,
                             vp_def_proj_task      IN     VARCHAR2 DEFAULT NULL)
      RETURN BOOLEAN
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
      v_item_serial  VARCHAR2(255);
   BEGIN

      co_debug.message('gem_auto_quick_ship_core.locator_validate', 'vp_project_id = '||vp_project_id);
      co_debug.message('gem_auto_quick_ship_core.locator_validate', 'vp_task_id = '||vp_task_id);

      copy_txn_to_pack(txn, pack_txn);
      IF (NOT gem_auto_pack_lpn_core.locator_validate(usr, pack_txn, flds, v_item_serial, vp_field_name,
                                                      'Quick Ship', vp_auto_fill_set, vp_project_id, vp_task_id,
                                                      vp_auto_fill_prompt, vp_def_proj_task)) THEN
         RETURN FALSE;
      END IF;
      gem_auto_pack_lpn_core.update_transfer_locator(usr, pack_txn);

      txn.loc                 := pack_txn.locator;
      txn.locator_id          := pack_txn.locator_id;
      txn.available_quantity  := pack_txn.subinv_avail_qty;
      txn.project_id          := pack_txn.project_id;
      txn.task_id             := pack_txn.task_id;
      txn.transfer_locator    := pack_txn.transfer_to_location;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN bp_apps.go_back THEN
         RAISE bp_apps.go_back;
      WHEN bp_apps.main_menu THEN
         RAISE bp_apps.main_menu;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.locator_validate', SQLERRM);
         bpascui.display_error('GAQSC37 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END locator_validate;

   /*
   ||****************************************************************************
   || Func: get_default_revision
   || Desc: This function will check for a revision that has quantity available.
   ||****************************************************************************
   */
   FUNCTION get_default_revision(usr   IN OUT bp_apps.AppsUsr,
                                 txn   IN     bp_apps.AppsTxn)
      RETURN VARCHAR2
   IS
      pack_txn          gem_auto_pack_lpn_core.pack_txn_type;

      CURSOR get_rev IS
         SELECT mir.revision
           FROM mtl_item_revisions mir
          WHERE mir.inventory_item_id = txn.inventory_item_id
            AND mir.organization_id = usr.organization_id
         ORDER BY mir.revision desc;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);
      FOR rev_rec IN get_rev LOOP
         IF (gem_auto_pack_lpn_core.rev_avail_qty(usr, pack_txn, rev_rec.revision) > 0) THEN
            RETURN rev_rec.revision;
         END IF;
      END LOOP;
      RETURN NULL;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.get_default_revision', SQLERRM);
         bpascui.display_error('GAQSC38 SQL Error', SQLERRM, usr.error_wait);
         RETURN NULL;
   END get_default_revision;

   /*
   ||****************************************************************************
   || Func: revision_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_pack_lpn_core.revision_validate
   ||****************************************************************************
   */
   FUNCTION revision_validate(usr      IN OUT bp_apps.AppsUsr,
                              txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);
      IF (NOT gem_auto_pack_lpn_core.revision_validate(usr, pack_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.item_revision             := pack_txn.revision;
      txn.available_quantity        := pack_txn.subinv_avail_qty;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.revision_validate', SQLERRM);
         bpascui.display_error('GAQSC39 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END revision_validate;

   /*
   ||****************************************************************************
   || Func: lot_number_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_pack_lpn_core.lot_number_validate
   ||****************************************************************************
   */
   FUNCTION lot_number_validate(usr      IN OUT bp_apps.AppsUsr,
                                txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);
      IF (NOT gem_auto_pack_lpn_core.lot_number_validate(usr, pack_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.lot_number                := pack_txn.lot_number;
      txn.available_quantity        := pack_txn.subinv_avail_qty;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.lot_number_validate', SQLERRM);
         bpascui.display_error('GAQSC40 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END lot_number_validate;

   /*
   ||****************************************************************************
   || Func: serial_number_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_pack_lpn_core.revision_validate
   ||****************************************************************************
   */
   FUNCTION serial_number_validate(usr      IN OUT bp_apps.AppsUsr,
                                   txn      IN OUT bp_apps.AppsTxn)
      RETURN NUMBER
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
      v_qty          NUMBER;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);
      v_qty := gem_auto_pack_lpn_core.serial_number_validate(usr, pack_txn, txn.transaction_quantity);
      IF (v_qty < 1) THEN
         RETURN v_qty;
      END IF;

      txn.serial_number_end             := pack_txn.serial_number;
      RETURN v_qty;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.serial_number_validate', SQLERRM);
         bpascui.display_error('GAQSC41 SQL Error', SQLERRM, usr.error_wait);
         RETURN 0;
   END serial_number_validate;

   /*
   ||****************************************************************************
   || Func: quantity_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_pack_lpn_core.quantity_validate
   ||****************************************************************************
   */
   FUNCTION quantity_validate(usr      IN OUT bp_apps.AppsUsr,
                              txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);
      IF (NOT gem_auto_pack_lpn_core.quantity_validate(usr, pack_txn)) THEN
         RETURN FALSE;
      END IF;

      IF (NOT gem_auto_pack_lpn_core.check_staging_qty(usr, pack_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.transaction_quantity             := pack_txn.transaction_quantity;
      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.quantity_validate', SQLERRM);
         bpascui.display_error('GAQSC42 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END quantity_validate;

   /*
   ||****************************************************************************
   || Func: pack_lpn
   || Desc: This function will pack any delivery details that went through
   ||       complete line, but have not been packed yet.
   ||****************************************************************************
   */
   FUNCTION pack_lpn(usr      IN OUT bp_apps.AppsUsr,
                     txn      IN     bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      CURSOR temp IS
         SELECT wdd.delivery_detail_id
           FROM wsh_delivery_details wdd,
                wsh_delivery_assignments wda
          WHERE wdd.attribute10 = to_char(txn.so_header_id)
            AND wda.delivery_detail_id = wdd.delivery_detail_id
            AND wda.parent_delivery_detail_id IS NULL;


      l_api_version     CONSTANT NUMBER      := 1.0;
      l_init_msg_list            VARCHAR2(1) := FND_API.G_TRUE;
      l_commit                   VARCHAR2(1) := FND_API.G_FALSE;
      l_validation_level         NUMBER      := FND_API.G_VALID_LEVEL_FULL;
      l_return_status            VARCHAR2(30);
      l_msg_count                NUMBER;
      l_msg_data                 VARCHAR2(3000);

      l_detail_tab               WSH_UTIL_CORE.ID_TAB_TYPE;
      l_container_name           VARCHAR2(30);
      l_container_flag           VARCHAR2(1);
      l_cont_instance_id         NUMBER;
      l_delivery_flag            VARCHAR2(1);
      l_delivery_id              NUMBER;
      l_delivery_name            VARCHAR2(30);
      l_action_code              VARCHAR2(30);

      l_changed_table            WSH_DELIVERY_DETAILS_PUB.ChangedAttributeTabType;
      l_source_code              VARCHAR2(20) := 'OTHER';
      l_index                    NUMBER;
      i                          NUMBER;
      l_container_rec            WSH_DELIVERY_DETAILS_PUB.ChangedAttributeRecType;

      v_detail_table             WSH_DELIVERY_DETAILS_PUB.ID_Tab_Type;


      v_details                  WSH_UTIL_CORE.ID_TAB_TYPE;

      l_delivery_info            WSH_DELIVERIES_PUB.Delivery_Pub_Rec_Type;
      v_delivery                 VARCHAR2(20);
      v_delivery_id              NUMBER;
      continue_field             bp_apps.AppsFldType;


      CURSOR get_packed_details (vc_lpn_id  NUMBER) IS
         SELECT wda.delivery_detail_id
           FROM wsh_delivery_assignments wda
          WHERE wda.parent_delivery_detail_id = vc_lpn_id;


   BEGIN
      co_debug.debug('gem_auto_quick_ship_core.pack_lpn', 'intmed_ship_to_org_id = '||txn.intmed_ship_to_location_id);
      co_debug.debug('gem_auto_quick_ship_core.pack_lpn', 'fob_code = '||txn.fob_code);
      co_debug.debug('gem_auto_quick_ship_core.pack_lpn', 'freight_terms_code = '||txn.freight_terms_code);
      co_debug.debug('gem_auto_quick_ship_core.pack_lpn', 'ship_method_code = '||txn.ship_method_code);


      FOR temp_rec IN temp LOOP
         co_debug.debug('gem_auto_quick_ship_core.pack_lpn', 'Will pack '||temp_rec.delivery_detail_id, co_debug.SEVERITY_MESSAGE);
         l_detail_tab(l_detail_tab.COUNT + 1) := temp_rec.delivery_detail_id;


         ---------------------------------------------------------------------------
         -- If a detail has a delivery assigned, unassign from the delivery before
         -- packing detail into LPN
         ---------------------------------------------------------------------------
         SELECT wda.delivery_id
           INTO l_delivery_id
           FROM wsh_delivery_assignments wda
          WHERE wda.delivery_detail_id = temp_rec.delivery_detail_id;

         IF (l_delivery_id IS NOT NULL) THEN
            co_debug.debug(usr, 'gem_auto_quick_ship_core.pack_lpn', 'Unassign detail '||temp_rec.delivery_detail_id||' from delivery '||l_delivery_id, co_debug.SEVERITY_MESSAGE);
            v_detail_table.DELETE;
            v_detail_table(v_detail_table.COUNT + 1) := temp_rec.delivery_detail_id;
            wsh_delivery_details_pub.detail_to_delivery
            (
               p_api_version       => 1.0,
               p_init_msg_list     => FND_API.G_TRUE,
               p_commit            => FND_API.G_FALSE,
               p_validation_level  => FND_API.G_Valid_Level_Full,
               x_return_status     => l_return_status,
               x_msg_count         => l_msg_count,
               x_msg_data          => l_msg_data,
               p_TabOfDelDets      => v_detail_table,
               p_action           => 'UNASSIGN',
               p_delivery_id       => l_delivery_id,
               p_delivery_name     => NULL
            );
            IF (NOT bpa_request.post_api(usr,
                                         'wsh_delivery_details_pub.detail_to_delivery',
                                         l_return_status,
                                         l_msg_count,
                                         'Unassign Detail')) THEN
               RETURN(FALSE);
            END IF;
         END IF;


         -- Assign group shipping attributes of detail
         l_index := l_changed_table.COUNT + 1;
         l_changed_table(l_index).delivery_detail_id := temp_rec.delivery_detail_id;
         --l_changed_table(l_index).customer_number := pack_txn.customer_id;
         --l_changed_table(l_index).ship_from_org_id := pack_txn.ship_from_location_id;
         --l_changed_table(l_index).deliver_to_org_id := pack_txn.deliver_to_location_id;
         l_changed_table(l_index).intmed_ship_to_org_id := txn.intmed_ship_to_location_id;
         l_changed_table(l_index).fob_code := txn.fob_code;
         l_changed_table(l_index).freight_terms_code := txn.freight_terms_code;
         l_changed_table(l_index).shipping_method_code := txn.ship_method_code;
      END LOOP;


      /* Assign group shipping attributes of already packed detail */
      FOR temp_rec IN get_packed_details(txn.container_id) LOOP
         l_index := l_changed_table.COUNT + 1;
         l_changed_table(l_index).delivery_detail_id := temp_rec.delivery_detail_id;
         --l_changed_table(l_index).customer_number := pack_txn.customer_id;
         --l_changed_table(l_index).ship_from_org_id := pack_txn.ship_from_location_id;
         --l_changed_table(l_index).deliver_to_org_id := pack_txn.deliver_to_location_id;
         l_changed_table(l_index).intmed_ship_to_org_id := txn.intmed_ship_to_location_id;
         l_changed_table(l_index).fob_code := txn.fob_code;
         l_changed_table(l_index).freight_terms_code := txn.freight_terms_code;
         l_changed_table(l_index).shipping_method_code := txn.ship_method_code;
      END LOOP;


      /* Assign group shipping attributes of LPN */
      l_index := l_changed_table.COUNT + 1;
      l_changed_table(l_index).delivery_detail_id := txn.container_id;
      --l_changed_table(l_index).customer_number := pack_txn.customer_id;
      --l_changed_table(l_index).ship_from_org_id := pack_txn.ship_from_location_id;
      --l_changed_table(l_index).deliver_to_org_id := pack_txn.deliver_to_location_id;
      l_changed_table(l_index).intmed_ship_to_org_id := txn.intmed_ship_to_location_id;
      l_changed_table(l_index).fob_code := txn.fob_code;
      l_changed_table(l_index).freight_terms_code := txn.freight_terms_code;
      l_changed_table(l_index).shipping_method_code := txn.ship_method_code;


      IF (NOT gem_auto_pack_lpn_core.assign_group_attributes(usr, l_changed_table)) THEN
         RETURN FALSE;
      END IF;


      /* Unassign LPN from delivery first */
      v_details.DELETE;
      v_details(v_details.COUNT + 1) := txn.container_id;

      WSH_CONTAINER_PUB.Container_Actions
      (
         p_api_version       => 1.0,
         p_init_msg_list     => FND_API.G_TRUE,
         p_commit            => FND_API.G_FALSE,
         p_validation_level  => FND_API.G_VALID_LEVEL_FULL,
         x_return_status     => l_return_status,
         x_msg_count         => l_msg_count,
         x_msg_data          => l_msg_data,
         p_detail_tab        => v_details,
         p_container_name    => NULL,
         p_cont_instance_id  => NULL,
         p_container_flag    => 'N',
         p_delivery_flag     => 'Y',
         p_delivery_id       => txn.delivery_id,
         p_delivery_name     => NULL,
         p_action_code       => 'UNASSIGN'
      );
      IF (NOT bpa_request.post_api(usr,
                                   'WSH_CONTAINER_PUB.Container_Actions',
                                   l_return_status,
                                   l_msg_count,
                                   'Unassign LPN Error')) THEN
         RETURN(FALSE);
      END IF;


      /* Pack detail */
      l_container_name := txn.container_num;
      l_cont_instance_id := txn.container_id;
      l_container_flag     := 'N';
      l_delivery_flag      := 'N';
      l_delivery_id        := NULL;
      l_action_code        := 'PACK';

      l_init_msg_list      := FND_API.G_TRUE;
      l_return_status      := NULL;
      l_msg_count          := 0;
      l_msg_data           := NULL;

      WSH_CONTAINER_PUB.CONTAINER_ACTIONS
      (
         l_api_version,
         l_init_msg_list,
         l_commit,
         l_validation_level,
         l_return_status,
         l_msg_count,
         l_msg_data,
         l_detail_tab,
         l_container_name,
         l_cont_instance_id,
         l_container_flag,
         l_delivery_flag,
         l_delivery_id,
         l_delivery_name,
         l_action_code
      );
      IF (NOT bpa_request.post_api(usr,
                                   'WSH_CONTAINER_PUB.CONTAINER_ACTIONS',
                                   l_return_status,
                                   l_msg_count,
                                   'Pack API Error')) THEN
         RETURN(FALSE);
      END IF;


      /* Assign group shipping attributes of delivery */
      l_delivery_info.delivery_id := txn.delivery_id;
      l_delivery_info.intmed_ship_to_location_id := txn.intmed_ship_to_location_id;
      l_delivery_info.fob_code := txn.fob_code;
      l_delivery_info.freight_terms_code := txn.freight_terms_code;

      WSH_DELIVERIES_PUB.Create_Update_Delivery(1.0,
                                                FND_API.G_TRUE,
                                                l_return_status,
                                                l_msg_count,
                                                l_msg_data,
                                                'UPDATE',
                                                l_delivery_info,
                                                NULL,
                                                v_delivery_id,
                                                v_delivery);
      IF (NOT bpa_request.post_api(usr,
                                   'WSH_DELIVERIES_PUB.Create_Update_Delivery',
                                   l_return_status,
                                   l_msg_count,
                                   'Update Delivery Error')) THEN
         RETURN(FALSE);
      END IF;

      -----------------------------------------------------------------------------
      -- *NOTE*                                                                  --
      -- Beginning with 11.5.8, Oracle disallows the update of ship_method_code, --
      -- carrier_id, service_level, mode_of_transport after the delivery is      --
      -- assigned to a trip. So we have to manually update ship_method_code as   --
      -- there is no available API.                                              --
      -----------------------------------------------------------------------------
      UPDATE wsh_new_deliveries
         SET ship_method_code = txn.ship_method_code
       WHERE delivery_id = txn.delivery_id;


      /* Assign LPN back to delivery */
      v_details.DELETE;
      v_details(v_details.COUNT + 1) := txn.container_id;

      WSH_CONTAINER_PUB.Container_Actions
      (
         p_api_version       => 1.0,
         p_init_msg_list     => FND_API.G_TRUE,
         p_commit            => FND_API.G_FALSE,
         p_validation_level  => FND_API.G_VALID_LEVEL_FULL,
         x_return_status     => l_return_status,
         x_msg_count         => l_msg_count,
         x_msg_data          => l_msg_data,
         p_detail_tab        => v_details,
         p_container_name    => NULL,
         p_cont_instance_id  => NULL,
         p_container_flag    => 'N',
         p_delivery_flag     => 'N',
         p_delivery_id       => txn.delivery_id,
         p_delivery_name     => NULL,
         p_action_code       => 'ASSIGN'
      );
      IF (NOT bpa_request.post_api(usr,
                                   'WSH_CONTAINER_PUB.Container_Actions',
                                   l_return_status,
                                   l_msg_count,
                                   'Assign LPN Error')) THEN
         RETURN(FALSE);
      END IF;


      /* Update the number_of_lpn field of the delivery */
      IF (NOT update_number_of_lpn(usr, txn, txn.delivery_id)) THEN
         RETURN FALSE;
      END IF;



/*
      ----------------------------------------------------------------------------
      -- If packed details are pick-released in Oracle with auto-create delivery,
      -- assign LPN to that delivery.
      ----------------------------------------------------------------------------
      SELECT wda.delivery_id
        INTO l_delivery_id
        FROM wsh_delivery_assignments wda
       WHERE wda.delivery_detail_id = pack_txn.container_id;

      IF (pack_txn.delivery_id IS NOT NULL) THEN
         IF (l_delivery_id IS NULL) THEN
            co_debug.debug(usr, 'gem_auto_pack_lpn_core.pack_lpn', 'Assign LPN '||pack_txn.container_id||' to delivery '||pack_txn.delivery_id, co_debug.SEVERITY_MESSAGE);
            l_detail_tab.DELETE;
            l_detail_tab(l_detail_tab.COUNT + 1) := pack_txn.container_id;
            wsh_container_pub.Container_Actions
            (
               1.0,
               FND_API.G_TRUE,
               FND_API.G_FALSE,
               FND_API.G_Valid_Level_Full,
               l_return_status,
               l_msg_count,
               l_msg_data,
               l_detail_tab,
               NULL,
               NULL,
               'N',
               'Y',
               pack_txn.delivery_id,
               NULL,
               'ASSIGN'
            );
            IF (l_return_status != FND_API.G_RET_STS_SUCCESS) THEN
               co_debug.debug(usr, 'gem_auto_pack_lpn_core.pack_lpn', 'Calling wsh_container_pub.Container_Actions ', co_debug.SEVERITY_MESSAGE);
               co_debug.debug(usr, 'gem_auto_pack_lpn_core.pack_lpn', 'l_msg_data = '||l_msg_data, co_debug.SEVERITY_MESSAGE);
               co_debug.debug(usr, 'gem_auto_pack_lpn_core.pack_lpn', 'Error: '||fnd_msg_pub.get(1, NULL), co_debug.SEVERITY_MESSAGE);
               bpascui.display_error('Assign LPN', fnd_msg_pub.get(1, NULL), usr.error_wait);
               RETURN FALSE;
            END IF;
         END IF;
      END IF;
*/

      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.pack_lpn', SQLERRM);
         bpascui.display_error('GAQSC44 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END pack_lpn;

   /*
   ||****************************************************************************
   || Proc: complete_line
   || Desc: This function is a wrapper for
   ||       gem_auto_pack_lpn_core.complete_line
   ||****************************************************************************
   */
   FUNCTION complete_line(usr      IN OUT bp_apps.AppsUsr,
                          txn      IN     bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      pack_txn       gem_auto_pack_lpn_core.pack_txn_type;
   BEGIN
      copy_txn_to_pack(txn, pack_txn);
      gem_auto_pack_lpn_core.complete_line(usr, pack_txn);

      IF (NOT pack_lpn(usr, txn)) THEN
         RETURN FALSE;
      END IF;

      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.go_back THEN
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.complete_line', SQLERRM);
         bpascui.display_error('GAQSC45 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END complete_line;

   /*
   ||****************************************************************************
   || Func: ship_method_validate
   || Desc: This function will validate the ship method.
   ||****************************************************************************
   */
   FUNCTION ship_method_validate(usr      IN OUT bp_apps.AppsUsr,
                                 txn      IN OUT bp_apps.AppsTxn,
                                 vp_code     OUT VARCHAR2)
      RETURN BOOLEAN
   IS
      CURSOR get_ship_methods IS
         SELECT DISTINCT lookup_code,
                meaning
           FROM fnd_lookup_values_vl flv
          WHERE UPPER(flv.meaning) LIKE UPPER(txn.input)||'%'
            AND lookup_type = 'SHIP_METHOD'
            AND view_application_id = 3
            AND NVL(start_date_active,sysdate) <= sysdate
            AND NVL(end_date_active,sysdate) >= sysdate
            AND enabled_flag = 'Y'
            AND EXISTS (SELECT NULL
                          FROM wsh_carrier_services wcs,
                               wsh_org_carrier_services wocs
                         WHERE wocs.organization_id = usr.organization_id
                           AND wcs.ship_method_code = flv.lookup_code
                           AND wcs.enabled_flag = 'Y'
                           AND wocs.enabled_flag = 'Y'
                           AND wcs.carrier_service_id = wocs.carrier_service_id)
          ORDER BY meaning;
   BEGIN
      IF (INSTR(txn.input,'%') = 0) THEN
         BEGIN
            SELECT DISTINCT lookup_code
              INTO vp_code
              FROM fnd_lookup_values_vl flv
             WHERE flv.meaning = txn.input
               AND lookup_type = 'SHIP_METHOD'
               AND view_application_id = 3
               AND NVL(start_date_active,sysdate) <= sysdate
               AND NVL(end_date_active,sysdate) >= sysdate
               AND enabled_flag = 'Y'
               AND EXISTS (SELECT NULL
                             FROM wsh_carrier_services wcs,
                                  wsh_org_carrier_services wocs
                            WHERE wocs.organization_id = usr.organization_id
                              AND wcs.ship_method_code = flv.lookup_code
                              AND wcs.enabled_flag = 'Y'
                              AND wocs.enabled_flag = 'Y'
                              AND wcs.carrier_service_id = wocs.carrier_service_id);

            RETURN(TRUE);
         EXCEPTION
            WHEN no_data_found THEN
               NULL;
         END;
      END IF;

      bpl_aio.start_table;
      FOR ship_rec IN get_ship_methods LOOP
         IF (NOT bpl_aio.table_row(ship_rec.meaning)) THEN
            EXIT;
         END IF;

         bpl_aio.put_variable('code', ship_rec.lookup_code);
      END LOOP;

      IF (NOT bpl_aio.quick_pick(gem_fields.get_prompt('carrier'))) THEN
         RETURN FALSE;
      END IF;

      vp_code := bpl_aio.get_variable('code');
      RETURN TRUE;
   EXCEPTION
      WHEN no_data_found THEN
         bp_apps.error_message(usr, txn, 1229);
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.ship_method_validate', SQLERRM);
         bpascui.display_error('GAQSC50 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END ship_method_validate;

   /*
   ||****************************************************************************
   || Func: vehicle_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_confirm_trip_core.validate_vehicle.
   ||****************************************************************************
   */
   FUNCTION vehicle_validate(usr      IN OUT bp_apps.AppsUsr,
                             txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      trip_txn          gem_auto_confirm_trip_core.trip_txn_rec;
   BEGIN
      trip_txn.input := txn.input;
      trip_txn.vehicle_org_id := txn.vehicle_organization_id;

      IF (NOT gem_auto_confirm_trip_core.validate_vehicle(usr, trip_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.vehicle := trip_txn.vehicle;
      txn.vehicle_item_id := trip_txn.vehicle_item_id;
      txn.vehicle_organization_id := trip_txn.vehicle_org_id;
      RETURN TRUE;
   EXCEPTION
      WHEN gem_auto_confirm_trip_core.same_prompt THEN
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.vehicle_validate', SQLERRM);
         bpascui.display_error('GAQSC55 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END vehicle_validate;

   /*
   ||****************************************************************************
   || Func: vehicle_number_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_confirm_trip_core.validate_vehicle_number
   ||****************************************************************************
   */
   FUNCTION vehicle_number_validate(usr      IN OUT bp_apps.AppsUsr,
                                    txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      trip_txn          gem_auto_confirm_trip_core.trip_txn_rec;
   BEGIN
      trip_txn.input := txn.input;
      IF (NOT gem_auto_confirm_trip_core.validate_vehicle_number(usr, trip_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.vehicle_number := trip_txn.vehicle_number;
      RETURN TRUE;
   EXCEPTION
      WHEN gem_auto_confirm_trip_core.same_prompt THEN
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.vehicle_number_validate', SQLERRM);
         bpascui.display_error('GAQSC56 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END vehicle_number_validate;

   /*
   ||****************************************************************************
   || Func: get_default_ship_date
   || Desc: This function is a wrapper for
   ||       gem_auto_confirm_trip_core.get_default_ship_date
   ||****************************************************************************
   */
   FUNCTION get_default_ship_date(usr     IN OUT bp_apps.AppsUsr,
                                  txn     IN     bp_apps.AppsTxn)
      RETURN VARCHAR
   IS
      trip_txn          gem_auto_confirm_trip_core.trip_txn_rec;
   BEGIN
      trip_txn.trip_id := txn.trip_id;

      RETURN gem_auto_confirm_trip_core.get_default_ship_date(usr, trip_txn);
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.get_default_ship_date', SQLERRM);
         bpascui.display_error('GAQSC57 SQL Error', SQLERRM, usr.error_wait);
         RETURN NULL;
   END get_default_ship_date;

   /*
   ||****************************************************************************
   || Func: ship_date_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_confirm_trip_core.validate_ship_date
   ||****************************************************************************
   */
   FUNCTION ship_date_validate(usr      IN OUT bp_apps.AppsUsr,
                               txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      trip_txn          gem_auto_confirm_trip_core.trip_txn_rec;
   BEGIN
      trip_txn.input := txn.input;

      IF (NOT gem_auto_confirm_trip_core.validate_ship_date(usr, trip_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.date_shipped := trip_txn.ship_date;
      RETURN TRUE;
   EXCEPTION
      WHEN gem_auto_confirm_trip_core.same_prompt THEN
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.ship_date_validate', SQLERRM);
         bpascui.display_error('GAQSC57 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END ship_date_validate;

   /*
   ||****************************************************************************
   || Func: update_trip_attributes
   || Desc: This function will update vehicle, vehicle number on the trip.
   ||****************************************************************************
   */
   FUNCTION update_trip_attributes(usr      IN OUT bp_apps.AppsUsr,
                                   txn      IN     bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      l_api_return_status         VARCHAR2(1);
      l_msg_count                 NUMBER;
      l_msg_data                  VARCHAR2(2000);
      v_trip_rec                  WSH_TRIPS_PUB.Trip_Pub_Rec_Type;
      v_trip_id                   NUMBER;
      v_trip_name                 VARCHAR2(30);
   BEGIN
      v_trip_rec.trip_id := txn.trip_id;
      v_trip_rec.name := txn.trip_name;
      v_trip_rec.vehicle_item_id := txn.vehicle_item_id;
      v_trip_rec.vehicle_organization_id := txn.vehicle_organization_id;
      v_trip_rec.vehicle_number := txn.vehicle_number;
      WSH_TRIPS_PUB.create_update_trip
      (
         p_api_version_number   => 1.0,
         p_init_msg_list        => FND_API.G_TRUE,
         x_return_status        => l_api_return_status,
         x_msg_count            => l_msg_count,
         x_msg_data             => l_msg_data,
         p_action_code          => 'UPDATE',
         p_trip_info            => v_trip_rec,
         p_trip_name            => NULL,
         x_trip_id              => v_trip_id,
         x_trip_name            => v_trip_name
      );
      IF (NOT bpa_request.post_api(usr,
                                   'WSH_TRIPS_PUB.create_update_trip',
                                   l_api_return_status,
                                   l_msg_count,
                                   'Update Trip Error')) THEN
         RETURN(FALSE);
      END IF;

      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.update_trip_attributes', SQLERRM);
         bpascui.display_error('GAQSC60 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END update_trip_attributes;

   /*
   ||****************************************************************************
   || Func: get_next_delivery
   || Desc: This function will get the next delivery assigned to this trip.
   ||****************************************************************************
   */
   FUNCTION get_next_delivery(usr      IN OUT bp_apps.AppsUsr,
                              txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      CURSOR get_del (vc_class VARCHAR2) IS
         SELECT wnd.delivery_id,
                wnd.name,
                wnd.waybill,
                muom.uom_code
           FROM wsh_new_deliveries wnd,
                wsh_delivery_legs wdl,
                wsh_trip_stops wts,
                mtl_units_of_measure muom
          WHERE wnd.delivery_id = wdl.delivery_id
            AND wdl.pick_up_stop_id = wts.stop_id
            AND wts.trip_id = txn.trip_id
            AND wnd.status_code = 'OP'
            AND muom.language = usr.appl_language
            AND muom.base_uom_flag = 'Y'
            AND muom.uom_class = vc_class
         ORDER BY wnd.name;

      v_idx          NUMBER;
      v_weight_uom_class   VARCHAR2(50);
   BEGIN

      SELECT weight_uom_class
        INTO v_weight_uom_class
        FROM WSH_SHIPPING_PARAMETERS
       WHERE organization_id = usr.organization_id;

      v_idx := 0;
      FOR del_rec IN get_del (v_weight_uom_class) LOOP
         v_idx := v_idx + 1;
         IF (v_idx = txn.component_rownum) THEN
            txn.delivery_id := del_rec.delivery_id;
            txn.delivery_name := del_rec.name;
            txn.waybill_num := del_rec.waybill;
            txn.weight_unit_code := del_rec.uom_code;
            RETURN TRUE;
         END IF;
      END LOOP;


      RETURN FALSE;

   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.get_next_delivery', SQLERRM);
         bpascui.display_error('GAQSC70 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END get_next_delivery;

   /*
   ||****************************************************************************
   || Func: is_bol_enabled
   || Desc: This function will determine if bol is enabled.
   ||****************************************************************************
   */
   FUNCTION is_bol_enabled(usr      IN OUT bp_apps.AppsUsr,
                           txn      IN     bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      v_bol_type        fnd_document_sequences.type%TYPE;
   BEGIN
      IF (gem_auto_confirm_trip_core.is_bol_enabled(usr)) THEN
         IF (gem_auto_confirm_trip_core.is_bol_enabled_for_ship_method(usr, txn.delivery_id, txn.ship_method_code, v_bol_type)) THEN
            IF (v_bol_type = 'M') THEN
               IF (NOT gem_auto_confirm_trip_core.is_bol_created(usr, txn.delivery_id)) THEN
                  RETURN TRUE;
               END IF;
            END IF;
         END IF;
      END IF;

      RETURN FALSE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.is_bol_enabled', SQLERRM);
         bpascui.display_error('GAQSC71 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END is_bol_enabled;

   /*
   ||****************************************************************************
   || Func: bol_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_confirm_trip_core.validate_bol
   ||****************************************************************************
   */
   FUNCTION bol_validate(usr      IN OUT bp_apps.AppsUsr,
                         txn      IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      trip_txn          gem_auto_confirm_trip_core.trip_txn_rec;
      del_info_tbl      gem_auto_confirm_trip_core.delivery_info_table;
   BEGIN
      trip_txn.input := txn.input;
      trip_txn.ship_method_code := txn.ship_method_code;
      trip_txn.cur_del_info := 1;
      del_info_tbl(1).delivery_id := txn.delivery_id;

      IF (NOT gem_auto_confirm_trip_core.validate_bol(usr, del_info_tbl, trip_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.bill_of_lading := del_info_tbl(trip_txn.cur_del_info).bol_number;
      RETURN TRUE;
   EXCEPTION
      WHEN gem_auto_confirm_trip_core.same_prompt THEN
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.bol_validate', SQLERRM);
         bpascui.display_error('GAQSC75 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END bol_validate;

   /*
   ||****************************************************************************
   || Func: weight_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_confirm_trip_core.validate_weight
   ||****************************************************************************
   */
   FUNCTION weight_validate(usr     IN OUT bp_apps.AppsUsr,
                            txn     IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      trip_txn          gem_auto_confirm_trip_core.trip_txn_rec;
      del_info_tbl      gem_auto_confirm_trip_core.delivery_info_table;
   BEGIN
      trip_txn.input := txn.input;
      trip_txn.cur_del_info := 1;
      IF (NOT gem_auto_confirm_trip_core.validate_weight(usr, del_info_tbl, trip_txn)) THEN
         RETURN FALSE;
      END IF;
      txn.weight := del_info_tbl(1).weight;
      RETURN TRUE;
   EXCEPTION
      WHEN gem_auto_confirm_trip_core.same_prompt THEN
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.weight_validate', SQLERRM);
         bpascui.display_error('GAQSC80 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END weight_validate;

   /*
   ||****************************************************************************
   || Func: update_delivery_attributes
   || Desc: This function will update waybill, weight and create the bol for
   ||       the delivery.
   ||****************************************************************************
   */
   FUNCTION update_delivery_attributes(usr     IN OUT bp_apps.AppsUsr,
                                       txn     IN     bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      l_api_return_status           VARCHAR2(1);
      l_msg_count                   NUMBER;
      l_msg_data                    VARCHAR2(2000);
      v_new_del_rec                 WSH_DELIVERIES_PUB.delivery_pub_rec_type;
      v_delivery_id                 NUMBER;
      v_delivery_name               VARCHAR2(30);

      vp_del_rec                    update_delivery_rec;
      trip_txn                      gem_auto_confirm_trip_core.trip_txn_rec;

      v_pvt_del_rec                 WSH_NEW_DELIVERIES_PVT.Delivery_Rec_Type;

   BEGIN
      IF (NOT delivery_to_trip_action(usr, UNASSIGN_FROM_TRIP, txn.delivery_id, txn.trip_id, vp_del_rec)) THEN
         RETURN FALSE;
      END IF;

      -- Update delivery attributes
      v_new_del_rec.delivery_id := txn.delivery_id;
      v_new_del_rec.name := txn.delivery_name;
      --v_new_del_rec.waybill := txn.waybill_num;
      v_new_del_rec.gross_weight := txn.weight;
      v_new_del_rec.net_weight := txn.weight;
      v_new_del_rec.weight_uom_code := txn.weight_unit_code;
      v_new_del_rec.initial_pickup_date := txn.date_shipped;
      v_new_del_rec.ultimate_dropoff_date := txn.date_shipped;
      v_new_del_rec.confirm_date := txn.date_shipped;
      v_new_del_rec.last_update_date := SYSDATE;
      v_new_del_rec.last_updated_by := usr.user_id;
      v_new_del_rec.last_update_login := usr.user_id;

      WSH_DELIVERIES_PUB.create_update_delivery
      (
         p_api_version_number    =>  1.0,
         p_init_msg_list         =>  FND_API.G_TRUE,
         x_return_status         =>  l_api_return_status,
         x_msg_count             =>  l_msg_count,
         x_msg_data              =>  l_msg_data,
         p_action_code           =>  'UPDATE',
         p_delivery_info         =>  v_new_del_rec,
         p_delivery_name         =>  NULL,
         x_delivery_id           =>  v_delivery_id,
         x_name                  =>  v_delivery_name
      );
      IF (NOT bpa_request.post_api(usr,
                                   'WSH_DELIVERIES_PUB.create_update_delivery',
                                   l_api_return_status,
                                   l_msg_count,
                                   'Update Del Error')) THEN
         RETURN(FALSE);
      END IF;

      /* First populate with the current delivery */
      wsh_new_deliveries_pvt.Populate_Record(txn.delivery_id,
                                             v_pvt_del_rec,
                                             l_api_return_status);
      IF (l_api_return_status != 'S') THEN
         bpascui.display_error('Populate_Record', fnd_msg_pub.get(1, NULL), 3);
         bpascui.display_error('Query Delivery failed','Failed to query attributes of delivery '||txn.delivery_name, usr.error_wait);
         co_debug.message('gem_auto_quick_ship_core.update_delivery_attributes','Failed to query attributes of delivery '||txn.delivery_name);
         co_debug.message('gem_auto_quick_ship_core.update_delivery_attributes','Error: '||fnd_msg_pub.get(1,NULL));
      END IF;


      /* Change the fields we want to update */


      v_pvt_del_rec.waybill := txn.waybill_num;


      /* Call the update API */
      wsh_new_deliveries_pvt.Update_Delivery(v_pvt_del_rec.rowid,
                                             v_pvt_del_rec,
                                             l_api_return_status);
      IF (l_api_return_status != 'S') THEN
         bpascui.display_error('Update_Delivery', fnd_msg_pub.get(1, NULL), 3);
         bpascui.display_error('Update Delivery failed','Failed to update attributes of delivery '||txn.delivery_name, usr.error_wait);
         co_debug.message('gem_auto_quick_ship_core.update_delivery_attributes','Failed to update attributes of delivery '||txn.delivery_name);
         co_debug.message('gem_auto_quick_ship_core.update_delivery_attributes','Error: '||fnd_msg_pub.get(1,NULL));
      END IF;

      IF (NOT delivery_to_trip_action(usr, ASSIGN_TO_TRIP, txn.delivery_id, txn.trip_id, vp_del_rec)) THEN
         RETURN FALSE;
      END IF;

      -- Create BOL number
      IF (is_bol_enabled(usr, txn)) THEN
         trip_txn.ship_method_code := txn.ship_method_code;
         IF (NOT gem_auto_confirm_trip_core.create_bol(usr,
                                                       txn.delivery_id,
                                                       txn.bill_of_lading,
                                                       trip_txn))
         THEN
            RETURN FALSE;
         END IF;
         co_debug.debug('gem_auto_quick_ship_core.update_delivery_attributes', 'BOL number is created', co_debug.SEVERITY_MESSAGE);
      END IF;
      RETURN TRUE;
   EXCEPTION
      WHEN gem_auto_confirm_trip_core.same_prompt THEN
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.update_delivery_attributes', SQLERRM);
         bpascui.display_error('GAQSC81 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END update_delivery_attributes;

   /*
   ||****************************************************************************
   || Func: freight_type_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_confirm_trip_core.validate_freight_type
   ||****************************************************************************
   */
   FUNCTION freight_type_validate(usr     IN OUT bp_apps.AppsUsr,
                                  txn     IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      trip_txn          gem_auto_confirm_trip_core.trip_txn_rec;
      del_info_tbl      gem_auto_confirm_trip_core.delivery_info_table;
      freight_tbl       gem_auto_confirm_trip_core.freight_cost_table;
   BEGIN
      trip_txn.input := txn.input;
      trip_txn.cur_del_info := 1;
      del_info_tbl(1).freight_cost_index := 0;

      IF (NOT gem_auto_confirm_trip_core.validate_freight_type(usr, freight_tbl, del_info_tbl, trip_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.freight_name := freight_tbl(1).freight_cost_type_name;
      txn.freight_charge := freight_tbl(1).freight_charge;
      txn.freight_charge_type_id := freight_tbl(1).freight_cost_type_id;
      RETURN TRUE;
   EXCEPTION
      WHEN gem_auto_confirm_trip_core.same_prompt THEN
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.freight_type_validate', SQLERRM);
         bpascui.display_error('GAQSC82 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END freight_type_validate;

   /*
   ||****************************************************************************
   || Func: freight_charge_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_confirm_trip_core.freight_charge_validate.
   ||****************************************************************************
   */
   FUNCTION freight_charge_validate(usr     IN OUT bp_apps.AppsUsr,
                                    txn     IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      trip_txn          gem_auto_confirm_trip_core.trip_txn_rec;
      del_info_tbl      gem_auto_confirm_trip_core.delivery_info_table;
      freight_tbl       gem_auto_confirm_trip_core.freight_cost_table;
   BEGIN
      trip_txn.input := txn.input;
      trip_txn.cur_del_info := 1;
      freight_tbl(1).freight_cost_type_id := txn.freight_charge_type_id;
      IF (NOT gem_auto_confirm_trip_core.validate_freight_charge(usr, freight_tbl, del_info_tbl, trip_txn)) THEN
         RETURN FALSE;
      END IF;

      txn.freight_charge := freight_tbl(1).freight_charge;
      RETURN TRUE;
   EXCEPTION
      WHEN gem_auto_confirm_trip_core.same_prompt THEN
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.freight_charge_validate', SQLERRM);
         bpascui.display_error('GAQSC83 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END freight_charge_validate;

   /*
   ||****************************************************************************
   || Func: create_freight_cost
   || Desc: This function will create a freight cost for the delivery, all from
   ||       txn record.
   ||****************************************************************************
   */
   FUNCTION create_freight_cost(usr    IN OUT bp_apps.AppsUsr,
                                txn    IN     bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      l_api_return_status           VARCHAR2(1);
      l_msg_count                   NUMBER;
      l_msg_data                    VARCHAR2(2000);

      --v_freight_cost_info           WSH_FREIGHT_COSTS_PVT.freight_cost_rec_type;
      v_freight_cost_info           WSH_FREIGHT_COSTS_PUB.PubFreightCostRecType;
      v_freight_cost_id             NUMBER;
      v_rowid                       VARCHAR2(80);
      v_index                       NUMBER;
      v_profile_value               VARCHAR2(255);
   BEGIN
      SELECT currency_code
        INTO v_freight_cost_info.currency_code
        FROM wsh_freight_cost_types
       WHERE freight_cost_type_id = txn.freight_charge_type_id;

      -- Get the CO_CONVERSION_TYPE profile value
      IF (NOT bp_apps.get_profile(usr, 'CO_CONVERSION_TYPE', v_profile_value, FALSE)) THEN
         v_profile_value := NULL;
      END IF;

      v_freight_cost_info.freight_cost_type_id  := txn.freight_charge_type_id;
      v_freight_cost_info.unit_amount           := txn.freight_charge;
      v_freight_cost_info.delivery_id           := txn.delivery_id;
      v_freight_cost_info.conversion_type_code  := v_profile_value;
      v_freight_cost_info.creation_date         := sysdate;
      v_freight_cost_info.created_by            := usr.user_id;
      v_freight_cost_info.last_update_date      := sysdate;
      v_freight_cost_info.last_updated_by       := usr.user_id;
      v_freight_cost_info.last_update_login     := usr.user_id;

      co_debug.debug('gem_auto_quick_ship_core.create_freight_cost', 'About to call wsh freight cost package - '||txn.freight_name||' - '||txn.freight_charge_type_id||' for '||txn.freight_charge, co_debug.SEVERITY_MESSAGE);

      WSH_FREIGHT_COSTS_PUB.Create_Update_Freight_Costs
      (
         p_api_version_number     => 1.0,
         p_init_msg_list          => FND_API.G_TRUE,
         p_commit                 => FND_API.G_FALSE,
         x_return_status          => l_api_return_status,
         x_msg_count              => l_msg_count,
         x_msg_data               => l_msg_data,
         p_pub_freight_costs      => v_freight_cost_info,
         p_action_code            => 'CREATE',
         x_freight_cost_id        => v_freight_cost_id
      );
      IF (NOT bpa_request.post_api(usr,
                                   'WSH_FREIGHT_COSTS_PUB.Create_Update_Freight_Costs',
                                   l_api_return_status,
                                   l_msg_count,
                                   'Freight CST Error')) THEN
         RETURN(FALSE);
      END IF;
      RETURN TRUE;
   EXCEPTION
      WHEN no_data_found THEN
         bp_apps.error_message (usr, txn, 1155);
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN OTHERS THEN
         co_debug.debug('gem_auto_quick_ship_core.create_freight_cost', SQLERRM);
         bpascui.display_error('GAQSC84 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END create_freight_cost;

   /*
   ||****************************************************************************
   || Proc: print_doc_validate
   || Desc: This function is a wrapper for
   ||       gem_auto_confirm_trip_core.validate_report_set.
   ||****************************************************************************
   */
   FUNCTION print_doc_validate(usr     IN OUT bp_apps.AppsUsr,
                               txn     IN OUT bp_apps.AppsTxn)
      RETURN BOOLEAN
   IS
      trip_txn          gem_auto_confirm_trip_core.trip_txn_rec;
   BEGIN
      IF (NOT gem_auto_confirm_trip_core.validate_report_set(usr, trip_txn)) THEN
         RETURN FALSE;
      END IF;
      txn.wip_entity_id := trip_txn.report_set_id;
      RETURN TRUE;
   EXCEPTION
      WHEN gem_auto_confirm_trip_core.same_prompt THEN
         RETURN FALSE;
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.print_doc_validate', SQLERRM);
         bpascui.display_error('GAQSC90 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END print_doc_validate;

   /*
   ||****************************************************************************
   || Func: process
   || Desc: This function will complete the subinventory transfers, and create
   ||       the reservations.
   ||****************************************************************************
   */
   FUNCTION process(usr             IN OUT bp_apps.AppsUsr,
                    txn             IN     bp_apps.AppsTxn,
                    vp_ship_confirm IN     BOOLEAN)
      RETURN BOOLEAN
   IS
      p_retval          NUMBER;
      l_msg_data        VARCHAR2(2000);
      pack_txn          gem_auto_pack_lpn_core.pack_txn_type;

      v_report_set_id   NUMBER;
      v_report_set_name wsh_report_sets.name%TYPE;

      l_api_return_status           VARCHAR2(1);
      l_msg_count                   NUMBER;

      v_asg_trip_id                 NUMBER;
      v_asg_trip_name               VARCHAR2(30);
      v_asg_pickup_stop_id          NUMBER;
      v_asg_pickup_loc_id           NUMBER;
      v_asg_pickup_loc_code         VARCHAR2(30);
      v_asg_pickup_arr_date         DATE;
      v_asg_pickup_dep_date         DATE;
      v_asg_dropoff_stop_id         NUMBER;
      v_asg_dropoff_loc_id          NUMBER;
      v_asg_dropoff_loc_code        VARCHAR2(30);
      v_asg_dropoff_arr_date        DATE;
      v_asg_dropoff_dep_date        DATE;
      v_sc_stage_del_flag           VARCHAR2(1);
      v_sc_trip_ship_method         VARCHAR2(30);
      v_sc_actual_dep_date          VARCHAR2(30);
      v_wv_override_flag            VARCHAR2(1);
      v_trip_id                     VARCHAR2(30);
      v_trip_name                   VARCHAR2(30);

      v_input                       VARCHAR2(10);

      CURSOR get_dels IS
         SELECT wnd.name delivery_name,
                wnd.delivery_id
           FROM wsh_new_deliveries wnd,
                wsh_delivery_legs wdl,
                wsh_trip_stops wts
          WHERE wnd.delivery_id = wdl.delivery_id
            AND wdl.pick_up_stop_id = wts.stop_id
            AND wts.trip_id = txn.trip_id
            AND wnd.status_code = 'OP';

   BEGIN
      UPDATE mtl_material_transactions_temp
         SET transaction_status = NULL
       WHERE transaction_header_id = txn.so_header_id;

      p_retval := inv_lpn_trx_pub.process_lpn_trx
            (
               p_trx_hdr_id   => txn.so_header_id,
               x_proc_msg     => l_msg_data,
               p_proc_mode    => 1
            );

      IF (p_retval != 0) THEN
         co_debug.debug('gem_auto_quick_ship_core.process', l_msg_data);
         bpascui.display_error('Move API Error', l_msg_data, usr.error_wait);
         RETURN FALSE;
      END IF;

      copy_txn_to_pack(txn, pack_txn);
      IF (NOT gem_auto_pack_lpn_core.create_reservations(usr, pack_txn)) THEN
         RETURN FALSE;
      END IF;

      IF (vp_ship_confirm) THEN
         IF (txn.wip_entity_id IS NOT NULL) THEN
            SELECT wsp.delivery_report_set_id report_set_id,
                   wrs.name report_set_name
              INTO v_report_set_id,
                   v_report_set_name
              FROM wsh_shipping_parameters wsp,
                   wsh_report_sets wrs
             WHERE wsp.organization_id = usr.organization_id
               AND wsp.delivery_report_set_id = wrs.report_set_id;
         ELSE
            v_report_set_id := NULL;
            v_report_set_name := NULL;
         END IF;

         FOR del_rec IN get_dels LOOP
            -- Ship confirm the delivery
            co_debug.debug(usr, 'gem_auto_quick_ship_core.process', 'About to ship confirm');
            co_debug.debug(usr, 'gem_auto_quick_ship_core.process', 'delivery id = '||del_rec.delivery_id);

            IF (NOT gem_auto_confirm_trip_core.update_delivery_details(usr, del_rec.delivery_id)) THEN
               RETURN FALSE;
            END IF;

            WSH_DELIVERIES_PUB.delivery_action
            (
               p_api_version_number      => 1.0,
               p_init_msg_list           => FND_API.G_TRUE,
               x_return_status           => l_api_return_status,
               x_msg_count               => l_msg_count,
               x_msg_data                => l_msg_data,
               p_action_code             => 'CONFIRM',
               p_delivery_id             => del_rec.delivery_id,
               p_delivery_name           => del_rec.delivery_name,
               p_asg_trip_id             => v_asg_trip_id,
               p_asg_trip_name           => v_asg_trip_name,
               p_asg_pickup_stop_id      => v_asg_pickup_stop_id,
               p_asg_pickup_loc_id       => v_asg_pickup_loc_id,
               p_asg_pickup_loc_code     => v_asg_pickup_loc_code,
               p_asg_pickup_arr_date     => v_asg_pickup_arr_date,
               p_asg_pickup_dep_date     => v_asg_pickup_dep_date,
               p_asg_dropoff_stop_id     => v_asg_dropoff_stop_id,
               p_asg_dropoff_loc_id      => v_asg_dropoff_loc_id,
               p_asg_dropoff_loc_code    => v_asg_dropoff_loc_code,
               p_asg_dropoff_arr_date    => v_asg_dropoff_arr_date,
               p_asg_dropoff_dep_date    => v_asg_dropoff_dep_date,
               p_sc_action_flag          => 'T',
               p_sc_intransit_flag       => 'N',
               p_sc_close_trip_flag      => 'N',
               p_sc_create_bol_flag      => 'N',
               p_sc_stage_del_flag       => v_sc_stage_del_flag,
               p_sc_trip_ship_method     => v_sc_trip_ship_method,
               p_sc_actual_dep_date      => txn.date_shipped,
               p_sc_report_set_id        => v_report_set_id,
               p_sc_report_set_name      => v_report_set_name,
               p_sc_defer_interface_flag => 'Y',
               p_wv_override_flag        => v_wv_override_flag,
               x_trip_id                 => v_trip_id,
               x_trip_name               => v_trip_name
            );
            IF (NOT bpa_request.post_api(usr,
                                         'WSH_DELIVERIES_PUB.delivery_action',
                                         l_api_return_status,
                                         l_msg_count,
                                         'Ship Confirm Error')) THEN
               RETURN(FALSE);
            END IF;

         END LOOP;
      END IF;

      RETURN TRUE;
   EXCEPTION
      WHEN bp_apps.terminate THEN
         RAISE bp_apps.terminate;
      WHEN others THEN
         co_debug.debug('gem_auto_quick_ship_core.process', SQLERRM);
         bpascui.display_error('GAQSC99 SQL Error', SQLERRM, usr.error_wait);
         RETURN FALSE;
   END process;

/*
||****************************************************************************
|| Proc: get_default_project_task
|| Desc: This procedure will get the project/task from the allocations. If the
|| the item is not allocated, it will get the values from the sales order line.
||****************************************************************************
*/
PROCEDURE get_default_project_task (usr               IN OUT bp_apps.AppsUsr,
                                    txn               IN     bp_apps.AppsTxn,
                                    vp_def_project_id IN OUT NUMBER,
                                    vp_def_task_id    IN OUT NUMBER,
                                    vp_def_project    IN OUT pjm_projects_mtll_v.project_name%TYPE,
                                    vp_def_task       IN OUT pjm_tasks_mtll_v.task_number%TYPE)
IS
   v_loc            mtl_item_locations_kfv.concatenated_segments%TYPE;
   v_def_project    pjm_projects_mtll_v.project_name%TYPE;
   v_def_task       pjm_tasks_mtll_v.task_number%TYPE;
   v_profile_value   VARCHAR2(50);

BEGIN

   co_debug.message ('gem_auto_quick_ship_core.get_default_project_task', 'Project Enabled: '||usr.project_enabled);
   co_debug.message ('gem_auto_quick_ship_core.get_default_project_task', 'Task Enabled: '||usr.task_enabled);

   IF (usr.project_enabled = 'Y' AND usr.task_enabled = 'Y') THEN

      IF (gem_auto_quick_ship.lpn_method = gem_auto_quick_ship.SALES_ORDER) THEN
         SELECT DISTINCT wdd.project_id,
                wdd.task_id
           INTO vp_def_project_id,
                vp_def_task_id
           FROM wsh_delivery_details wdd,
                wsh_delivery_assignments wda
          WHERE wdd.source_header_id = txn.header_id
            AND wdd.source_line_id = txn.line_id
            --AND wdd.released_status = 'S'
            AND wdd.organization_id = usr.organization_id
            AND wdd.project_id IS NOT NULL
            AND wdd.delivery_detail_id = wda.delivery_detail_id
            AND wda.parent_delivery_detail_id IS NULL
            AND ROWNUM = 1;
      ELSE
         SELECT DISTINCT project_id,
                task_id
           INTO vp_def_project_id,
                vp_def_task_id
           FROM wsh_delivery_details wdd,
                wsh_delivery_assignments wda
          WHERE wda.delivery_id = txn.delivery_id
            AND wda.parent_delivery_detail_id IS NULL
            AND wda.delivery_detail_id = wdd.delivery_detail_id
            AND wdd.inventory_item_id = txn.inventory_item_id
            --AND wdd.released_status = 'S'
            AND wdd.organization_id = usr.organization_id
            AND wdd.project_id IS NOT NULL
            AND ROWNUM = 1;
      END IF;

      SELECT project_name
        INTO vp_def_project
        FROM pjm_projects_mtll_v
       WHERE project_id = vp_def_project_id;

      IF (vp_def_task_id IS NOT NULL) THEN
         SELECT task_number
           INTO vp_def_task
           FROM pjm_tasks_mtll_v
          WHERE project_id = vp_def_project_id
            AND task_id = vp_def_task_id;
      END IF;

   END IF;


   co_debug.message('gem_auto_quick_ship_core.get_default_project_task', 'Default Project: '||vp_def_project);
   co_debug.message('gem_auto_quick_ship_core.get_default_project_task', 'Default Project ID: '||vp_def_project_id);
   co_debug.message('gem_auto_quick_ship_core.get_default_project_task', 'Default Task: '||vp_def_task);
   co_debug.message('gem_auto_quick_ship_core.get_default_project_task', 'Default Task ID: '||vp_def_task_id);

EXCEPTION
   WHEN no_data_found THEN
      NULL;
   WHEN bp_apps.terminate THEN
      RAISE bp_apps.terminate;
   WHEN OTHERS THEN
      co_debug.message('gem_auto_quick_ship_core.get_default_project_task', SQLERRM);
      bpascui.display_error('get_default_project_task', SUBSTR(SQLERRM,1,60), usr.error_wait);
END get_default_project_task;

/******************************************************************************
||    Function : validate_tracking_number
|| Checks that entered tracking number is shorter that 30 characters.
|| Returns true if it is, false otherwise.
******************************************************************************/
FUNCTION validate_tracking_number  (usr      IN OUT   bp_apps.AppsUsr,
                                    vp_input IN       VARCHAR2 DEFAULT NULL)
   RETURN BOOLEAN
IS

   v_input VARCHAR2(250);

BEGIN

   IF vp_input IS NOT NULL THEN
      v_input := vp_input;
   ELSE
      v_input := gem_txn.get('input');
   END IF;

   IF (LENGTH(v_input) > 30 ) THEN
      bp_apps.error_message(usr, 1163);
      RETURN FALSE;
   END IF;

   gem_txn.put('new_tracking_number', gem_txn.get('input'));

   RETURN TRUE;

END validate_tracking_number;


/******************************************************************************
|| Function : update_tracking_number
|| Desc: Updates a tracking number for the current delivery id, and its children.  It
|| is different than update_number that it will update tracking number
|| for the nested lpns also.  It is used by Quick Ship Module.
******************************************************************************/
FUNCTION update_tracking_number (usr                     IN OUT bp_apps.AppsUsr,
                        vp_cont_del_det_id      IN     NUMBER DEFAULT NULL,
                        vp_track_num            IN     VARCHAR2 DEFAULT NULL)
   RETURN BOOLEAN
IS

   curr_delivery     bpa_request.delivery_det_rec_t;
   v_return_status   VARCHAR2(1);
   v_failed          BOOLEAN := FALSE;

   v_del_det_id      NUMBER;
   v_track_num       VARCHAR2(30);
   v_table           WSH_DELIVERY_DETAILS_PUB.ChangedAttributeTabType;

BEGIN


   IF (vp_cont_del_det_id IS NOT NULL) THEN
      v_del_det_id := vp_cont_del_det_id;
   ELSE
      v_del_det_id := gem_txn.get('delivery_detail_id');
   END IF;

   IF (vp_track_num IS NOT NULL) THEN
      v_track_num := vp_track_num;
   ELSE
      v_track_num := gem_txn.get('new_tracking_number');
   END IF;



   /*get all delivery detail ids */
   gem_auto_quick_ship_core.get_all_details(usr, vp_cont_del_det_id, v_table);
   v_table(v_table.COUNT+1).delivery_detail_id := v_del_det_id;

   FOR i in 1..v_table.COUNT LOOP

      -- for each delivery details that belong to the selected container
      curr_delivery :=  bpa_request.initialize_del_detail_rec(usr, v_table(i).delivery_detail_id);

      co_debug.message('gem_auto_quick_ship_core.update_tracking_number','current delivery_detail_id:' || v_table(i).delivery_detail_id);
      co_debug.message('gem_auto_quick_ship_core.update_tracking_number','old tracking number:' || curr_delivery.tracking_number );
      co_debug.message('gem_auto_quick_ship_core.update_tracking_number','new tracking number:' || v_track_num);

      curr_delivery.tracking_number := v_track_num;

      bpa_request.update_delivery_details(usr, NULL, curr_delivery, v_return_status);

      IF (v_return_status <> 'S') THEN
            v_failed := TRUE;
            -- Unable to update LPN tracking number
            bp_apps.error_message(usr, 2012);
            co_debug.message('gem_auto_quick_ship_core.update_tracking_number', 'returning after update error');
            EXIT;
      END IF;

      co_debug.message('gem_auto_quick_ship_core.update_tracking_number', 'Updated tracking number, status: ' || v_return_status);

   END LOOP;

   IF (v_failed) THEN
      RETURN FALSE;
   END IF;

   RETURN TRUE;

EXCEPTION
   WHEN no_data_found THEN
      -- Unable to find delivey
      bp_apps.error_message(usr, 1844);
      RETURN FALSE;
   WHEN bp_apps.end_loop THEN
      RAISE bp_apps.end_loop;
   WHEN others THEN
         co_debug.message ('gem_auto_quick_ship_core.update_number.update_tracking_number','Others: ' || TO_CHAR(sqlcode) ||','|| SUBSTR(sqlerrm,1,120));
         bpascui.display_error('gem_auto_quick_ship_core.update_tracking_number: '||TO_CHAR(sqlcode), SUBSTR(sqlerrm,1,120), usr.error_wait);
      RETURN(FALSE);
END update_tracking_number;



END gem_auto_quick_ship_core;
/
