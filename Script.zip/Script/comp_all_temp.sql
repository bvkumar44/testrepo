set hea off pages 0 lines 79 verify off echo off
spool comp_all_debug.tmp
select
    decode( TYPE, 'PACKAGE BODY',
    'alter PACKAGE ' || OWNER||'.'||NAME || ' compile body;',
    'MATERIALIZED VIEW',
    'alter MATERIALIZED VIEW '|| OWNER||'.'||NAME|| ' compile;',
    'UNDEFINED',
    'alter SNAPSHOT '|| OWNER||'.'||NAME|| ' compile;',
    'JAVA CLASS',
    'alter java class '|| OWNER||'."'||NAME|| '"  resolve;',
    'alter ' || TYPE || ' ' || OWNER||'.'||NAME || ' compile;' )
from
    DBA_PLSQL_OBJECT_SETTINGS
where
    plsql_debug='TRUE' and
    TYPE in ( 'PACKAGE BODY', 'PACKAGE', 'FUNCTION', 'PROCEDURE',
                      'TRIGGER', 'VIEW', 'MATERIALIZED VIEW', 'UNDEFINED',
                      'JAVA CLASS','INDEX' )
order by
    TYPE,
    NAME;
spool off
