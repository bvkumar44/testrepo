col owner for a20
col obj for a30
col typ for a20
set lines 120
set pages 500
compute sum of cnt on report
compute sum of cnt on owner
break on owner on report
select owner,object_name obj,object_type typ,1 cnt from dba_objects where status!='VALID' order by 1,2;
