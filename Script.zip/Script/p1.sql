DECLARE
   cursor c1 is select table_name from dba_synonyms where db_link is null;
BEGIN
   FOR C2 IN C1 LOOP
   declare
        cursor cc1 is select table_name from dba_tables where table_name like c2.table_name||'/_%' ESCAPE '/';
   begin
        for cc2 in cc1 loop
           dbms_output.put_line(cc2.table_name);
        end loop;
   end;
   END LOOP;
END;
/
