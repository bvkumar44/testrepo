rem ***************************************************************
rem * file: comp_all.sql  created: 06/10/96    by: Robert Cordingley
rem * purpose: compile all database stored objects. 
rem * to use:  log in using a the appropriate account then execute
rem *          this script using the following syntax:
rem *
rem *            SQL> @comp_all
rem *
rem * NOTE:    You should not have to run this script more than
rem *          once since it uses the order_object_by_dependency
rem *          table to compile objects in the proper order.  Any
rem *          compilation errors generated should be investigated.
rem ***************************************************************
set hea off pages 0 lines 79 verify off echo off
spool comp_all.tmp
select
    decode( OBJECT_TYPE, 'PACKAGE BODY',
    'alter PACKAGE ' || OWNER||'.'||OBJECT_NAME || ' compile body;',
    'MATERIALIZED VIEW',
    'alter MATERIALIZED VIEW '|| OWNER||'.'||OBJECT_NAME|| ' compile;',
    'UNDEFINED',
    'alter SNAPSHOT '|| OWNER||'.'||OBJECT_NAME|| ' compile;',
    'JAVA CLASS',
    'alter java class '|| OWNER||'."'||OBJECT_NAME|| '"  resolve;',
    'alter ' || OBJECT_TYPE || ' ' || OWNER||'.'||OBJECT_NAME || ' compile;' )
from
    dba_objects
where
    STATUS = 'INVALID' and
    OBJECT_TYPE in ( 'PACKAGE BODY', 'PACKAGE', 'FUNCTION', 'PROCEDURE',
                      'TRIGGER', 'VIEW', 'MATERIALIZED VIEW', 'UNDEFINED',
                      'JAVA CLASS','INDEX' )
    and owner ='APPS'
order by
    OBJECT_TYPE,
    OBJECT_NAME;
spool off
#set hea on pages 22 lines 79 verify on 
select '@comp_all.tmp' from dual;
-- @comp_all.tmp
/
