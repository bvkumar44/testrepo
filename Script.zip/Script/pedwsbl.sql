conn system/Mgr_PRODSBL10@PEDWSBL
set sqlprompt PEDWSBL>
SET TIME ON