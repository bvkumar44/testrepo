select tablespace_name from dba_tablespaces
where tablespace_name not in ('UNDOTBS2','UNDOTBS1','TEMP')
minus
select tablespace_name from 
(
select tablespace_name,max(mbfree) mbfree
from
(
select tablespace_name,max((maxbytes-bytes)/1024/1024) mbfree 
from   dba_data_files
where autoextensible = 'YES'
and maxbytes!=bytes
and (maxbytes-bytes)/1024/1024 >900
group by tablespace_name
union
select tablespace_name,max(bytes)/1024/1024 mbfree
from dba_free_space
group by tablespace_name
having max(bytes)/1024/1024 >900
order by tablespace_name
)
group by tablespace_name
having max(mbfree)>900
);