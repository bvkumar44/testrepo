select 	request_id,
	to_char(actual_start_date,'dd/mm hh24:mi') sdt,
	to_char(actual_completion_date,'dd/mm hh24:mi') edt,
		round((actual_completion_date-actual_start_date)*(60*24),0) mints,
        ARGUMENT_TEXT
from fnd_concurrent_requests a
     fnd_concurrent_programs_vl b
where a.concurrent_program_id = b.concurrrent_program_id
and b.concurrent_program_name='&short_name';

