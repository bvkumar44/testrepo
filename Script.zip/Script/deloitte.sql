set termout off pages 0 heading off echo off feedback off 
set line 999 

set trimspool on 
spool PO_AGENTS.csv 
SELECT 
'"' || replace(agent_id, '"')                || '",' || 
'"' || replace(START_DATE_ACTIVE, '"')                || '",' || 
'"' || replace(END_DATE_ACTIVE, '"')                || '"' 
FROM apps.PO_AGENTS 
/ 
spool off 

set termout off pages 0 heading off echo off feedback off 
set line 999 

set trimspool on 
spool BCC_RA_RULE_SCHEDULES.csv 
select 
   '"' || replace(PERCENT1,'"')  ||'",' || 
   '"' || replace(PERIOD_NUMBER,'"')  ||'",' || 
   '"' || replace(RULE_ID,'"') 
 ||'"' 
from RA_RULE_SCHEDULES 
/ 
spool off 

set termout off pages 0 heading off echo off feedback off 
set line 999 

set trimspool on 
spool BCC_FA_ADDITIONS_TL.csv 
select 
   '"' || replace(ASSET_ID,'"')  ||'",' || 
   '"' || replace(DESCRIPTION,'"') 
 ||'"' 
from FA_ADDITIONS_TL 
/ 
spool off 