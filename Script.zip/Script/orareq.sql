select request_id,oracle_process_id opid
from fnd_concurrent_requests
where request_id in ('20942010','20942003','20942000')
