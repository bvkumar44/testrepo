select 'Current INV Rollup: '||ver||' ('||bug||')' "Description" from (
select x.* from
(select 1 seq, '5739724' bug, '11.5.0' pv,'INV RUP4' ver from dual
union select 2 seq, '6449139' bug,'11.5.0' pv,'INV RUP5' ver from dual
union select 3 seq, '6461517' bug,'11.5.0' pv,'INV RUP6' ver from dual
union select 4 seq, '6461519' bug,'11.5.0' pv,'INV RUP7' ver from dual
union select 5 seq, '6461522' bug,'11.5.0' pv,'INV RUP8' ver from dual
union select 6 seq, '6870030' bug,'11.5.0' pv,'INV RUP9' ver from dual
union select 7 seq, '7258620' bug,'11.5.0' pv,'INV RUP10' ver from dual
union select 8 seq, '7258624' bug,'11.5.0' pv,'INV RUP11' ver from dual
union select 9 seq, '7258629' bug,'11.5.0' pv,'INV RUP12' ver from dual
union select 10 seq, '7581431' bug,'11.5.0' pv,'INV RUP13' ver from dual
union select 11 seq, '7666112' bug,'11.5.0' pv,'INV RUP14' ver from dual
union select 12 seq, '8403245' bug,'11.5.0' pv,'INV RUP15' ver from dual
union select 13 seq, '8403254' bug,'11.5.0' pv,'INV RUP16' ver from dual
union select 14 seq, '8403258' bug,'11.5.0' pv,'INV RUP17' ver from dual
union select 15 seq, '9063156' bug,'11.5.0' pv,'INV RUP18' ver from dual
union select 16 seq, '9265857' bug,'11.5.0' pv,'INV RUP19' ver from dual
union select 17 seq, '9466436' bug,'11.5.0' pv,'INV RUP20' ver from dual
union select 18 seq, '9649124' bug,'11.5.0' pv,'INV RUP21' ver from dual
union select 19 seq, '9878808' bug,'11.5.0' pv,'INV RUP22' ver from dual
union select 20 seq, '10111967' bug,'11.5.0' pv,'INV RUP23' ver from dual
) x,
(select product_version pv from fnd_product_installations
where application_id=401) i,
ad_bugs bugs
where x.bug = bugs.bug_number and x.pv = i.pv order by 1 desc) where rownum = 1
union
select 'Product Installation: '||patch_level||': '||decode(status,
'I','Installed','S','Shared','Not Installed')
from fnd_product_installations
where application_id=401
order by 1
/