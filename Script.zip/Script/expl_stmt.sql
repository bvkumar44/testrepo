explain plan set statement_id = 'richb' for                                                                                         
/                                                                                                                                   
