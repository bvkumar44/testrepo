select inst_id insid,sid,serial#,action,module,last_call_et,status,event,machine mac
 from gv$session
where type!='BACKGROUND'
and status='ACTIVE'
and event not like 'pipe%'
and event not like 'Streams%'
and event not like 'jobq slave%'
and (machine like 'usmlrs352%' or machine like 'usmlrs350%' or machine like 'usmlrs351%')
order by machine
/
