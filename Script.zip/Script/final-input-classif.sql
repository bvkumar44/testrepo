CREATE OR REPLACE VIEW zx_input_classifications_v AS
SELECT
   tcc.org_id ORG_ID,
   COALESCE(rtl.tax_rate_name, lkp.meaning, lkp.lookup_code) MEANING,
   COALESCE(rtl.description, lkp.description, lkp.lookup_code) DESCRIPTION,
   lkp.lookup_code LOOKUP_CODE,
   lkp.lookup_type LOOKUP_TYPE,
   lkp.leaf_node LEAF_NODE,
   lkp.enabled_flag ENABLED_FLAG,
   nvl(tcc.effective_from,lkp.start_date_active) START_DATE_ACTIVE,
   COALESCE(Least(tcc.effective_to,lkp.end_date_active), tcc.effective_to, lkp.end_date_active) END_DATE_ACTIVE,
   tcc.tax_type TAX_TYPE,
   tcc.tax_class TAX_CLASS
FROM
   fnd_lookup_values lkp,
   zx_id_tcc_mapping_all tcc,
   zx_rates_b rb,
   zx_rates_tl rtl
WHERE 1 = 1
   AND lkp.lookup_type IN ('ZX_INPUT_CLASSIFICATIONS', 'ZX_WEB_EXP_TAX_CLASSIFICATIONS')
   AND lkp.view_application_id = 0
   AND lkp.security_group_id = 0
   AND lkp.LANGUAGE = userenv('LANG')
   AND tcc.tax_classification_code = lkp.lookup_code
   AND Nvl(tcc.tax_type,'XXX') <> 'TAX_GROUP'
   AND tcc.active_flag = 'Y'
   AND NVL(tcc.tax_class,'INPUT') = 'INPUT'
   AND rb.source_id = tcc.tax_rate_code_id
   AND rb.tax_rate_code = tcc.tax_classification_code 
   AND NVL(rb.tax_class,'INPUT') = 'INPUT'
   AND rtl.tax_rate_id = rb.tax_rate_id
   AND rtl.LANGUAGE = userenv('LANG')
UNION ALL
SELECT
   tcc.org_id ORG_ID,
   COALESCE(rtl.tax_rate_name, lkp.meaning, lkp.lookup_code) MEANING,
   COALESCE(rtl.description, lkp.description, lkp.lookup_code) DESCRIPTION,
   lkp.lookup_code LOOKUP_CODE,
   lkp.lookup_type LOOKUP_TYPE,
   lkp.leaf_node LEAF_NODE,
   lkp.enabled_flag ENABLED_FLAG,
   nvl(tcc.effective_from,lkp.start_date_active) START_DATE_ACTIVE,
   COALESCE(Least(tcc.effective_to,lkp.end_date_active), tcc.effective_to, lkp.end_date_active) END_DATE_ACTIVE,
   tcc.tax_type TAX_TYPE,
   tcc.tax_class TAX_CLASS
FROM
   fnd_lookup_values lkp,
   zx_id_tcc_mapping_all tcc,
   zx_rates_b rb,
   zx_rates_tl rtl
WHERE 2 = 2
   AND lkp.lookup_type IN ('ZX_INPUT_CLASSIFICATIONS', 'ZX_WEB_EXP_TAX_CLASSIFICATIONS')
   AND lkp.view_application_id = 0
   AND lkp.security_group_id = 0
   AND lkp.LANGUAGE = userenv('LANG')
   AND tcc.tax_classification_code = lkp.lookup_code
   AND Nvl(tcc.tax_type,'XXX') <> 'TAX_GROUP'
   AND tcc.active_flag = 'Y'
   AND NVL(tcc.tax_class,'INPUT') = 'INPUT'
   AND rb.tax_rate_id = tcc.tax_rate_code_id
   AND rb.source_id IS NULL
   AND rb.tax_rate_code = tcc.tax_classification_code 
   AND NVL(rb.tax_class,'INPUT') = 'INPUT'
   AND rtl.tax_rate_id = rb.tax_rate_id
   AND rtl.LANGUAGE = userenv('LANG')
UNION ALL
SELECT
   tcc.org_id ORG_ID,
   NVL(lkp.meaning, lkp.lookup_code) MEANING,
   COALESCE(lkp.description, lkp.meaning, lkp.lookup_code) DESCRIPTION,
   lkp.lookup_code LOOKUP_CODE,
   lkp.lookup_type LOOKUP_TYPE,
   lkp.leaf_node LEAF_NODE,
   lkp.enabled_flag ENABLED_FLAG,
   nvl(tcc.effective_from,lkp.start_date_active) START_DATE_ACTIVE,
   COALESCE(Least(tcc.effective_to,lkp.end_date_active), tcc.effective_to, lkp.end_date_active) END_DATE_ACTIVE,
   tcc.tax_type TAX_TYPE,
   tcc.tax_class TAX_CLASS
FROM
   fnd_lookup_values lkp,
   zx_id_tcc_mapping_all tcc
WHERE 3 = 3
   AND lkp.lookup_type IN ('ZX_INPUT_CLASSIFICATIONS', 'ZX_WEB_EXP_TAX_CLASSIFICATIONS')
   AND lkp.view_application_id = 0
   AND lkp.security_group_id = 0
   AND lkp.LANGUAGE = userenv('LANG')
   AND tcc.tax_classification_code = lkp.lookup_code
   AND tcc.active_flag = 'Y'
   AND tcc.tax_type = 'TAX_GROUP'
   AND NVL(tcc.tax_class,'INPUT') = 'INPUT' 
/
