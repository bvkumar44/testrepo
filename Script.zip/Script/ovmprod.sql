CONN SYSTEM/b9u7!sch@ovmprod
set sqlprompt OVMPROD>