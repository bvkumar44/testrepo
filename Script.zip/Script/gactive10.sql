set lines 250
set pages 200
col process for a8
col action for a15
col osuser for a7
col machine for a13
col module for a30
col osuser for a8 trunc
col event for a40 
select a.inst_id,a.sid,serial#,a.process,action,module,osuser,last_call_et,status,a.event
from gv$session a,gv$session_wait b 
where a.sid = b.sid and a.inst_id=b.inst_id and
      a.sid in (&sid)
/
