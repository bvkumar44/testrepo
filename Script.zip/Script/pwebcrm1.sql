conn system/lfhollis6401@pwebcrm1
set sqlprompt PWEBCRM1>