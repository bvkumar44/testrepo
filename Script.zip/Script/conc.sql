col min for 999
select a.request_id,b.concurrent_program_name,status_code,phase_code,to_char(actual_start_date,'dd/mm hh24:mi') sdate,to_char(actual_completion_date,'dd/mm hh24:mi')  cdate,(actual_completion_date-actual_start_date)*(60*24) tim ,argument_text
from fnd_concurrent_requests a,fnd_concurrent_programs_vl b
where a.concurrent_program_id = b.concurrent_program_id
-- and user_concurrent_program_name='&pg'
--and a.concurrent_program_id = 47994
--and request_id=83603341 
and b.concurrent_program_name='XXLF_LL_RDEM_EXTRACT'
order by 1;