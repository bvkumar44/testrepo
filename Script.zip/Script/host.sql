col DB_hosts for a40
col Instance_host for a40
select host_name DB_hosts from gv$instance;
select host_name Instance_Host from v$instance
/