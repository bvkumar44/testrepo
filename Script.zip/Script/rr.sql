	REM Script provides the request details corresponding to any Process-id 
	REM which can be acquired from the top sessions
	set lines 410
	set pages 1000
	set verify off
	undef spid
	column req_id format 99999999999
	column OPID format a10
	column PPID format a8
	column SPID format a8
	column ST_CD format a1
	column ph_cd format a1
	column CNAME format a30
	column event format a15
	column user_name format a15
	column program format a20
	column serial# format 999999
	column sid format 9999
	column username format a8
	select a.request_id "REQ_ID",a.oracle_process_id "OPID",a.os_process_id "PPID",
	e.user_concurrent_program_name "CNAME",
	f.user_name,a.status_code "ST_CD",a.phase_code "PH_CD", b.username,b.sid,
	b.serial#,b.program,g.event,
	to_char(a.ACTUAL_START_DATE,'MON-DD-HH-MI-SS') START_DATE,
	to_char(a.ACTUAL_COMPLETION_DATE,'MON-DD-HH-MI-SS') COMPL_DATE
	from apps.fnd_concurrent_requests a,(select c.username,c.sid,c.serial#,
				c.program,d.spid from v$session c, v$process d
				where c.paddr=d.addr) b, 
				apps.fnd_concurrent_programs_tl e,
				apps.fnd_user f,
				v$session_wait g
				where a.oracle_process_id=b.spid
				and a.concurrent_program_id=e.concurrent_program_id
				and e.language='US'
				and a.requested_by=f.user_id	
				and b.sid=g.sid
				and a.status_code='R'
				and a.phase_code='R';