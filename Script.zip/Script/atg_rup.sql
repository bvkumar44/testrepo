SET Lines 120 pages 100
col n_patch format A65
col bug_number format A10
col patch_name format A10
spool atg_pf_ptch_level.txt
select bug_number, decode(bug_number,
'3438354', '11i.ATG_PF.H',
'4017300', '11i.ATG_PF.H.RUP1',
'4125550', '11i.ATG_PF.H.RUP2',
'4334965', '11i.ATG_PF.H RUP3',
'4676589', '11i.ATG_PF.H RUP4',
'5382500', '11i.ATG_PF.H RUP5 HELP',
'5473858', '11i.ATG_PF.H.5',
'5674941', '11i.ATG_PF.H RUP5 SSO Integrat',
'5903765', '11i.ATG_PF.H RUP6',
'6117031', '11i.ATG_PF.H RUP6 SSO 10g Integration',
'6330890', '11i.ATG_PF.H RUP6 HELP',
'6241631', '11i.ATG_PF.H.RUP7',
'8248307', '11i.ATG_PF.H RUP7 HELP'
) n_patch, last_update_date
FROM ad_bugs
WHERE bug_number
IN ( '3438354', '4017300', '4125550', '4334965', '4676589', '5382500', '5473858', '5674941', '5903765', '6117031', '6330890', '6241631', '8248307' )
/
