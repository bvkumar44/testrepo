set pagesize 500
set linesize 200
col sid for 9999 
col serial for 99999
col module for a20 trunc
col action for a20 trunc
col program for a20 trunc
col event for a20 trunc
col sqlt for a20

select 	s.sid sid,s.serial# serial,s.module module,s.action action,s.program program,sw.event,sq.sql_text sqlt
from	v$session_wait sw,v$sql sq,v$session s,v$process p,fnd_concurrent_requests fnd
where 	sw.sid = s.sid
and     sql.hash_value = s.sql_hash_value
and	sq.address = s.sql_address
and	p.addr = s.paddr
and	p.spid = fnd.oracle_process_id
and	fnd.request_id = '&reqid';