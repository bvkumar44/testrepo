set lines 125
set pages 500
col pnam for a25
col cval for a30
col oval for a30
select c.profile_option_name pnam,a.profile_option_value cval,b.profile_option_value oval
--a.application_id,a.profile_option_id,a.level_id,a.level_value,
from fnd_profile_option_values a,profile_option_values_25dec b, fnd_profile_options c
where 	c.profile_option_id = b.profile_option_id
and     c.application_id = b.application_id
and     a.application_id= b.application_id
and 	a.profile_option_id=b.profile_option_id
and 	a.level_id= b.level_id
and 	a.level_value= b.level_value
and     a.profile_option_value!= b.profile_option_value
/
