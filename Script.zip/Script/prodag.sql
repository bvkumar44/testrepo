conn system/mgrl3ap13@prodag
set sqlprompt PRODAG>