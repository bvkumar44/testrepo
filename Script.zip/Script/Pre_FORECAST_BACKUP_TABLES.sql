 /*
--
-- $Header: FORECAST_BACKUP_TABLES.sql 
--
-- Copyright (c) 2010, by Sapient Corporation, All Rights Reserved
--
-- Author: 			K S CHAKRAVARTHI
-- Component Id: 	TBD
-- Script Location: TBD
-- Description:    	This tables is getting Forecast Numbers of Pre.
-- View Usage : 	Created for Usage of ForecastPre-Post Analysis .
-- Notes:
-- History:
-- Name            	 	Date          	Version      	Description
-- ------------   		------------- 	----------      ----------------------
-- K S Chakravarthi	  	20-APR-2010     1.0          	Original Creation
--
*/

SPOOL ON

SPOOL PRE_FORECAST_BACKUP_TABLES.log

SELECT name from v$database ;

SELECT TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') "Start Date and Time" FROM dual;

CREATE  TABLE sape_it.pa_budget_versions_pre_bkp AS  (SELECT * FROM pa_budget_versions);

PROMPT  sape_it.pa_budget_versions_pre_bkp  TABLE created.

CREATE  TABLE sape_it.pa_budget_lines_pre_bkp AS (SELECT * FROM pa_budget_lines); 

PROMPT  sape_it.pa_budget_lines_pre_bkp  TABLE created.

CREATE  TABLE sape_it.pa_resource_assignts_pre_bkp AS (SELECT * FROM pa_resource_assignments);

PROMPT  sape_it.pa_resource_assignts_pre_bkp  TABLE created.

CREATE  TABLE sape_it.pa_resource_list_pre_bkp AS (SELECT * FROM pa_resource_list_members);

PROMPT  sape_it.pa_resource_list_pre_bkp  TABLE created.

CREATE TABLE sape_it.pa_projects_all_pre_bkp AS (SELECT * FROM pa_projects_all);

PROMPT  sape_it.pa_projects_all_pre_bkp  TABLE created.

CREATE TABLE sape_it.pa_project_assignments_pre_bkp AS (SELECT * FROM pa_project_assignments);

PROMPT  sape_it.pa_project_assignments_pre_bkp  TABLE created.

--CREATE TABLE sape_it.pa_forecast_items_pre_bkp AS (SELECT * FROM pa_forecast_items);

--PROMPT  sape_it.pa_forecast_items_pre_bkp  TABLE created.

PROMPT Forecast Backup Tables Created.

SELECT TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') "End Date and Time" FROM dual;

SPOOL OFF
/

