##################################################################### 
### START OF SCRIPT ### 
##################################################################### 
# 
( 
# source in 10.1.3 environment 
. $ORA_CONFIG_HOME/10.1.3/$APPLFENV 
# check OPMN status (this should fail as OPMN is not running) 
$ORA_CONFIG_HOME/10.1.3/opmn/bin/opmnctl status 
# 
echo "Attempting to startup OPMN" 
$ORA_CONFIG_HOME/10.1.3/opmn/bin/opmnctl verbose start 
exit_code=$?; 
echo "Exit status code of startup command is $exit_code" 
echo " " 
# check for status of processes 
$ORA_CONFIG_HOME/10.1.3/opmn/bin/opmnctl status 
# check processes are up 
echo "Checking the OPMN processes are running " 
ps -ef | grep "opmn -d" | grep -v grep 
# 
) 2>&1 | tee mzManualStartOPMN.txt 
# 
##################################################################### 
### END OF SCRIPT ### 
#####################################################################

