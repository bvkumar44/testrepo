
select  'insert into xxrequest_in_prd values('||''''||
        req.concurrent_program_id||''''||','||''''||prog.user_concurrent_program_name||''''||','||
--        actual_start_date,actual_completion_date,
        round(min(((actual_completion_date-actual_start_date)*1440)),2)||','||
        round(max(((actual_completion_date-actual_start_date)*1440)),2)||');'
from    fnd_concurrent_requests req,
        fnd_concurrent_programs_vl prog
where   req.concurrent_program_id = prog.concurrent_program_id
and req.concurrent_program_id !=36034
--and requested_start_date > sysdate -10
and actual_completion_date is not null
and phase_code = 'C'
and status_code='C'
and (round(actual_completion_date-actual_start_date,4)*1440) >1
group by req.concurrent_program_id,prog.user_concurrent_program_name

order by 2

select * from v$instance

insert into xxrequest_in_prd values('42100','Aging - 7 Buckets  - By Account Report',1.55,1.62);
insert into xxrequest_in_prd values('20392','Check Periodic Alert',.95,61.4);
insert into xxrequest_in_prd values('20394','Periodic Alert Scheduler',1.32,1.32);
insert into xxrequest_in_prd values('20428','Autoinvoice Import Program',.95,2.18);
insert into xxrequest_in_prd values('20821','Invoice Validation',1.45,1.45);
insert into xxrequest_in_prd values('20874','Customer Credit Snapshot',1.38,1.38);
insert into xxrequest_in_prd values('31711','Sales Journal by GL Account Report',1.88,7.45);
insert into xxrequest_in_prd values('31757','Compile value set hierarchies',1.48,2.97);
insert into xxrequest_in_prd values('31757','General Ledger Transfer Program',1.48,2.97);
insert into xxrequest_in_prd values('31902','MPS Relief Worker',1.12,1.12);
insert into xxrequest_in_prd values('31955','Planning Manager Worker (once-a-day tasks)',7.62,15.97);
insert into xxrequest_in_prd values('32263','Purge Concurrent Request and/or Manager Data',1.87,3.23);
insert into xxrequest_in_prd values('32362','Item demand history report',1,1);
insert into xxrequest_in_prd values('32393','WIP Location Report',15.82,20.65);
insert into xxrequest_in_prd values('32532','Financial Statement Generator',1.05,1.17);
insert into xxrequest_in_prd values('32853','Receipt Traveller Concurrent program',.95,15.47);
insert into xxrequest_in_prd values('33044','Create Releases',1.03,1.32);
insert into xxrequest_in_prd values('33136','Memory-based Planner',1.75,2.33);
insert into xxrequest_in_prd values('33137','Memory-based Snapshot',3.1,26.1);
insert into xxrequest_in_prd values('33138','Snapshot Delete Worker',.97,3.68);
insert into xxrequest_in_prd values('33140','Snapshot Monitor',2.13,24.85);
insert into xxrequest_in_prd values('33148','Load/Copy/Merge MDS',1.98,4.12);
insert into xxrequest_in_prd values('33415','Memory-based Snapshot Worker',.95,24.38);
insert into xxrequest_in_prd values('33430','Account Analysis - Subledger Detail (132 char)',1,1);
insert into xxrequest_in_prd values('33489','Rollup Cumulative Lead Times GUI',12.17,15.27);
insert into xxrequest_in_prd values('33497','Quality Dynamic Plan View Creator',11.5,13.48);
insert into xxrequest_in_prd values('33703','PRC: Update Project Summary Amounts',.95,1.72);
insert into xxrequest_in_prd values('33734','Material cost transaction worker',.95,1.48);
insert into xxrequest_in_prd values('33737','Collection Import Manager',1.32,1.9);
insert into xxrequest_in_prd values('33860','Min-max planning report',1.02,1.02);
insert into xxrequest_in_prd values('33921','Close Discrete Jobs',1.93,2.5);
insert into xxrequest_in_prd values('35740','WIP Mass Load',.95,3.22);
insert into xxrequest_in_prd values('35741','Planning AutoSchedule',7.93,7.93);
insert into xxrequest_in_prd values('36888','Workflow Background Process',.95,.95);
insert into xxrequest_in_prd values('37150','OUT: Planning Schedule (830/DELFOR)',1.22,1.22);
insert into xxrequest_in_prd values('37420','Periodic Actual Cost Worker',16.85,100.13);
insert into xxrequest_in_prd values('37746','Meritor Purchase Order',.95,1.15);
insert into xxrequest_in_prd values('37746','Czech KB Payment Format',.95,1.15);
insert into xxrequest_in_prd values('37766','Meritor Interface da NF emitidas com Consignados de Terceiros - Billing',9.48,23.47);
insert into xxrequest_in_prd values('37915','Transfer Periodic Cost Distributions to GL',26.27,26.27);
insert into xxrequest_in_prd values('37916','Copy Item Period Cost',1.88,1.88);
insert into xxrequest_in_prd values('37949','Razao GL',1.47,1.92);
insert into xxrequest_in_prd values('38230','Print Worksheet',1.3,3.55);
insert into xxrequest_in_prd values('38230','Meritor Rela��o de Notas Fiscais Divergentes',1.3,3.55);
insert into xxrequest_in_prd values('38656','EDI Inbound Transactions',1,2.87);
insert into xxrequest_in_prd values('38792','MRA Supplier Delivery On Time Report',.95,956.27);
insert into xxrequest_in_prd values('39263','Meritor Orders by Item Report',2.5,2.5);
insert into xxrequest_in_prd values('39265','Pick Selection List Generation',1.12,1.12);
insert into xxrequest_in_prd values('39359','Periodic Material and Receiving Distribution Summary Report',2.37,2.37);
insert into xxrequest_in_prd values('39361','Periodic WIP Distribution Summary Report',6.88,6.88);
insert into xxrequest_in_prd values('39362','Periodic Material and Receiving Distribution Details Report',2.5,5.88);
insert into xxrequest_in_prd values('39443','Triggering Process Outbound',1.65,8.98);
insert into xxrequest_in_prd values('39591','PRC: Interface Supplier Costs',1.13,2.57);
insert into xxrequest_in_prd values('39827','Global Security List Maintenance (Obsolete)',1,1.45);
insert into xxrequest_in_prd values('39827','Meritor Grava no Oracle Mov.Geradas no WMS - para Correcao',1,1.45);
insert into xxrequest_in_prd values('39853','Pick Slip Report',.95,27.93);
insert into xxrequest_in_prd values('39936','Order/Invoice Summary Report',1.65,11.78);
insert into xxrequest_in_prd values('40127','Meritor Sele��o de T�tulos para pagamento',1,2.3);
insert into xxrequest_in_prd values('40130','Meritor Gerar Arquivo de envio para o Banco Real',1.55,3.62);
insert into xxrequest_in_prd values('40168','Meritor Sele��o Relat�rio Retorno',1.18,3.58);
insert into xxrequest_in_prd values('40392','Meritor Acompanhamento de Entregas - Resumo',.97,1.05);
insert into xxrequest_in_prd values('40436','Meritor Posi��o de Faturamento',5.07,5.07);
insert into xxrequest_in_prd values('40859','Meritor Notas Fiscais de Faturamento Canceladas',2.02,2.02);
insert into xxrequest_in_prd values('41784','Purge Debug Log',4.6,15.85);
insert into xxrequest_in_prd values('41795','Synchronize WF LOCAL tables',1.18,1.18);
insert into xxrequest_in_prd values('43727','Retroactive Price Update of Purchasing Documents Program',2.63,2.63);
insert into xxrequest_in_prd values('43990','Auto Ship Confirm Report',.97,6.43);
insert into xxrequest_in_prd values('44020','Automated Ship Confirm - SRS',1.17,1.28);
insert into xxrequest_in_prd values('44750','Movimenta��o Peri�dica dos Estoques',14.35,24.75);
insert into xxrequest_in_prd values('44756','Restri��o de Itens para o Processamento do PAC',42.22,42.22);
insert into xxrequest_in_prd values('44761','Processo de Contabiliza�ao do Custo Peri�dico',285.05,285.05);
insert into xxrequest_in_prd values('44763','Processo de Contabiliza�ao NF Compl',20.2,20.2);
insert into xxrequest_in_prd values('44766','Processo Periodico de Carga dos Saldos por Subinvent�rio',69.28,69.28);
insert into xxrequest_in_prd values('44818','Meritor Autoinvoice',.95,5.98);
insert into xxrequest_in_prd values('44842','Meritor Atualizacao das Bases de Apropriacao de Custos',173.72,173.72);
insert into xxrequest_in_prd values('44846','Meritor Margin Analysis Report',1.17,6.97);
insert into xxrequest_in_prd values('44862','Meritor Relatorio de Contabilizacao x Producao em Andamento',4.65,16.47);
insert into xxrequest_in_prd values('44863','Meritor Relatorio de Contabilizacao x Estoque',4.6,4.6);
insert into xxrequest_in_prd values('44942','Meritor Periodic WIP Value Report',48.93,53.72);
insert into xxrequest_in_prd values('44982','Meritor Relacao de Notas Fiscais Divergentes - VW',1.3,3.98);
insert into xxrequest_in_prd values('45062','MRA ATB extract for webfocus reporting',2.93,4.62);
insert into xxrequest_in_prd values('45282','Meritor Historico de Precos do PO',44.63,44.63);
insert into xxrequest_in_prd values('45347','BPAARM WIP Traveler Label',.97,1.03);
insert into xxrequest_in_prd values('45367','Meritor Acerta Interface RLM - Acerto Data Final',1.63,5.25);
insert into xxrequest_in_prd values('45427','ArvinMeritor - Load de notas fiscais ASN',1.17,1.22);
insert into xxrequest_in_prd values('45428','ArvinMeritor - Revalida notas fiscais ASN',.95,14.87);
insert into xxrequest_in_prd values('45429','ArvinMeritor - Submit Concurrent Load EDI ASN',1,13.05);
insert into xxrequest_in_prd values('45487','ARM Release Management Demand Processor',1.12,22.68);
insert into xxrequest_in_prd values('45527','ARM Expense Data Extract Program',7.68,7.68);
insert into xxrequest_in_prd values('45793','Notification Based on Material Reservation',1.3,8.05);
insert into xxrequest_in_prd values('46072','ARM Process EDI IC Files and Sent EDI Outbound Files',1.03,1.2);
insert into xxrequest_in_prd values('46073','ARM EDI IC File Transfer - PL',1.02,1.2);