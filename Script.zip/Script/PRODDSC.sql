-- conn system/mgrpr0ddsc@PRODDSC
-- conn apps/Ph0enix9@PRODDSC
conn ronly/readdsc1@proddsc