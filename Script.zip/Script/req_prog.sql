set verify off lines 150
col request_id for 9999999999
col user_concurrent_program_name for a40
col argument_text for a40
select request_id,user_concurrent_program_name,argument_text,phase_code,status_code,actual_start_date,actual_completion_date,
round ((actual_completion_date-actual_start_date)*24*60,0) "Mins" 
from apps.fnd_conc_req_summary_v 
where user_concurrent_program_name='&concurrent_program_name' 
order by actual_start_date desc
/