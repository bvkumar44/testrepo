set lines 150
col message for a100
select sid,message,sofar,totalwork,time_remaining from v$session_longops where sofar!=totalwork;