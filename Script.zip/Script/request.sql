set verify off
set echo off
set pages 1500
set linesize 132
break on row skip 1  
prompt Checking for Concurrent program details run by this process id
prompt **************************************************************
prompt
prompt
select /*+ CHOOSE*/
  'Node Name..............................: ' || q.node_name                          || chr(10) ||
  'Req id.................................: ' || Request_Id                           || chr(10) ||
  'Requestor..............................: ' || User_Name                            || chr(10) ||
  'Manager................................: ' || Q.User_Concurrent_Queue_Name         || chr(10) ||
  'Status code............................: ' || decode(status_code,'A', 'Waiting','B',
  'Resuming','D', 'Cancelled','E', 'Error', 'G', 'Warning', 'H',
  'On Hold', 'R', 'Normal','S', 'Suspended', 'T', 'Terminating',
                  'W', 'Paused', 'X','Terminated', status_code)                                       || chr(10) ||
  'Phase code.............................: '  || decode(phase_code, 'C', 'Completed',
  'I', 'Inactive', 'P', 'Pending', 'R', 'Running', phase_code)                        || chr(10) ||
  'Priority...............................: ' || Fcr.priority                         || chr(10) ||
  'Program................................: ' || Fcp.User_Concurrent_Program_Name     || chr(10) ||
  'Time so far ...........................: ' ||trunc((sysdate-Fcr.actual_start_date)*24*60,2)||' min'|| chr(10) ||
  'Avg execution time in  30 days.........: ' || trunc(AVG_TIME,2)  ||' min'          || chr(10) ||
  'Max execution time in 30 days..........: ' ||  trunc(MAX_TIME,2)  ||' min'         || chr(10) ||
  'Fastest execution Time in 30 days......: ' ||trunc( MIN_TIME,2) || ' min'          || chr(10) ||
  'Number of executions in last 30 days...: ' ||occurance                             || chr(10) ||
  'ClientPID..............................: ' || Fcr.OS_PROCESS_ID                    || chr(10) ||
  'ServerPID..............................: ' || Fcr.ORACLE_PROCESS_ID     || chr(10) ||
  'Arguments passed to the program .......: ' ||Fcr.argument_text
                 from apps.Fnd_Concurrent_Requests Fcr,
apps.Fnd_Concurrent_Programs_vl Fcp,
apps.Fnd_Oracle_Userid O,
apps.Fnd_Concurrent_Processes P,
apps.Fnd_Concurrent_Queues_vl Q,
apps.Fnd_User,(select
concurrent_program_id
,count(concurrent_program_id) occurance
,min(actual_completion_date-actual_start_date)*24*60 MIN_TIME
,max(actual_completion_date-actual_start_date)*24*60 MAX_TIME
, avg(actual_completion_date-actual_start_date)*24*60 AVG_TIME
from apps.fnd_concurrent_requests
where status_code='C' and phase_code='C'
and trunc(actual_start_date)>trunc(sysdate-30)
group by concurrent_program_id
having max(actual_completion_date-actual_start_date)*24*60 >5) CREQ
where Controlling_Manager = Concurrent_Process_ID
And ( P.Concurrent_Queue_ID  = Q.Concurrent_Queue_ID AND
P.Queue_Application_ID = Q.Application_ID )
And O.Oracle_Id = Fcr.Oracle_Id  and  Request_Id in ('&Request_Id')
And ( Fcr.Program_Application_Id = Fcp.Application_Id
And   Fcr.Concurrent_Program_Id  = Fcp.Concurrent_Program_Id )
And Requested_By = User_Id
--adding joins with new
and Fcr.Concurrent_Program_Id=CREQ.Concurrent_Program_Id(+)
Order By   Q.User_Concurrent_Queue_Name,q.node_name, Actual_Start_Date, Request_Id;