CONN SYSTEM/b9u7!sch@edwprod
set sqlpromopt EDWPROD>