select BBB.NAME, AAA.TABLESPACE_NAME, AAA.FREE_SPACE
FROM 
(
 select AA.TABLESPACE_NAME, max(AA.MARGIN) FREE_SPACE
 from
 (select A.tablespace_name, MAX(trunc((A.maxbytes-A.bytes)/1024/1024)) MARGIN
   from dba_data_files A
   where A.autoextensible='YES'
   group by A.TABLESPACE_NAME
 ) AA
 group by aa.tablespace_name
) AAA,
(select name from v$database) BBB
where free_space < 700 and AAA.TABLESPACE_NAME not in ('RBS1','RBS2','INTERIM','APPS_UNDOTS1','APPS_UNDOTS2');