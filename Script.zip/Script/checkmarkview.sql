select count(*) cnt, sfea.event_type_id tid, event_name name, manager_id manager 
from markview.sf_event_alert sfea, markview.sf_event_type sfet, markview.sf_manager_event_assignment sfmea 
where sfea.event_type_ID = sfet.event_type_ID and SFEA.EVENT_TYPE_ID = sfmea.event_type_id group by sfea.event_type_id, sfet.event_name, sfmea.manager_id;
