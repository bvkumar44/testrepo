CREATE TABLE ontarm.ontarm_open_so_hdr_stg_0312_1 AS (SELECT * FROM ontarm.ontarm_open_so_headers_stg);

CREATE TABLE ontarm.ontarm_open_so_lns_stg_0312_1 AS (SELECT * FROM ontarm.ontarm_open_so_lines_stg);

CREATE TABLE ontarm.oe_open_hdrs_iface_0312_1 AS (SELECT * FROM apps.oe_headers_iface_all);

CREATE TABLE ontarm.oe_open_lns_iface_0312_1 AS (SELECT * FROM apps.oe_lines_iface_all);
