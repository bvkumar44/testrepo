conn system/mgrhjpr0d1@hjprod1
set sqlprompt HJPROD1>
