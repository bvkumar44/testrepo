set head off
set feedback off
set lines 120
select 'ALTER TRIGGER '||OWNER||'.'||trigger_name||' DISABLE;' CMD
from dba_triggers 
where owner='MARKVIEW'
AND STATUS='ENABLED';
spool disable_mv_triggers.sql
/
spool off

select 'ALTER TRIGGER '||OWNER||'.'||trigger_name||' ENABLE;' CMD
from dba_triggers 
where owner='MARKVIEW'
AND STATUS='ENABLED';
spool enable_mv_triggers.sql
/
spool off
