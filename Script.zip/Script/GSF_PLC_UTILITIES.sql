CREATE OR REPLACE PACKAGE BODY GSF_PLC_UTILITIES
AS


/**********************************************************************
CREATED BY: Sandhya M
CREATED DATE: 22/SEP/2014
PURPOSE: To determine the  previous Roll Set Number that was created on a particular Machine in a shift
Created specifically for OCS Camera defects tracking
MODIFIED BY:  Sivan
MODIFIED DATE: 22-Jan-2015
MODIFIED COMMENTS: For Q2 material, Machine Name value in the New_Roll_Archive table coming from the Parent Roll's (Q3) Machine.
***********************************************************************/
FUNCTION GET_PREVIOUS_ROLL_SET_NUMBER
    (
    P_MACHINE_NAME IN NUMBER
    )
RETURN NUMBER

IS

    v_max_roll_number  NUMBER(12) ;
    v_set_number       NUMBER(3);
    v_roll_creation_date    TIMESTAMP;
    v_shift_start_date  TIMESTAMP;
    v_shift_end_date  TIMESTAMP;

BEGIN

    v_max_roll_number := -1 ;

    SELECT  SUBSTR(rollnumber,1,10)
    INTO v_max_roll_number
    FROM
        (select * from new_roll_archive nr
             -- Commented and modified below doe by Sivan for WO# 820857 
             -- For Q2 material, Machine Name value in the New_Roll_Archive table coming from the Parent Roll's (Q3) Machine.
             -- So changed the logic for checking machine name from the first 3 digits of roll number 
            --WHERE machine_name= P_MACHINE_NAME
            WHERE   ROLLNUMBER LIKE P_MACHINE_NAME ||'%'
            --
            ORDER BY nr.date_produced  DESC)
    WHERE rownum =1;

    DBMS_OUTPUT.PUT_LINE('Roll Set Number : ' || v_max_roll_number);

    RETURN v_max_roll_number;

EXCEPTION

    WHEN OTHERS THEN
    RETURN 0; -- fail

END GET_PREVIOUS_ROLL_SET_NUMBER;

END GSF_PLC_UTILITIES;
/