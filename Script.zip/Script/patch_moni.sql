select a.sid,serial#,a.process,action,module,osuser,last_call_et,status,a.event
from gv$session a,gv$session_wait b
where a.sid = b.sid and a.inst_id=b.inst_id and a.module like '%adworker@usmlrs18.arrow.com%' and a.status!='INACTIVE'
/