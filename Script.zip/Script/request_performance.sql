ROMPT " **** "
PROMPT " ****  EXECUTE THIS SQL OVER AMS_EUCVSPRD BUT RUN THE OUTPUT .sh OVER MOCK   ***** "
PROMPT " **** "
accept X

spool CONCSUB_eucvsprd_MOCK.sh

select 'CONCSUB APPS/$apps_pwd ' || 
       nvl(ap_r.APPLICATION_SHORT_NAME, '$NOT_FOUND_RESP_APP_SHORT_NAME') ||
       ' '''||nvl(rp.RESPONSIBILITY_NAME, '$NOT_FOUND_RESP_NAME') ||''' ' ||
       U.USER_NAME ||
       ' CONCURRENT '|| 
       nvl(ap_p.APPLICATION_SHORT_NAME, '$NOT_FOUND_CONCPRG_APP_SHORT_NAME') || ' ' || 
       nvl(p.CONCURRENT_PROGRAM_NAME, '$NOT_FOUND_CONCPRG_NAME') ||
       --DECODE(r.PRINTER, NULL, '', (' PRINTER=' ||  r.PRINTER)) ||
       --DECODE(r.NUMBER_OF_COPIES, NULL, '', (' NUMBER_OF_COPIES=' || r.NUMBER_OF_COPIES)) ||
       ' NUMBER_OF_COPIES=0' || 
       --DECODE(r.PRINT_STYLE, NULL, '', (' PRINT_STYLE=' || r.PRINT_STYLE)) ||
       --DECODE(r.PRINT_GROUP, NULL, '', (' PRINT_GROUP=' || r.PRINT_GROUP)) ||
       --DECODE(r.RESUBMIT_TIME, NULL, '', (' REPEAT_TIME=' ||r.RESUBMIT_TIME)) ||
       --DECODE(r.RESUBMIT_INTERVAL, '', (' REPEAT_INTERVAL=' ||r.RESUBMIT_INTERVAL)) ||
       --DECODE(r.RESUBMIT_INTERVAL_UNIT_CODE, NULL, '', (' REPEAT_INTERVAL_UNIT=' || r.RESUBMIT_INTERVAL_UNIT_CODE)) ||
       --DECODE(r.RESUBMIT_INTERVAL_TYPE_CODE, NULL, '', (' REPEAT_INTERVAL_TYPE=' || r.RESUBMIT_INTERVAL_TYPE_CODE)) ||
       --DECODE(r.RESUBMIT_END_DATE, to_date(NULL), '', (' REPEAT_END=' || r.RESUBMIT_END_DATE)) ||
       --DECODE(r.IMPLICIT_CODE, NULL, '', (' IMPLICIT=' || r.IMPLICIT_CODE)) ||
       '   '''||'"'||replace(r.argument_text, ', ', '''"  "''')||'"'||''' ' CONCSUB_CMD,
----       
       p_tl.USER_CONCURRENT_PROGRAM_NAME,    
       r.REQUEST_ID, r.REQUEST_DATE, r.ACTUAL_START_DATE,  r.ACTUAL_COMPLETION_DATE,  --r.controlling_manager, -- r.REQUESTED_START_DATE, p.USER_CONCURRENT_PROGRAM_NAME , /*(r.ACTUAL_COMPLETION_DATE - r.REQUESTED_START_DATE) Duration_Sec,*/ 
       DECODE(r.PHASE_CODE,'C','(C)ompleted','I','(I)nactive','P','(P)ending','R','(R)unning') PHASE, 
       DECODE(r.STATUS_CODE,'A','A-Waiting','B','B-Resuming','C','C-Normal','D','D-Cancelled','E','E-Error','F','F-Scheduled','G','G-Warning','H','H-On Hold','I','I-Normal','M','M-No Manager','Q','Q-Standby','R','R-Normal','S','S-Suspended','T','T-Terminating','U','U-Disabled','W','W-Paused','X','X-Terminated','Z','Z-Waiting') STATUS,
       u.USER_NAME OLD_USER_NAME        
---
from   applsys.fnd_concurrent_requests r, --perfstat.ARM_FND_CONCURRENT_REQUESTS r, -- 
       applsys.fnd_application ap_r,
       applsys.fnd_application ap_p,
       applsys.fnd_responsibility_tl rp,
       applsys.fnd_user u, 
       applsys.fnd_concurrent_programs p,
       applsys.fnd_concurrent_programs_tl p_tl
where  p.CONCURRENT_PROGRAM_ID = r.CONCURRENT_PROGRAM_ID
and    p.CONCURRENT_PROGRAM_ID = p_tl.CONCURRENT_PROGRAM_ID
and    p.APPLICATION_ID=ap_p.APPLICATION_ID
and    r.RESPONSIBILITY_APPLICATION_ID=ap_r.APPLICATION_ID
and    rp.RESPONSIBILITY_ID=r.RESPONSIBILITY_ID
and    u.USER_ID = r.REQUESTED_By
--and    r.PHASE_CODE='P'  
--and    r.controlling_manager in (8949, 8950, 8951, 8952, 8987)
--and    u.USER_NAME = 'TEBOGTAN'
and    p_tl.USER_CONCURRENT_PROGRAM_NAME in (--like '%Alert%' --'Accrual Rebuild Reconciliation Report'-- 'Update Standard Costs'-- 'Active Users'
&ConcProgs_List
)
;

spool off

