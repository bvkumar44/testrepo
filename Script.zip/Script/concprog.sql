set lines 130
set pages 500
col uprog for a10 trun
col prog for a25 trunc
col appname for a30 trunc
col appshname for a5
col uname for a10
col bname for a11
col emthd for a15 trunc

select 	fcp.USER_CONCURRENT_PROGRAM_NAME uprog,
	fcp.CONCURRENT_PROGRAM_NAME prog,
	DECODE (fcp.execution_method_code,
		'B', 'Request Set Stage Function',
		'Q', 'SQL*Plus',
		'H', 'Host',
		'L', 'SQL*Loader',
		'A', 'Spawned',
		'I', 'PL/SQL Stored Procedure',
		'P', 'Oracle Reports',
		'S', 'Immediate',
		fcp.execution_method_code
		) emthd,
	fa.APPLICATION_name appname,
	fa.APPLICATION_SHORT_NAME appshname,
	fnda.user_name uname,
	fndb.user_name bname
from 	fnd_user fnda,
	fnd_user fndb,
	fnd_concurrent_programs_vl  fcp,
	fnd_application_vl fa
where 	fndb.user_id = fcp.created_by
and	fnda.user_id = fcp.last_updated_by
and	fa.application_id = fcp.application_id
and     fcp.last_update_date >= sysdate - 60
/
