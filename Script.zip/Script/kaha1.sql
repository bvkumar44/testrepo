SELECT   MAX (sh.last_update_date) header_last_update_date,
         MAX (sl.last_update_date) line_last_update_date,
         TO_DATE ('01-jan-1900', 'DD-mon-yyyy') detail_last_update_date,
         SUBSTR (sl.cust_model_serial_number,
                 1,
                 LENGTH (sl.cust_model_serial_number) - 2
                ) chassis_number,
         SUBSTR (sl.cust_model_serial_number,
                 LENGTH (sl.cust_model_serial_number) - 1,
                 LENGTH (sl.cust_model_serial_number)
                ) axle_position,
         sl.cust_po_number po_number, rc.customer_id customer_id,
         rc.customer_name customer_name, msi.inventory_item_id assy_item_id,
         msi.organization_id org_id, msi.segment1 meritor_axle_part_number,
         apps.xx_utilities.get_customer_item_number
                                 (rc.customer_id,
                                  msi.inventory_item_id,
                                  sh.org_id
                                 ) customer_item_number,
         sh.header_id ord_header_id, sh.order_number order_number,
         MIN (sl.line_id) ord_line_id, sl.line_number line_number,
         MAX (SUBSTR (sl.customer_job, 1, 2)) factory_code,
         SUBSTR
             (NVL (sl.customer_production_line, 0),
              1,
              2
             ) vehicle_assembly_line_number,
            SUBSTR (sl.attribute10, 1, 3)
         || ' '
         || SUBSTR (sl.attribute10, 4, 2)
         || ' '
         || SUBSTR (sl.attribute10, 6, 1) dock_destination,
         msi.attribute3 axle_flow,
         SUM (NVL (sl.ordered_quantity, 0)) ordered_qty,
         SUM (NVL (sl.shipped_quantity, 0)) shipped_qty,
         SUM (NVL (sl.cancelled_quantity, 0)) cancelled_qty,
         NVL (sl.attribute11, 'No sequence') shipping_date_and_time,
         MIN (sl.request_date) requirement_date,
         MIN (sl.schedule_ship_date) schedule_date,
         MAX (NVL (sl.open_flag, 'Y')) open_flag,
         rs.site_use_id customer_site_id,
         MIN (wdd.delivery_detail_id) delivery_detail_id
    FROM apps.oe_order_lines_all sl,
         apps.ra_customers rc,
         (SELECT   MAX (syncronisation_date) syncronisation_date,
                   process_code process_code
              FROM apps.xxmast_syncronisation_log
          GROUP BY process_code) xs,
         apps.ra_addresses_all ra,
         apps.oe_transaction_types_all ott,
         apps.ra_site_uses_all rs,
         (SELECT   MIN (wdd.delivery_detail_id) delivery_detail_id,
                   wdd.source_line_id source_line_id
              FROM apps.wsh_delivery_details wdd
             WHERE wdd.organization_id = 111
          GROUP BY wdd.source_line_id) wdd,
         apps.oe_order_headers_all sh,
         apps.mtl_system_items msi
   WHERE 1 = 1
     AND rc.customer_id = ra.customer_id
     AND ra.address_id = rs.address_id
     AND rs.site_use_id = sh.ship_to_org_id
     AND sl.line_id = wdd.source_line_id
     AND msi.attribute3 IS NOT NULL
     AND msi.inventory_item_status_code || '' = 'Active'
     AND msi.inventory_item_id = sl.inventory_item_id
     AND msi.organization_id = sl.ship_from_org_id              --warehouse_id
     AND sl.ship_from_org_id = 111
     AND sh.org_id = 111
     AND sl.header_id = sh.header_id
     AND sl.line_type_id = ott.transaction_type_id
     AND ott.order_category_code != 'RETURN'
--	 AND wdd.source_line_id = '2834827'
     --AND sh.order_number = '5002535'
     --AND sl.line_number = 98
     AND sl.flow_status_code IN
            ('BOOKED', 'AWAITING_SHIPPING', 'SCHEDULED', 'CLOSED',
             'CANCELLED')
     AND xs.process_code = 'SALES_ORDERS'
     AND (   sh.last_update_date > xs.syncronisation_date
          OR sl.last_update_date > xs.syncronisation_date
         )
GROUP BY TO_DATE ('01-jan-1900', 'DD-mon-yyyy'),
         SUBSTR (sl.cust_model_serial_number,
                 1,
                 LENGTH (sl.cust_model_serial_number) - 2
                ),
         SUBSTR (sl.cust_model_serial_number,
                 LENGTH (sl.cust_model_serial_number) - 1,
                 LENGTH (sl.cust_model_serial_number)
                ),
         sl.cust_po_number,
         rc.customer_id,
         rc.customer_name,
         msi.inventory_item_id,
         msi.organization_id,
         msi.segment1,
         apps.xx_utilities.get_customer_item_number (rc.customer_id,
                                                     msi.inventory_item_id,
                                                     sh.org_id
                                                    ),
         sh.header_id,
         sh.order_number,
         sl.line_number,
         SUBSTR (NVL (sl.customer_production_line, 0), 1, 2),
            SUBSTR (sl.attribute10, 1, 3)
         || ' '
         || SUBSTR (sl.attribute10, 4, 2)
         || ' '
         || SUBSTR (sl.attribute10, 6, 1),
         msi.attribute3,
         rs.site_use_id,
         NVL (sl.attribute11, 'No sequence')
ORDER BY sh.order_number, sl.line_number;