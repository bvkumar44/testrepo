col "ELAPSED(Second)" for 999999999.999
col "Ela/Exec(Sec)" for 999999999.9999
select sql_id,plan_hash_value,executions,elapsed_time/1000000 "ELAPSED(Second)",elapsed_time/1000000/decode(executions,0,1,executions) "Ela/Exec(Sec)",Rows_processed,sql_profile from gv$sql  where module='&module'
order by 4 desc
/