REM $Header: bom10u03.sql 115.2.115100.4 2005/01/18 00:42:13 rfarook ship $

REM dbdrv: sql ~PROD ~PATH ~FILE none none none sqlplus_repeat \
REM dbdrv: &phase=upg+5 checkfile:~PROD:~PATH:~FILE &un_bom &batchsize

REM dbdrv: sql ~PROD ~PATH bomdbicx.sql none none none sql &phase=con \
REM dbdrv: checkfile:~PROD:~PATH:bomdbicx.sql:norecord
 
REM dbdrv: sql ~PROD ~PATH bomebicx.sql none none none sql &phase=en \
REM dbdrv: checkfile:~PROD:~PATH:bomebicx.sql:norecord 

REM /*=======================================================================+
REM  |     Copyright (c) 1993 Oracle Corporation Belmont, California, USA    |
REM  |                         All rights reserved.                          |
REM  +=======================================================================+
REM  | FILENAME
REM  |   bom10u03.sql
REM  |
REM  | DESCRIPTION
REM  |   BOM 11.5.9 to 11.5.10 data upgrades
REM  |  
REM  | NOTES
REM  | HISTORY
REM  |   Jul-20-2004 rfarook  	 11.5.10 components data upgrade
REM  |                           Populate the PK column values and the from minor rev, from object rev
REM  |
REM  |
REM  +======================================================================*/
SET VERIFY OFF;
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR  EXIT FAILURE ROLLBACK;


DECLARE
  l_worker_id       NUMBER  := &&3;
  l_num_workers     NUMBER  := &&4;
  l_table_owner     VARCHAR2(30) := '&&1';
  l_batch_size      VARCHAR2(30) := &&2;
  l_any_rows_to_process BOOLEAN;

  l_table_name      VARCHAR2(30) := 'BOM_COMPONENTS_B';

  --
  -- the APIs use a combination of TABLE_NAME and UPDATE_NAME to track an
  -- update. The update should be a no-op on a rerun, provided the TABLE_NAME
  -- and UPDATE_NAME do not change.
  -- 
  -- If you have modified the script for upgrade logic and you want the
  -- script to reprocess the data, you must modify UPDATE_NAME to reflect
  -- the change.
  --
  l_update_name     VARCHAR2(30) := 'bomcmp03.sql';

  l_start_rowid     ROWID;
  l_end_rowid       ROWID;
  l_rows_processed  NUMBER;

  l_str_type_id  NUMBER;

BEGIN

  /* Populate the PK column values and the from minor rev, from object rev 
   for all the components */

  ad_parallel_updates_pkg.initialize_rowid_range(
           ad_parallel_updates_pkg.ROWID_RANGE,
           l_table_owner,
           l_table_name,
           l_update_name,
           l_worker_id,
           l_num_workers,
           l_batch_size, 0);

   ad_parallel_updates_pkg.get_rowid_range(
           l_start_rowid,
           l_end_rowid,
           l_any_rows_to_process,
           l_batch_size,
           TRUE);

  WHILE (l_any_rows_to_process = TRUE)
  LOOP     

  	UPDATE /*+ ROWID (bc) */ bom_inventory_components bc
  	SET bc.pk1_value = bc.component_item_id,
      		bc.from_minor_revision_id = 0,
      		(bc.pk2_value, bc.from_object_revision_id) = 
      		             (SELECT bs.organization_id, mir.revision_id
                              FROM bom_bill_of_materials bs, mtl_item_revisions_b mir
                              WHERE bs.bill_sequence_id = bc.bill_sequence_id AND
                              bs.assembly_item_id = mir.inventory_item_id AND
                              bs.organization_id = mir.organization_id AND mir.effectivity_date =
                              (SELECT max(mir1.effectivity_date) FROM mtl_item_revisions_b mir1
                               WHERE mir1.inventory_item_id = mir.inventory_item_id AND
                               mir1.organization_id = mir.organization_id AND
                               mir1.effectivity_date <= bc.effectivity_date) AND ROWNUM = 1)
  	WHERE bc.from_object_revision_id IS NULL
  	      AND rowid BETWEEN l_start_rowid AND l_end_rowid;

        l_rows_processed := SQL%ROWCOUNT;

  	UPDATE /*+ ROWID (BC2) */ bom_inventory_components BC2
  		SET BC2.pk1_value = BC2.component_item_id,
        	BC2.from_minor_revision_id = 0,
  	       (BC2.pk2_value, BC2.from_object_revision_id) = 
  	       (SELECT bs.organization_id, mir.revision_id
                FROM bom_bill_of_materials bs, mtl_item_revisions_b mir
                WHERE bs.bill_sequence_id = BC2.bill_sequence_id AND
                bs.assembly_item_id = mir.inventory_item_id AND
                bs.organization_id = mir.organization_id AND mir.effectivity_date =
                (SELECT min(mir1.effectivity_date) FROM mtl_item_revisions_b mir1
                WHERE mir1.inventory_item_id = mir.inventory_item_id AND
                mir1.organization_id = mir.organization_id) and ROWNUM=1)
  	WHERE BC2.from_object_revision_id IS NULL
  	AND rowid BETWEEN l_start_rowid AND l_end_rowid;

        l_rows_processed := Greatest(l_rows_processed,SQL%ROWCOUNT);

        UPDATE /*+ ROWID (BC3) */ bom_inventory_components BC3
                SET BC3.implementation_date = BC3.creation_date 
        WHERE BC3.implementation_date IS NULL
        AND BC3.change_notice IS NULL 
        AND rowid BETWEEN l_start_rowid AND l_end_rowid;

        l_rows_processed := Greatest(l_rows_processed,SQL%ROWCOUNT);

        ad_parallel_updates_pkg.processed_rowid_range(
          l_rows_processed,
          l_end_rowid);

    --
    -- commit transaction here
    --

    COMMIT;

    --
    -- get new range of rowids
    --
    ad_parallel_updates_pkg.get_rowid_range(
         l_start_rowid,
         l_end_rowid,
         l_any_rows_to_process,
         l_batch_size,
         FALSE);

  END LOOP;  

END;
/

COMMIT;
EXIT;

