BEGIN 
  DBMS_NETWORK_ACL_ADMIN.CREATE_ACL( 
  acl => 'wallet-acl.xml', 
  description => 'Wallet ACL', 
  principal => 'APPS', 
  is_grant => TRUE, 
  privilege => 'RvQb8QkM'); 
  
  DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE( 
  acl => 'wallet-acl.xml', 
  principal => 'APPS', 
  is_grant => TRUE, 
  privilege => 'RvQb8QkM'); 
  
  DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE( 
  acl => 'wallet-acl.xml', 
  principal => 'XXVERTEX', 
  is_grant => TRUE, 
  privilege => 'xxvertex'); 
  
  DBMS_NETWORK_ACL_ADMIN.ASSIGN_WALLET_ACL( 
  acl => 'wallet-acl.xml', 
  wallet_path => 'file:/tclo1i/oracle/product/11203/appsutil/wallet'); 
  
   COMMIT;
 END;
/