/*--------------------------------------------- ArvinMeritor Inc. ----------------------------------*/
-- Application Module Name : Flow Manufacturing
-- File Name               : FLMARM_FSH_WORKBNCH_TABLE.sql
-- Date                    : 03-Sep-2003
-- Author                  : Gerald Alphonse Rajendran
-- MD060 Name              : FTC - FLow Assembly Report
--                                                                              
-- Description:                                                                 
--       This script is used to create the custom table FLMARM_FSH_WORKBNCH 
-- in FLMARM schema
-- 
-- Modification History
--
--   REVISON   DATE/TIME  AUTHOR         Remarks
--   Rev X.X   MON DD YYYY HH:MM:SS   
--
--   1.0  Sep-03-2003  Gerald Alphonse Rajendran     Initial creation                              
--
--   1.1  Sep-28-2007  Mariappan B
--   Europe Installation - Commented out the GRANT to APPS_MRC schema.
--
/*--------------------------------------------------------------------------------------------------*/
WHENEVER SQLERROR CONTINUE;
DROP table flmarm_fsh_workbnch cascade constraints;

WHENEVER SQLERROR EXIT FAILURE ROLLBACK;

CREATE TABLE flmarm_fsh_workbnch (
  conc_request_id          number,
  arm_assembly_part_number varchar2(40),
  customer_part_number     varchar2(2000),
  assembly_category        varchar2(40),
  build_sequence           number,
  completion_date          date,
  schedule_group           varchar2(30),
  schedule_group_name      varchar2(30),
  line_pallet_number       varchar2(150),
  quantity                 number,
  customer_ship_to_name    varchar2(40),
  component_pn1            varchar2(40),
  component_pn2            varchar2(40),
  component_pn3            varchar2(40),
  component_pn4            varchar2(40),
  component_pn5            varchar2(40),
  component_pn6            varchar2(40),
  component_pn7            varchar2(40),
  component_pn8            varchar2(40),
  component_pn9            varchar2(40),
  component_pn10           varchar2(40),
  component_pn11           varchar2(40),
  component_pn12           varchar2(40),
  component_description1   varchar2(240),
  component_description2   varchar2(240),
  component_description3   varchar2(240),
  component_description4   varchar2(240),
  component_description5   varchar2(240),
  component_description6   varchar2(240),
  component_description7   varchar2(240),
  component_description8   varchar2(240),
  component_description9   varchar2(240),
  component_description10  varchar2(240),
  component_description11  varchar2(240),
  component_description12  varchar2(240),
  component_qty1           number,
  component_qty2           number,
  component_qty3           number,
  component_qty4           number,
  component_qty5           number,
  component_qty6           number,
  component_qty7           number,
  component_qty8           number,
  component_qty9           number,
  component_qty10          number,
  component_qty11          number,
  component_qty12          number,
  break_pages_yes_no       varchar2(1)
);


GRANT all on flmarm_fsh_workbnch to apps with grant option;
--Commented as per Rev 1.1
--GRANT all on flmarm_fsh_workbnch to apps_mrc;

