set termout off pages 0 heading off echo off feedback off 
set line 999 

set trimspool on 
spool BCC_RA_RULE_SCHEDULES.csv 
select 
   '"' || replace(PERCENT,'"')  ||'",' || 
   '"' || replace(PERIOD_NUMBER,'"')  ||'",' || 
   '"' || replace(RULE_ID,'"') 
 ||'"' 
from RA_RULE_SCHEDULES 
/ 
spool off 
