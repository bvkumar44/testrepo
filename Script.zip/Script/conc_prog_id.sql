select CONCURRENT_PROGRAM_ID from fnd_concurrent_requests where request_id=&req_id
/

