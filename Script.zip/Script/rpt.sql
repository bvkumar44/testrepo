set lines 150
set pages 1000
col owner for a20 trunc
col segment_name for a30
col A1STWEEK FOR 99999999.99 head "1st Week"
col B2NDWEEK FOR 99999999.99 head "2nd week"
col C3RDWEEK FOR 99999999.99 head "3rd week"
col D4THWEEK FOR 99999999.99 head "4th week"
compute sum of a1stweek on report owner
compute sum of b2ndweek on report owner
compute sum of c3rdweek on report owner
compute sum of d4thweek on report owner
break on owner on report
select A.OWNER,A.segment_name,
       ROUND(A.bytes/1024/1024/1024,2) A1STWEEK,
       ROUND(B.bytes/1024/1024/1024,2) B2NDWEEK,
       ROUND(C.bytes/1024/1024/1024,2) C3RDWEEK,
       ROUND(C.bytes/1024/1024/1024,2) D4THWEEK
from   PELPERF.PEL_GROWTH_MONITOR a,
       PELPERF.PEL_GROWTH_MONITOR b,
       PELPERF.PEL_GROWTH_MONITOR c,
       PELPERF.PEL_GROWTH_MONITOR d
where  d.bytes/1024/1024 - a.bytes/1024/1024 >10 and
       a.owner = b.owner and
       a.segment_name = b.segment_name and
       nvl(a.partition_name,'#') = nvl(b.partition_name,'#') and
       a.segment_type = b.segment_type and
       a.segment_type not like '%UNDO%' AND
       c.owner = b.owner and
       c.segment_name = b.segment_name and
       nvl(c.partition_name,'#') = nvl(b.partition_name,'#') and
       c.segment_type = b.segment_type and
       d.owner = b.owner and
       d.segment_name = b.segment_name and
       nvl(d.partition_name,'#') = nvl(b.partition_name,'#') and
       d.segment_type = b.segment_type and
       TRUNC(A.CDATE) = (select distinct trunc(cdate) from pelperf.pel_growth_monitor p1 where 3 = (select count(distinct(p2.cdate)) from pelperf.pel_growth_monitor p2 where p2.cdate > p1.cdate))  and
       TRUNC(B.CDATE) = (select distinct trunc(cdate) from pelperf.pel_growth_monitor p1 where 2 = (select count(distinct(p2.cdate)) from pelperf.pel_growth_monitor p2 where p2.cdate > p1.cdate))  and
       TRUNC(C.CDATE) = (select distinct trunc(cdate) from pelperf.pel_growth_monitor p1 where 1 = (select count(distinct(p2.cdate)) from pelperf.pel_growth_monitor p2 where p2.cdate > p1.cdate))  and
       TRUNC(D.CDATE) = (select trunc(max(cdate)) from pelperf.pel_growth_monitor)
       order by 1,2,3 asc;