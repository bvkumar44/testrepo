set pages 500
set lines 120
col module for a40 trunc
col action for a20 trunc noprint
col uname for a10 trunc
col event for a20 trunc

select a.sid,serial#,action,module,last_call_et,status,a.event
 from v$session a
where event not like '%SQL%';
