select distinct a.profile_option_value pval,a.profile_option_id,a.level_id,b.user_profile_option_name pnam
from apps.fnd_profile_option_values a,apps.fnd_profile_options_vl b
where 	a.application_id= b.application_id
and 	a.profile_option_id=b.profile_option_id
and level_id = 10004
and a.profile_option_id in
(
4532,
3804,
7514,
2353,
4532
)
