select phase_code,status_code from fnd_concurrent_requests where request_id='&req_id'
/
