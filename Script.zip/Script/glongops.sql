col sid for 99999
col message for a100
set lines 120
set pages 500
col tm for 999999999
select sid,message,TIME_REMAINING tm from gv$session_longops where sofar!=totalwork;
/
