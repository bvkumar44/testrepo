explain plan for
SELECT CIB.INCIDENT_ID AS "INCIDENT_ID"
     , CIB.INCIDENT_NUMBER AS "INCIDENT_NUMBER"
     , TO_CHAR (NEW_TIME (CIB.CREATION_DATE, 'CST', 'GMT'), 'DD-MON-YYYY HH24:MI:SS') AS "CREATION_DATE"
     , FU1.USER_NAME AS "CREATED_BY"
     , TO_CHAR (NEW_TIME (CIB.LAST_UPDATE_DATE, 'CST', 'GMT'), 'DD-MON-YYYY HH24:MI:SS')
                                                                                        AS "LAST_UPDATE_DATE"
     , FU2.USER_NAME AS "LAST_UPDATED_BY"
     , PMAP.RN_ID AS "CONTACT_PARTY_ID"
     , CIB.SUMMARY AS "SUMMARY"
     , CI_SEV.NAME AS "EVENT_PRIORITY"
     , CI_TYPES_B.ATTRIBUTE1 AS "EVENT_TYPE"
     , CI_STATUS_B.ATTRIBUTE1 AS "EVENT_STATUS"
     , CI_TYPES.NAME AS "ORIGINAL_SR_TYPE"
     , CI_STATUS_TL.NAME AS "ORIGINAL_SR_STATUS"
     , CI_TYPES_B.ATTRIBUTE2 AS "LEGAL_TYPE"
FROM   CS_INCIDENTS_ALL_B CIB
     , CS_INCIDENT_TYPES_TL CI_TYPES
     , CS_INCIDENT_TYPES_B CI_TYPES_B
     , CS_INCIDENT_STATUSES_B CI_STATUS_B
     , CS_INCIDENT_STATUSES_TL CI_STATUS_TL
     , CS_INCIDENT_SEVERITIES_TL CI_SEV
     , PELLA.PEL_PSI_RN_PARTY_ID_MAP PMAP
     , CS_HZ_SR_CONTACT_POINTS SR_CONT
     , FND_USER FU1
     , FND_USER FU2
WHERE  1 = 1
AND    CIB.INCIDENT_TYPE_ID = CI_TYPES.INCIDENT_TYPE_ID
AND    CIB.INCIDENT_STATUS_ID = CI_STATUS_B.INCIDENT_STATUS_ID
AND    CIB.INCIDENT_STATUS_ID = CI_STATUS_TL.INCIDENT_STATUS_ID
AND    FU1.USER_ID = CIB.CREATED_BY
AND    FU2.USER_ID = CIB.LAST_UPDATED_BY
AND    SR_CONT.INCIDENT_ID(+) = CIB.INCIDENT_ID
AND    SR_CONT.PRIMARY_FLAG(+) = 'Y'
AND    PMAP.CONTACT_PARTY_ID = NVL (SR_CONT.PARTY_ID, CIB.CUSTOMER_ID)
AND    PMAP.PROCESS_TYPE = 'CONTACT'
AND    CIB.INCIDENT_TYPE_ID = CI_TYPES_B.INCIDENT_TYPE_ID
AND    CIB.INCIDENT_SEVERITY_ID = CI_SEV.INCIDENT_SEVERITY_ID
AND    EXISTS (
          SELECT 1
          FROM   HZ_PARTIES HP, HZ_CUST_ACCOUNTS HCA
          WHERE  HP.PARTY_ID = CIB.CUSTOMER_ID
          AND    HP.STATUS = 'A'
          AND    HP.PARTY_ID = HCA.PARTY_ID
          AND    HCA.STATUS = 'A'
          AND    ROWNUM < 2)
AND    CI_TYPES.NAME IN
          ('Expedite', 'Replacement/Credit Request', 'Customer Complaint', 'Letter', 'Executive Letter'
         , 'Other', 'Order Cancellation', 'Product Problem', 'RGA', 'Personal Injury', 'Thermastar'
         , 'Customer Service Request', 'Service Provider Request', 'Replacement Order', 'Credit Request'
         , 'Product Information', 'Request for Service', 'RP Order', 'QUALITY ALERT', 'ILS-Request'
         , 'RGA-Quality', 'ILS-Email Request', 'ILS-Letter Request', 'ILS-President Letter'
         , 'Re-Order Request - Vinyl', 'Re-Order Request - Wood', 'NA-Escalated SR', 'Credit Request Promo'
         , 'Check Request', 'Request for Parts', 'Lowes Corp', 'PDSN Document Retention', 'Viking'
         , 'Legal Settlement(Saltzman)', 'Legal Settlement(Glube)')
AND    (   (:B1 = 'ALL')
        OR ((:B1 = 'ERROR') AND (EXISTS (SELECT 1
                                         FROM   PELLA.PEL_PSI_RN_SR_LOAD_SYNC
                                         WHERE  INCIDENT_ID = CIB.INCIDENT_ID AND RN_STATUS_FLAG = 'E')))
        OR ((:B1 = 'DELTA') AND (NOT EXISTS (SELECT 1
                                             FROM   PELLA.PEL_PSI_RN_SR_LOAD_SYNC
                                             WHERE  INCIDENT_ID = CIB.INCIDENT_ID AND RN_STATUS_FLAG = 'S')))
       );
SELECT * FROM table(DBMS_XPLAN.DISPLAY);