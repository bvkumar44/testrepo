select tablespace_name nam,
       sum(bytes)/1024/1024/1024 gb
  from dba_free_space
where  tablespace_name like 'PERFSTAT'
group by tablespace_name
/
