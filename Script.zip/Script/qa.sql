conn apps/apps6dev@qa
SET SQLPROMPT QA>