PROMPT "Enter the Month Start Date [DD-MON-YY] "
ACCEPT stdate
PROMPT "Enter the Month End Date   [DD-MON-YY] "
ACCEPT eddate
PROMPT "Enter the apps password "
ACCEPT APPS_PASSWD
SET PAGES 5000 TERM OFF FEEDBACK OFF MARKUP HTML ON
SET VERIFY OFF
SPOOL ebs_esmr_TCLO1I.html
SELECT '<STYLE>table {font-family: verdana;font-size:10px;text-align:auto;width:auto;border-width: 2px;border-collapse: collapse;}table th {border-width: 1px;;padding: 8px;border-style: solid;}table td {border-width: 1px;padding: 8px;border-style: solid;}</STYLE>'
FROM   DUAL;
SELECT '<P ALIGN="CENTER"><B>ESMR REPORT FOR THE PERIOD &&STDATE TO &&EDDATE</B></P>'
FROM   DUAL;
COL CPU FOR 99,999,999
COL WAIT FOR 99,999,999
COL IO FOR 99,999,999
COL TOTAL FOR 99,999,999
SELECT TOPSQL.SQL_ID ,
  TOPSQL.MODULE ,
  TOPSQL.CPU_TIME ,
  TOPSQL.IO_TIME ,
  TOPSQL.ELAPSED_TIME ,
  TOPSQL.EXEC_COUNT ,
  TOPSQL.CPU_TIME_PER_EXEC ,
  TEXT.SQL_TEXT
FROM
  (SELECT STAT.SQL_ID ,
    STAT.MODULE ,
    ROUND (SUM (STAT.CPU_TIME_DELTA     / 1000000), 0) CPU_TIME ,
    ROUND (SUM (STAT.IOWAIT_DELTA       / 1000000), 0) IO_TIME ,
    ROUND (SUM (STAT.ELAPSED_TIME_DELTA / 1000000), 0) ELAPSED_TIME ,
    ROUND (SUM (STAT.EXECUTIONS_DELTA),0) EXEC_COUNT ,
    ROUND ((SUM (STAT.CPU_TIME_DELTA)                       /SUM(DECODE(STAT.EXECUTIONS_DELTA,0,1,STAT.EXECUTIONS_DELTA)))/1000000, 0) CPU_TIME_PER_EXEC ,
    RANK () OVER (ORDER BY ROUND ( SUM (STAT.CPU_TIME_DELTA / 1000000), 0) DESC) AS TOPORDER
  FROM DBA_HIST_SQLSTAT STAT,
    DBA_HIST_SNAPSHOT SNAP,
    DBA_HIST_SQLTEXT TEXT
  WHERE STAT.SNAP_ID = SNAP.SNAP_ID
  AND STAT.SQL_ID    = TEXT.SQL_ID
  AND STAT.INSTANCE_NUMBER = SNAP.INSTANCE_NUMBER AND STAT.MODULE NOT LIKE 'DBMS_SCHEDULER'
  AND SNAP.INSTANCE_NUMBER = 1
  AND TEXT.COMMAND_TYPE IN (2,3,6,7)
  AND TRUNC(SNAP.BEGIN_INTERVAL_TIME) BETWEEN '&&STDATE' AND '&&EDDATE' /*AND STAT.SQL_ID NOT IN('c92uxxwhs2sbz','5xcqgzcxb958t','29jpyrwdu3ztp','gmhkpn4q0tfsb','gasf6wsrkfgdn','587a3abysrfbj','3kwcksp8zf2j9','93p43ka2mqa46','4dbfz7njtmmt0','0kx956yqhq1pm','6npsfdvj35bsd','544jdt08bhpx7','6npsfdvj35bsd','bz9tptwwqy5sm','8rz1u9cpgy5c2','bjw4bd5pm2vs8','12az2y858ujt5','4vv8avga9nd5a','4wzwx9y2vj681','25mk2k3s7wrx8','1umxtr5dyh9x3','48nqtd9ndbrh6','0hqgg16qaf7jr','618jt13vgvb8y','1nc3tt9415mk9','gppghmz476gcr','51vcx5ywxvwhm','c2un8zc10766b','b3rurj1m7y77y','6npsfdvj35bsd','bjw4bd5pm2vs8','3ktgw7pm4np0z','dv9a4kc89a31') */ GROUP BY STAT.SQL_ID,STAT.MODULE
  ) TOPSQL ,DBA_HIST_SQLTEXT TEXT
WHERE TEXT.SQL_ID = TOPSQL.SQL_ID /* AND STAT.MODULE NOT LIKE 'DBMS_SCHEDULER'  AND TOPSQL.SQL_ID NOT IN ('c92uxxwhs2sbz','5xcqgzcxb958t','29jpyrwdu3ztp','gmhkpn4q0tfsb','gasf6wsrkfgdn','587a3abysrfbj','3kwcksp8zf2j9','93p43ka2mqa46','4dbfz7njtmmt0','0kx956yqhq1pm','6npsfdvj35bsd','544jdt08bhpx7','6npsfdvj35bsd','bz9tptwwqy5sm','8rz1u9cpgy5c2','bjw4bd5pm2vs8','12az2y858ujt5','4vv8avga9nd5a','4wzwx9y2vj681','25mk2k3s7wrx8','1umxtr5dyh9x3','48nqtd9ndbrh6','0hqgg16qaf7jr','618jt13vgvb8y','1nc3tt9415mk9','gppghmz476gcr','51vcx5ywxvwhm','c2un8zc10766b','b3rurj1m7y77y','6npsfdvj35bsd','bjw4bd5pm2vs8','3ktgw7pm4np0z','dv9a4kc89a31') */
AND TOPORDER      < 11
order by topsql.cpu_time_per_exec                  ;
/

SELECT REQUESTOR "USER_NAME"
     , USER_CONCURRENT_PROGRAM_NAME
     , CNT "Count"
FROM   (SELECT   REQUESTOR
               , USER_CONCURRENT_PROGRAM_NAME
               , COUNT (1) CNT
        FROM     APPS.FND_CONC_REQ_SUMMARY_V
        WHERE    TRUNC (ACTUAL_START_DATE) BETWEEN '&&stdate' AND '&&eddate'
        AND      PHASE_CODE IN ('C')
        AND      STATUS_CODE IN ('C', 'G')
        GROUP BY REQUESTOR, USER_CONCURRENT_PROGRAM_NAME
        ORDER BY COUNT (1) DESC) EXECUTIONS_COUNT
WHERE  ROWNUM < 26
/
SELECT REQUESTOR "USER_NAME"
     , USER_CONCURRENT_PROGRAM_NAME
     , TRUNC (RUN_TIME) "Minutes"
FROM   (SELECT   REQUESTOR
               , USER_CONCURRENT_PROGRAM_NAME
               , MAX (ACTUAL_COMPLETION_DATE - ACTUAL_START_DATE) * 24 * 60 RUN_TIME
        FROM     APPS.FND_CONC_REQ_SUMMARY_V
        WHERE    TRUNC (ACTUAL_START_DATE) BETWEEN '&&stdate' AND '&&eddate'
        AND      PHASE_CODE IN ('C')
        AND      STATUS_CODE IN ('C', 'G')
        GROUP BY REQUESTOR, USER_CONCURRENT_PROGRAM_NAME
        ORDER BY MAX (ACTUAL_COMPLETION_DATE - ACTUAL_START_DATE) * 24 * 60 DESC) EXECUTIONS_TIME
WHERE  ROWNUM < 26
/
COL "Login Date" for a15
SELECT   /*+ parallel(5) */
         TRUNC (END_TIME) "Login Date"
       , COUNT (*) "Count"
FROM     APPLSYS.FND_LOGINS
WHERE    TRUNC (END_TIME) BETWEEN '&&stdate' AND '&&eddate'
GROUP BY TRUNC (END_TIME)
ORDER BY TRUNC (END_TIME)
/
COL "Wait Class" for a20
SELECT WAITC.WC "Wait Class"
     , ROUND (WAITC.TW * 100 / TTW.TTIME) "%"
FROM   (SELECT   WC.WAIT_CLASS WC
               , SUM (WC.TIME_WAITED / 100) TW
        FROM     DBA_HIST_SERVICE_WAIT_CLASS WC, DBA_HIST_SNAPSHOT SNAP
        WHERE    WC.SNAP_ID = SNAP.SNAP_ID
        AND      TRUNC (SNAP.BEGIN_INTERVAL_TIME) BETWEEN '&&stdate' AND '&&eddate'
        AND      WC.WAIT_CLASS != 'Idle'
        GROUP BY WC.WAIT_CLASS
        ORDER BY 2 DESC) WAITC
     , (SELECT SUM (WC1.TIME_WAITED / 100) TTIME
        FROM   DBA_HIST_SERVICE_WAIT_CLASS WC1, DBA_HIST_SNAPSHOT SNAP1
        WHERE  WC1.SNAP_ID = SNAP1.SNAP_ID
        AND    TRUNC (SNAP1.BEGIN_INTERVAL_TIME) BETWEEN '&&stdate' AND '&&eddate'
        AND    WC1.WAIT_CLASS != 'Idle') TTW
/
COL % for 99.99
COL "Size(GB)" for 99,999.99
SELECT TS.TABLESPACE_NAME "Tablespace Name"
     , ROUND (TS.SIZE_IN_GB, 2) "Size(GB)"
     , ROUND (TS.SIZE_IN_GB * 100 / TOTTS.SIZE_IN_GB, 2) "%"
FROM   (SELECT   TABLESPACE_NAME
               , SUM (BYTES / 1024 / 1024 / 1024) SIZE_IN_GB
        FROM     DBA_DATA_FILES
        WHERE    TABLESPACE_NAME NOT IN (SELECT TABLESPACE_NAME
                                         FROM   DBA_TABLESPACES
                                         WHERE  CONTENTS IN ('UNDO', 'TEMPORARY'))
        GROUP BY TABLESPACE_NAME
        ORDER BY SUM (BYTES / 1024 / 1024 / 1024) DESC) TS
     , (SELECT SUM (BYTES / 1024 / 1024 / 1024) SIZE_IN_GB
        FROM   DBA_DATA_FILES
        WHERE  TABLESPACE_NAME NOT IN (SELECT TABLESPACE_NAME
                                       FROM   DBA_TABLESPACES
                                       WHERE  CONTENTS IN ('UNDO', 'TEMPORARY'))) TOTTS
WHERE  ROWNUM < 11
/
--Large Segments
COL "Size(GB)" for 99,999.99
SELECT OWNER "Owner"
     , SEGMENT_NAME "Segment Name"
     , SEGMENT_TYPE "Segment Type"
     , ROUND (SIZE_IN_GB, 2) "Size(GB)"
FROM   (SELECT   OWNER
               , SEGMENT_NAME
               , SEGMENT_TYPE
               , SUM (BYTES / 1024 / 1024 / 1024) SIZE_IN_GB
        FROM     DBA_SEGMENTS
        GROUP BY OWNER, SEGMENT_NAME, SEGMENT_TYPE
        ORDER BY SUM (BYTES / 1024 / 1024 / 1024) DESC) LARGE_SEGMENT
WHERE  ROWNUM < 11
/
CONN APPS/&&APPS_PASSWD@TCLO1I
SELECT 'Purchase Orders '
     , 'Average : ' || LPAD (ROUND (AVG (cnt), 0), 6) || ' Peak : ' || LPAD (MAX (cnt), 6)
FROM   (SELECT   TRUNC (creation_date) po_date
               , COUNT (1) cnt
        FROM     po.po_headers_all
        WHERE    TRUNC (creation_date) BETWEEN '&&stdate' AND '&&eddate'
        GROUP BY TRUNC (creation_date))
/
--Journals
SELECT 'Journals '
     , 'Average : ' || LPAD (ROUND (AVG (cnt), 0), 6) || ' Peak : ' || LPAD (MAX (cnt), 6)
FROM   (SELECT   TRUNC (accounting_date) ACC_DATE
               , COUNT (*) CNT
        FROM     AP.AP_AE_HEADERS_ALL
        WHERE    TRUNC (accounting_date) BETWEEN '&&stdate' AND '&&eddate'
        GROUP BY TRUNC (accounting_date))
/
--Sales Orders
SELECT 'Sales Orders '
     , ' Average : ' || LPAD (ROUND (AVG (cnt), 0), 6) || ' Peak : ' || LPAD (MAX (cnt), 6)
FROM   (SELECT   TRUNC (ordered_date) ord_date
               , COUNT (1) cnt
        FROM     oe_order_headers_all
        WHERE    TRUNC (ordered_date) BETWEEN '&&stdate' AND '&&eddate'
        GROUP BY TRUNC (ordered_date))
/
--Order Lines
SELECT 'Order Lines '
     , ' Average : ' || LPAD (ROUND (AVG (cnt), 0), 6) || ' Peak : ' || LPAD (MAX (cnt), 6)
FROM   (SELECT   TRUNC (ordered_date) ord_date
               , COUNT (1) cnt
        FROM     oe_order_headers_all ooh, oe_order_lines_all ool
        WHERE    TRUNC (ooh.ordered_date) BETWEEN '&&stdate' AND '&&eddate' AND ooh.header_id = ool.header_id
        GROUP BY TRUNC (ooh.ordered_date))
/
--Inventory transactions
SELECT 'Inventory transactions '
     , ' Average : ' || LPAD (ROUND (AVG (cnt), 0), 6) || ' Peak : ' || LPAD (MAX (cnt), 6)
FROM   (SELECT   TRUNC (transaction_date) TRX_DATE
               , COUNT (1) CNT
        FROM     inv.MTL_MATERIAL_TRANSACTIONS
        WHERE    TRUNC (transaction_date) BETWEEN '&&stdate' AND '&&eddate'
        GROUP BY TRUNC (transaction_date))
/
--Shipments
SELECT 'Shipments '
     , ' Average : ' || LPAD (ROUND (AVG (cnt), 0), 6) || ' Peak : ' || LPAD (MAX (cnt), 6)
FROM   (SELECT   TRUNC (date_scheduled) date_sch
               , COUNT (1) cnt
        FROM     apps.WSH_DELIVERY_DETAILS
        WHERE    TRUNC (date_scheduled) BETWEEN '&&stdate' AND '&&eddate'
        GROUP BY TRUNC (date_scheduled))
/
SELECT 'BR'
FROM   DUAL;
SELECT 'Orders Booked '
     , ' Average : ' || LPAD (ROUND (AVG (cnt), 0), 6) || ' Peak : ' || LPAD (MAX (cnt), 6)
FROM   (SELECT   TRUNC (booked_date) book_date
               , COUNT (1) cnt
        FROM     apps.oe_order_headers_all
        WHERE    TRUNC (booked_date) BETWEEN '&&stdate' AND '&&eddate'
        GROUP BY TRUNC (booked_date))
/
SPOOL OFF