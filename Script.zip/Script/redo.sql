select s.sid, s.value
from v$sesstat s, v$statname n
where s.statistic#=n.statistic#
and n.name = 'redo size'
order by 2 desc