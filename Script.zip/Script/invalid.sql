col owner for a20
col object_name for a30
col object_type for a20
col status for a10
select owner,object_name,object_type,status,object_id from dba_objects where object_name like upper('%&obj%')
/