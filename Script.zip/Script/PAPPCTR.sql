conn system/sysPAPPCTR@pappctr
SET SQLPROMPT PAPPCTR>