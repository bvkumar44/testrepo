select count(*) from dba_objects where status!='VALID'
/