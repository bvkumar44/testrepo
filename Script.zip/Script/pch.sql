select a.sid,serial#,action,module,program,last_call_et,status,event
 from v$session a
where event not like '%SQL%'
/

 select sid,sofar,totalwork,MESSAGE from v$session_longops where sofar!=TOTALWORK
/