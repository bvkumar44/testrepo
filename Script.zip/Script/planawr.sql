undefine sql_id
set lines 200 pages 5000
select * from TABLE(dbms_xplan.display_awr('&sql_id'));