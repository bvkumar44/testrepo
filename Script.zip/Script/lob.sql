select table_name||'.'||column_name from dba_lobs where segment_name='&lob_seg_name'
/
