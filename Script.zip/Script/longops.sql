col sid for 99999
col message for a100
set lines 130
set pages 500
col tm for 999999999
col inst_id for 99 head 'in'
select inst_id,sid,message,TIME_REMAINING tm from gv$session_longops where sofar!=totalwork;
