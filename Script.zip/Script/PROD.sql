-- CONN APPS/tkar0nt014@PROD
conn ronly/only4users@prod
set sqlprompt PROD>