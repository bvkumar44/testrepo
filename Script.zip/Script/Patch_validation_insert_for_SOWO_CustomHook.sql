INSERT INTO xcbp_oobject_patch_validation (
                                                   owner,
                                                   object_name,
                                                   object_type,
                                                   cust_version,
                                                   current_version,
                                                   status,
                                                   last_verification_date,
                                                   Description
           )
  VALUES   (
               'APPS',
               'MSC_RELEASE_HOOK',
               'PACKAGE',
               '/* $Header: MSCRLHKS.pls 120.2 2007/05/18 15:52:30 vpalla ship $ */',
               '/* $Header: MSCRLHKS.pls 120.2 2007/05/18 15:52:30 vpalla ship $ */',
               null,
               SYSDATE,
               'Clopay Customization for SOWO Solution'
           );



INSERT INTO xcbp_oobject_patch_validation (
                                                   owner,
                                                   object_name,
                                                   object_type,
                                                   cust_version,
                                                   current_version,
                                                   status,
                                                   last_verification_date,
                                                   Description
           )
  VALUES   (
               'APPS',
               'MSC_RELEASE_HOOK',
               'PACKAGE BODY',
               '/* $Header: MSCRLHKB.pls 120.2 2007/05/18 15:53:31 vpalla ship $ */',
               '/* $Header: MSCRLHKB.pls 120.2 2007/05/18 15:53:31 vpalla ship $ */',
               null,
               SYSDATE,
               'Clopay Customization for SOWO Solution'
           );
           
commit;

INSERT INTO xcbp_oobject_patch_validation (
                                                   owner,
                                                   object_name,
                                                   object_type,
                                                   cust_version,
                                                   current_version,
                                                   status,
                                                   last_verification_date,
                                                   Description
           )
  VALUES   (
               'APPS',
               'MSC_CL_CLEANSE',
               'PACKAGE',
               '/* $Header: MSCCLCAS.pls 120.0 2005/05/27 07:26:58 appldev noship $ */',
               '/* $Header: MSCCLCAS.pls 120.0 2005/05/27 07:26:58 appldev noship $ */',
               null,
               SYSDATE,
               'Clopay Customization for SOWO Solution'
           );



INSERT INTO xcbp_oobject_patch_validation (
                                                   owner,
                                                   object_name,
                                                   object_type,
                                                   cust_version,
                                                   current_version,
                                                   status,
                                                   last_verification_date,
                                                   Description
           )
  VALUES   (
               'APPS',
               'MSC_CL_CLEANSE',
               'PACKAGE BODY',
               '/* $Header: MSCCLCAB.pls 120.0 2005/05/25 20:00:48 appldev noship $ */',
               '/* $Header: MSCCLCAB.pls 120.0 2005/05/25 20:00:48 appldev noship $ */',
               null,
               SYSDATE,
               'Clopay Customization for SOWO Solution'
           );
           
commit;