col cp for a2
col db for a2
col wb for a2
select node_name,support_cp cp,support_web wb,support_forms fm,support_db db,support_admin adm from apps.fnd_nodes order by 4,2,3;