REM checking Timing details, Client PID of associated oracle SID
REM ===================================
set head off
--set verify off
--set echo off
--set pages 1500
--set linesize 100
--set lines 120
prompt
prompt Session Details
prompt ===============
select /*+ CHOOSE*/
'Session  Id.............................................: '||s.sid,
'Serial Num..............................................: '||s.serial#,
'User Name ..............................................: '||s.username,
'Session Status .........................................: '||s.status,
'Client Process Id on Client Machine ....................: '||'*'||s.process||'*'  Client,
'Server Process ID ......................................: '||p.spid Server,
'Sql_Address ............................................: '||s.sql_address,
'Sql_hash_value .........................................: '||s.sql_hash_value,
'Schema Name ..... ......................................: '||s.SCHEMANAME,
'Program  ...............................................: '||s.program,
'Module .................................................: '|| s.module,
'Wait Event  ........................................ ...: '||w.EVENT,
'Action .................................................: '||s.action,
'Terminal ...............................................: '||s.terminal,
'Client Machine .........................................: '||s.machine,
'CLIENT_IDENTIFIER ......................................: '||s.CLIENT_IDENTIFIER,
'LAST_CALL_ET ...........................................: '||s.last_call_et,
'S.LAST_CALL_ET/3600 ....................................: '||s.last_call_et/3600
from gv$session s, gv$process p, gv$session_wait w
where p.addr=s.paddr and
s.sid=nvl('&sid',s.sid) and
p.spid=nvl('&spid',p.spid) and
nvl(s.process,-1) = nvl('&ClientPid',nvl(s.process,-1)) and
s.sid=w.sid
/
prompt SQL Text Details
prompt =================
select piece,sql_text from gv$sqltext where HASH_VALUE = &hash and ADDRESS ='&addr' order by piece
/
set head on
