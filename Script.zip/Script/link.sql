set pages 250
set lines 250
col db_link for a40
col host for a50
col owner for a20
col username for a20

select name from v$database;

select * from dba_db_links order by created;