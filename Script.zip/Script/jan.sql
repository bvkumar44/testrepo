DECLARE
   l_msg_data                VARCHAR2 (100);
   l_msg_count               NUMBER;
   l_return_status           VARCHAR2 (1);
   l_locator_id              NUMBER;
   l_locator_exists          VARCHAR2 (1);
   l_user_id                 NUMBER          := 2596;
   l_resp_id                 NUMBER          := 52240; 
   l_resp_appl_id            NUMBER          := 401;

   /*Fetch data into cursor for deletion of Locator*/ 
   CURSOR c_loc 
   IS
         SELECT mil.inventory_location_id locator_id
         ,      mil.segment1
         ,      mil.subinventory_code
         ,      mil.organization_id
         ,      par.organization_code
         FROM   inv.mtl_item_locations mil
         ,      inv.mtl_parameters par
         WHERE  mil.organization_id = 198
         AND    mil.subinventory_code = 'V1'
         AND    mil.segment1 LIKE 'V3%'
         AND    par.organization_id = mil.organization_id;
        
BEGIN 

   apps.fnd_global.apps_initialize (l_user_id, l_resp_id, l_resp_appl_id);

   FOR  r_loc IN c_loc LOOP

      apps.fnd_msg_pub.initialize;
      DBMS_OUTPUT.put_line ('Trying to Delete '||r_loc.segment1|| '-'||r_loc.locator_id);
      
      apps.inv_loc_wms_pub.delete_locator 
                          (x_return_status              => l_return_status,
                           x_msg_count                  => l_msg_count,
                           x_msg_data                   => l_msg_data,
                           p_inventory_location_id      => r_loc.locator_id,
                           p_organization_id            => r_loc.organization_id,
                           p_organization_code          => r_loc.organization_code,
                           p_concatenated_segments      => r_loc.segment1,
                           p_validation_req_flag        => 'N'
                          );
      COMMIT;
      
      DBMS_OUTPUT.put_line ('Return Status ' || l_return_status);
      
            IF l_return_status IN ('E', 'U')
            THEN
               DBMS_OUTPUT.put_line ('# of Errors ' || l_msg_count);
               IF l_msg_count = 1 
               THEN
                  DBMS_OUTPUT.put_line ('Error ' || l_msg_data);
               ELSE
                  FOR i IN 1 .. l_msg_count 
                  LOOP
                     DBMS_OUTPUT.put_line ('Error ' || apps.fnd_msg_pub.get (i, 'F'));
                  END LOOP;
               END IF;
            ELSE
               DBMS_OUTPUT.put_line ('Locator Id is ' || r_loc.locator_id);
            END IF;
            
   END LOOP;
         

END;
/