CONN SYSTEM/b9u7!sch@psoraprd
set sqlprompt PSORAPRD>