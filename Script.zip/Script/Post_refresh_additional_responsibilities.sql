spool post_refresh_additional_resp.log
exec fnd_user_pkg.addresp (username=>'JBATZLAFF',resp_app=>'AR',resp_key=>'BPC_AR_CUST_MAINT',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'JBATZLAFF',resp_app=>'MFG',resp_key=>'CERP_BPC_PLAN_SUPER_USER',security_group=> 'STANDARD',description=>'Clopay BPC Planning Super User',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'JBATZLAFF',resp_app=>'XBOL',resp_key=>'APPLICATIONS_ADMINISTRATION',security_group=> 'STANDARD',description=>'Business Online Application Administrator',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'GSIMON',resp_app=>'ONT',resp_key=>'BPC_ORDER_MGMT_SUPER_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'GSIMON',resp_app=>'BOM',resp_key=>'BPC_BOM_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'GSIMON',resp_app=>'AR',resp_key=>'BPC_AR_CUST_MAINT',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'GSIMON',resp_app=>'INV',resp_key=>'BPC-INVENTORY_GUI',security_group=> 'STANDARD',description=>'BPC Operating Unit Inventory GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'GSIMON',resp_app=>'ONT',resp_key=>'BPC_RUS_OM_USR',security_group=> 'STANDARD',description=>'Russia OM User',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'GSIMON',resp_app=>'WIP',resp_key=>'BPC-WORK_IN_PROCESS_GUI',security_group=> 'STANDARD',description=>'BPC-Work in Process GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'GSIMON',resp_app=>'XXBPCCONV',resp_key=>'BPC_REP_REQ',security_group=> 'STANDARD',description=>'BPC-Reporting and Requests',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'BPETITJEAN',resp_app=>'ONT',resp_key=>'BPC_ORDER_MGMT_SUPER_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'BPETITJEAN',resp_app=>'BOM',resp_key=>'BPC_BOM_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'BPETITJEAN',resp_app=>'AR',resp_key=>'BPC_AR_CUST_MAINT',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'BPETITJEAN',resp_app=>'INV',resp_key=>'BPC-INVENTORY_GUI',security_group=> 'STANDARD',description=>'BPC Operating Unit Inventory GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'BPETITJEAN',resp_app=>'ONT',resp_key=>'BPC_RUS_OM_USR',security_group=> 'STANDARD',description=>'Russia OM User',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'BPETITJEAN',resp_app=>'WIP',resp_key=>'BPC-WORK_IN_PROCESS_GUI',security_group=> 'STANDARD',description=>'BPC-Work in Process GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'BPETITJEAN',resp_app=>'XXBPCCONV',resp_key=>'BPC_REP_REQ',security_group=> 'STANDARD',description=>'BPC-Reporting and Requests',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'BBROHARD',resp_app=>'ONT',resp_key=>'BPC_ORDER_MGMT_SUPER_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'BBROHARD',resp_app=>'BOM',resp_key=>'BPC_BOM_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'BBROHARD',resp_app=>'AR',resp_key=>'BPC_AR_CUST_MAINT',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'BBROHARD',resp_app=>'INV',resp_key=>'BPC-INVENTORY_GUI',security_group=> 'STANDARD',description=>'BPC Operating Unit Inventory GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'BBROHARD',resp_app=>'ONT',resp_key=>'BPC_RUS_OM_USR',security_group=> 'STANDARD',description=>'Russia OM User',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'BBROHARD',resp_app=>'WIP',resp_key=>'BPC-WORK_IN_PROCESS_GUI',security_group=> 'STANDARD',description=>'BPC-Work in Process GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'BBROHARD',resp_app=>'XXBPCCONV',resp_key=>'BPC_REP_REQ',security_group=> 'STANDARD',description=>'BPC-Reporting and Requests',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'PWEAD',resp_app=>'ONT',resp_key=>'BPC_ORDER_MGMT_SUPER_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'PWEAD',resp_app=>'BOM',resp_key=>'BPC_BOM_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'PWEAD',resp_app=>'AR',resp_key=>'BPC_AR_CUST_MAINT',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'PWEAD',resp_app=>'INV',resp_key=>'BPC-INVENTORY_GUI',security_group=> 'STANDARD',description=>'BPC Operating Unit Inventory GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'PWEAD',resp_app=>'ONT',resp_key=>'BPC_RUS_OM_USR',security_group=> 'STANDARD',description=>'Russia OM User',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'PWEAD',resp_app=>'WIP',resp_key=>'BPC-WORK_IN_PROCESS_GUI',security_group=> 'STANDARD',description=>'BPC-Work in Process GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'PWEAD',resp_app=>'XXBPCCONV',resp_key=>'BPC_REP_REQ',security_group=> 'STANDARD',description=>'BPC-Reporting and Requests',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'MSAXE',resp_app=>'ONT',resp_key=>'BPC_ORDER_MGMT_SUPER_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'MSAXE',resp_app=>'BOM',resp_key=>'BPC_BOM_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'MSAXE',resp_app=>'AR',resp_key=>'BPC_AR_CUST_MAINT',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'MSAXE',resp_app=>'INV',resp_key=>'BPC-INVENTORY_GUI',security_group=> 'STANDARD',description=>'BPC Operating Unit Inventory GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'MSAXE',resp_app=>'ONT',resp_key=>'BPC_RUS_OM_USR',security_group=> 'STANDARD',description=>'Russia OM User',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'MSAXE',resp_app=>'WIP',resp_key=>'BPC-WORK_IN_PROCESS_GUI',security_group=> 'STANDARD',description=>'BPC-Work in Process GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'MSAXE',resp_app=>'XXBPCCONV',resp_key=>'BPC_REP_REQ',security_group=> 'STANDARD',description=>'BPC-Reporting and Requests',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'KMESCHER',resp_app=>'ONT',resp_key=>'BPC_ORDER_MGMT_SUPER_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'KMESCHER',resp_app=>'BOM',resp_key=>'BPC_BOM_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'KMESCHER',resp_app=>'AR',resp_key=>'BPC_AR_CUST_MAINT',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'KMESCHER',resp_app=>'INV',resp_key=>'BPC-INVENTORY_GUI',security_group=> 'STANDARD',description=>'BPC Operating Unit Inventory GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'KMESCHER',resp_app=>'ONT',resp_key=>'BPC_RUS_OM_USR',security_group=> 'STANDARD',description=>'Russia OM User',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'KMESCHER',resp_app=>'WIP',resp_key=>'BPC-WORK_IN_PROCESS_GUI',security_group=> 'STANDARD',description=>'BPC-Work in Process GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'KMESCHER',resp_app=>'XXBPCCONV',resp_key=>'BPC_REP_REQ',security_group=> 'STANDARD',description=>'BPC-Reporting and Requests',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'CSYNAN',resp_app=>'ONT',resp_key=>'BPC_ORDER_MGMT_SUPER_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'CSYNAN',resp_app=>'BOM',resp_key=>'BPC_BOM_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'CSYNAN',resp_app=>'AR',resp_key=>'BPC_AR_CUST_MAINT',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'CSYNAN',resp_app=>'INV',resp_key=>'BPC-INVENTORY_GUI',security_group=> 'STANDARD',description=>'BPC Operating Unit Inventory GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'CSYNAN',resp_app=>'ONT',resp_key=>'BPC_RUS_OM_USR',security_group=> 'STANDARD',description=>'Russia OM User',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'CSYNAN',resp_app=>'WIP',resp_key=>'BPC-WORK_IN_PROCESS_GUI',security_group=> 'STANDARD',description=>'BPC-Work in Process GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'CSYNAN',resp_app=>'XXBPCCONV',resp_key=>'BPC_REP_REQ',security_group=> 'STANDARD',description=>'BPC-Reporting and Requests',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'JEDEAM',resp_app=>'ONT',resp_key=>'BPC_ORDER_MGMT_SUPER_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'JEDEAM',resp_app=>'BOM',resp_key=>'BPC_BOM_USER',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'JEDEAM',resp_app=>'AR',resp_key=>'BPC_AR_CUST_MAINT',security_group=> 'STANDARD',description=>'',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'JEDEAM',resp_app=>'INV',resp_key=>'BPC-INVENTORY_GUI',security_group=> 'STANDARD',description=>'BPC Operating Unit Inventory GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'JEDEAM',resp_app=>'ONT',resp_key=>'BPC_RUS_OM_USR',security_group=> 'STANDARD',description=>'Russia OM User',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'JEDEAM',resp_app=>'WIP',resp_key=>'BPC-WORK_IN_PROCESS_GUI',security_group=> 'STANDARD',description=>'BPC-Work in Process GUI',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'JEDEAM',resp_app=>'XXBPCCONV',resp_key=>'BPC_REP_REQ',security_group=> 'STANDARD',description=>'BPC-Reporting and Requests',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'LGOODMAN',resp_app=>'ONT',resp_key=>'BPC_RUS_OM_USR',security_group=> 'STANDARD',description=>'Russia OM User',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'JHOEHNE',resp_app=>'ONT',resp_key=>'BPC_RUS_OM_USR',security_group=> 'STANDARD',description=>'Russia OM User',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'TGERLACH',resp_app=>'XBOL',resp_key=>'APPLICATIONS_ADMINISTRATION',security_group=> 'STANDARD',description=>'Business Online Application Administrator',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'MBURNS',resp_app=>'ONT',resp_key=>'BPC_ORDER_ENTRY',security_group=> 'STANDARD',description=>'BPC-ORDER ENTRY, Main Order Entry Resp.',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'MBURNS',resp_app=>'MFG',resp_key=>'CERP_BPC_PROD_ENG',security_group=> 'STANDARD',description=>'Clopay BPC Product Engineering',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'TYOUTSEY',resp_app=>'ONT',resp_key=>'BPC_ORDER_ENTRY',security_group=> 'STANDARD',description=>'BPC-ORDER ENTRY, Main Order Entry Resp.',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'TYOUTSEY',resp_app=>'MFG',resp_key=>'CERP_BPC_PROD_ENG',security_group=> 'STANDARD',description=>'Clopay BPC Product Engineering',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'DSHIVES',resp_app=>'ONT',resp_key=>'BPC_ORDER_ENTRY',security_group=> 'STANDARD',description=>'BPC-ORDER ENTRY, Main Order Entry Resp.',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'DSHIVES',resp_app=>'MFG',resp_key=>'CERP_BPC_PROD_ENG',security_group=> 'STANDARD',description=>'Clopay BPC Product Engineering',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'RKRIEGER',resp_app=>'ONT',resp_key=>'BPC_ORDER_ENTRY',security_group=> 'STANDARD',description=>'BPC-ORDER ENTRY, Main Order Entry Resp.',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'RKRIEGER',resp_app=>'MFG',resp_key=>'CERP_BPC_PROD_ENG',security_group=> 'STANDARD',description=>'Clopay BPC Product Engineering',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'JKMCGEE',resp_app=>'ONT',resp_key=>'BPC_ORDER_ENTRY',security_group=> 'STANDARD',description=>'BPC-ORDER ENTRY, Main Order Entry Resp.',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'JKMCGEE',resp_app=>'MFG',resp_key=>'CERP_BPC_PROD_ENG',security_group=> 'STANDARD',description=>'Clopay BPC Product Engineering',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'JMJOHNSON',resp_app=>'ONT',resp_key=>'BPC_ORDER_ENTRY',security_group=> 'STANDARD',description=>'BPC-ORDER ENTRY, Main Order Entry Resp.',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'JMJOHNSON',resp_app=>'MFG',resp_key=>'CERP_BPC_PROD_ENG',security_group=> 'STANDARD',description=>'Clopay BPC Product Engineering',start_date=> sysdate-1,end_date=>null);

exec fnd_user_pkg.addresp (username=>'SHAMILTON',resp_app=>'ONT',resp_key=>'BPC_ORDER_ENTRY',security_group=> 'STANDARD',description=>'BPC-ORDER ENTRY, Main Order Entry Resp.',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'SHAMILTON',resp_app=>'MFG',resp_key=>'CERP_BPC_PROD_ENG',security_group=> 'STANDARD',description=>'Clopay BPC Product Engineering',start_date=> sysdate-1,end_date=>null);


exec fnd_user_pkg.addresp (username=>'SJAGADEESAN',resp_app=>'XBOL',resp_key=>'APPLICATIONS_ADMINISTRATION',security_group=> 'STANDARD',description=>'Business Online Application Administrator',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'SSIRIPURAM',resp_app=>'XBOL',resp_key=>'APPLICATIONS_ADMINISTRATION',security_group=> 'STANDARD',description=>'Business Online Application Administrator',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'MALLU',resp_app=>'XBOL',resp_key=>'APPLICATIONS_ADMINISTRATION',security_group=> 'STANDARD',description=>'Business Online Application Administrator',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'SSINGH',resp_app=>'XBOL',resp_key=>'APPLICATIONS_ADMINISTRATION',security_group=> 'STANDARD',description=>'Business Online Application Administrator',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'RYEMPATI',resp_app=>'XBOL',resp_key=>'APPLICATIONS_ADMINISTRATION',security_group=> 'STANDARD',description=>'Business Online Application Administrator',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'VBATTULA',resp_app=>'XBOL',resp_key=>'APPLICATIONS_ADMINISTRATION',security_group=> 'STANDARD',description=>'Business Online Application Administrator',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'ADEVIREDDY',resp_app=>'XBOL',resp_key=>'APPLICATIONS_ADMINISTRATION',security_group=> 'STANDARD',description=>'Business Online Application Administrator',start_date=> sysdate-1,end_date=>null);
exec fnd_user_pkg.addresp (username=>'SKOYYALAMUDI',resp_app=>'XBOL',resp_key=>'APPLICATIONS_ADMINISTRATION',security_group=> 'STANDARD',description=>'Business Online Application Administrator',start_date=> sysdate-1,end_date=>null);
spool off