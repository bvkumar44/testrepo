select 	request_id,p.os_process_id
from 	fnd_concurrent_processes p,
	fnd_concurrent_requests r
where 	r.controlling_manager=p.concurrent_process_id
and 	r.request_id=&fnd;
