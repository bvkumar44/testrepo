set linesize 80 
col sess for a15

SELECT DECODE(request,0,'Holder: ','Waiter: ')||trim(sid) sess,
         id1, id2, lmode, request, type
    FROM V$LOCK
   WHERE (id1, id2, type) IN
             (SELECT id1, id2, type FROM V$LOCK WHERE request>0)
   ORDER BY id1, request
/

set pagesize 500
set linesize 250
col sid for 9999 
col serial for 99999
col module for a20 trunc
col action for a20 trunc
col program for a20 trunc
col event for a30 trunc
col dt for a12 trunc
col request_id for 9999999999
col uname for a20
col dt for a24

select 	request_id,s.sid sid,s.serial# serial,to_char(logon_time,'DD-MON-YYYY HH24:MI:SS') dt,s.module module,s.action action,fu.user_name uname,sw.event
from	v$session_wait sw,v$session s,v$process p,fnd_concurrent_requests fnd,fnd_user fu
where 	sw.sid = s.sid
and	p.addr = s.paddr
and	p.spid = fnd.oracle_process_id
and	fnd.status_code = 'R'
and	fnd.phase_code = 'R'
and 	fnd.requested_by=fu.user_id
order by 4
/
