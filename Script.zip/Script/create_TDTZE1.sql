STARTUP NOMOUNT
CREATE CONTROLFILE REUSE SET DATABASE "TDTZE1" RESETLOGS  NOARCHIVELOG
    MAXLOGFILES 25
    MAXLOGMEMBERS 3
    MAXDATAFILES 100
    MAXINSTANCES 1
    MAXLOGHISTORY 13613
LOGFILE
  GROUP 1 '/oradata/test/TDTZE1/redo01.log'  SIZE 3M,
  GROUP 2 '/oradata/test/TDTZE1/redo02.log'  SIZE 3M,
  GROUP 3 '/oradata/test/TDTZE1/redo03.log'  SIZE 3M,
  GROUP 4 '/oradata/test/TDTZE1/redo04.log'  SIZE 3M
DATAFILE
  '/oradata/test/TDTZE1/system01.dbf',
  '/oradata/test/TDTZE1/undotbs01.dbf',
  '/oradata/test/TDTZE1/drsys01.dbf',
  '/oradata/test/TDTZE1/indx01.dbf',
  '/oradata/test/TDTZE1/roofmxdata.dbf',
  '/oradata/test/TDTZE1/roofmxdefault.dbf',
  '/oradata/test/TDTZE1/roofmxindex.dbf',
  '/oradata/test/TDTZE1/tools01.dbf',
  '/oradata/test/TDTZE1/users01.dbf',
  '/oradata/test/TDTZE1/xdb01.dbf',
  '/oradata/test/TDTZE1/ddxdata.dbf',
  '/oradata/test/TDTZE1/TVCINDEX.dbf',
  '/oradata/test/TDTZE1/TVCDATA.dbf'
CHARACTER SET AL32UTF8
;

ALTER TABLESPACE TEMP ADD TEMPFILE '/oradata/test/TDTZE1/temp01.dbf'
     SIZE 314572800  REUSE AUTOEXTEND ON NEXT 655360  MAXSIZE 32767M;


/data/oracle/admin/PDTZE1/arch/PDTZE1_344677.arc
/data/oracle/admin/PDTZE1/arch/PDTZE1_344679.arc


/data/oracle/admin/TDTZE1/arch/PDTZE1_344677.arc
/data/oracle/admin/TDTZE1/arch/PDTZE1_344678.arc
/data/oracle/admin/TDTZE1/arch/PDTZE1_344679.arc
