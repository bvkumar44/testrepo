set pages 1000 lines 150 head off verify off
select '--Table Reorg' from dual
union all
select 'alter table '||owner||'.'||table_name||' move tablespace '||tablespace_name||' parallel 8;' from dba_tables where table_name='&&tabname'
union all
select 'alter table '||owner||'.'||table_name||' parallel '||degree||' ;' from dba_tables where table_name='&&tabname'
union all
select '--Index Rebuild' from dual
union  all
select 'alter index '||owner||'.'||index_name||' rebuild parallel 8;' from dba_indexes where table_name='&&tabname'
union all
select 'alter index '||owner||'.'||index_name||' parallel '||degree||';' from dba_indexes where table_name='&&tabname';
set head on  verify on
undef tabname