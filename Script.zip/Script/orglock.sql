set linesize 80
col sess for a15
SELECT DECODE(request,0,'Holder: ','Waiter: ')||trim(sid) sess,
         id1, id2, lmode, request, type
    FROM V$LOCK
   WHERE (id1, id2, type) IN
             (SELECT id1, id2, type FROM V$LOCK WHERE request>0)
and sid not in(
SELECT sid
    FROM V$LOCK
   WHERE request>0)
   ORDER BY id1, request;