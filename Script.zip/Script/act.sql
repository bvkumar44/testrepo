set pages 500
set lines 160
col sid for 99999
col serial# for 9999999
col last_et for 9999999
col module for a25 trunc
col action for a20 trunc
col uname for a10 trunc
col event for a30 trunc
col status for a8
col mac for a15 trunc
select sid,serial#,action,module,last_call_et "Elapsed-Secs",status,event,machine mac,sql_id,prev_sql_id
 from gv$session
where type!='BACKGROUND'
and status='ACTIVE'
--and sid=493
and event not like 'pipe%'
and event not like 'Streams%'
and event not like 'jobq slave%'
-- and machine like '%TRO2K3ORA%'
order by last_call_et desc;