select count(*),host,to_char(last_update_date,'dd/mm hh24:mi') dt
from apps.jtf_fm_service_monitor
WHERE SERVER_ID =10000
AND HEALTH = 'A'
group by host,to_char(last_update_date,'dd/mm hh24:mi')
/
