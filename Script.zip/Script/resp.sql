BEGIN
Fnd_User_Resp_Groups_Api.upload_assignment (80150,  -- user id of cbhanuchandra
                                               20420,--responsibility_id for system Administrator,
                                               1,--responsibility_application_id,
                                               0,--security_group_id,
                                               SYSDATE,
                                               SYSDATE + 30,--enddate
                                               NULL --description
                                              );
commit;
END;
/