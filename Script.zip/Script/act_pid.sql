col module for a10 trunc
set lines 190
select a.inst_id isid,a.sid,a.serial#,module,a.last_call_et,a.status,a.event,a.machine mac,a.sql_id,a.process,b.spid,b.pid
 from gv$session a,gv$process b
where a.inst_id = b.inst_id
and b.inst_id = a.inst_id
and a.paddr = b.addr 
and a.type!='BACKGROUND'
and a.status='ACTIVE'
and a.event not like 'pipe%'
and a.event not like 'Streams%'
and a.event not like 'jobq slave%'
order by a.machine
/
