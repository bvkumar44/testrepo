set lines 130
col segment_name format a10 head 'Rollback|Segment'
col owner format a10 head 'Owner'
col tablespace_name format a10 head 'Tablespace|Name'
col init format 99999.99
col next format 99999.99
col opt format 99999.99
col extents format 999 head 'Ext'
col min_extents format 999 head 'Min|Ext'
col max_extents format 9999 head 'Max|Ext'
col pct_increase format 999 head 'PctInc'

select 
  s.segment_id, s.segment_name, s.owner, s.tablespace_name,
  s.initial_extent/1024/1024 Init, s.next_extent/1024/1024 Next,
  v.optsize/1024/1024 Opt, v.extents, v.shrinks, v.wraps, s.min_extents,
  s.max_extents, s.pct_increase, s.status 
from 
  sys.dba_rollback_segs s,
  v$rollstat v 
where
  v.usn = s.segment_id    
order by 1 ;
