/*****************************************************************
This script will report on active tasks see perf2.sql also

*****************************************************************/
set linesize 132
set pagesize 80
set heading on;
column physical_reads format 9,999,999 heading 'Phy|Reads';
column consistent_gets format 9,999,999,999 heading 'Consistent|GETS';
column process format 99999 heading 'Client|PID';
column spid format 99999 heading 'Server|PID';
column username format a9 heading 'User|Name';
column OSUSER format a10;
column MODULE format a10;
column EVENT format a25 trunc  heading 'Wait|Event';
column value format 9,999,999 heading 'Sort|Rows'
column BLOCK_GETS format 9,999,999 heading 'Block|Get'
column BLOCK_CHANGES format 9,999,999 heading 'Block|Changes'
column CONSISTENT_CHANGES format 9,999,999 heading 'Cons|Changes'

--select s.username, s.process , p.spid ,s.OSUSER ,s.MODULE,s.sid, i.physical_reads, i.consistent_gets,i.BLOCK_GETS, i.BLOCK_CHANGES
select s.username, s.process , p.spid ,s.OSUSER ,s.MODULE,s.sid,s.serial#, i.physical_reads, i.consistent_gets
,w.Event
from 	v$process 	p,
	v$session_wait	w,
	sys.v_$sess_io 	i,
	sys.v_$session 	s
where s.status = 'ACTIVE'
and s.type <> 'BACKGROUND'
and s.sid = i.sid
and p.addr = s.paddr
and s.sid = w.sid
and w.Event not like 'pipe%'
order by physical_reads+i.consistent_gets;
set linesize 132

