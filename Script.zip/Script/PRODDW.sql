conn system/mgrpr0ddw@PRODDW
set sqlprompt PRODDW>
SET TIME ON