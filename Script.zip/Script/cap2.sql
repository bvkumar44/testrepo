/**********************************************************************
 * File:        cap2.sql
 * Type:        SQL*Plus script
 *
 * Description:
 *      SQL*Plus script to query the "history" of a specified SQL
 *      statement, using its "SQL ID" across all database instances
 *      in a database, using the AWR repository.  This report is useful
 *      for obtaining an hourly perspective on SQL statements seen in
 *      more aggregated reports.
 *
 * Modifications:
 *********************************************************************/

set echo off
set feedback off timing off verify off pagesize 100 linesize 170 recsep off
set serveroutput on size 1000000 format wrapped trimout on trimspool on
col phv heading "Plan|Hash Value"
col snap_time format a12 truncate heading "Snapshot|Time"
col execs format 999,990 heading "Execs"
col lio_per_exec format 999,999,999,990.00 heading "Avg LIO|Per Exec"
col pio_per_exec format 999,999,999,990.00 heading "Avg PIO|Per Exec"
col cpu_per_exec format 999,999,999,990.00 heading "Avg|CPU (min)|Per Exec"
col ela_per_exec format 999,999,999,990.00 heading "Avg|Elapsed (min)|Per Exec"
col sql_text format a64 heading "Text of SQL statement"
clear breaks computes
ttitle off
btitle off

accept V_SQL_ID prompt "Enter the SQL_ID: "
accept V_NBR_DAYS prompt "Enter number of days (backwards from today) to report (default: ALL): "
accept V_BUFFER_GETS prompt "Enter number of buffer gets to report : "

variable v_nbr_days number
variable v_sql_id number;
variable v_db varchar2(10);
variable v_host varchar2(10);


spool SQL_capacity_report_&&V_SQL_ID

declare
        cursor get_phv(in_sql_id in varchar2, in_days in integer)
        is
        select  ss.plan_hash_value,
                min(s.begin_interval_time) min_time,
                max(s.begin_interval_time) max_time,
                min(s.snap_id) min_snap,
                max(s.snap_id) max_snap,
                sum(ss.executions_delta) sum_execs,
                sum(ss.disk_reads_delta) sum_disk_reads,
                sum(ss.buffer_gets_delta) sum_buffer_gets,
                sum(ss.cpu_time_delta)/1000000 sum_cpu_time,
                sum(ss.elapsed_time_delta)/1000000 sum_elapsed_time
        from    dba_hist_sqlstat        ss,
                dba_hist_snapshot       s
        where   ss.dbid = s.dbid
        and     ss.instance_number = s.instance_number
        and     ss.snap_id = s.snap_id
        and     ss.sql_id = in_sql_id
        and     ss.executions_delta > 0
        and     ss.buffer_gets_delta/decode(ss.executions_delta,0,1,ss.executions_delta) >= &&v_buffer_gets
        and     s.begin_interval_time >= sysdate-in_days
        group by ss.plan_hash_value
        order by sum_elapsed_time desc;
        --
        cursor get_xplan(in_sql_id in varchar2, in_phv in number)
        is
        select  plan_table_output
        from    table(dbms_xplan.display_awr(in_sql_id, in_phv, null, 'ALL  PEEKED_BINDS'));
        --from    table(dbms_xplan.display_awr(in_sql_id, in_phv, null, 'ALL -ALIAS'));
        --
/*        cursor get_objects(in_sql_id varchar2)
        select
        from DISTINCT s.sql_id, p.object_name 
        where DBA_HIST_SQLSTAT S, dba_hist_sql_plan p 
        and s.SNAP_ID > ? 
        and s.SNAP_ID <= ? 
        and s.sql_id = p.sql_id 
        and s.dbid = p.dbid 
        and s.plan_hash_value = p.plan_hash_value 
        order by object_name IS NOT NULL 
ORDER BY s.sql_id, p.object_name;
*/
        v_prev_plan_hash_value  number := -1;
        v_text_lines            number := 0;
        v_errcontext            varchar2(100);
        v_errmsg                varchar2(100);
        v_display_sql_text      boolean;
        --
begin
        --
        v_errcontext := 'query NBR_DAYS from DUAL';

        select name into :v_db from v$database;

        select  decode('&&V_NBR_DAYS','',10,to_number(nvl('&&V_NBR_DAYS','10')))
        into    :v_nbr_days
        from    dual;
        --

        EXECUTE IMMEDIATE 'ALTER SESSION SET STATISTICS_LEVEL=ALL';
        --
        v_errcontext := 'open/fetch get_phv';
        for phv in get_phv('&&V_SQL_ID', :v_nbr_days) loop
                --
                if get_phv%rowcount = 1 then
                        --
                        dbms_output.put_line('+'||
                                rpad('-',12,'-')||
                                rpad('-',10,'-')||
                                rpad('-',10,'-')||
                                rpad('-',12,'-')||
                                rpad('-',15,'-')||
                                rpad('-',15,'-')||
                                rpad('-',12,'-')||
                                rpad('-',12,'-')||'+');
                        dbms_output.put_line('|'||
                                rpad('Plan HV',12,' ')||
                                rpad('Min Snap',10,' ')||
                                rpad('Max Snap',10,' ')||
                                rpad('Execs',12,' ')||
                                rpad('LIO',15,' ')||
                                rpad('PIO',15,' ')||
                                rpad('CPU',12,' ')||
                                rpad('Elapsed',12,' ')||'|');
                        dbms_output.put_line('+'||
                                rpad('-',12,'-')||
                                rpad('-',10,'-')||
                                rpad('-',10,'-')||
                                rpad('-',12,'-')||
                                rpad('-',15,'-')||
                                rpad('-',15,'-')||
                                rpad('-',12,'-')||
                                rpad('-',12,'-')||'+');
                        --
                end if;
                --
                dbms_output.put_line('|'||
                        rpad(trim(to_char(phv.plan_hash_value)),12,' ')||
                        rpad(trim(to_char(phv.min_snap)),10,' ')||
                        rpad(trim(to_char(phv.max_snap)),10,' ')||
                        rpad(trim(to_char(phv.sum_execs,'999,999,990')),12,' ')||
                        rpad(trim(to_char(phv.sum_buffer_gets,'999,999,999,990')),15,' ')||
                        rpad(trim(to_char(phv.sum_disk_reads,'999,999,999,990')),15,' ')||
                        rpad(trim(to_char(phv.sum_cpu_time,'999,990.00')),12,' ')||
                        rpad(trim(to_char(phv.sum_elapsed_time,'999,990.00')),12,' ')||'|');
                --
                v_errcontext := 'fetch/close get_phv';
                --
        end loop;
        dbms_output.put_line('+'||
                rpad('-',12,'-')||
                rpad('-',10,'-')||
                rpad('-',10,'-')||
                rpad('-',12,'-')||
                rpad('-',15,'-')||
                rpad('-',15,'-')||
                rpad('-',12,'-')||
                rpad('-',12,'-')||'+');
        --
        v_errcontext := 'open/fetch get_phv';
        for phv in get_phv('&&V_SQL_ID', :v_nbr_days) loop
                --
                if v_prev_plan_hash_value <> phv.plan_hash_value then
                        --
                        v_prev_plan_hash_value := phv.plan_hash_value;
                        v_display_sql_text := TRUE;
                        --
                        v_text_lines := 0;
                        v_errcontext := 'open/fetch get_xplan';
                        for s in get_xplan('&&V_SQL_ID', phv.plan_hash_value) loop
                                --
                                if v_text_lines = 0 then
                                        dbms_output.put_line('.');
                                        dbms_output.put_line('========== PHV = ' ||
                                                phv.plan_hash_value ||
                                                '==========');
                                        dbms_output.put_line('First seen from "'||
                                                to_char(phv.min_time,'MM/DD/YY HH24:MI:SS') ||
                                                '" (snap #'||phv.min_snap||')');
                                        dbms_output.put_line('Last seen from  "'||
                                                to_char(phv.max_time,'MM/DD/YY HH24:MI:SS') ||
                                                '" (snap #'||phv.max_snap||')');
                                        dbms_output.put_line('.');
                                        dbms_output.put_line(
                                                rpad('Execs',15,' ')||
                                                rpad('LIO',15,' ')||
                                                rpad('PIO',15,' ')||
                                                rpad('CPU',15,' ')||
                                                rpad('Elapsed',15,' '));
                                        dbms_output.put_line(
                                                rpad('=====',15,' ')||
                                                rpad('===',15,' ')||
                                                rpad('===',15,' ')||
                                                rpad('===',15,' ')||
                                                rpad('=======',15,' '));
                                        dbms_output.put_line(
                                                rpad(trim(to_char(phv.sum_execs,'999,999,999,990')),15,' ')||
                                                rpad(trim(to_char(phv.sum_buffer_gets,'999,999,999,990')),15,' ')||
                                                rpad(trim(to_char(phv.sum_disk_reads,'999,999,999,990')),15,' ')||
                                                rpad(trim(to_char(phv.sum_cpu_time,'999,999,990.00')),15,' ')||
                                                rpad(trim(to_char(phv.sum_elapsed_time,'999,999,990.00')),15,' '));
                                        dbms_output.put_line('.');
                                end if;
                                --
                                if v_display_sql_text = FALSE and
                                   s.plan_table_output like 'Plan hash value: %' then
                                        --
                                        v_display_sql_text := TRUE;
                                        --
                                end if;
                                --
                                if v_display_sql_text = TRUE then
                                        --
                                        dbms_output.put_line(s.plan_table_output);
                                        --
                                end if;
                                --
                                v_text_lines := v_text_lines + 1;
                                --
                        end loop;
                        --
                end if;
                --
                v_errcontext := 'fetch/close get_phv';
                --
        end loop;
        --
exception
        when others then
                v_errmsg := sqlerrm;
                raise_application_error(-20000, v_errcontext || ': ' || v_errmsg);
end;
/

/*
SELECT DISTINCT s.sql_id, p.object_name, p.object_type 
FROM DBA_HIST_SQLSTAT S, dba_hist_sql_plan p 
WHERE    
   -- s.SNAP_ID > ? 
--AND s.SNAP_ID <= ? 
 s.sql_id = '&&v_sql_id' 
AND s.dbid = p.dbid 
AND s.plan_hash_value = p.plan_hash_value 
AND p.object_name IS NOT NULL 
ORDER BY s.sql_id, p.object_name;

SELECT s.sql_id, t.* 
FROM dba_hist_sqlstat s, TABLE(DBMS_XPLAN.DISPLAY_CURSOR('&&v_sql_id',null,'PEEKED_BINDS')) t 
WHERE sql_id = '&&v_sql_id'; 
*/

set echo off
set feedback off timing off verify off pagesize 40 linesize 190 recsep off
set serveroutput on size 1000000 format wrapped trimout on trimspool on

col snap_id format 999999 
col snap_time format a12 truncate heading "Snapshot|Time"
col snap_time format a12 truncate heading "Snapshot|Time"

col optimizer_cost          format 99999          heading "Optimizer|Cost"
col execs                   format 9,990          heading "Execs"
col fetches_per_exec        format 99,990         heading "Fetches|Per Exec"
col lio_per_exec            format 99,999,999,990 heading "Avg LIO|Per Exec"
col pio_per_exec            format 9,999,990      heading "Avg PIO|Per Exec"
col rows_per_exec           format 9,999,990      heading "Avg Row|Per Exec"
col iowait_per_exec         format 9,990.00       heading "Avg IO|Wait (min)|Per Exec"
col cpu_per_exec            format 99,990.00      heading "Avg|CPU (min)|Per Exec"
col ela_per_exec            format 99,990.00      heading "Avg|Elapsed (min)|Per Exec"
col module                  format a45            heading "Module"
col action                  format a35            heading "Action"

clear breaks computes
ttitle off
btitle off

col snap_time format a12 truncate heading "Snapshot|Time"

break on report
compute sum of execs on report
compute sum of lio_per_exec on report
compute sum of pio_per_exec on report
compute sum of cpu_per_exec on report
compute sum of ela_per_exec on report
compute sum of iowait_per_exec on report;
compute sum of rows_per_exec on report;

--ttitle center 'SQL Execution Histort Report on DB: :v_db for the Past &&V_NBR_DAYS Days' skip 2

select  ss.snap_id, 
        to_char(s.begin_interval_time, 'DD-MON HH24:MI') snap_time,
        sql_id, 
        optimizer_cost, 
        ss.executions_delta execs,
        ss.buffer_gets_delta/decode(ss.executions_delta,0,1,ss.executions_delta) lio_per_exec,
        ss.disk_reads_delta/decode(ss.executions_delta,0,1,ss.executions_delta) pio_per_exec,
        ss.rows_processed_delta/decode(ss.executions_delta,0,1,ss.executions_delta) rows_per_exec,
       (ss.iowait_delta/1000000)/decode(ss.executions_delta,0,1,ss.executions_delta)/60 iowait_per_exec,
       (ss.cpu_time_delta/1000000)/decode(ss.executions_delta,0,1,ss.executions_delta)/60 cpu_per_exec,
       (ss.elapsed_time_delta/1000000)/decode(ss.executions_delta,0,1,ss.executions_delta)/60 ela_per_exec,
        ss.module module, ss.action action
from    dba_hist_snapshot       s,
        dba_hist_sqlstat        ss
where   ss.dbid = s.dbid
and     ss.instance_number = s.instance_number
and     ss.snap_id = s.snap_id
and     ss.buffer_gets_delta/decode(ss.executions_delta,0,1,ss.executions_delta) >= &&v_buffer_gets
and     ss.sql_id = '&&v_sql_id'
and     ss.executions_delta > 0
and     s.begin_interval_time > sysdate  - &&v_nbr_days  
order by to_char(s.begin_interval_time);  --, ss.buffer_gets_delta/decode(ss.executions_delta,0,1,ss.executions_delta) desc
 

clear breaks computes

break on phv skip 1 on report
compute sum of execs on phv
compute avg of lio_per_exec on phv
compute avg of pio_per_exec on phv
compute avg of cpu_per_exec on phv
compute avg of ela_per_exec on phv
col version_count format 999 heading "Version|Count"

ttitle center 'Per-Plan Execution Statistics Over Time' skip 2

select  ss.plan_hash_value phv, version_count,  
        to_char(s.begin_interval_time, 'DD-MON HH24:MI') snap_time,
        ss.executions_delta execs,
        ss.buffer_gets_delta/decode(ss.executions_delta,0,1,ss.executions_delta) lio_per_exec,
        ss.disk_reads_delta/decode(ss.executions_delta,0,1,ss.executions_delta) pio_per_exec,
        (ss.cpu_time_delta/1000000)/decode(ss.executions_delta,0,1,ss.executions_delta)/60 cpu_per_exec,
        (ss.elapsed_time_delta/1000000)/decode(ss.executions_delta,0,1,ss.executions_delta)/60 ela_per_exec,
        ss.module module, 
        ss.action action
from    dba_hist_snapshot       s,
        dba_hist_sqlstat        ss
where   ss.dbid = s.dbid
and     ss.instance_number = s.instance_number
and     ss.snap_id = s.snap_id
and     ss.sql_id = '&&V_SQL_ID'
and     ss.executions_delta > 0
and     s.begin_interval_time >= sysdate - :v_nbr_days
order by ss.plan_hash_value, s.snap_id;
clear breaks computes

spool off
set verify on echo on feedback on





