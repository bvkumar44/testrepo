set serveroutput on;
set pages 60 newpage 0;

column sql_addr new_value sql_addr;
column sql_hash new_value sql_hash;
select sql_address sql_addr,
	   to_char(sql_hash_value,'999999999999') sql_hash
from v$session 
where SID = '&session_id';

set heading off verify off feedback off;

spool expl_stmt.sql

declare
  curr_line       varchar2(80);
  loc_of_space    number(5);
  loc_of_comma    number(5);
  loc_of_equal    number(5);
  text_break      number(5);
  text_pointer    number(5) := 0;
  line_length     number(2) := 80;
  
  cursor stmt_cur is
    select sql_text
    from sys.v_$sqltext
    where address = hextoraw('&sql_addr')
    order by piece;

  new_sql_text    varchar2(64);
  curr_sql_text   varchar2(2000);

  first_line      boolean := TRUE;
  no_comma_or_space exception;

begin
  -- Enlarge the output buffer to allow large statements to be printed 
  dbms_output.enable(1000000);

  dbms_output.put_line('explain plan set statement_id = ' ||
                       chr(39) || 'richb' || chr(39) ||
                       ' for ');

  open stmt_cur;
  loop
    fetch stmt_cur into new_sql_text;
    exit when stmt_cur%NOTFOUND;

    -- save current sql line along with old characters leftover

    curr_sql_text := curr_sql_text || new_sql_text;
    curr_sql_text := replace(curr_sql_text,' . ','.');

    if first_line = FALSE then
      loc_of_space := instr(new_sql_text,' ');
      if loc_of_space = 0 then
        -- what about no spaces in line?
        -- look for first comma
        loc_of_comma := instr(new_sql_text,',');
        if loc_of_comma = 0 then
          -- what about breaking on =
          loc_of_equal := instr(new_sql_text,'=');
          if loc_of_equal = 0 then
            raise no_comma_or_space;
          else
             text_break := loc_of_equal;
          end if;
        else
          text_break := loc_of_comma;
        end if;
      else
        text_break := loc_of_space;
      end if;

      if text_break + length(curr_sql_text) > line_length then
        text_pointer := line_length;
        loop  -- find first space or comma before line_length 
          loc_of_space := 0;
          loc_of_comma := 0;
          loc_of_equal := 0;
          loc_of_space := instr(curr_sql_text,' ',text_pointer,1);
          if loc_of_space = 0  or loc_of_space > line_length then
            loc_of_comma := instr(curr_sql_text,',',text_pointer,1);
            if loc_of_comma = 0 or loc_of_comma > line_length then
              loc_of_equal := instr(curr_sql_text,'=',text_pointer,1);
              if loc_of_equal = 0 or loc_of_equal > line_length then 
                if text_pointer = 0 then
                  -- no spaces or commas left in this line
                  exit;
                end if;
              else -- found equals sign
                text_break := loc_of_equal;
                exit;
              end if;
            else -- found comma
              text_break := loc_of_comma;
              exit;
            end if;
          else  -- found space 
            text_break := loc_of_space;
            exit;
          end if;
          text_pointer := text_pointer - 1;
        end loop;
        -- now output the line
        curr_line := substr(curr_sql_text,1,text_break);
        dbms_output.put_line(curr_line);
        curr_sql_text := substr(curr_sql_text,text_break + 1 ,2000);
      end if;
  
    else -- set boolean flag
      first_line := FALSE;
    end if;
  end loop;
  close stmt_cur;

  --  now print out the remaining characters of the line
  dbms_output.put_line(curr_sql_text);
  dbms_output.put_line('/');
 exception
   when no_comma_or_space then
     dbms_output.put_line('No commas or spaces to break on, exiting...');
   when others then
     dbms_output.put_line('Failed with unhandled exception');
end;

.
/
spool off;
set heading on verify on feedback on;
