spool otmeb_rebuild_index.log

alter table ar.RA_CUSTOMER_TRX_ALL move;
alter table ar.RA_CUSTOMER_TRX_LINES_ALL move;

alter index AR.RA_CUSTOMER_TRX_N15 rebuild;
alter index AR.RA_CUSTOMER_TRX_N23 rebuild;
alter index AR.RA_CUSTOMER_TRX_N11 rebuild;
alter index AR.RA_CUSTOMER_TRX_N10 rebuild;
alter index AR.RA_CUSTOMER_TRX_N12 rebuild;
alter index AR.RA_CUSTOMER_TRX_N13 rebuild;
alter index AR.RA_CUSTOMER_TRX_N21 rebuild;
alter index AR.RA_CUSTOMER_TRX_U1 rebuild;
alter index AR.RA_CUSTOMER_TRX_N1 rebuild;
alter index AR.RA_CUSTOMER_TRX_N6 rebuild;
alter index AR.RA_CUSTOMER_TRX_N9 rebuild;
alter index AR.RA_CUSTOMER_TRX_U2 rebuild;
alter index AR.RA_CUSTOMER_TRX_N20 rebuild;
alter index AR.RA_CUSTOMER_TRX_N22 rebuild;
alter index AR.RA_CUSTOMER_TRX_N14 rebuild;
alter index AR.RA_CUSTOMER_TRX_N2 rebuild;
alter index AR.RA_CUSTOMER_TRX_N16 rebuild;
alter index AR.RA_CUSTOMER_TRX_N17 rebuild;
alter index AR.RA_CUSTOMER_TRX_N19 rebuild;
alter index AR.RA_CUSTOMER_TRX_N18 rebuild;
alter index AR.RA_CUSTOMER_TRX_N7 rebuild;
alter index AR.RA_CUSTOMER_TRX_N5 rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_N1 rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_N10 rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_N11 rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_N12 rebuild;
alter index APPS.ADS_RA_CUSTOMER_TRX_LINES_ALL rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_N7 rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_N8 rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_U1 rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_N4 rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_N2 rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_N3 rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_N9 rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_N5 rebuild;
alter index AR.RA_CUSTOMER_TRX_LINES_N6 rebuild;

spool off