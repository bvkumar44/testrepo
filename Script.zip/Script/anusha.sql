CREATE OR REPLACE PACKAGE BODY APPS.MRPARM_DMTRA_FCST_UPLOAD
AS
/*---------------------------- ArvinMeritor Inc. -----------------------------*/
-- Application Module Name : Oracle Master Scheduling/MRP ARM
-- File Name               : MRPARM_DMTRA_FCST_UPLOAD.plb
-- Date                    : 30-May-2008
-- Author                  : R Rajeswari
-- MD060 Name              : ARM Demantra Forecast Upload to Oracle-MD60.doc
-- Description:
--           This program is used to identify all parts that should be delivered to the
-- assembly line based on the Flow Pick List report and creates a Move Order to Auto Pick
-- requirements based on parameters
--
-- Modification History
--
--   REVISON        DATE/TIME         AUTHOR
--   Rev 1.0        MAY 30 2008       R Rajeswari
--   Initial Development.
--   Rev 1.1        JUL 28 2008       R Rajeswari
--   Changes made as per the revised MD060 received from onsite.
--   Rev 1.2        AUG 18 2008       R Rajeswari
--   Changes made as per the revised MD060 received from onsite.
--   Rev 1.3        OCT 22 2008       Anusha Iyer
--   Changes made as per the revised MD060 (version 3.0 and 4.0)
--
/*----------------------------------------------------------------------------- */

   /*----------------------------------------------------------------------------- */
   /* Procedure to write LOG Messages
   /*----------------------------------------------------------------------------- */
   PROCEDURE write_log (p_err_msg VARCHAR2)
   IS
   BEGIN
      fnd_file.put_line (fnd_file.LOG, p_err_msg);
   END write_log;

   -- Added Rev 1.3 Start
   PROCEDURE create_synonm(p_regn_code VARCHAR2)
   IS
   l_crea_statement   VARCHAR2(3000);
   l_reg_cd           VARCHAR2(10);
   l_tab_name         VARCHAR2(40);
   BEGIN
      l_reg_cd        := p_regn_code;
      l_tab_name      := 'BIEO_FCST_EXPORT_'||l_reg_cd||'@ERP_TO_DEM';
      --l_tab_name      := 'BIEO_FCST_EXPORT_'||'@ERP_TO_DEM';

      l_crea_statement := 'DROP SYNONYM APPS.MRPARM_BIEO_FCST_EXPORT';
      EXECUTE IMMEDIATE l_crea_statement;

      l_crea_statement := 'DROP SYNONYM APPS_MRC.MRPARM_BIEO_FCST_EXPORT';
      EXECUTE IMMEDIATE l_crea_statement;

      l_crea_statement := 'CREATE SYNONYM APPS.MRPARM_BIEO_FCST_EXPORT FOR '|| l_tab_name;
      EXECUTE IMMEDIATE l_crea_statement;

      l_crea_statement := 'CREATE SYNONYM APPS_MRC.MRPARM_BIEO_FCST_EXPORT FOR '||l_tab_name;
      EXECUTE IMMEDIATE l_crea_statement;
   END;
   -- Added Rev 1.3 End


  /*----------------------------------------------------------------------------- */
  /* Procedure to get DEMANTRA data into the Staging Table
  /*----------------------------------------------------------------------------- */

   PROCEDURE MRPARM_GET_DEMANTRA_DATA(p_fcst_wk_start   IN DATE,
                                      p_fcst_wk_end     IN DATE,
                                      p_regn_code       IN VARCHAR2, -- Added Rev 1.3
                                      p_organization_id IN NUMBER,   -- Added as per Rev 1.1
                                      p_cat_set_id      IN NUMBER,
                                      p_cat_id          IN NUMBER,   -- Added as per Rev 1.1
                                      p_cust_id         IN NUMBER,   -- Added as per Rev 1.1
                                      p_cust_ship_to    IN NUMBER,   -- Added as per Rev 1.1
                                      p_forecast_level  IN VARCHAR2, -- Added as per Rev 1.1
                                      p_dest_fcst_set   IN VARCHAR2, -- Added as per Rev 1.1
                                      p_dest_fcst_nm    IN VARCHAR2, -- Added as per Rev 1.1
                                      p_debug_yes_no    IN VARCHAR2, -- Added as per Rev 1.1
                                      p_round_fcst_qty  IN NUMBER,
                                      p_appr_fcst       IN VARCHAR2,    -- Added Rev 1.3
                                      p_model_excl      IN VARCHAR2,    -- Added Rev 1.3
                                      p_spec_modl       IN VARCHAR2 )   -- Added Rev 1.3
   IS
      l_orgn_cd        org_organization_definitions.organization_code%TYPE;
      l_item           mtl_system_items_b.inventory_item_id%TYPE;
      l_cust_id        mrp_forecast_designators.customer_id%TYPE;
      l_ship_id        mrp_forecast_designators.ship_id%TYPE;
      l_party_id       hz_parties.party_id%TYPE;
      l_item_nm        mtl_system_items_b.segment1%TYPE;
      l_cat_set_nm     mtl_category_sets.CATEGORY_SET_NAME%TYPE;
      l_cat_segment1   mtl_categories.segment1%TYPE;
      l_cat_segment2   mtl_categories.segment2%TYPE;
      l_cat_segment3   mtl_categories.segment3%TYPE;
      l_cat_segment4   mtl_categories.segment4%TYPE;
      l_cat_segment5   mtl_categories.segment5%TYPE;
      l_cat_segment6   mtl_categories.segment6%TYPE;
      l_cat_nm         VARCHAR2(100);
      l_it_available   VARCHAR2(1);
      l_cust_available VARCHAR2(1);
      l_except_chk     NUMBER;
      l_rec_count      NUMBER;
      t_cust_id        NUMBER;
      t_ship_id        NUMBER;
      l_ship_id_cnt    NUMBER;
      l_cnt            NUMBER;
      x_request_id     NUMBER; -- Added Rev 1.3

   BEGIN

       t_cust_id := p_cust_id;
       t_ship_id := p_cust_ship_to;

       IF p_cat_id IS NOT NULL THEN

          SELECT segment1,segment2,segment3,segment4,segment5,segment6
            into l_cat_segment1, l_cat_segment2,l_cat_segment3,l_cat_segment4,l_cat_segment5,l_cat_segment6
            from mtl_categories
           where category_id = p_cat_id;

          l_cat_nm := l_cat_segment1||'.'||l_cat_segment2||'.'||l_cat_segment3||'.'||l_cat_segment4||'.'
                              ||l_cat_segment5||'.'||l_cat_segment6;

       END IF;

       CREATE_SYNONM(p_regn_code);

       DELETE FROM MRPARM_DEMANTRA_FCST_LOAD_TEMP
       WHERE  TRUNC(REQ_RUN_DATE) < TRUNC(SYSDATE) - 2;
-- <Start Rev 1.1>
       --FOR temp_insert IN ( SELECT sdate,level1,level2,level3,c_pred,record_type  -- Commented Rev 1.3
       FOR temp_insert IN ( SELECT sdate,REPLACE(level1,p_regn_code) level1,         -- Added Rev 1.3
                            REPLACE(level2,p_regn_code) level2,                      -- Added Rev 1.3
                            REPLACE(level3,p_regn_code) level3,  c_pred,record_type  -- Added Rev 1.3
            FROM MRPARM_BIEO_FCST_EXPORT
           WHERE REPLACE(level4,p_regn_code) = NVL(p_cust_id,REPLACE(level4,p_regn_code))
             AND fapprove = DECODE(p_appr_fcst,'Y',1,fapprove) -- Added Rev 1.3
             AND REPLACE(level3,p_regn_code) = p_organization_id -- Added Rev 1.3
             AND record_type = 2
             AND round(c_pred,p_round_fcst_qty) > 0
             AND sdate >= NVL(p_fcst_wk_start,sdate)
             AND sdate <= NVL(p_fcst_wk_end,sdate) )
             --AND level3 = p_organization_id) -- Commented Rev 1.3

       LOOP

          /*write_log('temp_insert.level1 '||temp_insert.level1);
          write_log('p_cat_set_id '||p_cat_set_id);
          write_log('p_cat_id '||p_cat_id);*/

-- Check whether the Category Set / Category matches with the item
          --l_item := SUBSTR(temp_insert.level1,3); -- Commented Rev 1.3
          l_item := NULL; --  Added Rev 1.3
          l_item := temp_insert.level1; -- Added Rev 1.3
          l_it_available := NULL;
          l_cust_available := NULL;
          l_except_chk := 0;

-- Find out the Item Name / Category Segments and Category Set Name
          BEGIN
          SELECT segment1
            INTO l_item_nm
            FROM mtl_system_items_b
           WHERE inventory_item_id = l_item
             AND organization_id = p_organization_id;
          EXCEPTION
             WHEN NO_DATA_FOUND THEN
                l_item_nm := NULL;
             WHEN OTHERS THEN
                l_item_nm := NULL;
          END;

          --write_log('Temp Insert :'||temp_insert.level1);
          --write_log('l_item :'||l_item);
          --write_log('l_item_nm :'||l_item_nm);

          IF l_item_nm IS NOT NULL THEN
             -- Rev 1.3 Start
             IF p_spec_modl IS NOT NULL THEN
                BEGIN
                   SELECT 'X'
                     INTO l_it_available
                     FROM mtl_item_categories_v
                    WHERE segment3          = p_spec_modl
                      AND organization_id   = p_organization_id
                      AND category_set_name = 'ARM DEMANTRA FORECAST';
                EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                      l_it_available := NULL;
                   WHEN OTHERS THEN
                      l_it_available := NULL;
                END;
             -- Rev 1.3 End
             ELSE
                BEGIN
                  SELECT category_set_name
                  INTO l_cat_set_nm
                  FROM mtl_category_sets
                  WHERE category_set_id = p_cat_set_id;
                EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                      l_cat_set_nm := null;
                   WHEN OTHERS THEN
                      l_cat_set_nm := null;
                END;
                IF p_cat_id IS NOT NULL THEN
                   BEGIN
                      SELECT 'X'
                        INTO l_it_available
                        FROM mtl_item_categories
                       WHERE organization_id = p_organization_id
                         AND category_set_id = p_cat_set_id
                         AND category_id = p_cat_id
                         AND inventory_item_id = l_item;
                   EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                         IF P_DEBUG_YES_NO ='Y' THEN
                            IF l_item_nm IS NOT NULL THEN
                               WRITE_LOG (' ITEM DOES NOT MATCH THE CATEGORY SET , CATEGORY GIVEN : Category set '||l_cat_set_nm||' Category '||l_cat_nm||' Inventory Item '||l_item_nm);
                            END IF;
                         END IF;
                      WHEN OTHERS THEN
                         IF P_DEBUG_YES_NO ='Y' THEN
                            WRITE_LOG (' Error while checking ITEM,CATEGORY SET,CATEGORY '||SQLERRM);
                         END IF;
                   END;
                ELSE -- IF p_cat_id IS NULL THEN
                   BEGIN
                      SELECT 'X'
                        INTO l_it_available
                        FROM mtl_item_categories
                       WHERE organization_id = p_organization_id
                         AND category_set_id = p_cat_set_id
                         AND inventory_item_id = l_item;
                   EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                         IF P_DEBUG_YES_NO ='Y' THEN
                            IF l_item_nm IS NOT NULL THEN
                               WRITE_LOG (' ITEM DOES NOT MATCH THE CATEGORY SET GIVEN  : Category set '||l_cat_set_nm||' Inventory Item '||l_item_nm);
                            END IF;
                         END IF;
                      WHEN OTHERS THEN
                         IF P_DEBUG_YES_NO ='Y' THEN
                            WRITE_LOG (' Error while checking ITEM,CATEGORY SET,CATEGORY '||SQLERRM);
                         END IF;
                   END;
                END IF; -- IF p_cat_id IS NOT NULL THEN
             END IF;   -- IF p_spec_model IS NOT NULL
-- fetch organization code corresponding to the organization id
             BEGIN
               SELECT organization_code
                 INTO l_orgn_cd
                 FROM org_organization_definitions
                WHERE organization_id = p_organization_id;
            EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  IF p_debug_yes_no = 'Y' THEN
                     write_log(' Error while fetching Organization Code ');
                  END IF;
                  l_orgn_cd := NULL;
               WHEN OTHERS THEN
                  IF p_debug_yes_no = 'Y' THEN
                     write_log(' Error while fetching Organization Code '||SQLERRM);
                  END IF;
                  l_orgn_cd := NULL;
            END;
-- Check whether the item needs to excluded from Import
            IF p_model_excl = 'Y' THEN  -- Added Rev 1.3

               SELECT count(*)
                 INTO l_except_chk
                 FROM mtl_item_categories mic,mtl_categories mc, mfg_lookups ml,mtl_category_sets mcs
                WHERE mic.organization_id = p_organization_id
                  AND mic.category_set_id = mcs.category_set_id
                  and mcs.category_set_name = ml.description
                  AND mic.inventory_item_id = l_item
                  AND mic.category_id = mc.category_id
                  AND mc.segment3 = ml.meaning
                  and ml.lookup_type = ''|| l_orgn_cd||''||'_DEM_FCST_UPL_MODEL_EXCLUDE';
            ELSE -- Added Rev 1.3
               l_except_chk := 0;
            END IF;

                 /*
                 FROM mtl_item_categories mic,mtl_categories mc, mfg_lookups
                WHERE mic.organization_id = p_organization_id
                  --AND mic.category_set_id = p_cat_set_id
                  AND mic.inventory_item_id = l_item
                  AND mic.category_id = mc.category_id
                  --AND mc.category_id = NVL(p_cat_id,mc.category_id)
                  AND mc.segment3 IN (SELECT meaning
                                        FROM mfg_lookups
                                       WHERE lookup_type = ''|| l_orgn_cd||''||'_DEM_FCST_UPL_MODEL_EXCLUDE'
                                         AND description = l_cat_set_nm);*/
             IF l_except_chk > 0 THEN
                l_it_available := NULL;
             END IF;
             /*write_log('l_item '||l_item);
             write_log('l_except_chk '||l_except_chk);
             write_log('l_it_available '||l_it_available);*/
             /*write_log('p_forecast_level '||p_forecast_level);
             write_log('p_cust_id '||p_cust_id);
             write_log('p_cust_ship_to '||p_cust_ship_to);
             write_log('p_dest_fcst_nm '||p_dest_fcst_nm);
             write_log('p_dest_fcst_set '||p_dest_fcst_set);*/

             IF (p_dest_fcst_nm IS NULL AND p_cust_id IS NULL AND p_cust_ship_to IS NULL) THEN
            --    write_log(' Part 1 -- p_dest_fcst_nm IS NULL AND p_cust_id IS NULL AND p_cust_ship_to IS NULL ');
                SELECT COUNT(*)
                  INTO l_ship_id_cnt
                  FROM mrp_forecast_designators
                 WHERE forecast_set = p_dest_fcst_set
                   AND organization_id = p_organization_id
                   AND ship_id IS NOT NULL;
            --    write_log('l_ship_id_cnt '||l_ship_id_cnt);
                IF l_ship_id_cnt > 0 THEN
                   FOR FCST_DESIG IN (SELECT forecast_designator,customer_id,ship_id
                                        FROM mrp_forecast_designators
                                       WHERE forecast_set = p_dest_fcst_set
                                         AND organization_id = p_organization_id)
                   LOOP
                      --IF SUBSTR(temp_insert.level2,3) = fcst_desig.ship_id THEN -- Commented Rev 1.3
                      IF temp_insert.level2 = fcst_desig.ship_id THEN -- Added Rev 1.3
                         IF l_cust_available IS NULL THEN
                            l_cust_available := 'X';
                         END IF;
                      END IF;
                   END LOOP;
                ELSE
                   l_cust_available := 'X';
                END IF;
             ELSIF (p_dest_fcst_nm IS NULL AND p_cust_id IS NOT NULL AND p_cust_ship_to IS NULL) THEN
                --write_log(' Part 2 -- p_dest_fcst_nm IS NULL AND p_cust_id IS NOT NULL AND p_cust_ship_to IS NULL ');
                SELECT COUNT(*)
                  INTO l_ship_id_cnt
                  FROM mrp_forecast_designators
                 WHERE forecast_set = p_dest_fcst_set
                   AND organization_id = p_organization_id
                   AND customer_id = p_cust_id
                   AND ship_id IS NOT NULL;
                IF l_ship_id_cnt > 0 THEN
                   FOR FCST_DESIG_1 IN (SELECT forecast_designator, customer_id,ship_id
                                        FROM mrp_forecast_designators
                                       WHERE forecast_set = p_dest_fcst_set
                                         AND customer_id = p_cust_id
                                         AND organization_id = p_organization_id)
                   LOOP
                      --IF SUBSTR(temp_insert.level2,3) = fcst_desig_1.ship_id THEN -- Commented Rev 1.3
                      IF temp_insert.level2 = fcst_desig_1.ship_id THEN -- Added Rev 1.3
                         IF l_cust_available IS NULL THEN
                            l_cust_available := 'X';
                         END IF;
                      END IF;
                   END LOOP;
                ELSE
                   l_cust_available := 'X';
                END IF;
             ELSE
                --write_log('part 3');
                SELECT count(*)
                  INTO l_cnt
                  FROM mrp_forecast_designators
                 WHERE forecast_set = p_dest_fcst_set
                   AND forecast_designator = nvl(p_dest_fcst_nm,forecast_designator)
                   AND customer_id = nvl(p_cust_id,customer_id)
                   AND ship_id = nvl(p_cust_ship_to,ship_id);

                --write_log('l_cnt '||l_cnt);

                IF l_cnt > 0 THEN
                   BEGIN
                      SELECT customer_id,ship_id
                        INTO l_cust_id,l_ship_id
                        FROM mrp_forecast_designators
                       WHERE forecast_set = p_dest_fcst_set
                         AND forecast_designator = nvl(p_dest_fcst_nm,forecast_designator)
                         AND customer_id = nvl(p_cust_id,customer_id)
                         AND ship_id = nvl(p_cust_ship_to,ship_id);
                   EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                         l_cust_id := NULL;
                         l_ship_id := NULL;
                      WHEN OTHERS THEN
                         l_cust_id := NULL;
                         l_ship_id := NULL;
                   END;
                   IF (p_dest_fcst_nm IS NOT NULL AND p_cust_id IS NOT NULL AND p_cust_ship_to IS NOT NULL) THEN
                      IF l_cust_id = p_cust_id AND l_ship_id = p_cust_ship_to THEN
                         --IF p_cust_ship_to = SUBSTR(temp_insert.level2,3) THEN -- Commented Rev 1.3
                         IF p_cust_ship_to = temp_insert.level2 THEN -- Added Rev 1.3
                            l_cust_available := 'X';
                         END IF;
                      END IF;
                   ELSIF (p_dest_fcst_nm IS NOT NULL AND p_cust_id IS NOT NULL AND p_cust_ship_to IS NULL) OR
                         (p_dest_fcst_nm IS NULL AND p_cust_id IS NOT NULL AND p_cust_ship_to IS NOT NULL) OR
                         (p_dest_fcst_nm IS NULL AND p_cust_id IS NULL AND p_cust_ship_to IS NOT NULL) THEN
                --      write_log('part 3 a');
                      --IF l_ship_id = SUBSTR(temp_insert.level2,3) THEN -- Commented Rev 1.3
                      IF l_ship_id = temp_insert.level2 THEN -- Added Rev 1.3
                         l_cust_available := 'X';
                      END IF;
                   ELSIF (p_dest_fcst_nm IS NOT NULL AND p_cust_id IS NULL AND p_cust_ship_to IS NOT NULL) THEN
                --      write_log('part 3 b');
                      IF l_ship_id = p_cust_ship_to THEN
                         --IF l_ship_id = SUBSTR(temp_insert.level2,3) THEN -- Commented Rev 1.3
                         IF l_ship_id = temp_insert.level2 THEN -- Added Rev 1.3
                            l_cust_available := 'X';
                         END IF;
                      END IF;
                   ELSIF (p_dest_fcst_nm IS NOT NULL AND p_cust_id IS NULL AND p_cust_ship_to IS NULL) THEN
                --      write_log('part 3 c');
                      IF l_ship_id IS NULL THEN
                         l_cust_available := 'X';
                      ELSE
                         --IF l_ship_id = SUBSTR(temp_insert.level2,3) THEN -- Commented Rev 1.3
                         IF l_ship_id = temp_insert.level2 THEN -- Added Rev 1.3
                            l_cust_available := 'X';
                         END IF;
                      END IF;
                   END IF;
                ELSE
                   l_cust_available := 'X';
                END IF;
             END IF;

             x_request_id := fnd_global.conc_request_id; -- Added Rev 1.3

             --write_log('l_it_avail'||l_it_available||' l_cust_available '||l_cust_available||' l_item_nm:'||l_item_nm||' l_item :'||l_item);
             IF l_it_available = 'X' THEN
                IF l_cust_available = 'X' THEN
                   INSERT INTO MRPARM_DEMANTRA_FCST_LOAD_TEMP (sdate,level1,level2,level3,c_pred,record_type,
                         request_id,req_run_date ) -- Added Rev 1.3
                        VALUES (temp_insert.sdate,temp_insert.level1,temp_insert.level2, temp_insert.level3,
                                round(temp_insert.c_pred,p_round_fcst_qty),temp_insert.record_type,
                                x_request_id,sysdate); -- Added Rev 1.3
                END IF;
             END IF; -- IF l_it_available = 'X' THEN
          END IF; -- IF l_item_nm IS NOT NULL THEN
       END LOOP;

-- <End Rev 1.1>
-- Commented as per Rev 1.1
/*
       INSERT INTO MRPARM_DEMANTRA_FCST_LOAD_TEMP (sdate,level1,level2,level3,c_pred,record_type)
       (
          SELECT sdate,level1,level2,level3,c_pred,record_type
            FROM BIEO_FCST_EXPORT@DEMANTRA
           WHERE record_type = 2
             AND c_pred > 0
             AND sdate >= NVL(p_fcst_wk_start,sdate)
             AND sdate <= NVL(p_fcst_wk_end,sdate));
*/

       COMMIT;

   END MRPARM_GET_DEMANTRA_DATA;

/*----------------------------------------------------------------------------- */
/* Procedure to get customer Name from Customer Ship To
/*----------------------------------------------------------------------------- */
   PROCEDURE MRPARM_CUST_NM (
      p_cust_shipto  IN  VARCHAR2,
      p_debug_yes_no IN VARCHAR2,
      p_req_id       IN  NUMBER,
      p_cust_id      OUT NUMBER,
      p_cust_name    OUT VARCHAR2,
      p_orgn_id      OUT NUMBER,
      p_orgn_cd      OUT VARCHAR2
      )
   IS
   BEGIN

-- Customer Name Fetching based on Customer Ship To
      BEGIN
         SELECT hca.cust_account_id,hp.party_name,hcsua.warehouse_id
           INTO p_cust_id,p_cust_name, p_orgn_id
           FROM hz_parties hp, hz_cust_accounts hca,
                hz_cust_acct_sites_all hcasa, hz_cust_site_uses_all hcsua
          --WHERE hcsua.site_use_id = to_number(substr(p_cust_shipto,3))  -- Commented Rev 1.3
          WHERE hcsua.site_use_id = to_number(p_cust_shipto)  -- Added Rev 1.3
            AND hcsua.SITE_USE_CODE = 'SHIP_TO'
            AND hcasa.cust_acct_site_id = hcsua.cust_acct_site_id
            AND hca.cust_account_id = hcasa.cust_account_id
            AND hp.party_id = hca.party_id;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            IF p_debug_yes_no = 'Y' THEN
               write_log(' Error while fetching Party Name for Customer Ship To '||p_cust_shipto);
            END IF;
            p_cust_id := NULL;
            p_cust_name := NULL;
            p_orgn_id := NULL;

         WHEN OTHERS THEN
            IF p_debug_yes_no = 'Y' THEN
               write_log(' Error while fetching Party Name for Customer Ship To '||p_cust_shipto||' '||SQLERRM);
            END IF;
            p_cust_id := NULL;
            p_cust_name := NULL;
            p_orgn_id := NULL;
      END;

      IF p_orgn_id IS NOT NULL THEN

         BEGIN
            SELECT organization_code
              INTO p_orgn_cd
              FROM org_organization_definitions
             WHERE organization_id = p_orgn_id;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               IF p_debug_yes_no = 'Y' THEN
                  write_log(' Error while fetching Organization Code ');
               END IF;
               p_orgn_cd := NULL;
            WHEN OTHERS THEN
               IF p_debug_yes_no = 'Y' THEN
                  write_log(' Error while fetching Organization Code '||SQLERRM);
               END IF;
               p_orgn_cd := NULL;
         END;
      ELSE
-- Update the staging table about the error
         BEGIN
            UPDATE mrparm_demantra_fcst_load_temp
               SET processed_flag = 'N'
             WHERE level2 = p_cust_shipto
               AND request_id = p_req_id;
         EXCEPTION
            WHEN OTHERS THEN
              IF p_debug_yes_no = 'Y' THEN
                 write_log('Error while updating processed_flag in MRPARM_DEMANTRA_FCST_LOAD_TEMP -- '||SQLERRM);
              END IF;
         END;
      END IF;
   END MRPARM_CUST_NM;
  /*----------------------------------------------------------------------------- */
  /* Main Procedure for inserting data into MRP_FORECAST_INTERFACE
  /*----------------------------------------------------------------------------- */

   PROCEDURE MRPARM_DMTRA_FCST
   (
      errbuf               OUT VARCHAR2,
      retcode              OUT NUMBER,
      p_regn_code          IN  VARCHAR2, -- Added Rev 1.3
      p_organization_id    IN  NUMBER,
      p_org_code           IN  VARCHAR2,
      p_forecast_level     IN  VARCHAR2,
      p_cust               IN  NUMBER,-- Added as per Rev 1.1
      p_cust_ship_to       IN  NUMBER,-- Added as per Rev 1.1
      p_dest_fcst_set      IN  VARCHAR2,
      p_dest_fcst_nm       IN  VARCHAR2, -- Added as per Rev 1.1
      p_cat_set            IN  VARCHAR2, -- Added as per Rev 1.1
      p_cat_id             IN  NUMBER, -- Added as per Rev 1.1
      p_mfg_cal_code       IN  VARCHAR2,
      p_fcst_wk_start      IN  VARCHAR2,
      p_fcst_wk_end        IN  VARCHAR2,
      p_appr_fcst          IN  VARCHAR2, -- Added Rev 1.3
      p_spec_modl          IN  VARCHAR2, -- Added Rev 1.3
      p_model_excl         IN  VARCHAR2, -- Added Rev 1.3
      p_email_id           IN  VARCHAR2,
      p_bckt_type          IN  VARCHAR2,
      p_round_fcst_qty     IN  NUMBER, -- Added as per Rev 1.1
      p_conf_percentage    IN  NUMBER,
      p_debug_yes_no       IN  VARCHAR2
   )IS

      l_request_id     NUMBER;

      CURSOR c_stag_data IS
         SELECT * FROM mrparm_demantra_fcst_load_temp
         WHERE request_id = l_request_id;

      l_item              mtl_system_items_b.segment1%TYPE;
      l_cust_name         hz_parties.party_name%TYPE;
      l_cust_id           hz_parties.party_id%TYPE;
      l_orgn_id           org_organization_definitions.organization_id%TYPE;
      l_orgn_cd           org_organization_definitions.organization_code%TYPE;
      l_fcst_desig        mrp_forecast_designators.forecast_designator%TYPE;
      l_shipto_loc        hz_cust_site_uses_all.location%TYPE;
      l_cat_set_id        mtl_category_sets.category_set_id%TYPE; -- Added as per Rev 1.1
      l_max_creation_date mrp_forecasT_interface.creation_date%TYPE; -- Added as per Rev 1.1
      l_max_update_date   mrp_forecasT_interface.last_update_date%TYPE; -- Added as per Rev 1.1

      l_file_path      VARCHAR2 (100):='$APPLCSF/$APPLLOG';
      l_file_name      VARCHAR2 (100);

      l_cntr           NUMBER;
      l_item_cntr      NUMBER;
      l_reqid          NUMBER;


      l_min_dt         DATE;
      l_max_dt         DATE;
      l_start_date     DATE;
      l_end_date       DATE;
      l_reccnt         NUMBER;

   BEGIN


      write_log(' Parameters for this Program are ');
      write_log(' =============================== ');

      write_log(' Organization ID                          : '||p_organization_id);
      write_log(' Forecast Level                           : '||p_forecast_level);
      write_log(' Customer ID                              : '||p_cust); -- Added as per Rev 1.1
      write_log(' Customer Ship To                         : '||p_cust_ship_to); -- Added as per Rev 1.1
      write_log(' Destination Forecast Set                 : '||p_dest_fcst_set);
      write_log(' Destination Forecast Name                : '||p_dest_fcst_nm);  -- Added as per Rev 1.1
      write_log(' Category Set Name                        : '||p_cat_set);  -- Added as per Rev 1.1
      write_log(' Category ID                              : '||p_cat_id);  -- Added as per Rev 1.1
      write_log(' Forecast Week Start Date                 : '||p_fcst_wk_start);
      write_log(' Forecast Week End Date                   : '||p_fcst_wk_end);
      write_log(' Email Notification ID                    : '||p_email_id);
      write_log(' Bucket Type                              : '||p_bckt_type);
      write_log(' No of Digits to round Forecast Qty       : '||p_round_fcst_qty); -- Added as per Rev 1.1
      write_log(' Confidence Percentage                    : '||p_conf_percentage);
      write_log(' Debug (Y/N)                              : '||p_debug_yes_no);
      write_log(' ');
      write_log(' Source, Staging and Interface Tables ');
      write_log(' =================================== ');
      write_log(' Source Table (Synonym for Demantra Table)   - MRPARM_BIEO_FCST_EXPORT ');
      write_log(' Staging Table (Oracle)    - MRPARM_DEMANTRA_FCST_LOAD_TEMP ');
      write_log(' Interface Table (Oracle)  - MRP_FORECAST_INTERFACE ');
      -- Rev 1.3 Start
      write_log(' ');
      write_log(' ');
      write_log(' Processing Details');
      write_log(' '||' '||TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI')||' Start');
      -- Rev 1.3 End

      DELETE FROM mrparm_forecast_interface_temp;

      COMMIT;

-- Find Start and End Dates based on the input parameters

      SELECT TO_DATE(p_fcst_wk_start,'YYYY/MM/DD HH24:MI:SS'), TO_DATE(p_fcst_wk_end,'YYYY/MM/DD HH24:MI:SS')
        INTO l_start_date, l_end_date
        FROM dual;


-- select the category set id corresponding to the input category set
      IF p_cat_set IS NOT NULL THEN
         SELECT category_set_id
           into l_cat_set_id
           from mtl_category_sets
          where category_set_name = p_cat_set;
      END IF;
      -- Find out the request id
      l_request_id := fnd_global.conc_request_id;


      --write_log(' l_start_date '||l_start_date);
      --write_log(' l_end_date '||l_end_date);
-- Get Demantra Table data and store it in a staging table in Oracle

--      MRPARM_GET_DEMANTRA_DATA(l_start_date,l_end_date); -- commented as per Rev 1.1
-- added as per Rev 1.1
      MRPARM_GET_DEMANTRA_DATA(l_start_date,l_end_date,p_regn_code,p_organization_id,l_cat_set_id,
                       p_cat_id,p_cust,p_cust_ship_to,p_forecast_level,p_dest_fcst_set,
                       p_dest_fcst_nm,p_debug_yes_no,p_round_fcst_qty,p_appr_fcst,p_model_excl,p_spec_modl);
      -- Rev 1.3 Start
      BEGIN
         SELECT count(*) INTO l_reccnt
         FROM   MRPARM_DEMANTRA_FCST_LOAD_TEMP
         WHERE  request_id = l_request_id;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            l_reccnt := 0;
      END;

      write_log(' '||' '||TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI')||' Get Demantra data to the oracle temp Table (MRPARM_DEMANTRA_FCST_LOAD_TEMP) : '||l_reccnt||' Records');

      -- Rev 1.3 End

--      write_log(' Demantra data loaded into ORacle Staging TAble');


      IF p_debug_yes_no = 'Y' THEN
         write_log(' ');
         write_log(' =============================================================================================== ');
         write_log(' Customer                        Ship To                               Start Date     End Date   ');
         write_log(' =============================================================================================== ');

         FOR l_stag_cust_ship_to IN (SELECT DISTINCT level2
                                       FROM MRPARM_DEMANTRA_FCST_LOAD_TEMP
                                       WHERE request_id = l_request_id)
         LOOP
            l_cust_name := NULL;
            l_cust_id := NULL;

            MRPARM_CUST_NM(l_stag_cust_ship_to.level2,p_debug_yes_no,l_request_id,l_cust_id,l_cust_name,l_orgn_id,l_orgn_cd);

            IF l_cust_id IS NOT NULL THEN
-- Select Min and Max dates for customer / ship to to show in the log
               SELECT MIN(sdate), MAX(sdate)
                 INTO l_min_dt,l_max_dt
                 FROM MRPARM_DEMANTRA_FCST_LOAD_TEMP
                WHERE level2 = l_stag_cust_ship_to.level2
                AND   request_id = l_request_id;

               BEGIN
                  SELECT location
                    INTO l_shipto_loc
                    FROM hz_cust_site_uses_all
                   --WHERE site_use_id = substr(l_stag_cust_ship_to.level2,3); -- Commented Rev 1.3
                   WHERE site_use_id = l_stag_cust_ship_to.level2; -- Added Rev 1.3
               EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                     l_shipto_loc := NULL;
                  WHEN OTHERS THEN
                     l_shipto_loc := NULL;
               END;
               IF p_debug_yes_no = 'Y' THEN
                  write_log(' '||RPAD(l_cust_name,33,' ')||'  '||RPAD(l_shipto_loc,33,' ')||'  '||l_min_dt||'      '||l_max_dt);
               END IF;
            ELSE
 -- Update the staging table about the error
               UPDATE mrparm_demantra_fcst_load_temp
                  SET processed_flag = 'N'
                WHERE level2 = l_stag_cust_ship_to.level2
                AND   request_id = l_request_id;
            END IF;
         END LOOP;

         write_log(' =============================================================================================== ');
         write_log(' ');
      END IF;

-- Take the staging table data and start processing

      l_cntr := 0;

      SELECT COUNT(*)
        INTO l_item_cntr
        FROM MRPARM_DEMANTRA_FCST_LOAD_TEMP
       WHERE PROCESSED_FLAG IS NULL
         AND request_id = l_request_id
         AND NOT EXISTS (SELECT inventory_item_id from mtl_system_items_b
                           WHERE organization_id = (SELECT organization_id
                                                      FROM org_organization_definitions
                                                     WHERE organization_code = 'GLO'));
      IF l_item_cntr <> 0 THEN
         write_log(' Some of the Items are Invalid ');
      END IF;

      write_log(' Processing the staging data from Table MRPARM_DEMANTRA_FCST_LOAD_TEMP ');

      FOR l_stag_data IN (SELECT level1,level2,c_pred,sdate
                            FROM MRPARM_DEMANTRA_FCST_LOAD_TEMP
                           WHERE processed_flag IS NULL
                             AND level3 = p_organization_id
                             AND request_id = l_request_id)
      LOOP

-- Get customer Name and Organization ID based on Customer Ship To
         l_cust_name := NULL;
         l_cust_id   := NULL;
         l_orgn_cd   := NULL;
         l_orgn_id   := NULL;

         --fnd_file.put_line(fnd_file.LOG,'l_stag_data.level2 '||l_stag_data.level2);

         MRPARM_CUST_NM(l_stag_data.level2,p_debug_yes_no,l_request_id,l_cust_id,l_cust_name,l_orgn_id,l_orgn_cd);

         --write_log('          l_cust_name '||l_cust_name);

         IF L_ORGN_ID IS NOT NULL THEN

-- Select forecast designator based on the forecast level parameter

            IF p_forecast_level = 'Item' THEN
               IF p_dest_fcst_nm IS NOT NULL THEN
                  l_fcst_desig := p_dest_fcst_nm;
               ELSE
                  BEGIN
                     SELECT forecast_designator
                       INTO l_fcst_desig
                       FROM mrp_forecast_designators
                      WHERE organization_id = l_orgn_id
                        AND forecast_set = p_dest_fcst_set
                        AND rownum = 1;
                  EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        IF p_debug_yes_no = 'Y' THEN
                           write_log(' Item --> Forecast Designator cannot be selected for the organization: '||l_orgn_id ||
                                     ' Forecast set '||p_dest_fcst_set||
                                     ' Customer '||mrp_manager_pk.get_customer_name(l_cust_id)||
                                     ' Ship To '||mrp_manager_pk.get_ship_address(l_stag_data.level2));
                        END IF;
                        l_fcst_desig := NULL;
                     WHEN OTHERS THEN
                        IF p_debug_yes_no = 'Y' THEN
                           write_log(' Item --> Error in selecting Forecast Designator '||SQLERRM);
                        END IF;
                        l_fcst_desig := NULL;
                  END;
               END IF;
            ELSIF p_forecast_level = 'Ship To' THEN
               IF p_dest_fcst_nm IS NOT NULL THEN
                  l_fcst_desig := p_dest_fcst_nm;
               ELSE
                  BEGIN
                     SELECT forecast_designator
                       INTO l_fcst_desig
                       FROM mrp_forecast_designators
                      WHERE organization_id = l_orgn_id
                        AND forecast_set = p_dest_fcst_set
                        AND customer_id = l_cust_id
                        --AND ship_id = substr(l_stag_data.level2,3);
                        AND ship_id = l_stag_data.level2;
                  EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        IF p_debug_yes_no = 'Y' THEN
                           write_log(' Ship To --> Forecast Designator cannot be selected for the organization: '||l_orgn_id ||
                                     ' Forecast set '||p_dest_fcst_set||
                                     ' Customer '||mrp_manager_pk.get_customer_name(l_cust_id)||
                                     ' Ship To '||mrp_manager_pk.get_ship_address(l_stag_data.level2));
                        END IF;
                        l_fcst_desig := NULL;
                     WHEN OTHERS THEN
                        IF p_debug_yes_no = 'Y' THEN
                           write_log(' Ship To --> Error in selecting Forecast Designator '||SQLERRM);
                        END IF;
                        l_fcst_desig := NULL;
                  END;
               END IF;
-- <Start Rev 1.1>
            ELSIF p_forecast_level = 'Customer' THEN
               IF p_dest_fcst_nm IS NOT NULL THEN
                  l_fcst_desig := p_dest_fcst_nm;
               ELSE
                  BEGIN
                     SELECT forecast_designator
                       INTO l_fcst_desig
                       FROM mrp_forecast_designators
                      WHERE organization_id = l_orgn_id
                        AND forecast_set = p_dest_fcst_set
                        AND customer_id = l_cust_id
--                        AND ship_id = substr(l_stag_data.level2,3)
                        and rownum = 1;
                  EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        IF p_debug_yes_no = 'Y' THEN
                           write_log(' Customer --> Forecast Designator cannot be selected for the organization: '||l_orgn_id ||
                                     ' Forecast set '||p_dest_fcst_set||
                                     ' Customer '||mrp_manager_pk.get_customer_name(l_cust_id)||
                                     ' Ship To '||mrp_manager_pk.get_ship_address(l_stag_data.level2));
                        END IF;
                        l_fcst_desig := NULL;
                     WHEN OTHERS THEN
                        IF p_debug_yes_no = 'Y' THEN
                           write_log(' Customer --> Error in selecting Forecast Designator '||SQLERRM);
                        END IF;
                        l_fcst_desig := NULL;
                  END;
               END IF;
-- <End Rev 1.1>
            END IF;

            --write_log('l_fcst_desig '||l_fcst_desig);

-- Insert into the MRP_FORECAST_INTERFACE Table

            IF l_fcst_desig IS NOT NULL THEN

               --write_log('quantity '||l_stag_data.c_pred||' rounded quantity '||round(l_stag_data.c_pred,p_round_fcst_qty));

               INSERT INTO mrparm_forecast_interface_temp (inventory_item_id,forecast_designator, organization_id,
                  forecast_date,last_update_date,last_updated_by,creation_date,created_by,last_update_login,
                  quantity,process_status,confidence_percentage,bucket_type,workday_control) VALUES
                  (l_stag_data.level1,l_fcst_desig,p_organization_id,l_stag_data.sdate,SYSDATE,
                  fnd_global.user_id,SYSDATE,fnd_global.user_id,fnd_global.login_id,
                  round(l_stag_data.c_pred,p_round_fcst_qty),2,p_conf_percentage,
                  DECODE(p_bckt_type,'Monthly',3,'Weekly',2),2);

               l_cntr := l_cntr + 1;

            ELSE
                UPDATE mrparm_demantra_fcst_load_temp
                   SET processed_flag = 'N'
                 WHERE level2 = l_stag_data.level2
                 AND   request_id = l_request_id;

            END IF;

         END IF;

      END LOOP;

      -- Rev 1.3 Start
      BEGIN
         SELECT COUNT(*)
         INTO   l_reccnt
         FROM   mrparm_forecast_interface_temp;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            l_reccnt := 0;
      END;

      write_log(' '||' '||TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI')||'Process and transfer data to the pre-interface table'||
                'MRPARM_FORECAST_INTERFACE_TEMP : '||l_reccnt||' Records');

      -- Rev 1.3 End
      --write_log(' l_cntr '||l_cntr);



      IF p_forecast_level = 'Item' THEN

/*         SELECT COUNT(inventory_item_id)
           INTO l_cntr
           FROM mrparm_forecast_interface_temp
       GROUP BY inventory_item_id,forecast_designator, organization_id,
                forecast_date,last_update_date,last_updated_by,creation_date,created_by,last_update_login,
                process_status,confidence_percentage,bucket_type,workday_control;*/
         l_cntr := 0;
         FOR i_cntr IN (SELECT inventory_item_id,forecast_designator, organization_id,
                  forecast_date,sum(quantity) sum_qty,process_status,confidence_percentage,bucket_type,workday_control,
                  created_by,last_updated_by,last_update_login
               FROM mrparm_forecast_interface_temp
           GROUP BY inventory_item_id,forecast_designator, organization_id,
                  forecast_date,process_status,confidence_percentage,bucket_type,workday_control,
                  created_by,last_updated_by,last_update_login)
         LOOP
            SELECT MAX(creation_date) ,MAX(last_update_date)
              INTO l_max_creation_date,l_max_update_date
              FROM mrparm_forecast_interface_temp
             WHERE forecast_designator = i_cntr.forecast_designator
               AND inventory_item_id = i_cntr.inventory_item_id
          GROUP BY forecast_designator,inventory_item_id;

            INSERT INTO mrp_forecast_interface(inventory_item_id,forecast_designator, organization_id,
                     forecast_date,quantity,process_status,confidence_percentage,bucket_type,workday_control,
                     created_by,last_updated_by,last_update_login,creation_date,last_update_date)
               VALUES (i_cntr.inventory_item_id,i_cntr.forecast_designator,i_cntr.organization_id,
                    i_cntr.forecast_date,i_cntr.sum_qty,i_cntr.process_status,i_cntr.confidence_percentage,
                    i_cntr.bucket_type,i_cntr.workday_control,i_cntr.created_by,i_cntr.last_updated_by,
                    i_cntr.last_update_login,l_max_creation_date,l_max_update_date);
            l_cntr := l_cntr + 1;
         END LOOP;
      ELSE
            INSERT INTO mrp_forecast_interface(inventory_item_id,forecast_designator, organization_id,
                   forecast_date,last_update_date,last_updated_by,creation_date,created_by,last_update_login,
                  quantity,process_status,confidence_percentage,bucket_type,workday_control)
            (SELECT inventory_item_id,forecast_designator, organization_id,
                  forecast_date,last_update_date,last_updated_by,creation_date,created_by,last_update_login,
                  quantity,process_status,confidence_percentage,bucket_type,workday_control
               FROM mrparm_forecast_interface_temp);
      END IF;

      -- Rev 1.3 Start
      BEGIN
         SELECT COUNT(*)
         INTO   l_reccnt
         FROM   mrparm_forecast_interface_temp;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            l_reccnt := 0;
      END;

      write_log(' '||' '||TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI')||' Inserted data into Interface Table MRP_FORECAST_INTERFACE : '||
                            l_reccnt||' Records');
      -- Rev 1.3 End
      --write_log(' Total No of Records inserted into MRP_FORECAST_INTERFACE '||l_cntr);


-- Find the file name based on the request id
      l_file_name := 'l'||l_request_id||'.req';

-- Calling a routing to email to log file.
      l_reqid := FND_REQUEST.SUBMIT_REQUEST('FNDARM','FNDARM_NOTIFICATION',NULL,NULL,FALSE,
                                            p_email_id, NULL, 'ARM Demantra Forecast Upload to Oracle'  ,
                                            'This email contains the log file of the above request for your reference',
                                            NULL,l_file_path ,l_file_name, l_file_name,
                                            CHR(0));

      IF l_reqid <> 0 THEN
         write_log(' Concurrent Program succesfully submitted. Request Id:'||l_reqid);
         COMMIT;
      ELSE
         write_log(' Error submitting concurrent program FNDARM_NOTIFICATION in procedure submit_mail_request');
      END IF;

      -- Rev 1.3 Start
      write_log(' '||TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI')||' End ');
      -- Rev 1.3 End

   END MRPARM_DMTRA_FCST;

END MRPARM_DMTRA_FCST_UPLOAD;
/