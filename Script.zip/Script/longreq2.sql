select 	request_id,s.sid sid,user_concurrent_program_name ucname,to_char(logon_time,'dd/mm hh24:mi') dt,s.module module,s.action action,user_name uname,sw.event
from	v$session_wait sw,v$session s,v$process p,fnd_concurrent_requests fnd,fnd_user fndu,fnd_concurrent_programs_vl fndc
where 	sw.sid = s.sid
and	p.addr = s.paddr
and     fndc.concurrent_program_id = fnd.concurrent_program_id
and	p.spid = fnd.oracle_process_id
and     fnd.requested_by = fndu.user_id
and	fnd.status_code = 'R'
and	fnd.phase_code = 'R'
order by 1
/
