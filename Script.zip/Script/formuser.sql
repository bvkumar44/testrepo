set pages 500
set lines 100
col sid for 99999
col user_name for a10 trunc
col serial for 99999 
col action for a10 trunc

select b.sid sid,b.serial# serial,b.action action,d.user_name nam
from apps.fnd_logins a, 
v$session b, v$process c, apps.fnd_user d
where b.paddr = c.addr
and a.pid=c.pid
and a.spid = b.process
and d.user_id = a.user_id
AND d.user_name = 'JAGADES'
/
