-- All Processed label requests

set pages 300
set lines 250
--col request_id for a12
col status_code for a12
col device_name for a18
col last_update_date for a30
col error_message for a70

SELECT cs.request_id
,      cs.status_code
,      cd.device_name
,      cs.last_update_date
,      cs.error_message
FROM   clr.con_service_requests_hs cs
,      clr.con_devices cd
WHERE cs.argument2 = cd.device_id
AND cs.argument3 = 'Label'
AND cs.creation_date > sysdate - 1/24
UNION
-- Running or Pending label requests
SELECT cs.request_id
,      cs.status_code
,      cd.device_name
,      cs.last_update_date
,      cs.error_message
FROM   clr.con_service_requests cs
,      clr.con_devices cd
WHERE cs.argument2 = cd.device_id
AND cs.argument3 = 'Label'
AND cs.creation_date > sysdate - 1/24
ORDER BY request_id desc
/
